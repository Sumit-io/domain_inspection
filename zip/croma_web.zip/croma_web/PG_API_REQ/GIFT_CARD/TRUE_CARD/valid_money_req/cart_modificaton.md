[real_value= card_number:1001340048054924  card_pin:264506]

General:
Request URL
https://api.croma.com/useraccount/allchannels/v2/users/ae6d0072ad99f3abbe4092d68388c6ae/carts/263955792897/cart-modification?forceRecalculate=true&fields=FULL&pincode=804453&refreshCart=false
Request Method
POST
Status Code
200 OK
Remote Address
23.212.0.117:443
Referrer Policy
strict-origin-when-cross-origin


Payload:
{"toBeAppliedPromoIdList":["01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116617"],"cromaPaymentRequestWsDTOList":[{"promoCode":"","paymentMode":"","provider":"","paymentType":"","paymentSubType":"","paidAmount":1128,"emiType":"","emiTenurePeriodInMonths":0}],"gvRequest":"OoooXTjyQ8CcLpBBWHOJjEw2jhsJn7rSPpYq+4vat75mjdYl57mIXcHP+L38+opisjzoUemxOHumH38mpU5DQtgYGflQvFyX9mMnVxhzOTn0gNL3w9U6E8vhrf/+pJDOg6FEeu0efX0gIsAgk4Qh/+XTTO6N/7fcIBvuVJ6jRiqtdVE2HJ1hdFQHglwRS7SiRzpUqkILDJyZRyx9FSMfn8RBBSBfwPTXa5GLOQNoL7nXilZNE7f4P2WNGfV/DLxCYP8vsP3gPQO1tmwjefHw8SKM8aDGeRwlj5pTVU1XTNBGgRynDTZ4Ai6gGmnbmWxF5jAamCZf8po96mn7l8g/NyfHqoFhQ5L13/GJKaYGwYEv9jHDaEIcrPByyNh9SCh0","giftCardAmount":101,"loyaltyPoints":"U7IYm97SkT8//UyUL6drcQ=="}

response:


{
    "code": "263955792897",
    "net": false,
    "totalPriceWithTax": {
        "currencyIso": "INR",
        "value": 1128.00,
        "priceType": "BUY",
        "formattedValue": "₹1,128.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "totalPrice": {
        "currencyIso": "INR",
        "value": 1128.00,
        "priceType": "BUY",
        "formattedValue": "₹1,128.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "totalTax": {
        "currencyIso": "INR",
        "value": 0.00,
        "priceType": "BUY",
        "formattedValue": "₹0.0",
        "minQuantity": null,
        "maxQuantity": null
    },
    "subTotal": {
        "currencyIso": "INR",
        "value": 1199.00,
        "priceType": "BUY",
        "formattedValue": "₹1,199.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "deliveryCost": {
        "currencyIso": "INR",
        "value": 29.00,
        "priceType": "BUY",
        "formattedValue": "₹29.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "entries": [
        {
            "entryNumber": 0,
            "quantity": 1,
            "basePrice": {
                "currencyIso": "INR",
                "value": 1199.00,
                "priceType": "BUY",
                "formattedValue": "₹1,199.00",
                "minQuantity": null,
                "maxQuantity": null
            },
            "totalPrice": {
                "currencyIso": "INR",
                "value": 1199.00,
                "priceType": "BUY",
                "formattedValue": "₹1,199.00",
                "minQuantity": null,
                "maxQuantity": null
            },
            "product": {
                "code": "316576",
                "name": "realme Buds Wireless 5 Lite Neckband with Environmental Noise Cancellation (IP55 Dust & Water Resistant, Dual Device Connection, Haze Blue)",
                "url": "/realme-buds-wireless-5-lite-neckband-with-environmental-noise-cancellation-ip55-dust-water-resistant-dual-device-connection-haze-blue-/p/316576",
                "price": {
                    "currencyIso": "INR",
                    "value": 1199.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,199.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "images": [
                    {
                        "imageType": "PRIMARY",
                        "format": "700Wx700H",
                        "url": "https://media.tatacroma.com/Croma%20Assets/Entertainment/Headphones%20and%20Earphones/Images/316576_0_hseadg.png",
                        "altText": "realme Buds Wireless 5 Lite Neckband with Environmental Noise Cancellation (IP55 Dust & Water Resistant, Dual Device Connection, Haze Blue)",
                        "galleryIndex": null
                    }
                ],
                "mrp": {
                    "currencyIso": "INR",
                    "value": 1999.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,999.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "homeDeliveryPincodeAvailability": false,
                "storePickPincodeAvailability": false,
                "expressShippingPincodeAvailability": false,
                "discount": 0.0,
                "pdpBreadcrumbs": [
                    {
                        "url": "/realme-buds-wireless-5-lite-neckband-with-environmental-noise-cancellation-ip55-dust-water-resistant-dual-device-connection-haze-blue-/p/316576",
                        "name": "realme Buds Wireless 5 Lite Neckband with Environmental Noise Cancellation (IP55 Dust & Water Resistant, Dual Device Connection, Haze Blue)",
                        "linkClass": null,
                        "categoryCode": null
                    }
                ],
                "categoryL0": "292",
                "categoryL1": "1012",
                "categoryL2": "1013",
                "finalReviewRating": 0.0,
                "demoFlag": false,
                "applianceType": "SA",
                "wiiFlag": false,
                "manufacturerAID": "b-1090",
                "classCode": "0631",
                "specialSKU": false,
                "manufacturerName": "Realme",
                "immediateSuperCategory": "Bluetooth Earphones",
                "immediateSuperCategoryName": "Bluetooth Earphones",
                "isEmiApplicable": "false",
                "savedAmount": 800.0,
                "installationFlag": "",
                "demo": "",
                "modelNumber": "RMA2416",
                "isGiftCard": false,
                "isDigital": false,
                "sdelCharge": {
                    "currencyIso": "INR",
                    "value": 0.0,
                    "priceType": "BUY",
                    "formattedValue": "₹0.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "hdelCharge": {
                    "currencyIso": "INR",
                    "value": 29.0,
                    "priceType": "BUY",
                    "formattedValue": "₹29.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "addedFromGoogle": false,
                "cscproduct": false,
                "podavailable": false,
                "SAP_MATERIAL_TYPE": "ZPLU",
                "SAP_BOM_DESC": "",
                "SAP_CATEGORY_CODE": "0631",
                "SAP_CATEGORY_NAME": "Neckbands"
            },
            "updateable": false,
            "deliveryMode": {
                "code": "cromaHomeDelivery",
                "name": "Home Delivery",
                "description": "1-2 business days",
                "deliveryCost": null
            },
            "discountPrice": {
                "currencyIso": "INR",
                "value": 0.00,
                "priceType": "BUY",
                "formattedValue": "₹0.00",
                "minQuantity": null,
                "maxQuantity": null
            },
            "totalPriceWithoutDiscount": {
                "currencyIso": "INR",
                "value": 1199.00,
                "priceType": "BUY",
                "formattedValue": "₹1,199.00",
                "minQuantity": null,
                "maxQuantity": null
            },
            "cartEntryRewardsData": [
                {
                    "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116617",
                    "promotionTypeId": 9999,
                    "promotionType": "MULTIBUYGROUP",
                    "operatorDisplayText": "Buy & Get Rs.100 off (Discount auto applied in cart)",
                    "customerDisplayText": "Buy & Get Rs.100 off (Discount auto applied in cart)",
                    "receiptPrintText": "null",
                    "benefitType": "INSTANT",
                    "thresholdTypeCode": "ITEM_QUANTITY",
                    "promotionRewardIdentifier": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116617-0",
                    "allUnitItemRewardData": [
                        {
                            "unitRewardIndex": 1,
                            "rewardType": "AMOUNT_OFF",
                            "rewardValue": 100.0,
                            "loyaltyPoints": 0,
                            "emiValue": 0.0
                        }
                    ]
                }
            ],
            "omsEddDate": "2026-02-13",
            "homeDeliveryFlag": true,
            "pickupDeliveryFlag": false,
            "expressDeliveryFlag": false,
            "greyOutFlag": false,
            "cartEntryQunatityRespectivePriceData": {
                "mrp": {
                    "currencyIso": "INR",
                    "value": 1999.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,999.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "actual": {
                    "currencyIso": "INR",
                    "value": 1199.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,199.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "strikeThroughPrice": {
                    "currencyIso": "INR",
                    "value": 1199.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,199.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "displayPrice": {
                    "currencyIso": "INR",
                    "value": 1099.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,099.00",
                    "minQuantity": null,
                    "maxQuantity": null
                },
                "oediscounted": {
                    "currencyIso": "INR",
                    "value": 1099.00,
                    "priceType": "BUY",
                    "formattedValue": "₹1,099.00",
                    "minQuantity": null,
                    "maxQuantity": null
                }
            },
            "isOnlyReward": false,
            "isFreebieProduct": false,
            "isMTMBApplied": false,
            "vasProduct": false,
            "vasUpgrade": false,
            "brandId": "1090",
            "approvalStatus": "approved",
            "isExchangeProductBonusExpired": false
        }
    ],
    "totalItems": 1,
    "deliveryAddress": {
        "id": null,
        "title": null,
        "titleCode": null,
        "firstName": "Sumit Kumar ",
        "lastName": "",
        "companyName": null,
        "line1": "Gayatri Nagar Kurthoul Patna ",
        "line2": "Kurthoul, Patna, Nathupur",
        "town": "",
        "region": null,
        "postalCode": "804453",
        "phone": "9508862996",
        "email": "sumit24037@gmail.com",
        "country": {
            "isocode": "IN",
            "name": "India"
        },
        "shippingAddress": true,
        "defaultAddress": false,
        "visibleInAddressBook": false,
        "formattedAddress": "Gayatri Nagar Kurthoul Patna , Kurthoul, Patna, Nathupur, 804453",
        "state": {
            "code": "BIHAR",
            "name": "BIHAR"
        },
        "city": {
            "code": "MASHAURHI",
            "name": "MASHAURHI"
        },
        "billingAddress": false,
        "gstNumber": null,
        "dty": null,
        "addressGender": null,
        "company": null,
        "latitude": null,
        "longitude": null,
        "house": "Choti Hanuman Mandir ",
        "addressType": "home",
        "nickName": "Gayatri Nagar Kurthoul Patna "
    },
    "productDiscounts": {
        "currencyIso": "INR",
        "value": 0.00,
        "priceType": "BUY",
        "formattedValue": "₹0.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "orderDiscounts": {
        "currencyIso": "INR",
        "value": 100.00,
        "priceType": "BUY",
        "formattedValue": "₹100.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "totalDiscounts": {
        "currencyIso": "INR",
        "value": 100.00,
        "priceType": "BUY",
        "formattedValue": "₹100.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "site": "croma_retail_shop",
    "store": "croma_retail_store",
    "guid": "AN_CR-20958114759f4251bed2074553a8937243e3d03c283233371341160554641236",
    "calculated": true,
    "allOfferSavingsData": [
        {
            "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116617",
            "promotionType": "MULTIBUYGROUP",
            "promotionSavings": "100.0",
            "orderAppliedSequenceNumber": "1",
            "operatorDisplayText": "Buy & Get Rs.100 off (Discount auto applied in cart)",
            "customerDisplayText": "Buy & Get Rs.100 off (Discount auto applied in cart)",
            "receiptPrintText": "null",
            "numberOfTimesPromotionApplied": 1,
            "customerActivatedPromotion": false,
            "programId": "01eae2ec-0576-1000-bbea-86e16dcb4b79",
            "benefitType": "INSTANT",
            "allCouponData": null
        }
    ],
    "allSuggestedOffers": {
        "itemLevelOffers": null,
        "transactionLevelOffers": null,
        "tenderItemLevelOffers": [
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116758",
                "promotionTitle": "Rs.2500 Instant discount on HSBC Credit Card on Product Value above Rs 50,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "promotionDescription": "Rs.2500 Instant discount on HSBC Credit Card on Product Value above Rs 50,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116799",
                "promotionTitle": "5% Upto Rs 2000 Instant discount on FEDERAL Bank Credit Card on Product Value above Rs 10,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "promotionDescription": "5% Upto Rs 2000 Instant discount on FEDERAL Bank Credit Card on Product Value above Rs 10,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA109338",
                "promotionTitle": "Get assured ₹40 Cashback (up to ₹500) on transaction value above Rs.1,999 via MobiKwik UPI only (@ikwik/@mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.",
                "promotionDescription": "Get assured ₹40 Cashback (up to ₹500) on transaction value above Rs.1,999 via MobiKwik UPI only (@ikwik/@mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA109339",
                "promotionTitle": "Get assured ₹150 Cashback (up to 10%) on transaction value above Rs.9,999 via MobiKwik UPI only (@ikwik / @mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.\n",
                "promotionDescription": "Get assured ₹150 Cashback (up to 10%) on transaction value above Rs.9,999 via MobiKwik UPI only (@ikwik / @mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.\n",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116756",
                "promotionTitle": "Rs.1800 Instant discount on HSBC Credit Card on Product Value above Rs 30,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "promotionDescription": "Rs.1800 Instant discount on HSBC Credit Card on Product Value above Rs 30,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116761",
                "promotionTitle": "Rs.3500 Instant discount on HSBC Credit Card on Product Value above Rs 75,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "promotionDescription": "Rs.3500 Instant discount on HSBC Credit Card on Product Value above Rs 75,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA116763",
                "promotionTitle": "Rs.6000 Instant discount on HSBC Credit Card on Product Value above Rs 100,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "promotionDescription": "Rs.6000 Instant discount on HSBC Credit Card on Product Value above Rs 100,000/-.Select offer under view all offer segment on payment page to avail the benefit.T&C Apply.",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            },
            {
                "promotionId": "01eae2ec-0576-1000-bbea-86e16dcb4b79:CROMA109340",
                "promotionTitle": "Get assured ₹300 Cashback (up to 20%) on transaction value above Rs.19,999 via MobiKwik UPI only (@ikwik / @mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.\n",
                "promotionDescription": "Get assured ₹300 Cashback (up to 20%) on transaction value above Rs.19,999 via MobiKwik UPI only (@ikwik / @mbkns). Select offer under view all offer segment on payment page to avail the benefit. T&C Apply.\n",
                "allowOverlap": false,
                "displayCoupons": null,
                "couponIdList": null
            }
        ],
        "tenderTransactionLevelOffers": null
    },
    "giftWrapNotApplicable": false,
    "proceedToCheckOut": false,
    "cromaCustomerAppliedCouponDataList": [],
    "extendedWarrantyProductExchanged": false,
    "discountWithoutCoupon": "100",
    "cartDeliveryThreshold": 240000.0,
    "isWaived": false,
    "totalUnitCount": 1,
    "hasExchangeProduct": false,
    "gvResponseDetailsWsDto": {
        "gvDetails": [
            {
                "cardNo": "1001340048054924",
                "cardPin": "264506",
                "cardBal": 101.0,
                "cardType": "QC-EGC-CROMA-VAR",
                "respMsg": "Your applied card is 1001340048054924. Amount deducted from your card :101.0",
                "paymentStatus": null,
                "valid": true
            }
        ],
        "customErrorMsg": null,
        "cardSpecificErrorMsg": null,
        "balAmountPayable": 1027.0,
        "gvRequest": null
    },
    "totalPriceWithTaxAndGv": {
        "currencyIso": "INR",
        "value": 1027.00,
        "priceType": "BUY",
        "formattedValue": "₹1,027.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "actualDeliveryCost": 29.0,
    "newCoinsApplied": {
        "currencyIso": "INR",
        "value": 0.00,
        "priceType": "BUY",
        "formattedValue": "₹0.00",
        "minQuantity": null,
        "maxQuantity": null
    },
    "loyaltypointsApplied": false
}

Request_headers:
:authority
api.croma.com
:method
POST
:path
/useraccount/allchannels/v2/users/ae6d0072ad99f3abbe4092d68388c6ae/carts/263955792897/cart-modification?forceRecalculate=true&fields=FULL&pincode=804453&refreshCart=false
:scheme
https
accept
application/json, text/plain, */*
accept-encoding
gzip, deflate, br, zstd
accept-language
en-US,en;q=0.9
accesstoken
5dc3a15a-879e-4665-9cf1-ea2ba42bb480
client_id
CROMA-WEB-APP
content-length
719
content-type
application/json
csc_code
null
customerhash
ae6d0072ad99f3abbe4092d68388c6ae
incallreqheader
p65mdWJpdmqDnXp09a8bNAVIuJEHP3OLlOZvzQvU1vGrVzuMZ6oW4UBPhTuaK7w4uly2Yrja30ASHDtsV3rTzKidJ5n0jQK7rSU27pH3MDhA/kS0GwFvVJq5m3s72XudnWv2XYS/FhlpbHtxWa0jrR5nPB+j9GqbCBow0jpNmurrwbkEu0TIH3d5NdvBNhE/i6hzNkxbRBjYbpW3q4mgWgHZb8zm9u+PIW8Q1NlTBjuqzuohlA6t0r3mwCLArapO/EOwCuwUedi4mK+RNu9vD1ZEOLR6KdS++RjDx5zerGAC5mXN5RrFbHXchOnbcxeyN12k+/N4GBpdd4EkhZ4BZQ==
ispaymentpage
true
origin
https://www.croma.com
priority
u=1, i
referer
https://www.croma.com/
sec-ch-ua
"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"
sec-ch-ua-mobile
?0
sec-ch-ua-platform
"Windows"
sec-fetch-dest
empty
sec-fetch-mode
cors
sec-fetch-site
same-site
source
null
user-agent
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36
usersource
null

Response_headers:

access-control-allow-credentials
true
access-control-allow-origin
https://www.croma.com
access-control-expose-headers
Transfer-Encoding,Connection,Request-Context,Vary,X-XSS-Protection,Content-Security-Policy,Referrer-Policy,Date,accessToken,SSOstatus,client_id,customerHash
accesstoken
5dc3a15a-879e-4665-9cf1-ea2ba42bb480
akamai-cache-status
NotCacheable from child
akamai-grn
0.2c1cc517.1770559131.2f38d61a
cache-control
no-cache, no-store, max-age=0, must-revalidate
client_id
CROMA-WEB-APP
content-encoding
gzip
content-length
2889
content-security-policy
script-src 'nonce-874adc3bcfe0d001ae16aa9f34b6bcf6' 'self'
content-type
application/json
customerhash
ae6d0072ad99f3abbe4092d68388c6ae
date
Sun, 08 Feb 2026 13:58:52 GMT
expires
0
pragma
no-cache
referrer-policy
same-origin
request-context
appId=cid-v1:8a027b7f-7450-437d-9b4c-a47116067af5
server-timing
cdn-cache; desc=MISS
server-timing
edge; dur=11
server-timing
origin; dur=144
server-timing
ak_p; desc="1770559131929_398793772_792253978_15485_6504_873_0_219";dur=1
set-cookie
bm_sz=C7BF77C5D47F4961A81B170FE5D218AD~YAAQLBzFFzhJBg+cAQAAu1GMPR71kWIRvR8AH3jQsSQPg/ZnksprjZjvNoMQjtcchSTQWUkVmY26U4k/uMj/VRbL9cTTWNke4LL3ueaWv9k5Vgix3ZIAqBSvEQ2UnHZ6v2tKORaNle9jkNiWlfq1k6FcK2f7rzZK8q7Jc3he4yLT6fFEKXSh+iyyKUY/T/ohqiBtzqfRu9QE8uEBigrG+7tYakv5TcQD+VPC2txmeCy6XFqKDQAY5eWubLeWXqX8Eons0/yDdU9axg3o2DwjrXY5pvGfMAH09DlOpJOHQ/LgYB8Nxzlghm1qLooeOqrvlID1wdH9btxp1/f2gY7vHDY/e11B2Ug0HTj24ZSFM+09Keiv~3163206~3687735; Domain=.croma.com; Path=/; Expires=Sun, 08 Feb 2026 17:58:51 GMT; Max-Age=14399
ssostatus
active
strict-transport-security
max-age=16070400; includeSubDomains
vary
Accept-Encoding
x-content-type-options
nosniff
x-frame-options
SAMEORIGIN
x-xss-protection
1; mode=block


Initiator

(anonymous)	@	tdl-sso-auth.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
Promise.then		
(anonymous)	@	20.fbe4f111.chunk.js:2
push.r.forEach.c.<computed>	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
g	@	main.12f68983.chunk.js:1
Jt	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
os	@	20.fbe4f111.chunk.js:2
gc	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
mc	@	20.fbe4f111.chunk.js:2
Zs	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
Go	@	20.fbe4f111.chunk.js:2
Vo	@	20.fbe4f111.chunk.js:2
$s	@	20.fbe4f111.chunk.js:2
ma	@	20.fbe4f111.chunk.js:2
ta	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
ea	@	28.227385d7.chunk.js:1
ua	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
va	@	28.227385d7.chunk.js:1
onClick	@	28.227385d7.chunk.js:1
s	@	20.fbe4f111.chunk.js:2
p	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
v	@	20.fbe4f111.chunk.js:2
at	@	20.fbe4f111.chunk.js:2
ot	@	20.fbe4f111.chunk.js:2
st	@	20.fbe4f111.chunk.js:2
pt	@	20.fbe4f111.chunk.js:2
D	@	20.fbe4f111.chunk.js:2
H	@	20.fbe4f111.chunk.js:2
Jt	@	20.fbe4f111.chunk.js:2
Xt	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
N	@	20.fbe4f111.chunk.js:2
Yt	@	20.fbe4f111.chunk.js:2
