

General:
Request URL
https://api.croma.com/user/allchannels/v1/ae6d0072ad99f3abbe4092d68388c6ae/checkout/gcvalidation/263955792897
Request Method
POST
Status Code
200 OK
Remote Address
23.212.0.117:443
Referrer Policy
strict-origin-when-cross-origin


Payload:
[real_value= card_number:1001340048054924  card_pin:264506]

vcxo7idlRHBRErey8O7uRHNOPKPaTzitsPWggUezjP/LgxmU7sV3V2EidI4NS8SOZS1YG6q4QWYuxCZuEihfH3l++uKwj/s5lZXjvDYWPD4=

response:
{
    "responseCode": null,
    "responseMessage": null,
    "cards": null,
    "gcValidationDetails": "DjXhw25zeU_mfcyK4kiEMwJnpTYjK5wMl_X9M0FNcJ4VAxu4V1NjDJoEs3rtiDE7DGgcFHGdG5usbq56AxREcYUgC5yALkAP_weGrFWm-fhtTR67kuDEmne-I6JvunFnQPl9LLzBpJ_az9gLMHkOoiAMoA956hiGh5ne1YED1XagISCDD-4OSMv2ZPeWGy7YYWTMO0_6QiYaLOH92jg_HBr6UXbpW_4XK-ORjptU76lh0NiuYbuKxINkOyHuuH1HWILJ1tpKHiay3v-Yt3i6TdDJRHO7FlN_fwk_5jUnWOyg-2YVbtMVkgAGiTsq4hwUi02hveqCNb422J9RlU8E6JGP1TZHcncL5vjFsg5jZGaLDc_-o4PxK0iexqs-AghyHcXEPuLsPW_i64HgmtRI7rT4zJRn8XkNr0MGX4IYgEL9MvLZZkprTO8dNH39aY7p",
    "errorCode": null,
    "errorDescription": null,
    "balAmountPayable": null,
    "customErrorMsg": null,
    "cardSpecificErrorMsg": null
}

Request_headers:

:authority
api.croma.com
:method
POST
:path
/user/allchannels/v1/ae6d0072ad99f3abbe4092d68388c6ae/checkout/gcvalidation/263955792897
:scheme
https
accept
application/json, text/plain, */*
accept-encoding
gzip, deflate, br, zstd
accept-language
en-US,en;q=0.9
accesstoken
5dc3a15a-879e-4665-9cf1-ea2ba42bb480
cartid
263955792897
channelname
client_id
CROMA-WEB-APP
content-length
108
content-type
application/json
csc_code
null
customerhash
ae6d0072ad99f3abbe4092d68388c6ae
origin
https://www.croma.com
priority
u=1, i
referer
https://www.croma.com/
sec-ch-ua
"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"
sec-ch-ua-mobile
?0
sec-ch-ua-platform
"Windows"
sec-fetch-dest
empty
sec-fetch-mode
cors
sec-fetch-site
same-site
source
null
user-agent
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36

Response_headers:

access-control-allow-credentials
true
access-control-allow-origin
https://www.croma.com
access-control-expose-headers
Transfer-Encoding,Connection,Request-Context,Vary,X-Content-Type-Options,X-XSS-Protection,X-Frame-Options,Date,accessToken,SSOstatus,client_id,customerHash
accesstoken
5dc3a15a-879e-4665-9cf1-ea2ba42bb480
akamai-cache-status
NotCacheable from child
akamai-grn
0.2c1cc517.1770559130.2f38ce0e
cache-control
no-cache, no-store, max-age=0, must-revalidate
client_id
CROMA-WEB-APP
content-length
645
content-type
application/json
customerhash
ae6d0072ad99f3abbe4092d68388c6ae
date
Sun, 08 Feb 2026 13:58:51 GMT
expires
0
pragma
no-cache
request-context
appId=cid-v1:8a027b7f-7450-437d-9b4c-a47116067af5
server-timing
cdn-cache; desc=MISS
server-timing
edge; dur=7
server-timing
origin; dur=618
server-timing
ak_p; desc="1770559130578_398793772_792251918_62318_6752_1042_0_219";dur=1
set-cookie
bm_sz=A6947F1191D009E1271C74EE27F58C43~YAAQLBzFFwxJBg+cAQAASU6MPR4rQKmjJvYHou8U0GEMKJKzro5Y4XOkZUUEhm+5UPPseCd3Di5eiJKSpK39swi63m5+9aEAn6RAviVZvmqqnpXHT+KlDwyBNKe8SZSGbtHeAVmLvkPC5KjGX/P+YhWtIJ4Qd4HVLIEnLUhSfyfVAx2tC1wtbSJWMUYuqSuSn7/K/nQiNFxNPkPx7KZTxZqyvbsCAsn7VlRYHDVwIPZyJlGnjCaL/xD3dKt5TfdTxbBt8wCjTI2dvE1rYgSV0pfV27ik17AH1UiZFxKBEftnXuRIOuk7fYSLh1m2obGP6zIqrKvWoUVZR8DlJhvHCy7D+XOl1fpGEjx93mvPRxJgRI6N~3753030~3356728; Domain=.croma.com; Path=/; Expires=Sun, 08 Feb 2026 17:58:50 GMT; Max-Age=14399
ssostatus
active
strict-transport-security
max-age=16070400; includeSubDomains
x-content-type-options
nosniff
x-frame-options
SAMEORIGIN
x-xss-protection
1; mode=block






Initiator


(anonymous)	@	tdl-sso-auth.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
Promise.then		
(anonymous)	@	20.fbe4f111.chunk.js:2
push.r.forEach.c.<computed>	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	28.227385d7.chunk.js:1
ea	@	28.227385d7.chunk.js:1
ua	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
va	@	28.227385d7.chunk.js:1
onClick	@	28.227385d7.chunk.js:1
s	@	20.fbe4f111.chunk.js:2
p	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
v	@	20.fbe4f111.chunk.js:2
at	@	20.fbe4f111.chunk.js:2
ot	@	20.fbe4f111.chunk.js:2
st	@	20.fbe4f111.chunk.js:2
pt	@	20.fbe4f111.chunk.js:2
D	@	20.fbe4f111.chunk.js:2
H	@	20.fbe4f111.chunk.js:2
Jt	@	20.fbe4f111.chunk.js:2
Xt	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
N	@	20.fbe4f111.chunk.js:2
Yt	@	20.fbe4f111.chunk.js:2
