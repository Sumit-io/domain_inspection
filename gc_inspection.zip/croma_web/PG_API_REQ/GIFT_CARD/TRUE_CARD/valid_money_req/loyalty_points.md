[real_value= card_number:1001340048054924  card_pin:264506]

General:
Request URL
https://api.tatadigital.com/api/v1/capillary-api/loyalty-points
Request Method
GET
Status Code
200 OK
Remote Address
[2600:1417:75::17c1:723a]:443
Referrer Policy
strict-origin-when-cross-origin

Payload:


response:
{
  "groupLoyaltyProgramDetails": [
    {
      "lifetimePoints": 2.967,
      "loyaltyPoints": 2,
      "promisedPoints": 0,
      "pointsToCurrencyRatio": 1.0,
      "groupProgramId": 1000007,
      "title": "Tata NeuPass",
      "description": "Tata NeuPass",
      "programsList": [
        {
          "id": 1000007,
          "name": "Tata NeuPass",
          "description": "Tata NeuPass"
        },
        {
          "id": 1000013,
          "name": "Croma",
          "description": "Croma"
        },
        {
          "id": 1000014,
          "name": "IHCL",
          "description": "IHCL"
        },
        {
          "id": 1000018,
          "name": "Tata Ginger Loyalty",
          "description": "Tata Ginger Loyalty"
        },
        {
          "id": 1000019,
          "name": "AirAsia India",
          "description": "AirAsia India"
        },
        {
          "id": 1000028,
          "name": "bigbasket",
          "description": "bigbasket"
        },
        {
          "id": 1000029,
          "name": "Tata CLiQ",
          "description": "Tata CLiQ"
        },
        {
          "id": 1000030,
          "name": "Westside",
          "description": "Westside"
        },
        {
          "id": 1000031,
          "name": "Tata AIA Life Insurance Company",
          "description": "Tata AIA Life Insurance Company"
        },
        {
          "id": 1000038,
          "name": "Tata 1mg",
          "description": "Tata 1mg"
        },
        {
          "id": 1000039,
          "name": "Tata Motors - PV",
          "description": "Tata Motors - PV"
        },
        {
          "id": 1000048,
          "name": "Cult",
          "description": "Cult"
        },
        {
          "id": 1000055,
          "name": "Tata Payments Ltd.",
          "description": "Tata Payments Ltd."
        },
        {
          "id": 1000086,
          "name": "TataNeu HDFC",
          "description": "TataNeu HDFC"
        },
        {
          "id": 1000087,
          "name": "Titan",
          "description": "Titan"
        },
        {
          "id": 1000094,
          "name": "Tata Digital Pvt. Ltd.",
          "description": "Tata Digital Pvt. Ltd."
        },
        {
          "id": 1000101,
          "name": "Tata Motors - EV",
          "description": "Tata Motors - EV"
        }
      ]
    }
  ],
  "blockedRedeemption": "Not Blocked",
  "blockedRedeemptionReason": null
}

Request_headers:
:authority
api.tatadigital.com
:method
GET
:path
/api/v1/capillary-api/loyalty-points
:scheme
https
accept
application/json, text/plain, */*
accept-encoding
gzip, deflate, br, zstd
accept-language
en-US,en;q=0.9
authorization
Bearer 5dc3a15a-879e-4665-9cf1-ea2ba42bb480
client_id
CROMA-WEB-APP
origin
https://www.croma.com
priority
u=1, i
referer
https://www.croma.com/
sec-ch-ua
"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"
sec-ch-ua-mobile
?0
sec-ch-ua-platform
"Windows"
sec-fetch-dest
empty
sec-fetch-mode
cors
sec-fetch-site
cross-site
store_id
croma.online
user-agent
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36



Response_headers:
access-control-allow-credentials
true
access-control-allow-origin
https://www.croma.com
access-control-expose-headers
Transfer-Encoding,Connection,Vary,X-Content-Type-Options,X-XSS-Protection,X-Frame-Options,Date,Content-Length
cache-control
no-cache, no-store, max-age=0, must-revalidate
content-encoding
gzip
content-length
510
content-type
application/json
date
Sun, 08 Feb 2026 13:58:57 GMT
expires
0
pragma
no-cache
request-context
appId=cid-v1:bb7ea1b5-3c4c-43ba-b2f0-54af335f620f
server-timing
cdn-cache; desc=MISS
server-timing
edge; dur=29
server-timing
origin; dur=72
server-timing
ak_p; desc="1770559136978_398553644_3464139794_10281_17153_0_0_219";dur=1
set-cookie
ak_bmsc=E5827F3EE59F328B17CB81FF30A96617~000000000000000000000000000000~YAAQLHLBF3uoMh+cAQAASmWMPR6Ch3yOlpkkw7jHXPUWeaXmyKhdYc6zMKRN8gxumzakG0aTdlRXBgYykK8/6K2+cC61uAVqB3pto/H9kTQc6iB6Pa4kg1esjOfrY+5p02AVZDCQfccWFKE2YaI+VFHSSHwd2K8sroeGAVlNCF8dkATQShjwLs2RFCodrCp8Z0RQ47+7t6dzZhmB5K8zdV0Y74YUtIubI9iEs0HL6ARDVMrOPXJZz4ru7Gt+aNgGwAbHfFU8hWpR/nZWFtXo4fuzpX2x3pixQzE5c8AGH0QU4SPOvzGVwUmz+oKoFcAGnHlY3YGZ9CwoCfumr3wU0C1HVOt3QfKh6MM87Jw/VJu3GOSnqHhvLyyJkM1DKmGq1JZ9yWSbr5U/i5k7AOVQpv4yVTs9MdcLElp+a6moU7BfNItW800Wu9ySMQ==; Domain=.tatadigital.com; Path=/; Expires=Sun, 08 Feb 2026 15:58:56 GMT; Max-Age=7199; HttpOnly
set-cookie
bm_sz=35E012840204E4246A8B830F057093FB~YAAQLHLBF3yoMh+cAQAASmWMPR6U4GDcZUll8dx6oJ4rPjr65+KlyjOUkUrc89+SUpZO0oOkYO0y0madBtBz1uvCWm6/137Cb+m3HnWPjRX89h8kUTQVEh06aG8MVLaHMerhWAyitnu2+k9gYuUeVh2OK92IS5tRIOasNNA9uffuT/D2v8Bt/Ar78k48VZZK5BqrcIusp2QTWnJFnbQEriN3pYovMFTN3yv6LVRnZj3kdrYDQDa21+zPvSqqC5/Re6STzQ4/s4hMF6+Ucw78ntgd6Mg4TqW7bb//UwAgi/H6P96eMpZo92EKcYq2PS7Y7v5NpjMWZBoDgKmhPi/XBoMcA7lflJ/HkdhGh87WZzQZ3K0ZpOmQIOXXXG8Cn2BN3vFsqjxqxtRaHTmevexwFKvdnnZW~4408630~4473904; Domain=.tatadigital.com; Path=/; Expires=Sun, 08 Feb 2026 17:58:56 GMT; Max-Age=14399
vary
Accept-Encoding
x-content-type-options
nosniff
x-frame-options
DENY
x-xss-protection
0

Initiator

(anonymous)	@	tdl-sso-auth.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
Promise.then		
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
d	@	28.227385d7.chunk.js:1
Yt	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
(anonymous)	@	28.227385d7.chunk.js:1
Wt	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
os	@	20.fbe4f111.chunk.js:2
gc	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
mc	@	20.fbe4f111.chunk.js:2
Zs	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
Go	@	20.fbe4f111.chunk.js:2
Vo	@	20.fbe4f111.chunk.js:2
$s	@	20.fbe4f111.chunk.js:2
ma	@	20.fbe4f111.chunk.js:2
jt	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
Jt	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
os	@	20.fbe4f111.chunk.js:2
gc	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
mc	@	20.fbe4f111.chunk.js:2
Zs	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
Go	@	20.fbe4f111.chunk.js:2
Vo	@	20.fbe4f111.chunk.js:2
$s	@	20.fbe4f111.chunk.js:2
ma	@	20.fbe4f111.chunk.js:2
ta	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
ea	@	28.227385d7.chunk.js:1
ua	@	28.227385d7.chunk.js:1
(anonymous)	@	28.227385d7.chunk.js:1
Promise.then		
va	@	28.227385d7.chunk.js:1
onClick	@	28.227385d7.chunk.js:1
s	@	20.fbe4f111.chunk.js:2
p	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
v	@	20.fbe4f111.chunk.js:2
at	@	20.fbe4f111.chunk.js:2
ot	@	20.fbe4f111.chunk.js:2
st	@	20.fbe4f111.chunk.js:2
pt	@	20.fbe4f111.chunk.js:2
D	@	20.fbe4f111.chunk.js:2
H	@	20.fbe4f111.chunk.js:2
Jt	@	20.fbe4f111.chunk.js:2
Xt	@	20.fbe4f111.chunk.js:2
(anonymous)	@	20.fbe4f111.chunk.js:2
qo	@	20.fbe4f111.chunk.js:2
N	@	20.fbe4f111.chunk.js:2
Yt	@	20.fbe4f111.chunk.js:2

