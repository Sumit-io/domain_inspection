<!-- [real_value= card_number:1001340045724756  card_pin:159321] -->

{
    "responseCode": null,
    "responseMessage": null,
    "cards": null,
    "gcValidationDetails": "DjXhw25zeU_mfcyK4kiEMwJnpTYjK5wMl_X9M0FNcJ4VAxu4V1NjDJoEs3rtiDE7DGgcFHGdG5usbq56AxREcb_5CxMHwrbm__WEN88Xqr-eIWNMRzQ8JZoTOjqKgZgz7YkSWzbsuAyZpkTI6RToVesqwe777CBsVHsbyliFW_aWdGVjIXfDv_NxbHWytfi822hglS7_XT5kSVnUazANGYUpBtdfzW0yiuhhlvybmZRxUr_SWwZDY488XexBL-Bdqc61vyVNQfTWtQDJhvQiRSj3FrEtdSdn0fyc6836pfdOZZAqJ517R76OLi9_o-ihY0NuRBi5BH88W7rKGBNbUM7i7kYl0u0zTnqbJmlZtVHsNaUt1fbf502bcNMGty1OCAd_jTWqdy_f0o5pYprvPgp9h2HetjMywSySqcNE8Ls",
    "errorCode": null,
    "errorDescription": null,
    "balAmountPayable": null,
    "customErrorMsg": null,
    "cardSpecificErrorMsg": null
}


Request URL
https://api.croma.com/user/allchannels/v1/ae6d0072ad99f3abbe4092d68388c6ae/checkout/gcvalidation/263955792897
Request Method
POST
Status Code
200 OK
Remote Address
[2600:140f:2e00::b856:7061]:443
Referrer Policy
strict-origin-when-cross-origin


vcxo7idlRHBRErey8O7uRHNOPKPaTzitsPWggUezjP9ftCPkNKDLINFqSBoFqqAvuBlfTfSxFDjOceQFehHvQnl++uKwj/s5lZXjvDYWPD4=


Request_headers

:authority
api.croma.com
:method
POST
:path
/user/allchannels/v1/ae6d0072ad99f3abbe4092d68388c6ae/checkout/gcvalidation/263955792897
:scheme
https
accept
application/json, text/plain, */*
accept-encoding
gzip, deflate, br, zstd
accept-language
en-US,en;q=0.9
accesstoken
5dc3a15a-879e-4665-9cf1-ea2ba42bb480
cartid
263955792897
channelname
client_id
CROMA-WEB-APP
content-length
108
content-type
application/json
csc_code
null
customerhash
ae6d0072ad99f3abbe4092d68388c6ae
origin
https://www.croma.com
priority
u=1, i
referer
https://www.croma.com/
sec-ch-ua
"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"
sec-ch-ua-mobile
?0
sec-ch-ua-platform
"Windows"
sec-fetch-dest
empty
sec-fetch-mode
cors
sec-fetch-site
same-site
source
null
user-agent
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36