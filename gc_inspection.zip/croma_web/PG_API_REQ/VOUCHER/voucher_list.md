Note the payload is unknown right now for me; but it uses the voucher value in its payload



Real value of voucher: CVFTCS9377 [face value:10000; exp: jun 11 2024 from scribd]

{"gvRequest":"6o9c/A3McOsexCndcLQODoDcwHFUTJRTFDq2KIAw7LjNVeXI2ViAl0b0DECHzOXUksRMUnloIiMP+2Ejg8tBnitwOW6XcRdmrUF9ZUyj3/8GdEpO+vTKEK6/FLdZslovsBMzpJZ4bWPgT+2Bn16qS159/2N3jPWrwMBMhyMGk1Ll+mH+f1UxY1VdpcNEJTjf"}

Response

{
    "gvDetails": null,
    "customErrorMsg": null,
    "cardSpecificErrorMsg": null,
    "balAmountPayable": null,
    "gvRequest": "6o9c_A3McOsexCndcLQODrYDDoLbBg4_KxNQeFJQCpkFH1oHb3svYILpOL7ManiQlWPU4KZtht-gMSHQiGJE-mgq6i-LIq1X2jIQ3EfZeknEoU1FRjgRnsroTSHIKO49GuiKTsZe8y9gV-z0UxxzJFQA5VLuFziWCz8P8vVcJdKjD6TIg9xJsWaQlFJ6Z0ZXAPkRx58VlV87gpEaNFfPWc3ruavdZEoyfgiRtz5IE0k"
}


------------------------------------


Payload
{"gvRequest":"6o9c/A3McOsexCndcLQODoDcwHFUTJRTFDq2KIAw7Lij4+66tA8od8xxa5PCzYBiksRMUnloIiMP+2Ejg8tBnitwOW6XcRdmrUF9ZUyj3/8GdEpO+vTKEK6/FLdZslovsBMzpJZ4bWPgT+2Bn16qS159/2N3jPWrwMBMhyMGk1Ll+mH+f1UxY1VdpcNEJTjf"}

Real value of voucher: CV9DA7FH72 [face value:10000; exp: jun 11 2024 from scribd]


Response
{
    "gvDetails": null,
    "customErrorMsg": null,
    "cardSpecificErrorMsg": null,
    "balAmountPayable": null,
    "gvRequest": "6o9c_A3McOsexCndcLQODleShwHVsx0vPdd-R1r0_DfzZv1QlDpLOgc5uw8DZeGJlWPU4KZtht-gMSHQiGJE-mgq6i-LIq1X2jIQ3EfZekl4yLszlt8RQP3xEK-9n8zQGuiKTsZe8y9gV-z0UxxzJFQA5VLuFziWCz8P8vVcJdKjD6TIg9xJsWaQlFJ6Z0ZXAPkRx58VlV87gpEaNFfPWc3ruavdZEoyfgiRtz5IE0k"
}
