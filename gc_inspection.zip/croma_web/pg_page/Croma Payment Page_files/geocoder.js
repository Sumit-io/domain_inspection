google.maps.__gjsload__("geocoder", function (_) {
  var mOa = function (a) {
      const b = _.Qm({
        address: _.dt,
        bounds: _.$m(_.ro),
        location: _.$m(_.sn),
        language: _.dt,
        region: _.dt,
        latLng: _.$m(_.sn),
        country: _.dt,
        partialmatch: _.et,
        newForwardGeocoder: _.et,
        newReverseGeocoder: _.et,
        extraComputations: _.$m(_.Um(_.Tm(lOa))),
        fulfillOnZeroResults: _.et,
        componentRestrictions: _.$m(
          _.Qm({
            route: _.$m(_.ft),
            locality: _.$m(_.ft),
            administrativeArea: _.$m(_.ft),
            postalCode: _.$m(_.ft),
            country: _.$m(_.ft),
          }),
        ),
        placeId: _.dt,
      });
      return _.Zm(
        (c) => b(c),
        function (c) {
          if (c.placeId) {
            if (c.address) throw _.Om("cannot set both placeId and address");
            if (c.latLng) throw _.Om("cannot set both placeId and latLng");
            if (c.location) throw _.Om("cannot set both placeId and location");
            if (c.componentRestrictions)
              throw _.Om("cannot set both placeId and componentRestrictions");
          }
          return c;
        },
      )(a);
    },
    nOa = function (a) {
      function b(c) {
        if (typeof c === "object" && c !== null)
          for (const d in c)
            if (d === "display_name") {
              const e = c.display_name,
                f = Object.keys(e);
              f.length === 2 &&
                f.includes("text") &&
                f.includes("language_code") &&
                ((c.display_name = e.text),
                (c.display_name_language_code = e.language_code));
            } else b(c[d]);
      }
      b(a);
    },
    oOa = function (a, b) {
      _.mM(a, _.nM);
      _.mM(a, _.gFa);
      nOa(a);
      b(a);
    },
    pOa = function (a) {
      switch (a) {
        case "OK":
        case "ZERO_RESULTS":
          return 0;
        case "INVALID_REQUEST":
          return 3;
        case "OVER_QUERY_LIMIT":
          return 8;
        case "REQUEST_DENIED":
          return 7;
        case "ERROR":
        case "UNKNOWN_ERROR":
          return 14;
        default:
          return 2;
      }
    },
    rOa = function (a, b, c, d) {
      qOa(
        a,
        _.qI(_.Kz, _.ds, _.MB + "/maps/api/js/GeocodeService.Search", (e) =>
          (0, _.cs)(e, d?.key),
        ),
        b,
        c,
      );
    },
    qOa = function (a, b, c, d) {
      function e(h = { UF: !1 }) {
        d && _.Ul(d, h.UF ? 4 : 10);
        c(null, "ERROR", null, null);
      }
      function f(h) {
        if (h && h.error_message) {
          _.Dm(h.error_message);
          if (h.error_message !== "" && d) {
            const k = pOa(h.status);
            k === 3 || k === 7 || k === 8
              ? _.Vl(d)
              : k === 0
                ? _.Ul(d, 11)
                : k === 14
                  ? _.Ul(d, 12)
                  : _.Ul(d, 9);
          }
          delete h.error_message;
        }
        oOa(h, (k) => {
          const m = k.results,
            p = k.status,
            r = k.address_descriptor;
          k = k.plus_code;
          if (d)
            try {
              sOa(m);
            } catch (t) {
              _.Ul(d, 15);
            }
          c(m, p, r, k);
        });
      }
      const g = tOa(a);
      _.EI(
        _.rC,
        () => {
          const h = _.hj(g, uOa());
          b(h, f, e, !0);
        },
        () => {
          d && _.Vl(d);
        },
      );
    },
    tOa = function (a) {
      const b = new vOa();
      var c = a.address;
      c && b.setQuery(c);
      if ((c = a.location || a.latLng)) {
        var d = _.Zf(b, _.vA, 5);
        _.mx(_.kx(d, c.lat()), c.lng());
      }
      var e = a.bounds;
      if (e) {
        d = _.Zf(b, _.wA, 6);
        c = e.getSouthWest();
        e = e.getNorthEast();
        const g = _.Zf(d, _.vA, 1);
        d = _.Zf(d, _.vA, 2);
        _.mx(_.kx(g, c.lat()), c.lng());
        _.mx(_.kx(d, e.lat()), e.lng());
      }
      d = _.kl.nh();
      e = d.nh();
      c = d.ph();
      (e = a.language || e) && b.Si(e);
      d = d.qh();
      (e = a.region) ? _.Gg(b, 7, e) : c && !d && _.Gg(b, 7, c);
      c = a.componentRestrictions;
      for (var f in c) {
        if (
          f !== "route" &&
          f !== "locality" &&
          f !== "administrativeArea" &&
          f !== "postalCode" &&
          f !== "country"
        )
          continue;
        e = f;
        f === "administrativeArea" && (e = "administrative_area");
        f === "postalCode" && (e = "postal_code");
        c[f] && ((d = _.Bf(b, 8, wOa)), (d = _.Gg(d, 1, e)), _.Gg(d, 2, c[f]));
      }
      (f = a.placeId) && _.Gg(b, 14, f);
      "newReverseGeocoder" in a &&
        (a.newReverseGeocoder ? _.Ig(b, 106, 3) : _.Ig(b, 106, 1));
      if (a.extraComputations && a.extraComputations.length > 0)
        for (const g of a.extraComputations)
          ((a = xOa[g]), a !== void 0 && _.zv(b, 100, a));
      return b;
    },
    lOa = { ADDRESS_DESCRIPTORS: "ADDRESS_DESCRIPTORS" };
  var yOa = {
      types: _.Um(_.ft),
      formatted_address: _.ft,
      place_id: _.Zm(_.dt, (a) => {
        if (!a || /^[\w-]+$/.test(a)) return a;
        throw _.Om("invalid place Id");
      }),
      address_components: _.Um(
        _.Qm({ short_name: _.dt, long_name: _.ft, types: _.Um(_.dt) }),
      ),
      partial_match: _.et,
      postcode_localities: _.$m(_.Um(_.ft)),
      plus_code: _.$m(_.Qm({ global_code: _.ft, compound_code: _.dt })),
      geometry: _.Qm({
        location: _.sn,
        location_type: _.Tm(_.Rfa),
        viewport: _.ro,
        bounds: _.$m(_.ro),
      }),
      address_descriptor: _.$m(
        _.Qm({
          areas: _.Um(
            _.Qm({
              containment: _.Tm({
                WITHIN: "WITHIN",
                OUTSKIRTS: "OUTSKIRTS",
                NEAR: "NEAR",
              }),
              display_name: _.dt,
              display_name_language_code: _.dt,
              place_id: _.dt,
            }),
          ),
          landmarks: _.Um(
            _.Qm({
              display_name: _.dt,
              display_name_language_code: _.dt,
              place_id: _.dt,
              types: _.Um(_.ft),
              travel_distance_meters: _.ct,
              straight_line_distance_meters: _.ct,
              spatial_relationship: _.Tm({
                NEAR: "NEAR",
                WITHIN: "WITHIN",
                BESIDE: "BESIDE",
                ACROSS_THE_ROAD: "ACROSS_THE_ROAD",
                DOWN_THE_ROAD: "DOWN_THE_ROAD",
                AROUND_THE_CORNER: "AROUND_THE_CORNER",
                BEHIND: "BEHIND",
              }),
            }),
          ),
        }),
      ),
    },
    zOa = _.Qm(yOa),
    sOa = _.Um(function (a) {
      if (a) {
        const b = Object.keys(yOa);
        for (const c of Object.keys(a)) b.includes(c) || delete a[c];
      }
      return zOa(a);
    });
  var xOa = { QO: 0, ADDRESS_DESCRIPTORS: 1, DO: 2, yP: 3, eP: 4 };
  var wOa = class extends _.M {
    constructor(a) {
      super(a);
    }
    getType() {
      return _.K(this, 1);
    }
    getName() {
      return _.K(this, 2);
    }
  };
  var vOa = class extends _.M {
    constructor(a) {
      super(a);
    }
    getQuery() {
      return _.K(this, 4);
    }
    setQuery(a) {
      return _.Gg(this, 4, a);
    }
    Si(a) {
      return _.Gg(this, 9, a);
    }
    Nk() {
      return _.pv(this, 9);
    }
  };
  var uOa = _.ki(vOa, [
    0,
    3,
    _.X,
    _.VM,
    _.WM,
    _.X,
    _.Y,
    [0, _.X, -1],
    _.X,
    _.V,
    _.Es,
    _.Gs,
    1,
    _.X,
    _.R,
    1,
    _.R,
    _.X,
    -1,
    4,
    _.Noa,
    _.X,
    74,
    _.mA,
    4,
    _.V,
    _.Z,
    7,
    _.X,
    2,
    _.V,
    6,
    _.V,
    -1,
  ]);
  var AOa = class {
    geocode(a, b, c, d) {
      _.oM(b);
      if (a.extraComputations)
        throw Error(
          "google.maps.GeocodeRequest with extraComputations is not available in this version of the Google Maps JavaScript API. Please switch to the beta channel to use this feature. https://developers.google.com/maps/documentation/javascript/versions#beta-channel",
        );
      if (b)
        try {
          mOa(a);
        } catch (f) {
          _.Pm(f);
        }
      const e = new Promise((f, g) => {
        try {
          a = mOa(a);
        } catch (h) {
          throw (c && _.Vl(c), h);
        }
        rOa(
          a,
          (h, k, m, p) => {
            if (c) {
              var r = pOa(k);
              [0, 14, 2].includes(r) ? _.Ul(c, r) : _.Vl(c);
            }
            a: switch (k) {
              case "OK":
                r = !0;
                break a;
              case "ZERO_RESULTS":
                r = !!a.fulfillOnZeroResults;
                break a;
              default:
                r = !1;
            }
            if (r)
              (b && b(h, k),
                f({ results: h, address_descriptor: m, plus_code: p }));
            else {
              b && b(null, k);
              a: {
                switch (k) {
                  case "ZERO_RESULTS":
                    h = "No result was found for this GeocoderRequest.";
                    break;
                  case "INVALID_REQUEST":
                    h = "This GeocoderRequest was invalid.";
                    break;
                  case "OVER_QUERY_LIMIT":
                    h =
                      "The webpage has gone over the requests limit in too short a period  of time.";
                    break;
                  case "REQUEST_DENIED":
                    h = "The webpage is not allowed to use the geocoder.";
                    break;
                  default:
                    k = new _.is(
                      "A geocoding request could not be processed due to a server error. The request may succeed if you try again.",
                      "GEOCODER_GEOCODE",
                      k,
                    );
                    break a;
                }
                k = new _.hs(h, "GEOCODER_GEOCODE", k);
              }
              g(k);
            }
          },
          c,
          d,
        );
      });
      b && e.catch(() => {});
      return e;
    }
  };
  _.Pl("geocoder", new AOa());
});
