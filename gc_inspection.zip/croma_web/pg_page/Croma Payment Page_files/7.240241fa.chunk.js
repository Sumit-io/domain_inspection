(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [7],
  { 949: function (p, a, c) {} },
]);
