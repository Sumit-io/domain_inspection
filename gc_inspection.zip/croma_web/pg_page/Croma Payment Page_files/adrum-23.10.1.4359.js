/* Copyright (c) 2010-2021 Google LLC. http://angular.io/license
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */
/* Version a57fe9a4dfa0e1d6b2dc001466e4e21d v:23.10.1.4359, c:86edb7e5c8b923527bd6bfc7742d40adcfb08771, b:23.10.1.4359 */ (function () {
  new (function () {
    if (!window.ADRUM && !0 !== window["adrum-disable"]) {
      var k = (window.ADRUM = {}),
        y = window.console,
        A = y && "function" == typeof y.log ? y : { log: function () {} };
      window["adrum-start-time"] =
        window["adrum-start-time"] || new Date().getTime();
      var u =
          (this && this.kd) ||
          (function () {
            var a =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (a, e) {
                  a.__proto__ = e;
                }) ||
              function (a, e) {
                for (var c in e) e.hasOwnProperty(c) && (a[c] = e[c]);
              };
            return function (b, e) {
              function c() {
                this.constructor = b;
              }
              a(b, e);
              b.prototype =
                null === e
                  ? Object.create(e)
                  : ((c.prototype = e.prototype), new c());
            };
          })(),
        d =
          (this && this.zp) ||
          Object.assign ||
          function (a) {
            for (var b, e = 1, c = arguments.length; e < c; e++) {
              b = arguments[e];
              for (var f in b)
                Object.prototype.hasOwnProperty.call(b, f) && (a[f] = b[f]);
            }
            return a;
          };
      (function (a) {
        (function (a) {
          a.setUpMonitors = function () {
            for (var a = [], b = 0; b < arguments.length; b++)
              a[b] = arguments[b];
            for (b = 0; b < a.length; b++) {
              var f = a[b];
              f && f.setUp();
            }
          };
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      window.Error.stackTraceLimit = Infinity;
      (function (a) {
        (function (b) {
          function e(a) {
            return b.refs.slice.apply(a, b.refs.slice.call(arguments, 1));
          }
          function c(a, p) {
            return f(b.refs.setTimeout.apply)
              ? b.refs.setTimeout.apply(window, arguments)
              : b.refs.setTimeout(a, p);
          }
          function f(a) {
            return "undefined" !== typeof a && null !== a;
          }
          function p(a) {
            return "object" == typeof a && !b.isArray(a) && null !== a;
          }
          function m(a) {
            return "function" == typeof a || !1;
          }
          function n(a) {
            return "string" == typeof a;
          }
          function l(a) {
            return "number" == typeof a;
          }
          function q(a) {
            return "" === a;
          }
          function t(a, f) {
            for (var m in f) {
              var n = f[m];
              if (x(f, m)) {
                var l = a[m];
                p(n) && p(l)
                  ? t(l, n)
                  : b.isArray(l) && b.isArray(n)
                    ? (a[m] = l.concat(n))
                    : (a[m] = n);
              }
            }
            return a;
          }
          function x(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b) && f(a[b]);
          }
          function s(a) {
            return n(a) ? a.replace(/^\s*/, "").replace(/\s*$/, "") : a;
          }
          function z() {
            return b.refs.ta && m(b.refs.ta.now);
          }
          function k() {
            return z()
              ? b.refs.round(b.refs.ta.now() + v())
              : new Date().getTime();
          }
          function v() {
            var a = b.refs.ta,
              a =
                a && a.timing && l(a.timing.navigationStart)
                  ? a.timing.navigationStart
                  : window["adrum-start-time"];
            f(a) || (a = k());
            return a;
          }
          function r(a, b) {
            var f = Array.prototype[a];
            return f ? J(f) : B(a, b);
          }
          function J(a) {
            return function (f) {
              return a.apply(f, b.refs.slice.call(arguments, 1));
            };
          }
          function B(a, b) {
            return function (p, n) {
              if (!f(p))
                throw new TypeError(a + " called on null or undefined");
              if (!m(n)) throw new TypeError(n + " is not a function");
              return b.apply(null, arguments);
            };
          }
          function D(a, b, f) {
            var p = Object(a),
              m = p.length >>> 0,
              n = 0;
            if (3 > arguments.length) {
              for (; n < m && !(n in p); ) n++;
              if (n >= m)
                throw new TypeError(
                  "Reduce of empty array with no initial value",
                );
              f = p[n++];
            }
            for (; n < m; n++) n in p && (f = b(f, p[n], n, p));
            return f;
          }
          function E(a, f, p) {
            return b.reduce(
              a,
              function (a, b, m, n) {
                a[m] = f.call(p, b, m, n);
                return a;
              },
              Array(a.length >>> 0),
            );
          }
          function F(a, f, p) {
            return b.reduce(
              a,
              function (a, b, m, n) {
                f.call(p, b, m, n) && a.push(b);
                return a;
              },
              [],
            );
          }
          function G(a, b, f) {
            a = Object(a);
            for (var p = a.length >>> 0, m = 0; m < p; m++)
              if (m in a && b.call(f, a[m], m, a)) return !0;
            return !1;
          }
          function H(a, f, p) {
            return !b.some(a, function (a) {
              return !f.call(p, a);
            });
          }
          function S(a, f, p) {
            b.reduce(
              a,
              function (a, b, m, n) {
                f.call(p, b, m, n);
              },
              void 0,
            );
          }
          function u(a) {
            a = new b.refs.Error("Async Function:" + (a ? " " + a : ""));
            a.stack &&
              -1 == a.stack.toString().indexOf(a.message) &&
              (a.stack = a.message + "\n" + a.stack);
            return a;
          }
          function C(a) {
            return u(a).stack;
          }
          function I(a) {
            try {
              throw u(a);
            } catch (b) {
              return b.stack;
            }
          }
          b.refs = {
            isArray: Array.isArray,
            toString: Object.prototype.toString,
            slice: Array.prototype.slice,
            setTimeout: window.setTimeout,
            setInterval: window.setInterval,
            ta:
              window.performance ||
              window.mozPerformance ||
              window.msPerformance ||
              window.webkitPerformance,
            assign: Object.assign,
            round: Math.round,
            Error: window.Error,
            Nj: Text,
          };
          b.La = e;
          b.oSTO = c;
          b.isCORSSupported = function () {
            var a = window.JSON && m(JSON.stringify);
            return (
              f(window.XMLHttpRequest) &&
              "withCredentials" in new XMLHttpRequest() &&
              a
            );
          };
          b.isDefined = f;
          b.Bm = function (a) {
            return "number" === typeof a && !window.isNaN(a);
          };
          b.isArray =
            m(b.refs.isArray) && m(b.refs.isArray.bind)
              ? b.refs.isArray.bind(Array)
              : function (a) {
                  return b.refs.toString.call(a) === b.refs.toString.call([]);
                };
          b.isObject = p;
          b.isFunction = m;
          b.isString = n;
          b.isNumber = l;
          b.isBoolean = function (a) {
            return "boolean" == typeof a;
          };
          b.xm = function (a) {
            if (!p(a)) return !1;
            var b = Object.prototype.toString.call(a);
            return (
              ("[object Error]" === b || "[object DOMException]" === b) &&
              "name" in a &&
              "message" in a
            );
          };
          b.max = function (a, b) {
            return Math.max(
              isNaN(a) ? Number.NEGATIVE_INFINITY : a,
              isNaN(b) ? Number.NEGATIVE_INFINITY : b,
            );
          };
          b.um = q;
          b.Ih = c;
          b.vq = function (a, b) {
            c(a, b || 1e4);
          };
          b.addEventListener = function (b, f, p, m) {
            function n() {
              try {
                return p.apply(this, e(arguments));
              } catch (m) {
                a.exception(m, "M1", f, b, m);
              }
            }
            void 0 === m && (m = !1);
            a.logInfo("M0", f, b);
            n.L = !0;
            b.addEventListener
              ? b.addEventListener(f, n, m)
              : b.attachEvent && b.attachEvent("on" + f, n);
          };
          b.loadScriptAsync = function (b) {
            var p = document.createElement("script"),
              m = a.conf.elementIdWithNonce;
            p.type = "text/javascript";
            p.async = !0;
            p.src = b;
            m &&
              f(s(m)) &&
              (m = document.getElementById(m)) &&
              ((m = m.nonce),
              (m = s(m)),
              f(m) && !q(m) && p.setAttribute("nonce", m));
            (m = document.getElementsByTagName("script")[0])
              ? (m.parentNode.insertBefore(p, m), a.logInfo("M2", b))
              : a.logInfo("M3", b);
          };
          b.mergeJSON = t;
          b.hasOwnPropertyDefined = x;
          b.gg = function (a, f) {
            if (b.isFunction(Object.getPrototypeOf))
              for (; b.isDefined(a) && !x(a, f); ) a = Object.getPrototypeOf(a);
            return a;
          };
          b.cp = function (a) {
            return f(a) ? (b.isArray(a) ? a : [a]) : [];
          };
          b.zq = function (a, b) {
            return null != a && a.slice(0, b.length) == b;
          };
          b.generateGUID =
            (function (a) {
              return (
                f(a) &&
                m(a.getRandomValues) &&
                function () {
                  function b(a) {
                    a = a.toString(16);
                    return "0000".substr(a.length) + a;
                  }
                  var f = new Uint16Array(8);
                  a.getRandomValues(f);
                  return (
                    b(f[0]) +
                    b(f[1]) +
                    "_" +
                    b(f[2]) +
                    "_" +
                    b(f[3]) +
                    "_" +
                    b(f[4]) +
                    "_" +
                    b(f[5]) +
                    b(f[6]) +
                    b(f[7])
                  );
                }
              );
            })(window.crypto || window.msCrypto) ||
            function () {
              return "xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx".replace(
                /[xy]/g,
                function (a) {
                  var b = (16 * Math.random()) | 0;
                  return ("x" == a ? b : (b & 3) | 8).toString(16);
                },
              );
            };
          b.tryExtractingErrorStack = function (a) {
            return a
              ? (a = a.stack) && "string" === typeof a
                ? a
                : null
              : null;
          };
          b.trim = s;
          b.wn = function (a) {
            var b = {},
              f,
              m;
            if (!a) return b;
            var p = a.split("\n");
            for (m = 0; m < p.length; m++) {
              var n = p[m];
              f = n.indexOf(":");
              a = s(n.substr(0, f)).toLowerCase();
              f = s(n.substr(f + 1));
              a && (b[a] = b[a] ? b[a] + (", " + f) : f);
            }
            return b;
          };
          b.tryPeriodically = function (a, b, f, m) {
            function p() {
              if (b()) f && f();
              else {
                var l = a(++n);
                0 < l ? c(p, l) : m && m();
              }
            }
            var n = 0;
            p();
          };
          b.Hf = function (a) {
            return a.charAt(0).toUpperCase() + a.slice(1);
          };
          b.jh = function (a) {
            for (var b = [], f = 1; f < arguments.length; f++)
              b[f - 1] = arguments[f];
            return function () {
              for (var f = [], m = 0; m < arguments.length; m++)
                f[m] = arguments[m];
              return a.apply(this, b.concat(f));
            };
          };
          b.Yp = z;
          b.now = k;
          b.fb = v;
          b.Hp = D;
          b.reduce = r("reduce", D);
          b.Gp = E;
          b.map = r("map", E);
          b.Ep = F;
          b.filter = r("filter", F);
          b.Ip = G;
          b.some = r("some", G);
          b.Dp = H;
          b.every = r("every", H);
          b.Fp = S;
          b.forEach = r("forEach", S);
          b.Tk = function (a) {
            return b.filter(a, f);
          };
          b.Mp = function (a) {
            return [].concat.apply([], a);
          };
          b.Uj =
            f(window.Reflect) && f(window.Reflect.construct)
              ? function (b, f, m, p) {
                  try {
                    return null !== f ? window.Reflect.construct(f, m, p) : b;
                  } catch (n) {
                    return (a.monitor.ErrorMonitor.B(n), b);
                  }
                }
              : function (b, f, m) {
                  try {
                    return (null !== f && f.apply(b, m)) || b;
                  } catch (p) {
                    return (a.monitor.ErrorMonitor.B(p), b);
                  }
                };
          b.kd = (function () {
            var a =
              Object.setPrototypeOf ||
              function (a, b) {
                var f = Object.getOwnPropertyNames(b),
                  m;
                for (m in f) a[m] = b[m];
              };
            return function (b, f) {
              function m() {
                this.constructor = b;
              }
              a(b, f);
              b.prototype =
                null === f
                  ? Object.create(f)
                  : ((m.prototype = f.prototype), new m());
            };
          })();
          b.al = function (a) {
            if (!b.isString(a)) return a;
            var f = {
              "&": "&amp;",
              "<": "&lt;",
              ">": "&gt;",
              "'": "&#39;",
              '"': "&quot;",
              "/": "&#47;",
            };
            return a.replace(/[&<>'"/]/g, function (a) {
              return f[a];
            });
          };
          b.Dq = function (a) {
            if (!b.isString(a)) return a;
            var f = {
              "&amp;": "&",
              "&#38;": "&",
              "&#x26;": "&",
              "&lt;": "<",
              "&#60;": "<",
              "&#x3c;": "<",
              "&gt;": ">",
              "&#62;": ">",
              "&#x3e;": ">",
              "&apos;": "'",
              "&#39;": "'",
              "&#x27;": "'",
              "&quot;": '"',
              "&#34;": '"',
              "&#x22;": '"',
              "&sol;": "/",
              "&#47;": "/",
              "&#x2f;": "/",
            };
            return a.replace(
              /&(?:amp|#0*38|#x0*26|lt|#0*60|#x0*3c|gt|#0*62|#x0*3e|apos|#0*39|#x0*27|quot|#0*34|#x0*22|sol|#0*47|#x0*2f);/g,
              function (a) {
                a = a.replace(/0+\B/g, "");
                return f[a];
              },
            );
          };
          b.Ok = function (a) {
            var b;
            return function () {
              var f = this;
              b && clearTimeout(b);
              b = c(function () {
                a.apply(f, arguments);
              }, 300);
            };
          };
          b.Fl = function (a) {
            var f = a.length;
            if (f)
              for (f -= 1; 0 <= f; f--)
                if (b.isObject(a[f]) && a[f].adrumArgs) return f;
            return -1;
          };
          b.Md = function (a, f) {
            var m = a.length,
              p;
            p = null;
            if (m)
              for (m -= 1; 0 <= m; m--)
                if (b.isObject(a[m]) && a[m].adrumArgs) {
                  p = a[m].adrumArgs;
                  p = p[f];
                  break;
                }
            return p;
          };
          b.ae = function () {
            return (
              a.conf.noConflictPromiseMode ||
              f(window.__zone_symbol__Promise) ||
              f(window.__zone_symbol__ZoneAwarePromise)
            );
          };
          var h = C(""),
            K = I("");
          b.Sa = h ? C : K ? I : C;
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        var b = a.conf || (a.conf = {});
        b.userConf = window["adrum-config"] || {};
        b.useHTTPSAlways = !0 === b.userConf.useHTTPSAlways;
        b.modernBrowserFeaturesAvailable =
          a.utils.isDefined(window.addEventListener) &&
          a.utils.isCORSSupported() &&
          a.utils.isDefined(Array.prototype.forEach);
        b.spa2 =
          b.userConf.spa &&
          b.userConf.spa.spa2 &&
          (!0 === b.userConf.spa.spa2 || a.utils.isObject(b.userConf.spa.spa2));
        b.clearResTiming =
          b.userConf.spa &&
          a.utils.isObject(b.userConf.spa.spa2) &&
          a.utils.isDefined(b.userConf.spa.spa2.clearResTiming)
            ? b.userConf.spa.spa2.clearResTiming
            : !0;
        b.disableTextForTesting = !0 === b.userConf.disableTextForTesting;
        b.enablePrimaryMetrics =
          (!a.utils.isDefined(b.userConf.enablePrimaryMetrics) ||
            !0 === b.userConf.enablePrimaryMetrics) &&
          b.modernBrowserFeaturesAvailable;
        b.N = !1;
        b.considerCarouselForVCT = a.utils.isDefined(b.userConf.Dk)
          ? b.userConf.Dk
          : !0;
        b.devMode = !0 === b.userConf.devMode;
        b.noConflictPromiseMode = !0 === b.userConf.noConflictPromiseMode;
        b.isZonePromise =
          !0 === b.userConf.isZonePromise ||
          !0 === b.userConf.angular ||
          !0 === b.userConf.noConflictPromiseMode;
        b.fetch =
          !a.utils.isDefined(b.userConf.fetch) || !0 == b.userConf.fetch;
        b.backTimeGap = Math.abs(b.userConf.backTimeGap) || 0;
        b.neverSendImageBeacon =
          !a.utils.isDefined(b.userConf.beacon) ||
          !a.utils.isDefined(b.userConf.beacon.neverSendImageBeacon) ||
          !0 == b.userConf.beacon.neverSendImageBeacon;
        b.beaconUrlHttp = a.utils.isDefined(b.userConf.beaconUrlHttp)
          ? b.userConf.beaconUrlHttp
          : "http://col.eum-appdynamics.com";
        b.beaconUrlHttps = a.utils.isDefined(b.userConf.beaconUrlHttps)
          ? b.userConf.beaconUrlHttps
          : "https://col.eum-appdynamics.com";
        b.corsEndpointPath =
          "/eumcollector/beacons/browser" + (b.spa2 ? "/v2" : "/v1");
        b.imageEndpointPath = "/eumcollector/adrum.gif?";
        b.appKey =
          b.userConf.appKey || window["adrum-app-key"] || "APP_KEY_NOT_SET";
        a = b.useHTTPSAlways || "https:" === document.location.protocol;
        var e = b.userConf.adrumExtUrlHttp || "http://cdn.appdynamics.com",
          c = b.userConf.adrumExtUrlHttps || "https://cdn.appdynamics.com";
        b.adrumExtUrl =
          (a ? c : e) + "/adrum-ext.a57fe9a4dfa0e1d6b2dc001466e4e21d.js";
        b.adrumXdUrl = c + "/adrum-xd.a57fe9a4dfa0e1d6b2dc001466e4e21d.html";
        b.agentVer = "23.10.1.4359";
        b.sendImageBeacon =
          (b.userConf.beacon && b.userConf.beacon.sendImageBeacon) ||
          window["adrum-send-image-beacon"];
        window["adrum-geo-resolver-url"]
          ? ((e = window["adrum-geo-resolver-url"]),
            (c = e.indexOf("://")),
            -1 != c && (e = e.substring(c + 3)),
            (e = (a ? "https://" : "http://") + e))
          : ((e = b.userConf.geoResolverUrlHttps || ""),
            (c = b.userConf.geoResolverUrlHttp || ""),
            (e = a ? e : c));
        b.geoResolverUrl = e;
        b.useStrictDomainCookies =
          !0 === window["adrum-use-strict-domain-cookies"];
        b.lj = 10;
        b.fj = 10;
        b.sendBeaconOnUnload =
          b.userConf.beacon && !1 === b.userConf.beacon.sendOnUnload ? !1 : !0;
        b.isReportingPaused = b.userConf.pauseReporting || !1;
        b.ja = !1 === b.userConf.longStackTrace ? !1 : !0;
        b.isAbapApp = b.userConf.isAbapApp || !1;
        b.elementIdWithNonce = b.userConf.elementIdWithNonce || void 0;
        b.releaseId = b.userConf.releaseId || void 0;
        b.disableWrappingEventListeners =
          b.userConf.disableWrappingEventListeners || !1;
        b.disableUsingCauseStart = b.userConf.disableUsingCauseStart || !1;
        b.getAjaxResponseHeaders = b.userConf.getAjaxResponseHeaders || void 0;
        b.enableCoreWebVitals = !0 === b.userConf.enableCoreWebVitals;
        b.traceparentHeaderEnabled = !0 === b.userConf.traceparentHeaderEnabled;
        b.enableSpeedIndex = !0 === b.userConf.enableSpeedIndex;
      })(k || (k = {}));
      (function (a) {
        function b(b, f, m, p) {
          b =
            a.conf.beaconUrlHttps +
            "/eumcollector/error.gif?version=1&appKey=" +
            m +
            "&msg=" +
            encodeURIComponent(b.substring(0, 500));
          p &&
            ((b += "&stack="),
            (b += encodeURIComponent(p.substring(0, 1500 - b.length))));
          return b;
        }
        function e(f, m) {
          2 <= J ||
            ((document.createElement("img").src = b(f, 0, a.conf.appKey, m)),
            J++);
        }
        function c(a) {
          return (
            0 <= a.location.search.indexOf("ADRUM_debug=true") ||
            0 <= a.cookie.search(/(^|;)\s*ADRUM_debug=true/)
          );
        }
        function f(b, f) {
          void 0 === f && (f = z.INFO);
          a.isDebug && v.push("" + f + b);
        }
        function p(a) {
          f(t(arguments).join(" | "), z.ERROR);
        }
        function m(a) {
          f(t(arguments).join(" | "), z.INFO);
        }
        function n(a) {
          r.push(t(arguments).join(" | "));
        }
        function l(a) {
          var b = t(arguments).join(" | ");
          p(b);
          e(b, null);
        }
        function q(a) {
          void 0 === a && (a = z.INFO);
          return x(
            v,
            function (b, f) {
              var m = parseInt(f.charAt(0));
              m >= a &&
                (b +=
                  "[" +
                  z[m] +
                  "] " +
                  f.slice(1).replace(/\<br\/\>/g, "\n\t") +
                  "\n");
              return b;
            },
            "",
          );
        }
        var t = a.utils.La,
          x = a.utils.reduce,
          s = a.utils.isDefined;
        a.iDR = c;
        var z;
        (function (a) {
          a[(a.DEBUG = 0)] = "DEBUG";
          a[(a.INFO = 1)] = "INFO";
          a[(a.ERROR = 2)] = "ERROR";
        })((z = a.LOG_LVL || (a.LOG_LVL = {})));
        var k;
        (function (a) {
          a[(a.API_ERROR = 0)] = "API_ERROR";
          a[(a.API_ERROR_INVALID_PARAMS = 1)] = "API_ERROR_INVALID_PARAMS";
          a[(a.API_ERROR_INVALID_CONFIG = 2)] = "API_ERROR_INVALID_CONFIG";
          a[(a.API_WARNING = 3)] = "API_WARNING";
          a[(a.API_WARNING_INEFFECTIVE_CONFIG = 4)] =
            "API_WARNING_INEFFECTIVE_CONFIG";
        })((k = a.Z || (a.Z = {})));
        a.Yb = [
          "JS Agent API Error:",
          "JS Agent API Error Invalid Parameters: ",
          "JS Agent API Error Invalid Configs: ",
          "JS Agent API Warning:",
          "JS Agent API Warning Ineffective Config:",
        ];
        a.tb =
          " a constructor is called as a function. Don't forget keyword new.";
        a.isDebug = c(document);
        a.apiMessageConsoleOut =
          s(a.conf.userConf) &&
          s(a.conf.userConf.log) &&
          !0 === a.conf.userConf.log.apiMessageConsoleOut
            ? !0
            : !1;
        var v = [],
          r = [];
        a.logMessages = v;
        a.apiMessages = r;
        a.logError = p;
        a.logInfo = m;
        a.logDebug = function (a) {
          f(t(arguments).join(" | "), z.DEBUG);
        };
        a.lq = n;
        a.error = l;
        a.reportAPIMessage = function (b, f, m, p) {
          var l = a.Dn.apply(this, arguments);
          n(l);
          a.apiMessageConsoleOut && A.log(l);
          return l;
        };
        a.exception = function () {
          if (!(1 > arguments.length)) {
            var b = t(arguments),
              f = a.utils.tryExtractingErrorStack(b[0]),
              b = b.slice(1);
            a.utils.isArray(b) && (b = b.slice(0, 20));
            b = b.join(" | ");
            a.logError(b);
            e(b, f);
          }
        };
        a.assert = function (a) {
          for (var b = 1; b < arguments.length; b++);
          var f = t(arguments);
          a ||
            ((b = f[1]),
            (f = f.slice(2)) && 0 < f.length ? l("M4", b, f) : l("M5", b));
        };
        a.Tp = q;
        a.dumpLog = a.isDebug
          ? function (a) {
              void 0 === a && (a = z.INFO);
              A.log(q(a));
            }
          : function () {};
        a.Xf = 0;
        a.Yf = 0;
        a.U =
          a.isDebug && a.utils.refs.ta
            ? function () {
                a.Xf = a.utils.refs.ta.now();
              }
            : function () {};
        a.V =
          a.isDebug && a.utils.refs.ta
            ? function () {
                a.Yf += a.utils.refs.ta.now() - a.Xf;
              }
            : function () {};
        a.Dn = function (b, f, m, p) {
          var n = "",
            n = "",
            l = new window.Error().stack,
            c,
            l = a.utils.isString(l) ? l.substring(5) : l + "";
          s(c) ||
            (c = a.utils.map(p, function (a) {
              return null === a
                ? "null"
                : void 0 == a
                  ? "undefined"
                  : "" === a
                    ? "''"
                    : a;
            }));
          switch (b) {
            case k.wa:
            case k.mp:
              n = a.Yb[b];
              n = s(m)
                ? "" + n + f + "\n in " + m + "(" + c.join(", ") + ")\n" + l
                : "" + n + f + "\n" + l;
              break;
            case k.Pe:
              n = a.Yb[b];
              n = "" + n + f + "\nin " + m + "(" + c.join(", ") + ")\n" + l;
              break;
            case k.lp:
            case k.xi:
              n = a.Yb[b];
              n = "" + n + f + ", but " + m + "=" + c.join(", ") + "\n" + l;
              break;
            default:
              ((n = a.Yb[k.wa]),
                (n =
                  "" + n + f + "\nin " + m + "(" + c.join(", ") + ")\n" + l));
          }
          return n;
        };
        a.cIEBU = b;
        var J = 0;
        m("M6");
      })(k || (k = {}));
      (function (a) {
        var b = (function () {
            function a(b) {
              this.max = b;
              this.wd = 0;
            }
            a.prototype.am = function () {
              this.yc() || this.wd++;
            };
            a.prototype.yc = function () {
              return this.wd >= this.max;
            };
            a.prototype.reset = function () {
              this.wd = 0;
            };
            return a;
          })(),
          e = (function () {
            function c() {
              this.hc = [];
              this.ye = new b(c.wj);
              this.ee = new b(c.pj);
            }
            c.prototype.submit = function (b) {
              this.push(b) && a.initEXTDone && this.processQ();
            };
            c.prototype.processQ = function () {
              for (var b = this.Wk(), p = 0; p < b.length; p++) {
                var m = b[p];
                "function" === typeof a.commands[m[0]]
                  ? (a.isDebug && a.logInfo("M7", m[0], m.slice(1).join(", ")),
                    a.commands[m[0]].apply(a, m.slice(1)))
                  : a.error("M8", m[0]);
              }
            };
            c.prototype.Km = function (a) {
              return "reportXhr" === a || "reportPageError" === a;
            };
            c.prototype.push = function (b) {
              var p = b[0],
                m = this.Km(p),
                n = m ? this.ye : this.ee;
              if (n.yc())
                return (
                  a.logInfo("M9", m ? "spontaneous" : "non spontaneous", p),
                  !1
                );
              this.hc.push(b);
              n.am();
              return !0;
            };
            c.prototype.Wk = function () {
              var a = this.hc;
              this.reset();
              return a;
            };
            c.prototype.size = function () {
              return this.hc.length;
            };
            c.prototype.reset = function () {
              this.hc = [];
              this.ye.reset();
              this.ee.reset();
            };
            c.prototype.isSpontaneousQueueDead = function () {
              return this.ye.yc();
            };
            c.prototype.isNonSpontaneousQueueDead = function () {
              return this.ee.yc();
            };
            return c;
          })();
        e.wj = 100;
        e.pj = 100;
        a.CommandExecutor = e;
      })(k || (k = {}));
      (function (a) {
        a.q = new a.CommandExecutor();
        a.command = function (b) {
          for (var e = 1; e < arguments.length; e++);
          a.isDebug &&
            a.logInfo(
              "M10",
              b,
              Array.prototype.slice.call(arguments).slice(1).join(", "),
            );
          a.q.submit(Array.prototype.slice.call(arguments));
        };
      })(k || (k = {}));
      (function (a) {
        (function (a) {
          var e = (function () {
            function a() {
              this.status = {};
            }
            a.prototype.setUp = function () {};
            a.prototype.set = function (a, b) {
              this.status[a] = b;
            };
            return a;
          })();
          a.fd = e;
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        var b = a.utils.al,
          e = (function () {
            function c(a, b, m, n, l, c, e, x) {
              this.action = a || "";
              this.Ui = b || "";
              this.className = m || "";
              this.tagName = n || "";
              this.name = l || "";
              this.text = c || "";
              this.src = e;
              this.item = x;
            }
            c.Zm = function (f) {
              var p = b(f.id) || "",
                m = b(f.className) || "",
                n = "",
                l = new c();
              f instanceof HTMLHtmlElement
                ? ((n = "html"), (l.text = "#html"))
                : f === document
                  ? ((n = "document"), (l.text = "#document"))
                  : f === window
                    ? ((n = "window"), (l.text = "#window"))
                    : f instanceof XMLHttpRequest
                      ? ((n = "xhr"),
                        (l.src = a.utils.isObject(f._adrumAjaxT)
                          ? encodeURI(f._adrumAjaxT.url())
                          : ""))
                      : f instanceof WebSocket
                        ? ((n = "websocket"), (l.src = encodeURI(f.url)))
                        : f instanceof HTMLScriptElement
                          ? ((n = "script"), (l.src = encodeURI(f.src)))
                          : f instanceof HTMLAnchorElement
                            ? ((n = "a"), (l.text = b(f.text) || ""))
                            : f instanceof HTMLButtonElement
                              ? ((n = "button"), (l.name = b(f.name)))
                              : f instanceof HTMLDivElement
                                ? (n = "div")
                                : f instanceof HTMLImageElement
                                  ? ((n = "img"),
                                    (l.src = encodeURI(f.src)),
                                    (l.text = b(f.title) || ""))
                                  : f instanceof HTMLLIElement
                                    ? ((n = "li"), (l.item = f.value))
                                    : f instanceof HTMLUListElement
                                      ? (n = "ul")
                                      : f instanceof HTMLFormElement
                                        ? (n = "form")
                                        : f instanceof HTMLFrameElement
                                          ? ((n = "frame"),
                                            (l.src = encodeURI(f.src)))
                                          : f instanceof HTMLInputElement
                                            ? ((n = b(f.type) || "input"),
                                              (l.text = b(f.value)),
                                              (l.name = b(f.name)))
                                            : f instanceof HTMLTableElement
                                              ? (n = "table")
                                              : f instanceof
                                                  HTMLTableCaptionElement
                                                ? (n = "tcap")
                                                : f instanceof
                                                    HTMLTableCellElement
                                                  ? (n = "td")
                                                  : f instanceof
                                                      HTMLTableRowElement
                                                    ? (n = "tr")
                                                    : ((n = a.utils.isDefined(
                                                        f.tagName,
                                                      )
                                                        ? b(f.tagName)
                                                        : ""),
                                                      a.logInfo("M11", n));
              l.Ui = p;
              l.className = m;
              l.tagName = n;
              a.utils.isString(l.text) &&
                ((l.text = a.utils.isDefined(String.prototype.trim)
                  ? l.text.trim()
                  : l.text),
                (l.text = l.text.substring(0, 30)));
              return l;
            };
            return c;
          })();
        a.Ka = e;
      })(k || (k = {}));
      var g = k.utils.La,
        h = k.utils.isFunction;
      (function (a) {
        var b = a.utils.generateGUID,
          e;
        (function (a) {
          a[(a.USER = 0)] = "USER";
          a[(a.TIMER = 1)] = "TIMER";
          a[(a.XHR = 2)] = "XHR";
          a[(a.RESOURCE = 3)] = "RESOURCE";
          a[(a.PROMISE = 4)] = "PROMISE";
          a[(a.FETCH = 5)] = "FETCH";
          a[(a.BASE_PAGE_LOAD = 6)] = "BASE_PAGE_LOAD";
          a[(a.OTHER = 7)] = "OTHER";
        })((e = a.CauseType || (a.CauseType = {})));
        a.$g = 50;
        var c = (function () {
          return function (f, m, n) {
            this.start = a.utils.now();
            this.parent = f;
            this.Xc = m;
            this.guid = b();
            this.type = n;
          };
        })();
        a.$b = c;
        var f = (function () {
          function b() {}
          b.ig = function () {
            return b.events;
          };
          b.Gg = function (b) {
            return a.utils.isDefined(b) && a.utils.isFunction(b.handleEvent);
          };
          b.vk = function (b) {
            b = this.rl(b);
            var f = b.cl;
            b.count < a.$g || (f.parent = null);
          };
          b.rl = function (b) {
            var f = b;
            b = b.parent;
            for (var p = 1; b && p < a.$g; ) (p++, (f = b), (b = b.parent));
            return { count: p, cl: f };
          };
          b.eo = function () {
            this.de = !0;
          };
          b.uk = function (a) {
            this.de && ((a.parent = null), (this.de = !1));
          };
          b.sh = function (f, n, l, c) {
            var e,
              x = n.guid;
            b.ua(n);
            try {
              b.Gg(f)
                ? (e = f.handleEvent.apply(f, c))
                : h(f) && (e = f.apply(l, c));
            } catch (s) {
              throw (
                a.conf.ja &&
                  ((f = a.b.ig()),
                  (n = f.length),
                  s.stack && f && 0 < n && (s.stack += b.Yh(f[n - 1]))),
                s
              );
            } finally {
              b.Q(x);
            }
            return e;
          };
          b.cd = function (f, n, l, c) {
            if (!a.utils.isDefined(n) || n.L) return n;
            c = c || !1;
            var e,
              x = a.conf.ja ? a.utils.Sa(f) : "";
            c || (e = b.ra());
            return function (c) {
              var q = b.Qa(f, c, e, l);
              a.conf.ja && (q.oa = x);
              return b.sh(n, q, this, arguments);
            };
          };
          b.Qa = function (f, n, l, q) {
            l ? a.logInfo("M12", f, l.Xc.action) : a.logInfo("M13", f);
            a.utils.isDefined(n)
              ? ((n = a.Ka.Zm(n.target || n.srcElement)), (n.action = f))
              : (n = new a.Ka(f));
            f = new c(l, n, q);
            b.uk(f);
            b.vk(f);
            return f;
          };
          b.gp = function (f, n, l) {
            if (!a.utils.isDefined(n) || n.L) return n;
            var c = b.Qa(f, void 0, b.ra(), l),
              e = a.conf.ja ? a.utils.Sa(f) : "";
            return function () {
              new a.Ka(f);
              a.conf.ja && (c.oa = e);
              return b.sh(n, c, this, arguments);
            };
          };
          b.Gq = function (a, f) {
            return function () {
              var l = f.apply(this, arguments);
              b.rd(a);
              return l;
            };
          };
          b.ra = function () {
            return 0 < b.events.length ? b.events[b.events.length - 1] : null;
          };
          b.ua = function (a) {
            b.events.push(a);
          };
          b.Q = function (a) {
            var f = b.events,
              l = f.length,
              c = null;
            if (a)
              for (l -= 1; 0 <= l; l--)
                if (a === f[l].guid) return ((c = b.events.splice(l, 1)), c[0]);
            return b.events.pop();
          };
          b.sd = function (b, f) {
            var p = b,
              c = 1,
              e = "";
            if (!a.utils.isDefined(p)) return null;
            for (; a.utils.isDefined(p.parent); )
              ((e = " -> " + p.Xc.action + e), (p = p.parent), (c += 1));
            var x = a.utils.now();
            a.utils.isDefined(p.Xc) && (e = p.Xc.action + e + " -> " + f);
            a.logInfo("M14", e);
            a.logInfo("M15", p.start, c);
            a.logInfo("M16", x - p.start);
            return p;
          };
          b.rd = function (a) {
            return b.sd(b.ra(), a);
          };
          b.Yh = function (b) {
            var f = "";
            if (a.utils.isDefined(b)) {
              for (; a.utils.isDefined(b.parent); )
                (b.oa && (f = f + "\n" + b.oa), (b = b.parent));
              f += b.oa ? "\n" + b.oa : "";
            }
            return f;
          };
          b.Ql = function () {
            var f = b.rd(void 0);
            if (a.utils.isDefined(f) && a.utils.isDefined(f.type))
              return [e.TIMER, e.USER].some(function (a) {
                return f.type == a;
              })
                ? f
                : void 0;
          };
          b.pm = function (a) {
            if (h(a)) return a;
            var b = "" + a;
            return function () {
              eval.call(window, b);
            };
          };
          b.setUp = function () {
            b.events = [];
            var f = a.utils.refs;
            [
              { ih: f.setTimeout, dg: "setTimeout" },
              { ih: f.setInterval, dg: "setInterval" },
            ].forEach(function (a) {
              var f = a.ih,
                m = a.dg;
              window[m] = function (a) {
                var n = g(arguments);
                if (a) {
                  if (a.usedByAgent) return f.apply(window, n);
                  var c = b.Nm(m, arguments[1]) ? e.OTHER : e.TIMER,
                    c = b.gp(m, b.pm(a), c);
                  n[0] = c;
                  return f.apply(window, n);
                }
                f.apply(window, n);
              };
            });
            a.conf.ja &&
              ((f = b.Qa("pageLoadInit", null, null, e.BASE_PAGE_LOAD)),
              b.ua(f),
              (b.Na = f.guid));
          };
          b.Nm = function (b, f) {
            return (
              "setTimeout" == b &&
              ((a.utils.isDefined(f) && 0 == f) || !a.utils.isDefined(f))
            );
          };
          return b;
        })();
        f.events = [];
        f.Na = "";
        f.de = !1;
        a.b = f;
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.La,
            c = a.utils.isDefined;
          window.ADRUM.aop = b;
          b.support = function (a) {
            return !a || "apply" in a;
          };
          b.around = function (f, p, m, n, l) {
            a.assert(b.support(f), "M17");
            f = f || function () {};
            return function () {
              if (a.isDebug)
                try {
                  a.logInfo("M18", n, e(arguments).join(", "));
                } catch (b) {
                  a.logError("M19", c(b.stack) || b.toString());
                }
              var t = e(arguments),
                x,
                s = null;
              try {
                if (p && (x = p.apply(this, t))) {
                  var z = a.utils.Fl(x),
                    s = x[z];
                  -1 !== z && x.splice(z, 1);
                }
              } catch (k) {
                a.exception(k, "M20", n, k);
              }
              a.assert(!x || a.utils.isArray(x));
              z = void 0;
              try {
                z = f.apply(this, x || t);
              } catch (v) {
                throw (
                  a.logInfo(v, "M21", n, v),
                  a.conf.ja &&
                    a.b &&
                    ((t = a.b.ig()),
                    (x = t.length),
                    v.stack && 0 < x && (v.stack += a.b.Yh(t[x - 1]))),
                  l && l(v),
                  v
                );
              } finally {
                try {
                  m &&
                    (s
                      ? ((s.adrumArgs.origFuncResult = z), t.push(s))
                      : c(z) &&
                        ((s = { adrumArgs: { origFuncResult: z } }), t.push(s)),
                    m.apply(this, t));
                } catch (r) {
                  a.exception(r, "M22", n, r);
                }
              }
              return z;
            };
          };
          b.before = function (a, p, m) {
            return b.around(a, p, null, m);
          };
          b.after = function (a, p, m) {
            return b.around(a, null, p, m);
          };
          b.forceWrap = function (b) {
            var p = b.customDescriptorConfig || {},
              m = null,
              n = b.parentObject,
              l = b.property,
              q = b.setUpFunc,
              e = b.wrapNewFunctionAgain || !1,
              x = b.propertyWrappedFunctionName;
            if (n && l) {
              m = Object.getOwnPropertyDescriptor(n, l);
              if (!m || m.configurable) {
                m
                  ? (delete m.writable, delete m.value)
                  : (m = { configurable: !0, enumerable: !0 });
                var s = m.set,
                  z = m.get;
                m.set =
                  p.set ||
                  function (m) {
                    !0 !== m.usedByAgent &&
                      (c(s) && s(arguments),
                      (c(b.bb) && !e) || !a.utils.isFunction(q) || q(m));
                  };
                m.get =
                  p.get ||
                  function () {
                    var m = z ? z() : a.utils.refs[x];
                    c(b.bb) && (m = b.bb);
                    return m;
                  };
              } else a.logInfo("M23", x);
              Object.defineProperty(n, l, m);
            } else a.error("M24");
          };
        })(a.aop || (a.aop = {}));
      })(k || (k = {}));
      (function (a) {
        a = a.EventType || (a.EventType = {});
        a[(a.PageView = 0)] = "PageView";
        a[(a.Ajax = 2)] = "Ajax";
        a[(a.VPageView = 3)] = "VPageView";
        a[(a.Error = 4)] = "Error";
        a[(a.WebVital = 5)] = "WebVital";
        a[(a.IFRAME = 1)] = "IFRAME";
        a[(a.ABSTRACT = 100)] = "ABSTRACT";
        a[(a.ADRUM_XHR = 101)] = "ADRUM_XHR";
        a[(a.NG_VIRTUAL_PAGE = 102)] = "NG_VIRTUAL_PAGE";
      })(k || (k = {}));
      (function (a) {
        var b = a.events || (a.events = {});
        b.K = {};
        b.K[a.EventType.ABSTRACT] = {
          guid: "string",
          url: "string",
          parentGUID: "string",
          parentUrl: "string",
          parentType: "number",
          parentPageName: "string",
          timestamp: "number",
        };
        b.K[a.EventType.VPageView] = { resTiming: "object" };
        b.K[a.EventType.NG_VIRTUAL_PAGE] = { digestCount: "number" };
        b.K[a.EventType.Ajax] = {
          method: "string",
          parentPhase: "string",
          parentPhaseId: "number",
          error: "object",
          parameter: "object",
          xhrStatus: "number",
          dataObject: "object",
        };
        b.K[a.EventType.ADRUM_XHR] = { allResponseHeaders: "string" };
        b.K[a.EventType.Error] = {
          msg: "string",
          line: "number",
          stack: "string",
        };
        b.K[a.EventType.WebVital] = { coreWebVitalsMetrics: "object" };
      })(k || (k = {}));
      (function (a) {
        var b = (function () {
          function a() {
            this.entries = {};
          }
          a.prototype.mark = function (a, b) {
            e.mark.apply(this, arguments);
          };
          a.prototype.getTiming = function (a) {
            return (a = this.getEntryByName(a)) && a.startTime;
          };
          a.prototype.measure = function (a, b, m) {
            e.measure.apply(this, arguments);
          };
          a.prototype.getEntryByName = function (a) {
            return e.getEntryByName.call(this, a);
          };
          return a;
        })();
        b.vd = function (a) {
          return e.vd(a);
        };
        a.PerformanceTracker = b;
        var e;
        (function (b) {
          var f = a.utils.hasOwnPropertyDefined,
            p = a.utils.fb(),
            m = a.utils.now;
          b.mark = function (b, f) {
            this.entries[b] = {
              name: b,
              entryType: "mark",
              startTime: a.utils.isDefined(f) ? f : m(),
              duration: 0,
            };
          };
          b.measure = function (b, l, c) {
            f(this.entries, l) && f(this.entries, c)
              ? (this.entries[b] = {
                  name: b,
                  entryType: "measure",
                  startTime: l ? this.entries[l].startTime : p,
                  duration:
                    (c ? this.entries[c].startTime : m()) -
                    (l ? this.entries[l].startTime : p),
                })
              : a.error("M25", f(this.entries, l) ? c : l);
          };
          b.getEntryByName = function (a) {
            return this.entries[a] || null;
          };
          b.vd = function (a) {
            return a + p;
          };
        })(e || (e = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          function e(b, f) {
            b = b || {};
            for (var n in b)
              f[n] = (function () {
                var f = n,
                  m = b[n];
                return function (b) {
                  var p = "_" + f,
                    n = this[p];
                  if (a.utils.isDefined(b))
                    if (typeof b === m) this[p] = b;
                    else
                      throw (
                        (p =
                          "wrong type of " +
                          f +
                          " value, " +
                          typeof b +
                          " passed in but should be a " +
                          m +
                          "."),
                        a.reportAPIMessage(
                          a.Z.Pe,
                          p,
                          "ADRUM.report",
                          Array.prototype.slice.call(arguments),
                        ),
                        TypeError(p)
                      );
                  return n;
                };
              })();
          }
          function c(a) {
            var b = {},
              f;
            for (f in a) {
              var l = a[f];
              b[l.start] = !0;
              b[l.end] = !0;
            }
            return b;
          }
          var f = (function () {
            function b(f) {
              this.perf = new a.PerformanceTracker();
              "Object" === this.constructor.name &&
                a.reportAPIMessage(a.Z.wa, a.tb);
              this.timestamp(a.utils.now());
              this.guid(a.utils.generateGUID());
              this.url(document.URL);
              this.Sc(f);
            }
            b.prototype.type = function () {
              return a.EventType.ABSTRACT;
            };
            b.prototype.Sc = function (b) {
              if (a.utils.isObject(b))
                for (var f in b) {
                  var p = this[f] || this["mark" + a.utils.Hf(f)];
                  p && a.utils.isFunction(p) && p.call(this, b[f]);
                }
            };
            b.od = function (a, b, f) {
              return {
                guid: function () {
                  return a;
                },
                url: function () {
                  return b;
                },
                type: function () {
                  return f;
                },
              };
            };
            b.prototype.Il = function () {
              return b.od(
                this.parentGUID(),
                this.parentUrl(),
                this.parentType(),
              );
            };
            b.prototype.parent = function (b) {
              var f = this.Il();
              a.utils.isDefined(b) &&
                (a.utils.isFunction(b.guid) &&
                a.utils.isFunction(b.url) &&
                a.utils.isFunction(b.type)
                  ? (this.parentGUID(b.guid()),
                    this.parentUrl(b.url()),
                    this.parentType(b.type()))
                  : a.reportAPIMessage(
                      a.Z.wa,
                      "object is not a valid EventIdentifier",
                      "EventTracker.parent",
                      Array.prototype.slice.call(arguments),
                    ));
              return f;
            };
            return b;
          })();
          b.EventTracker = f;
          b.Ma = e;
          b.Bf = function (b, f) {
            b = b || {};
            var n = c(b),
              l;
            for (l in n)
              ((n = a.utils.Hf(l)),
                (f["mark" + n] = a.utils.jh(function (a, b) {
                  this.perf.mark(a, b);
                }, l)),
                (f["get" + n] = a.utils.jh(function (a) {
                  return this.perf.getTiming(a);
                }, l)));
          };
          e(b.K[a.EventType.ABSTRACT], f.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (b) {
            function f(p) {
              p = b.call(this, p) || this;
              p.constructor != f &&
                a.reportAPIMessage(a.Z.wa, a.tb, "ADRUM.events.Error", []);
              return p;
            }
            u(f, b);
            f.prototype.type = function () {
              return a.EventType.Error;
            };
            return f;
          })(b.EventTracker);
          b.Error = e;
          b.Ma(b.K[a.EventType.Error], e.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function b() {}
            b.setUp = function () {
              b.perf = a.utils.refs.ta;
              (a.utils.isObject(b.perf) && a.utils.isObject(b.perf.timing)) ||
                (b.perf = void 0);
            };
            return b;
          })();
          e.perf = null;
          b.PerformanceWrapper = e;
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function c() {
              this.navTiming = null;
            }
            c.prototype.Of = function () {
              var f = b.PerformanceWrapper.perf;
              if ((f = f && f.timing))
                if (f.navigationStart && f.navigationStart <= f.loadEventEnd) {
                  var p = {},
                    m;
                  for (m in f) {
                    var n = f[m];
                    "number" === typeof n && (p[m] = n);
                  }
                  this.navTiming = p;
                } else a.logInfo("M27");
              else a.logInfo("M26");
            };
            c.prototype.setUp = function () {
              b.PerformanceWrapper.setUp();
            };
            return c;
          })();
          b.NavTimingMonitor = e;
          b.navMonitor = new b.NavTimingMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function c() {
              this.le = null;
              b.PerformanceWrapper.setUp();
              this.resourceBuffer = [];
              this.basePageResourceBuffer = [];
              this.jf = 500;
              this.jd = 150;
              this.Fj = 3e3;
              this.setResourceTimingBufferSize();
              this.fo();
            }
            c.prototype.setUp = function () {
              b.PerformanceWrapper.setUp();
              a.utils.isDefined(b.PerformanceWrapper.perf) &&
              a.utils.isFunction(b.PerformanceWrapper.perf.getEntriesByType)
                ? a.utils.isFunction(b.PerformanceWrapper.perf.addEventListener)
                  ? b.PerformanceWrapper.perf.addEventListener(
                      "resourcetimingbufferfull",
                      this.Cb.bind(this),
                    )
                  : "onresourcetimingbufferfull" in b.PerformanceWrapper.perf
                    ? a.utils.isFunction(b.PerformanceWrapper.perf.ke)
                      ? (b.PerformanceWrapper.perf.ke = a.aop.around(
                          b.PerformanceWrapper.perf.ke,
                          this.Cb.bind(this),
                        ))
                      : (b.PerformanceWrapper.perf.ke = this.Cb.bind(this))
                    : a.utils.refs.setInterval.call(
                        window,
                        this.Rn.bind(this),
                        this.Fj,
                      )
                : a.logInfo("M28");
              this.lo();
              this.Sn();
            };
            c.prototype.lo = function () {
              var f =
                a.conf.userConf &&
                a.conf.userConf.resTiming &&
                a.conf.userConf.resTiming.bufSize;
              a.utils.isDefined(b.PerformanceWrapper.perf) &&
                a.utils.isFunction(
                  b.PerformanceWrapper.perf.setResourceTimingBufferSize,
                ) &&
                a.utils.isNumber(f) &&
                0 < f &&
                (this.jd = f);
            };
            c.prototype.Sn = function () {
              var f = b.PerformanceWrapper.perf;
              a.utils.isDefined(f) &&
                (a.utils.isFunction(f.setResourceTimingBufferSize) &&
                  (f.setResourceTimingBufferSize = a.aop.around(
                    f.setResourceTimingBufferSize,
                    function () {
                      a.utils.isDefined(arguments) &&
                        a.utils.isDefined(arguments[0]) &&
                        (this.jd = arguments[0]);
                    }.bind(this),
                  )),
                a.utils.isFunction(f.clearResourceTimings) &&
                  (f.clearResourceTimings = a.aop.around(
                    f.clearResourceTimings,
                    function () {
                      this.Cb();
                    }.bind(this),
                  )));
            };
            c.prototype.Nf = function () {
              this.basePageResourceBuffer = this.fg();
            };
            c.prototype.Cb = function () {
              this.resourceBuffer = this.fg();
            };
            c.prototype.Rn = function () {
              this.Ib().length >= this.jd && this.Cb();
            };
            c.prototype.Ib = function () {
              var f = b.PerformanceWrapper.perf,
                p = [];
              f &&
                f.getEntriesByType &&
                (f = f.getEntriesByType("resource")) &&
                f.length &&
                0 < f.length &&
                f.unshift &&
                (p = f);
              0 == p.length && a.logInfo("M29");
              return p;
            };
            c.prototype.Ml = function (b, p) {
              return a.utils.filter(this.resourceBuffer, function (a) {
                return b + a.startTime >= p;
              });
            };
            c.prototype.Nl = function (a, b) {
              this.resourceBuffer = this.resourceBuffer.concat(this.Ib());
              var m = this.Ml(a, b);
              this.clearResourceTimings();
              this.resourceBuffer = [];
              return m;
            };
            c.prototype.fo = function () {
              var f = b.PerformanceWrapper.perf;
              a.utils.isDefined(f) &&
                a.utils.isFunction(f.clearResourceTimings) &&
                (this.le = f.clearResourceTimings.bind(f));
            };
            c.prototype.setResourceTimingBufferSize = function () {
              var f = b.PerformanceWrapper.perf,
                p =
                  a.conf.userConf &&
                  a.conf.userConf.resTiming &&
                  a.conf.userConf.resTiming.bufSize;
              !a.utils.isNumber(p) || 0 >= p
                ? a.logInfo("M30")
                : f && a.utils.isFunction(f.setResourceTimingBufferSize)
                  ? f.setResourceTimingBufferSize(p)
                  : a.logInfo("M31");
            };
            c.prototype.fg = function () {
              var b = this.Ib();
              if (this.resourceBuffer.length + b.length > this.jf)
                return (
                  a.logInfo("M32"),
                  this.resourceBuffer.concat(
                    b.slice(0, this.jf - this.resourceBuffer.length),
                  )
                );
              this.clearResourceTimings();
              return this.resourceBuffer.concat(b);
            };
            c.prototype.clearResourceTimings = function () {
              a.conf.clearResTiming && a.utils.isFunction(this.le) && this.le();
            };
            return c;
          })();
          b.ResourceMonitor = e;
          b.resourceMonitor = new b.ResourceMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (a) {
          function e(a) {
            return a.nodeName.toLowerCase();
          }
          function c(a) {
            return "video" == e(a);
          }
          function f(a) {
            return "image" == e(a);
          }
          function p(a) {
            return "svg" == e(a);
          }
          function m(a) {
            return "use" == e(a);
          }
          function n(a) {
            return a
              ? 0 === a.lastIndexOf("video/", 0) ||
                  0 === a.lastIndexOf("image/", 0) ||
                  0 === a.lastIndexOf("font/", 0) ||
                  0 === a.lastIndexOf("model/", 0) ||
                  0 === a.lastIndexOf("text/", 0)
              : !1;
          }
          function l(a) {
            return (
              "embed" == e(a) &&
              (a.type ? n(a.type) : n(a.getAttribute("type")))
            );
          }
          function q(a) {
            return (
              "object" == e(a) &&
              (a.type ? n(a.type) : n(a.getAttribute("type")))
            );
          }
          function t(a) {
            return "img" == e(a);
          }
          function x(a) {
            return "script" == e(a);
          }
          function s(a) {
            return "link" == e(a);
          }
          function z(f, m) {
            if (!s(f)) return !1;
            var p = f.attributes.getNamedItem("rel");
            return a.isDefined(p) ? p.value == m : !1;
          }
          function k(a) {
            return z(a, "stylesheet");
          }
          function v(f) {
            f = a.isDefined(f.attributes)
              ? f.attributes.getNamedItem("src") ||
                f.attributes.getNamedItem("href")
              : void 0;
            return a.isDefined(f) ? f.value : void 0;
          }
          function r(a) {
            return x(a) || k(a);
          }
          a.El = e;
          a.Ng = c;
          a.fq = f;
          a.eq = p;
          a.Jg = m;
          a.Eg = function (a) {
            return "canvas" == e(a);
          };
          a.Lg = function (f) {
            return f instanceof a.refs.Nj;
          };
          a.cq = n;
          a.hg = function (a) {
            return (a.right - a.left) * (a.bottom - a.top);
          };
          a.bq = l;
          a.dq = q;
          a.zm = t;
          a.Im = x;
          a.Zp = s;
          a.$p = z;
          a.Mm = k;
          a.Fm = function (a) {
            return z(a, "preload");
          };
          a.ib = function (a) {
            return t(a) || q(a) || l(a) || c(a) || f(a) || p(a) || m(a);
          };
          a.Lb = function (a, b) {
            var f = b || window.getComputedStyle(a);
            return (
              "none" !== f.getPropertyValue("display") &&
              "hidden" !== f.getPropertyValue("visibility")
            );
          };
          a.Qd = function (a) {
            var b = "";
            a instanceof HTMLImageElement
              ? (b = a.currentSrc || a.src)
              : a instanceof HTMLEmbedElement
                ? (b = a.src)
                : a instanceof HTMLObjectElement
                  ? (b = a.data)
                  : "undefined" != typeof HTMLVideoElement &&
                      a instanceof HTMLVideoElement
                    ? (b = a.currentSrc || a.src)
                    : a instanceof SVGImageElement
                      ? (b = a.href.baseVal)
                      : a instanceof SVGUseElement && (b = a.href.baseVal);
            return b;
          };
          a.Up = function (a) {
            var b = "";
            a instanceof HTMLImageElement
              ? (b = "img")
              : a instanceof HTMLEmbedElement
                ? (b = "embed")
                : a instanceof HTMLObjectElement
                  ? (b = "object")
                  : "undefined" != typeof HTMLVideoElement &&
                      a instanceof HTMLVideoElement
                    ? (b = "video")
                    : a instanceof SVGImageElement
                      ? (b = "image")
                      : a instanceof SVGUseElement && (b = "use");
            return b;
          };
          a.gb = v;
          a.tc = function (f) {
            var m = v(f);
            return m && 0 != m.length
              ? r(f)
                ? (a.isDefined(f.adrumNodeGUID) ||
                    (f.adrumNodeGUID = a.generateGUID()),
                  f.adrumNodeGUID)
                : m
              : null;
          };
          a.aq = r;
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        var b = (function () {
          function b() {
            this.qm = 0.2;
            this.rb = 0;
            this.Kb = !1;
            this.Pa = a.conf.spa2;
            this.qb = this.A = this.c = this.Aa = 0;
            this.ea = [];
            this.Nc = [];
            this.Ec = this.j = this.ka = 0;
            this.eb = null;
            this.pc = 0;
            this.zc = !1;
            this.yd = 3;
            this.sc = null;
            this.$c = this.ad = 0;
            this.viewport = {
              top: 0,
              left: 0,
              bottom: this.$c,
              right: this.ad,
            };
            this.Va = 1;
          }
          b.prototype.setUp = function () {
            this.P = {};
            this.Nb = {};
            this.Va = 1;
            this.ka = a.utils.now();
            this.j = 0;
            this.Mb = [];
            this.Ab = [];
            this.Fb = [];
            this.A = this.c = this.Ec = 0;
            var b = window.MutationObserver;
            this.zc = a.utils.isDefined(a.conf.considerCarouselForVCT)
              ? a.conf.considerCarouselForVCT
              : !0;
            this.Mf();
            a.utils.addEventListener(
              window,
              "resize",
              a.utils.Ok(this.Mf).bind(this),
            );
            a.utils.isDefined(b) &&
              (a.utils.isDefined(window.Zone) &&
              a.utils.isDefined(window.Zone.__symbol__) &&
              a.utils.isDefined(window.Zone.__symbol__("MutationObserver"))
                ? (this.Hc = new window[
                    window.Zone.__symbol__("MutationObserver")
                  ](this.fh.bind(this)))
                : (this.Hc = new b(this.fh.bind(this))),
              this.Hc.observe(document.documentElement, {
                childList: !0,
                subtree: !0,
                attributes: !0,
                attributeFilter: ["src", "href"],
              }),
              a.logInfo("M33"));
          };
          b.prototype.fh = function (b) {
            var f = this;
            a.U();
            b.forEach(function (a) {
              switch (a.type) {
                case "childList":
                  [].slice.call(a.addedNodes).forEach(function (a) {
                    f.Ef(a);
                  });
                  break;
                case "attributes":
                  f.Ef(a.target);
              }
            });
            a.V();
          };
          b.prototype.Mf = function () {
            this.ad =
              a.utils.isDefined(window.innerWidth) &&
              a.utils.isDefined(document.documentElement.clientWidth)
                ? Math.min(
                    window.innerWidth,
                    document.documentElement.clientWidth,
                  )
                : window.innerWidth ||
                  document.documentElement.clientWidth ||
                  document.getElementsByTagName("body")[0].clientWidth;
            this.$c =
              a.utils.isDefined(window.innerHeight) &&
              a.utils.isDefined(document.documentElement.clientHeight)
                ? Math.min(
                    window.innerHeight,
                    document.documentElement.clientHeight,
                  )
                : window.innerHeight ||
                  document.documentElement.clientHeight ||
                  document.getElementsByTagName("body")[0].clientHeight;
            a.logInfo("M34", this.ad, this.$c);
            this.viewport = {
              top: 0,
              left: 0,
              bottom: this.$c,
              right: this.ad,
            };
          };
          b.prototype.start = function () {
            a.U();
            this.setUp();
            a.V();
            a.logInfo("M35");
          };
          b.prototype.reset = function () {
            this.P = {};
            this.j = this.rb = 0;
            this.Nb = {};
            this.Va = 1;
            this.Ec = 0;
            this.Mb = [];
            this.sc = null;
            this.yd = 3;
            this.A = this.qb = this.c = 0;
            this.Ab = [];
            this.Fb = [];
            this.zc = a.utils.isDefined(a.conf.considerCarouselForVCT)
              ? a.conf.considerCarouselForVCT
              : !0;
            this.ea = [];
            this.Nc = [];
            a.logInfo("M36");
          };
          b.prototype.Ef = function (b) {
            a.U();
            var f = a.utils.now();
            if (a.utils.Jg(b) || !a.utils.ib(b) || b.isAdrumTrackedNode)
              a.utils.Eg(b) && !b.adrumNodeId
                ? (a.logInfo("M41"), this.zb(b, f))
                : a.utils.Lg(b) && (this.rb = Math.max(this.rb, f));
            else {
              this.Kb ||
                ((this.O = this.O.bind(this)),
                (this.B = this.B.bind(this)),
                (this.O.L = !0),
                (this.Kb = this.B.L = !0));
              this.j++;
              a.logInfo("M37", this.j);
              var p = a.utils.gb(b);
              a.logInfo("M38", p, f);
              a.utils.Ng(b)
                ? (b.addEventListener("loadeddata", this.O),
                  a.logInfo("M39", p))
                : (b.addEventListener("load", this.O), a.logInfo("M40", p));
              b.addEventListener("error", this.B);
              b.isAdrumTrackedNode = !0;
            }
            a.V();
          };
          b.prototype.O = function (b) {
            a.U();
            var f = a.utils.now();
            this.pc || (this.pc = f);
            this.ka = f;
            b = b.target;
            var p = a.utils.Qd(b);
            this.Ec++;
            this.zc && this.Vn();
            a.utils.isDefined(p) && 0 < p.length
              ? "data:" != p.substring(0, 5) || b.adrumNodeId
                ? this.$j(p, f, b)
                : (a.logInfo("M42"), this.zb(b, f))
              : b instanceof SVGElement &&
                !b.adrumNodeId &&
                (a.logInfo("M43"), this.zb(b, f));
            b &&
              b.isAdrumTrackedNode &&
              (this.Qb(b), this.j--, a.logInfo("M44", this.j));
            a.V();
          };
          b.prototype.B = function (b) {
            var f = b.target;
            f &&
              f.isAdrumTrackedNode &&
              (this.Qb(f),
              this.j--,
              (b = a.utils.Qd(b.target)),
              a.logInfo("M45", b));
          };
          b.prototype.Qb = function (a) {
            a.removeEventListener("load", this.O);
            a.removeEventListener("error", this.B);
          };
          b.prototype.wc = function (b) {
            return this.T(b) && a.utils.Lb(b);
          };
          b.prototype.$j = function (b, f, p) {
            a.utils.isDefined(this.P[b])
              ? this.wc(p) &&
                ((this.P[b] = { da: f, element: p }), a.logInfo("M46", b, f))
              : ((this.P[b] = { da: f, element: p }), a.logInfo("M47", b, f));
          };
          b.prototype.zb = function (b, f) {
            a.logInfo("M48", this.Va, f, b.outerHTML);
            b.adrumNodeId = this.Va;
            this.Nb[this.Va] = { da: f, element: b };
            this.Va += 1;
          };
          b.prototype.hn = function () {
            var a = 2,
              b = 3;
            return function () {
              var p = b + a;
              a = b;
              return (b = p);
            };
          };
          b.prototype.vm = function () {
            this.sc = this.sc || this.hn();
            return this.Ec >= this.yd ? ((this.yd = this.sc()), !0) : !1;
          };
          b.prototype.Vn = function () {
            var b = this;
            this.vm()
              ? (this.ec(this.P),
                this.ec(this.Nb),
                clearTimeout(this.eb),
                (this.eb = null))
              : b.eb ||
                (b.eb = a.utils.refs.setTimeout.call(
                  window,
                  function () {
                    b.ec(b.P);
                    b.ec(b.Nb);
                    clearTimeout(b.eb);
                    b.eb = null;
                  },
                  2e3,
                ));
          };
          b.prototype.ec = function (a) {
            for (var b = Object.keys(a), p = b.length, m = 0; m < p; m++) {
              var n = a[b[m]],
                l = this.Nd(n.element),
                q = l.top + "-" + l.right + "-" + l.bottom + "-" + l.left;
              n.Gd
                ? 30 >= n.nc.length && (n.nc.push(l), (n.Eb = n.Eb + "|" + q))
                : ((n.Gd = window.getComputedStyle(n.element)),
                  (n.nc = [l]),
                  (n.Eb = q),
                  (n.T = this.T(n.element)));
            }
          };
          b.prototype.Fg = function (b, f) {
            if (!a.conf.considerCarouselForVCT) return !1;
            var p = !1,
              m = f.Eb;
            if (m) {
              var m = m.split("|"),
                n = m.length;
              if (n) {
                var l = 0,
                  q = null,
                  e = this.Nd(b);
                2 == n &&
                  ((q = e.top + "-" + e.right + "-" + e.bottom + "-" + e.left),
                  m.push(q),
                  n++);
                for (
                  var x = 0;
                  x < n - 1 && !(m[x] !== m[x + 1] && (l++, 2 <= l));
                  x++
                );
                2 <= l &&
                  (this.Mb.push(f),
                  (p = !0),
                  q && ((f.Eb = f.Eb + "|" + q), f.nc.push(e)));
              }
            }
            return p;
          };
          b.prototype.Kk = function (a) {
            for (
              var b = a.length, p = [], m = [], n = [], l = [], q = 0;
              q < b;
              q++
            ) {
              var e = a[q],
                x = e.nc,
                s = x[0],
                x = x[x.length - 1];
              s &&
                x &&
                (50 < Math.abs(s.left - x.left)
                  ? 50 < Math.abs(s.right - x.right)
                    ? m.push(e)
                    : l.push(e)
                  : 50 < Math.abs(s.top - x.top)
                    ? 50 < Math.abs(s.bottom - x.bottom)
                      ? n.push(e)
                      : l.push(e)
                    : l.push(e));
            }
            l.length && (this.Fb = l);
            this.Pf(m, p);
            this.Pf(n, p);
            p.length && (this.Ab = p);
          };
          b.prototype.tl = function (a, b) {
            for (var p = [], m = 0; m < a.length; m++) {
              for (
                var n = !0, l = a[m].element.classList, q = 0;
                q < b.length;
                q++
              )
                if (!l.contains(b[m])) {
                  n = !1;
                  break;
                }
              n && (p.push(a[m]), a.splice(m, 1), m--);
            }
            return p;
          };
          b.prototype.Pf = function (a, b) {
            for (var p = 0; p < a.length; p++)
              b.push(this.tl(a, a[0].element.classList));
          };
          b.prototype.Uo = function (b, f, p, m) {
            b.adrumConsiderForVCT &&
              ((this.c = Math.max(this.c, p - m)),
              this.Ha(this.ea, { element: b, X: p - m }),
              a.logInfo("M49", f, this.c));
            delete b.adrumConsiderForVCT;
          };
          b.prototype.Qo = function (b, f, p, m) {
            var n = this.pg(f);
            a.utils.isDefined(n) &&
              ((p = n.startTime - (p - this.Aa)),
              (m = n.duration * m + p),
              a.logInfo("M50", f, m),
              a.logInfo("M51", n.duration, p),
              this.Pa &&
                ((this.A = Math.max(this.A, m)), a.logInfo("M52", f, this.A)),
              (0 >= this.pc || m < this.pc) &&
                this.T(b) &&
                ((this.c = Math.max(this.c, m)), a.logInfo("M53", f, a.c)),
              this.T(b) && this.Ha(this.ea, { element: b, X: m }));
          };
          b.prototype.Ro = function (b, f) {
            var p = this.Nb[b.adrumNodeId];
            if (a.utils.isDefined(p)) {
              var m = p.da;
              a.utils.Lb(b, p.Gd) &&
                (this.Pa &&
                  ((this.A = Math.max(this.A, m - f)),
                  a.logInfo("M54", b.adrumNodeId, m)),
                !this.Fg(b, p) &&
                  this.T(b) &&
                  (a.utils.isDefined(b.adrumConsiderForVCT)
                    ? (b.adrumConsiderForVCT &&
                        ((this.c = Math.max(this.c, m - f)),
                        this.Ha(this.ea, { element: b, X: m - f }),
                        a.logInfo(
                          "Element without src and from DOMObserver - VCT ",
                          this.c,
                        )),
                      delete b.adrumConsiderForVCT)
                    : ((this.c = Math.max(this.c, m - f)),
                      this.Ha(this.ea, { element: b, X: m - f }),
                      a.logInfo(
                        "Element without src and from Mutation Observer - VCT",
                        this.c,
                      )),
                  a.logInfo("M55", b.adrumNodeId, m)));
            }
            delete b.adrumNodeId;
          };
          b.prototype.Dl = function (a, b) {
            for (var p = a.length, m, n, l = 0, q = 0; q < p; q++)
              if (((n = a[q]), (m = n.element), b.push(n.da), n.T || this.T(m)))
                (l++, this.Ha(this.Nc, { element: m, da: n.da }));
            return l;
          };
          b.prototype.Al = function (a) {
            var b = [],
              p = 0;
            if ((a = this.Dl(a, b))) (b.sort(), (p = b[a - 1]));
            return p;
          };
          b.prototype.So = function (a) {
            for (var b = this.Ab.length, p = 0; p < b; p++) {
              var m = this.Al(this.Ab[p]);
              m && (this.c = Math.max(this.c, m - a));
            }
          };
          b.prototype.Oo = function (b, f) {
            var p = this;
            this.ol().forEach(function (m) {
              var n = m.url,
                l = m.wc,
                q = p.pg(n);
              a.utils.isDefined(q) &&
                ((q = q.duration * f + (q.startTime - (b - p.Aa))),
                p.Pa && (a.logInfo("M56", n, q), (p.A = Math.max(p.A, q))),
                l &&
                  (a.logInfo("M57", n, q),
                  (p.c = Math.max(p.c, q)),
                  p.Ha(p.ea, { element: m.element, X: q })));
            });
          };
          b.prototype.Po = function (b) {
            b = this.rb - b;
            this.Pa &&
              0 == this.A &&
              (a.logInfo("M58"), (this.A = Math.max(this.A, b)));
            0 == this.c &&
              (a.logInfo("M59"),
              (b = Math.max(this.c, b)),
              (this.c = 0 < this.A ? Math.min(this.A, b) : b));
          };
          b.prototype.To = function (a) {
            for (var b = this.Fb.length, p = 0; p < b; p++) {
              var m = this.Fb[p],
                n = m.element,
                l = m.da;
              if (m.T || this.T(n))
                ((this.c = Math.max(this.c, l - a)),
                  this.Ha(this.ea, { element: n, X: l - a }));
            }
          };
          b.prototype.Ha = function (b, f) {
            a.conf.enableSpeedIndex && b.push(f);
          };
          b.prototype.Gn = function (a, b) {
            return a.map(function (a) {
              return d({}, a, { X: a.da - b });
            });
          };
          b.prototype.zk = function (b) {
            if (!b.length) return 0;
            b = b
              .filter(function (b) {
                return a.utils.isDefined(b.element) &&
                  a.utils.isDefined(b.element.adrumConsiderForVCT)
                  ? b.element.adrumConsiderForVCT
                  : !0;
              })
              .map(function (a) {
                a.nd = 0;
                a.X = Math.floor(a.X || 0);
                if (a.element instanceof Element) {
                  var b = a.element.getBoundingClientRect();
                  return d({}, a, { nd: b.width * b.height || 0 });
                }
                return a;
              });
            var f = b.reduce(function (a, b) {
              return a + (b.nd || 0);
            }, 0);
            b.sort(function (a, b) {
              return a.X - b.X;
            });
            var p = 0,
              m = b[b.length - 1].X;
            if (!a.utils.isDefined(m) || 0 >= m) return 0;
            for (
              var m = 100 * Math.ceil(m / 100), n = 0, l = 0, q = 100;
              q <= m;
              q += 100
            ) {
              for (var e = l; e < b.length; e++) {
                var x = b[e].nd;
                if (b[e].X <= q) ((n += x || 0), (l = e + 1));
                else break;
              }
              e = 0;
              0 !== n && (e = n / f);
              p += 100 * (1 - e);
            }
            return p | 0;
          };
          b.prototype.td = function (b) {
            var f = this;
            this.zc = !1;
            a.l.ac.Wa && (this.Aa = b);
            a.logInfo("M60", b, this.Aa);
            var p = this.Kl(this.Aa);
            a.logInfo("M61", p);
            [].slice
              .call(document.getElementsByTagName("*"))
              .forEach(function (m) {
                var l = a.utils.Qd(m);
                delete m.isAdrumTrackedNode;
                if (a.utils.isDefined(m.adrumNodeId)) f.Ro(m, b);
                else if (a.utils.isDefined(l) && 0 < l.length) {
                  a.logInfo("M62", l);
                  var q = f.P[l];
                  if (a.utils.isDefined(q)) {
                    var e = q.da;
                    a.logInfo("M63", l, e);
                    a.utils.Lb(m, q.Gd) &&
                      (f.Pa &&
                        (a.logInfo("M64", f.A, e, b),
                        (f.A = Math.max(f.A, e - b)),
                        a.logInfo("M65", l, f.A)),
                      f.Fg(m, q) ||
                        (!q.T && !f.T(m)) ||
                        (a.logInfo("M66", a.c, e, b),
                        a.utils.isDefined(m.adrumConsiderForVCT)
                          ? f.Uo(m, l, e, b)
                          : ((f.c = Math.max(f.c, e - b)),
                            f.Ha(f.ea, { element: m, X: e - b }),
                            a.logInfo("M67", l, a.c))));
                  } else a.utils.ib(m) && a.utils.Lb(m) && f.Qo(m, l, b, p);
                }
              });
            a.conf.considerCarouselForVCT &&
              this.Mb &&
              this.Mb.length &&
              (this.Kk(this.Mb), this.Ab && this.So(b), this.Fb && this.To(b));
            a.logInfo("M68", this.c, this.A);
            this.Oo(b, p);
            a.conf.disableTextForTesting || this.Po(b);
            this.c |= 0;
            this.A |= 0;
            if (a.conf.enableSpeedIndex) {
              if (0 !== this.Nc.length) {
                var m = this.Gn(this.Nc, b);
                this.ea = this.ea.concat(m);
              }
              this.qb = this.zk(this.ea);
              0 == this.qb && (this.qb = this.c);
            }
            a.logInfo("M69", b, this.Aa);
            a.logInfo("M70", window.location.href);
            a.logInfo("M71", this.c, this.A, this.qb);
            return { vct: this.c, pct: this.A, spi: this.qb };
          };
          b.prototype.Nd = function (a) {
            try {
              var b = a.getBoundingClientRect(),
                p = document.documentElement || document.body,
                m =
                  b.top +
                  (window.pageYOffset || p.scrollTop) -
                  (p.clientTop || 0),
                n =
                  b.left +
                  (window.pageXOffset || p.scrollLeft) -
                  (p.clientLeft || 0);
              return {
                top: Math.round(m),
                left: Math.round(n),
                bottom: Math.round(m) + b.height,
                right: Math.round(n) + b.width,
              };
            } catch (l) {
              return { top: 0, left: 0, bottom: 0, right: 0 };
            }
          };
          b.prototype.T = function (b) {
            b = this.Nd(b);
            if (this.tm(b)) return (a.logInfo("M72"), !1);
            var f = {
                top: Math.max(this.viewport.top, b.top),
                left: Math.max(this.viewport.left, b.left),
                bottom: Math.min(this.viewport.bottom, b.bottom),
                right: Math.min(this.viewport.right, b.right),
              },
              f = a.utils.hg(f);
            b = a.utils.hg(b);
            if (0 != b && f / b >= this.qm) return !0;
            a.logInfo("M73");
            return !1;
          };
          b.prototype.tm = function (a) {
            return a.top > this.viewport.bottom ||
              a.bottom < this.viewport.top ||
              a.right < this.viewport.left ||
              a.left > this.viewport.right
              ? !0
              : !1;
          };
          b.prototype.Uk = function () {
            a.utils.isDefined(this.Hc) && this.Hc.disconnect();
            a.logInfo("M74");
          };
          b.prototype.Kl = function (b) {
            var f = this,
              p = 0,
              m = 0,
              n = this.rg(),
              n = n.filter(function (a) {
                return !(0 === a.transferSize && 0 < a.decodedBodySize);
              });
            n.forEach(function (n) {
              var q = n.name;
              if (a.utils.isDefined(f.P[q])) {
                var e = f.P[q].da - b - n.startTime,
                  x = n.duration;
                a.logInfo("M75", q, b, n.startTime, f.P[q].da, x);
                x && 0 < e && ((p += e / x), m++);
              }
            });
            return 0 < m ? p / m : 1;
          };
          b.prototype.ol = function () {
            var b = this,
              f = [];
            [].slice
              .call(document.getElementsByTagName("*"))
              .forEach(function (p) {
                if (a.utils.Lb(p)) {
                  var m = b.nl(p);
                  m &&
                    (b.T(p)
                      ? f.push({ url: m, wc: !0, element: p })
                      : b.Pa && f.push({ url: m, wc: !1, element: p }));
                }
              });
            return f;
          };
          b.prototype.nl = function (b) {
            if (b && b.style) {
              var f = window
                .getComputedStyle(b)
                .getPropertyValue("background-image");
              f || (f = (b.currentStyle || b.style).backgroundImage);
              b = this.Pl(f);
              return a.utils.isDefined(b) &&
                a.utils.isDefined(b.substr) &&
                "undefined" === b.substr(b.lastIndexOf("/") + 1)
                ? void 0
                : b;
            }
          };
          b.prototype.Pl = function (a) {
            if (a && a.match("url"))
              return a.replace('url("', "").replace('")', "");
          };
          b.prototype.pg = function (b) {
            for (var f = 0, p = this.rg(); f < p.length; f++) {
              var m = p[f];
              if (a.utils.isDefined(m.name) && 0 <= m.name.indexOf(b)) return m;
            }
          };
          b.prototype.rg = function () {
            return a.l.ac.Wa
              ? a.monitor.resourceMonitor.basePageResourceBuffer
              : a.monitor.resourceMonitor.resourceBuffer.concat(
                  a.monitor.resourceMonitor.Ib(),
                );
          };
          return b;
        })();
        a.yp = b;
        a.c = new b();
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function e() {
              this.Kb = !1;
              this.Ad = a.conf.spa2 ? 5e3 : 1e3;
              this.lb =
                a.conf.userConf &&
                a.conf.userConf.navComplete &&
                a.conf.userConf.navComplete.maxResourceQuietTime
                  ? a.conf.userConf.navComplete.maxResourceQuietTime
                  : this.Ad;
              this.Rk = 3e3;
              this.dn = Math.min(this.Rk, this.lb);
            }
            e.prototype.Rh = function () {
              a.U();
              this.Jb(Element.prototype, "innerHTML", this.ph.bind(this));
              this.Jb(HTMLElement.prototype, "innerHTML", this.ph.bind(this));
              this.Jb(HTMLImageElement.prototype, "src", this.Ob.bind(this));
              this.Jb(HTMLScriptElement.prototype, "src", this.Ob.bind(this));
              this.Jb(HTMLLinkElement.prototype, "href", this.Ob.bind(this));
              this.hm();
              this.Vd("append");
              this.Vd("appendChild");
              this.Vd("insertBefore");
              a.V();
            };
            e.prototype.setUp = function (b) {
              a.U();
              this.Bd = this.fe = this.j = 0;
              this.ka = b;
              this.Cc = null;
              this.Xd = this.sa = this.k = !1;
              this.ob = {};
              this.P = {};
              this.he = {};
              a.V();
            };
            e.prototype.start = function (b) {
              this.setUp(b);
              this.sa = !0;
              a.logInfo("M76");
            };
            e.prototype.reset = function () {
              this.k = !1;
              this.Bd = this.j = 0;
              this.Cc = null;
              this.Xd = this.sa = !1;
              this.P = {};
              this.he = {};
              a.logInfo("M77");
            };
            e.prototype.Jb = function (a, b, m) {
              this.un(a, b, Object.getOwnPropertyDescriptor(a, b), m);
            };
            e.prototype.un = function (b, p, m, n) {
              if (
                a.utils.isDefined(m) &&
                m.configurable &&
                a.utils.isDefined(m.set) &&
                !a.utils.isDefined(m.L)
              ) {
                var l = this;
                Object.defineProperty(b, p, {
                  set: function (a) {
                    var b;
                    try {
                      b = m.set.apply(this, arguments);
                    } catch (f) {
                      throw f;
                    } finally {
                      n.call(l, this);
                    }
                    return b;
                  },
                });
              }
            };
            e.prototype.Ob = function (b) {
              a.U();
              this.Fe(b);
              a.V();
            };
            e.prototype.hm = function () {
              var b = Element.prototype,
                p = this;
              a.utils.isDefined(b.setAttribute) &&
                (b.setAttribute = a.aop.around(
                  b.setAttribute,
                  null,
                  function () {
                    var a = g(arguments);
                    ("src" != a[0] && "href" != a[0]) || p.Ob.call(p, this);
                  },
                ));
            };
            e.prototype.Vd = function (b) {
              var p = Element.prototype,
                m = this;
              a.utils.isDefined(p[b]) &&
                (p[b] = a.aop.around(p[b], null, function () {
                  0 < arguments.length && m.Ob.call(m, arguments[0]);
                }));
            };
            e.prototype.ph = function (b) {
              a.U();
              this.sa &&
                a.utils.isDefined(b) &&
                a.utils.isDefined(b.childNodes) &&
                (this.Fe(b), this.ci(b.childNodes));
              a.V();
            };
            e.prototype.ci = function (b) {
              for (var p = 0; p < b.length; p++) {
                var m = b[p];
                "script" != a.utils.El(m) && this.Fe(m);
                this.ci(m.childNodes);
              }
            };
            e.prototype.Fe = function (f) {
              a.monitor.AnySpaMonitor.vc() ||
                (this.rm(f) ? this.mk(f) : a.conf.N && this.nk(f),
                this.Bd++,
                1 != this.Bd || this.k || (b.w.Uc(), (this.k = !0)));
            };
            e.prototype.mk = function (b) {
              var p = a.utils.gb(b),
                m = a.utils.tc(b);
              a.utils.isDefined(m) &&
                !a.utils.isDefined(this.ob[m]) &&
                (this.j++,
                (this.ob[m] = !0),
                a.logInfo("M78", m, p, this.j),
                this.Ff(b));
            };
            e.prototype.nk = function (b) {
              var p = a.utils.now();
              if (a.utils.Jg(b)) b.adrumNodeId || a.c.zb(b, p);
              else if (a.utils.ib(b) && !b.isAdrumTrackedNode) {
                var p = a.utils.gb(b),
                  m = a.utils.tc(b);
                a.utils.isDefined(m) &&
                  !a.utils.isDefined(this.ob[m]) &&
                  (this.j++,
                  (this.ob[m] = !0),
                  this.Ff(b),
                  a.logInfo("M79", m, p, this.j));
              } else
                a.utils.Eg(b) && !b.adrumNodeId
                  ? (a.logInfo("M80", p), a.c.zb(b, p))
                  : a.utils.Lg(b) && (a.c.rb = Math.max(a.c.rb, p));
            };
            e.prototype.Ff = function (b) {
              var p = a.utils.now();
              this.Kb ||
                ((this.O = this.O.bind(this)),
                (this.B = this.B.bind(this)),
                (this.O.L = !0),
                (this.Kb = this.B.L = !0));
              var m = a.utils.gb(b);
              a.utils.ib(b) &&
                (a.lifecycle.getPhaseName() === a.PageLifecycleTracker.md
                  ? this.Xd
                    ? (b.adrumConsiderForVCT = !1)
                    : this.Cc && p - this.Cc > this.dn
                      ? ((this.Xd = !0), (b.adrumConsiderForVCT = !1))
                      : ((b.adrumConsiderForVCT = !0), (this.Cc = p))
                  : (b.adrumConsiderForVCT = !0));
              a.utils.Ng(b)
                ? (b.addEventListener("loadeddata", this.O),
                  a.logInfo("M81", m))
                : (b.addEventListener("load", this.O),
                  a.logInfo("M82", m, b.nodeName));
              b.addEventListener("error", this.B);
            };
            e.prototype.rm = function (b) {
              return (
                a.utils.Im(b) || a.utils.zm(b) || a.utils.Fm(b) || a.utils.Mm(b)
              );
            };
            e.prototype.O = function (f) {
              a.U();
              var p = f.target,
                m = a.utils.gb(p),
                n = a.utils.tc(p);
              a.utils.isDefined(this.ob[n]) &&
                !a.utils.isDefined(this.P[n]) &&
                (this.j--,
                (this.P[n] = !0),
                0 > this.j && a.logError("M83", this.j),
                a.logInfo("M84", m, this.j));
              this.ka = a.utils.now();
              this.fe += 1;
              1 != this.fe || this.k || (b.w.Uc(), (this.k = !0));
              this.Qb(f.target);
              a.conf.N &&
                a.utils.ib(p) &&
                !p.isAdrumTrackedNode &&
                (a.logInfo("M85"), a.c.O(f));
              a.V();
            };
            e.prototype.B = function (b) {
              a.U();
              var p = b.target,
                m = a.utils.gb(p),
                n = a.utils.tc(p);
              a.utils.isDefined(this.ob[n]) &&
                !a.utils.isDefined(this.he[n]) &&
                (this.j--,
                (this.he[n] = !0),
                0 > this.j && a.logError("M86", this.j),
                a.logInfo("M87", m, this.j));
              a.conf.N &&
                a.utils.ib(p) &&
                !p.isAdrumTrackedNode &&
                (a.logInfo("M88"), a.c.B(b));
              this.Qb(b.target);
              a.V();
            };
            e.prototype.jk = function () {
              return 0 < this.j && this.k;
            };
            e.prototype.Td = function (b) {
              var p = this.j,
                m = 0;
              a.conf.N && ((p += a.c.j), (m = a.c.ka));
              a.logInfo("M89", p);
              return 0 >= p &&
                this.k &&
                (a.logInfo("M90"), (p = Math.max(this.ka, m)), b - p >= this.lb)
                ? (this.reset(), p)
                : -1;
            };
            e.prototype.Qb = function (a) {
              a.removeEventListener("load", this.O);
              a.removeEventListener("error", this.B);
            };
            return e;
          })();
          b.Ki = e;
        })(a.l || (a.l = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function e() {
              this.Ad = a.conf.spa2 ? 3e3 : 1e3;
              this.lb =
                a.conf.userConf &&
                a.conf.userConf.navComplete &&
                a.conf.userConf.navComplete.maxXhrQuietTime
                  ? a.conf.userConf.navComplete.maxXhrQuietTime
                  : this.Ad;
            }
            e.prototype.setUp = function (a) {
              this.nb = this.j = 0;
              this.Ca = a;
              this.sa = this.k = !1;
              this.ma = {};
            };
            e.prototype.start = function (a) {
              this.setUp(a);
              this.sa = !0;
            };
            e.prototype.vf = function (b) {
              a.monitor.AnySpaMonitor.vc() ||
                !this.sa ||
                a.utils.isDefined(this.ma[b.guid()]) ||
                this.ma[b.guid()] ||
                ((this.ma[b.guid()] = !0),
                (this.j += 1),
                a.logInfo("M91", b.guid(), b.url(), this.j));
            };
            e.prototype.dk = function (f) {
              !a.monitor.AnySpaMonitor.vc() &&
                this.sa &&
                a.utils.isDefined(this.ma[f.guid()]) &&
                this.ma[f.guid()] &&
                (delete this.ma[f.guid()],
                (this.Ca = a.utils.now()),
                (this.j -= 1),
                a.logInfo("M92", f.guid(), f.url(), this.j),
                (this.nb += 1),
                1 == this.nb && (b.w.Uc(), (this.k = !0)));
            };
            e.prototype.ck = function (f) {
              !a.monitor.AnySpaMonitor.vc() &&
                this.sa &&
                a.utils.isDefined(this.ma[f.guid()]) &&
                this.ma[f.guid()] &&
                (delete this.ma[f.guid()],
                (this.Ca = a.utils.now()),
                (this.j -= 1),
                a.logInfo("M93", f.guid(), f.url(), this.j),
                (this.nb += 1),
                1 == this.nb && (b.w.Uc(), (this.k = !0)));
            };
            e.prototype.Td = function (a) {
              return 0 == this.j && this.k && a - this.Ca >= this.lb
                ? (this.reset(), this.Ca)
                : -1;
            };
            e.prototype.kk = function () {
              return 0 < this.j && this.k;
            };
            e.prototype.reset = function () {
              this.ma = {};
              this.k = !1;
              this.j = 0;
              this.sa = !1;
            };
            return e;
          })();
          b.Ai = e;
        })(a.l || (a.l = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function e() {
              this.M = new b.Ki();
              this.I = new b.Ai();
              this.en = a.conf.spa2 ? 3e3 : 1e3;
              this.maxInactiveTime =
                a.conf.userConf &&
                a.conf.userConf.navComplete &&
                a.conf.userConf.navComplete.maxInactiveTime
                  ? a.conf.userConf.navComplete.maxInactiveTime
                  : Math.max(this.M.lb, this.I.lb) + this.en;
              this.nh = 1e3;
            }
            e.prototype.setUp = function (a) {
              this.currentTime = this.startTime = a;
              this.k = this.jb = !1;
              this.M.setUp(a);
              this.I.setUp(a);
            };
            e.prototype.start = function (a) {
              this.setUp(a);
              this.k = !0;
              this.M.start(a);
              this.I.start(a);
              this.If();
              this.vo();
            };
            e.prototype.vo = function () {
              this.bi = a.utils.refs.setInterval.call(
                window,
                function () {
                  a.U();
                  this.currentTime = a.utils.now();
                  var b = a.utils.max(this.M.ka, this.I.Ca);
                  if (this.currentTime - b >= this.maxInactiveTime) {
                    if (
                      a.conf.N &&
                      e.Wa &&
                      !a.utils.isDefined(
                        a.monitor.DOMEventsMonitor.currentBasePage,
                      )
                    ) {
                      a.logInfo("M94");
                      e.cb = e.cb || this.jb ? this.currentTime : b;
                      return;
                    }
                    this.currentTime = e.cb || this.currentTime;
                    a.logInfo("M95");
                    this.navComplete(this.jb ? this.currentTime : b);
                    this.reset();
                  }
                  a.V();
                }.bind(this),
                this.nh,
              );
            };
            e.prototype.Uc = function () {
              this.jb || (this.so(), (this.jb = !0));
            };
            e.prototype.If = function () {
              a.utils.isDefined(this.uh) && clearInterval(this.uh);
              a.utils.isDefined(this.bi) && clearInterval(this.bi);
            };
            e.prototype.reset = function () {
              this.If();
              this.k = this.jb = !1;
              this.M.reset();
              this.I.reset();
            };
            e.prototype.navComplete = function (b) {
              a.U();
              var p = a.utils.isDefined(
                a.monitor.AnySpaMonitor.vp &&
                  a.monitor.AnySpaMonitor.vp.startTime,
              )
                ? a.monitor.AnySpaMonitor.vp.startTime
                : this.startTime;
              a.logInfo("M96", b - p);
              a.conf.N
                ? e.Wa
                  ? (a.monitor.PerformanceWrapper.perf &&
                      (a.monitor.navMonitor.Of(),
                      a.monitor.resourceMonitor.Nf()),
                    a.logInfo("M97"),
                    (b = a.c.td(a.utils.fb())),
                    (a.monitor.DOMEventsMonitor.currentBasePage.vct = b.vct),
                    (a.monitor.DOMEventsMonitor.currentBasePage.spi = b.spi),
                    a.conf.spa2 &&
                      (a.monitor.DOMEventsMonitor.currentBasePage.pct = b.pct),
                    a.b.Na &&
                      (a.logInfo("M98", a.utils.now()),
                      a.b.Q(a.b.Na),
                      (a.b.Na = null)),
                    a.command(
                      "reportOnload",
                      a.monitor.DOMEventsMonitor.currentBasePage,
                    ),
                    a.c.reset(),
                    (a.c.Pa = !1),
                    (e.Wa = !1))
                  : a.monitor.AnySpaMonitor.ce(p, b)
                : ((a.monitor.resourceMonitor.basePageResourceBuffer = []),
                  a.monitor.AnySpaMonitor.ce(p, b));
              a.monitor.AnySpaMonitor.Ta ||
                (a.monitor.AnySpaMonitor.Ug(p),
                a.monitor.AnySpaMonitor.report());
              a.b.eo();
              a.V();
            };
            e.prototype.so = function () {
              this.uh = a.utils.refs.setInterval.call(
                window,
                function () {
                  a.U();
                  this.currentTime = a.utils.now();
                  var b = this.M.Td(this.currentTime);
                  0 <= b && a.logInfo("M99", b - this.startTime);
                  b = this.I.Td(this.currentTime);
                  0 <= b && a.logInfo("M100", b - this.startTime);
                  if (!this.I.k && !this.M.k) {
                    b = a.utils.max(this.I.Ca, this.M.ka);
                    if (
                      a.conf.N &&
                      e.Wa &&
                      !a.utils.isDefined(
                        a.monitor.DOMEventsMonitor.currentBasePage,
                      )
                    ) {
                      a.logInfo("M101");
                      e.cb = e.cb || b;
                      return;
                    }
                    b = e.cb || b;
                    a.logInfo("M102");
                    this.navComplete(b);
                    this.reset();
                  }
                  a.V();
                }.bind(this),
                this.nh,
              );
            };
            return e;
          })();
          e.Wa = !0;
          e.cb = 0;
          b.ac = e;
          b.w = new b.ac();
        })(a.l || (a.l = {}));
      })(k || (k = {}));
      (function (a) {
        var b = (function () {
          function b() {
            this.Wc = [];
            this.Kc(b.ld, 0);
          }
          b.prototype.ln = function (a) {
            this.Kc(b.wf, a);
          };
          b.prototype.nn = function (a) {
            this.Kc(b.Df, a);
          };
          b.prototype.mn = function (a) {
            this.Kc(b.md, a);
          };
          b.prototype.Kc = function (a, b) {
            this.Wc.push({ kn: new Date().getTime(), jn: b, kh: a });
            this.Nk = a;
          };
          b.prototype.getPhaseName = function () {
            return this.Nk;
          };
          b.prototype.getPhaseID = function (a) {
            for (var f = 0; f < b.Af.length; f++) if (b.Af[f] === a) return f;
            return null;
          };
          b.prototype.getPhaseCallbackTime = function (a) {
            for (var b = this.Wc, p = 0; p < b.length; p++)
              if (b[p].kh === a) return b[p].kn;
            return null;
          };
          b.prototype.findPhaseAtNominalTime = function (c) {
            a.assert(0 <= c);
            for (var f = this.Wc, p = f.length - 1; 0 <= p; p--)
              if (c >= f[p].jn) return f[p].kh;
            a.error("M103", c, a.utils.dumpObject(f));
            return b.ld;
          };
          return b;
        })();
        b.ld = "AFTER_FIRST_BYTE";
        b.wf = "AFTER_DOM_INTERACTIVE";
        b.Df = "AT_ONLOAD";
        b.md = "AFTER_ONLOAD";
        b.Af = [b.ld, b.wf, b.Df, b.md];
        a.PageLifecycleTracker = b;
        a.lifecycle = new b();
        a.lifecycle = a.lifecycle;
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (b) {
            function f(f) {
              f = b.call(this, f) || this;
              f.isBeaconSent = !1;
              f.backTimeGap = a.conf.backTimeGap;
              return f;
            }
            u(f, b);
            f.prototype.type = function () {
              return a.EventType.PageView;
            };
            return f;
          })(b.EventTracker);
          b.PageView = e;
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        a = a.events || (a.events = {});
        a = a.g || (a.g = {});
        a.navigationStart = "navigationStart";
        a.domainLookupStart = "domainLookupStart";
        a.domainLookupEnd = "domainLookupEnd";
        a.connectStart = "connectStart";
        a.secureConnectionStart = "secureConnectionStart";
        a.connectEnd = "connectEnd";
        a.requestStart = "requestStart";
        a.responseStart = "responseStart";
        a.responseEnd = "responseEnd";
        a.domContentLoadedEventStart = "domContentLoadedEventStart";
        a.loadEventEnd = "loadEventEnd";
        a.Lh = "sendTime";
        a.bg = "firstByteTime";
        a.Eh = "respAvailTime";
        a.Fh = "respProcTime";
        a.Le = "viewChangeStart";
        a.ji = "viewChangeEnd";
        a.Me = "viewDOMLoaded";
        a.si = "xhrRequestsCompleted";
        a.Eq = "viewFragmentsLoaded";
        a.Fq = "viewResourcesLoaded";
        a.Ne = "virtualPageStart";
        a.Zo = "virtualPageEnd";
      })(k || (k = {}));
      (function (a) {
        var b = a.events || (a.events = {});
        b.metricSpec = {};
        b.metricSpec[a.EventType.PageView] = {
          $k: {
            start: b.g.navigationStart,
            end: b.g.loadEventEnd,
            name: "PLT",
          },
          il: {
            start: b.g.navigationStart,
            end: b.g.responseStart,
            name: "FBT",
          },
          xq: {
            start: b.g.navigationStart,
            end: b.g.requestStart,
            name: "SCT",
          },
          yq: {
            start: b.g.secureConnectionStart,
            end: b.g.connectEnd,
            name: "SHT",
          },
          Qp: {
            start: b.g.domainLookupStart,
            end: b.g.domainLookupEnd,
            name: "DLT",
          },
          Bq: { start: b.g.connectStart, end: b.g.connectEnd, name: "TCP" },
          uq: { start: b.g.requestStart, end: b.g.responseStart, name: "RAT" },
          Sp: { start: b.g.responseStart, end: b.g.loadEventEnd, name: "FET" },
          Wp: {
            start: b.g.responseStart,
            end: b.g.domContentLoadedEventStart,
            name: "DRT",
          },
          Vp: { start: b.g.responseStart, end: b.g.responseEnd, name: "DDT" },
          Op: {
            start: b.g.responseEnd,
            end: b.g.domContentLoadedEventStart,
            name: "DPT",
          },
          tq: {
            start: b.g.domContentLoadedEventStart,
            end: b.g.loadEventEnd,
            name: "PRT",
          },
          Pp: {
            start: b.g.navigationStart,
            end: b.g.domContentLoadedEventStart,
            name: "DOM",
          },
        };
        b.metricSpec[a.EventType.Ajax] = {
          il: { start: b.g.Lh, end: b.g.bg, name: "FBT" },
          Cp: { start: b.g.bg, end: b.g.Eh, name: "DDT" },
          Bp: { start: b.g.Eh, end: b.g.Fh, name: "DPT" },
          $k: { start: b.g.Lh, end: b.g.Fh, name: "PLT" },
        };
        b.metricSpec[a.EventType.VPageView] = {
          kq: { start: b.g.Ne, end: b.g.Zo, name: "PLT" },
          Kp: { start: b.g.Le, end: b.g.ji, name: "DDT" },
          hq: { start: b.g.Le, end: b.g.Me, name: "DRT" },
          qp: { start: b.g.ji, end: b.g.Me, name: "DPT" },
          rp: { start: b.g.Le, end: b.g.Me, name: "DOM" },
          sq: {
            start: "viewChangeEnd",
            end: "xhrRequestsCompleted",
            name: null,
          },
          iq: { start: "viewChangeEnd", end: "viewPartialsLoaded", name: null },
          gq: {
            start: "viewPartialsLoaded",
            end: "viewFragmentsLoaded",
            name: null,
          },
          jq: {
            start: "viewPartialsLoaded",
            end: "viewResourcesLoaded",
            name: null,
          },
        };
        b.metricSpec[a.EventType.NG_VIRTUAL_PAGE] =
          b.metricSpec[a.EventType.VPageView];
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (e) {
            function f(p) {
              p = e.call(this, p) || this;
              p.constructor != f &&
                p.constructor != b.AdrumAjax &&
                a.reportAPIMessage(a.Z.wa, a.tb, "ADRUM.events.Ajax", []);
              return p;
            }
            u(f, e);
            f.prototype.type = function () {
              return a.EventType.Ajax;
            };
            return f;
          })(b.EventTracker);
          b.Ajax = e;
          b.Ma(b.K[a.EventType.Ajax], e.prototype);
          b.Bf(b.metricSpec[a.EventType.Ajax], e.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (b) {
            function f(a) {
              return b.call(this, a) || this;
            }
            u(f, b);
            f.prototype.type = function () {
              return a.EventType.Ajax;
            };
            return f;
          })(b.Ajax);
          b.AdrumAjax = e;
          b.Ma(b.K[a.EventType.ADRUM_XHR], e.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isDefined,
            c = (function () {
              function f() {}
              f.Oc = function (b, m) {
                a.conf.spa2 ? f.Ik(b, m) : f.Jh(b, m);
              };
              f.Ik = function (p, m) {
                if (
                  (e(p.status) && 0 == p.status) ||
                  (!e(p.status) && !e(m.response))
                )
                  (a.l.w.I.ck(m), delete p._adrumAjaxT);
                else {
                  var n = a.b.sd(p.h);
                  if (
                    e(a.monitor.AnySpaMonitor.vp) &&
                    !a.monitor.AnySpaMonitor.Ta &&
                    a.monitor.AnySpaMonitor.vp.Bb == n
                  ) {
                    m.parent(a.monitor.AnySpaMonitor.vp);
                    if (++a.monitor.AnySpaMonitor.vp.Cf > b.Ja.maxPerPageView)
                      return;
                    f.Jh(p, m);
                  } else
                    (e(a.monitor.AnySpaMonitor.vp) &&
                      !a.monitor.AnySpaMonitor.Ta &&
                      m.parent(a.monitor.AnySpaMonitor.vp),
                      f.oe(m, p),
                      b.oSTO(f.pe, f.Bj));
                  delete p._adrumAjaxT;
                  a.l.w.I.dk(m);
                }
              };
              f.Jh = function (p, m) {
                delete p._adrumAjaxT;
                var n = {};
                if (p instanceof XMLHttpRequest)
                  try {
                    if (
                      ((n = {
                        status: p.status,
                        getAllResponseHeaders: p.getAllResponseHeaders(),
                      }),
                      400 <= p.status)
                    )
                      if (b.isString(p.statusText)) n.statusText = p.statusText;
                      else
                        try {
                          n.responseText = p.responseText;
                        } catch (l) {
                          n.responseType = p.responseType;
                        }
                  } catch (q) {
                    a.error("M104", q);
                  }
                e((m.response || p).status) && f.reportXhr(n, m);
              };
              f.reportXhr = function (b, m) {
                f.fi(b, m);
                a.command("reportXhr", m);
              };
              f.oe = function (b, m) {
                if (e(m.h)) {
                  var n = a.b.sd(m.h).guid;
                  f.fi(m, b);
                  e(f.qa[n]) || (f.qa[n] = []);
                  -1 == f.qa[n].indexOf(b) && f.qa[n].push(b);
                } else a.logInfo("M105");
              };
              f.fi = function (a, f) {
                var n = f.response || a,
                  l = n.status,
                  e;
                b.isNumber(l) && f.xhrStatus(l);
                if (n.getAllResponseHeaders) {
                  var t = b.isFunction(n.getAllResponseHeaders)
                    ? n.getAllResponseHeaders()
                    : n.getAllResponseHeaders;
                  f.allResponseHeaders(t);
                }
                if (400 <= l) {
                  if (b.isString(n.statusText)) e = n.statusText;
                  else
                    try {
                      b.isString(n.responseText) && (e = n.responseText);
                    } catch (c) {
                      b.isString(n.responseType) && (e = n.responseType);
                    }
                  f.error({ status: l, msg: e });
                }
              };
              f.Lo = function (a, f) {
                var n = "";
                b.isDefined(Response) &&
                  a instanceof Response &&
                  a.headers.forEach(function (a, b) {
                    n += b + ": " + a + "\r\n";
                  });
                f.allResponseHeaders(n);
              };
              f.xh = function (a) {
                f.qa[a] = [];
                delete f.qa[a];
              };
              f.an = function (b, m) {
                var n = f.qa[m];
                e(n) &&
                  (n.forEach(function (f) {
                    f.parent(b);
                    a.command("reportXhr", f);
                  }),
                  f.xh(m));
              };
              f.pe = function (p) {
                for (var m in f.qa) {
                  for (var n = 0, l = f.qa[m]; n < l.length; n++) {
                    var q = l[n];
                    !e(a.monitor.AnySpaMonitor.vp) &&
                    ++f.ok <= b.Ja.maxPerPageView
                      ? a.command("reportXhr", q, p)
                      : e(a.monitor.AnySpaMonitor.vp) &&
                        ++a.monitor.AnySpaMonitor.vp.Cf <=
                          b.Ja.maxPerPageView &&
                        a.command("reportXhr", q);
                  }
                  f.xh(m);
                }
              };
              return f;
            })();
          c.Bj = 2e3;
          c.qa = {};
          c.ok = 0;
          b.Zb = c;
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.now,
            c = a.utils.Zb,
            f = (function () {
              function f() {}
              f.prototype.setUp = function () {
                var b = document.readyState;
                if ("loading" === b) (a.logInfo("M106"), f.jo(), f.Sh());
                else {
                  var n = { timeStamp: e() };
                  f.ub(n);
                  "interactive" === b
                    ? (a.logInfo("M107"), f.Sh())
                    : (a.logInfo("M108"), f.Pb(n), f.hh(n));
                }
              };
              f.Sh = function () {
                a.utils.addEventListener(window, "load", f.Pb);
                a.utils.addEventListener(window, "load", f.hh);
              };
              f.prototype.setUpOnBeforeUnload = function () {
                a.conf.sendBeaconOnUnload &&
                  a.utils.addEventListener(window, "beforeunload", f.sn);
              };
              f.sn = function () {
                var m = b.xa.Ya;
                if (m)
                  for (var n in m) {
                    var l = m[n],
                      e = l.ajaxT;
                    !e.getRespProcTime() &&
                      e.tempRespAvailAndProcTime &&
                      e.markRespProcTime(e.tempRespAvailAndProcTime);
                    !e.getRespAvailTime() &&
                      e.tempRespAvailAndProcTime &&
                      e.markRespAvailTime(e.tempRespAvailAndProcTime);
                    c.Oc(l.requestObj, l.ajaxT);
                  }
                f.currentBasePage && !f.currentBasePage.isBeaconSent
                  ? (a.conf.N &&
                      ((m = a.c.td(a.utils.fb())),
                      (f.currentBasePage.vct = m.vct),
                      (f.currentBasePage.spi = m.spi),
                      a.conf.spa2 && (f.currentBasePage.pct = m.pct)),
                    a.command("quickReportOnLoad", f.currentBasePage),
                    c.pe(!0))
                  : a.channel &&
                    a.channel.sendBeacon &&
                    (c.pe(!0),
                    a.l.w.navComplete(a.utils.now()),
                    a.channel.sendBeacon(!0));
              };
              f.hh = function (m) {
                f.currentBasePage = new a.events.PageView();
                a.lifecycle.nn(m && m.timeStamp);
                a.utils.Ih(function () {
                  var m = e();
                  a.lifecycle.mn(m);
                  a.command("mark", "onload", m);
                  f.Gc = !0;
                  a.conf.N
                    ? a.c.Uk()
                    : (b.PerformanceWrapper.perf &&
                        (b.navMonitor.Of(), b.resourceMonitor.Nf()),
                      a.b.Na && (a.b.Q(a.b.Na), (a.b.Na = null)),
                      a.command("reportOnload", f.currentBasePage));
                  !a.conf.N &&
                    a.conf.spa2 &&
                    a.conf.modernBrowserFeaturesAvailable &&
                    a.l.w.M.Rh();
                  a.utils.loadScriptAsync(a.conf.adrumExtUrl);
                });
                a.logInfo("M109");
              };
              f.jo = function () {
                if (a.utils.isFunction(document.addEventListener))
                  document.addEventListener("DOMContentLoaded", f.ub, !1);
                else if (a.utils.isObject(document.attachEvent)) {
                  document.attachEvent("onreadystatechange", f.ub);
                  var b = null;
                  try {
                    b =
                      null === window.frameElement
                        ? document.documentElement
                        : null;
                  } catch (n) {}
                  null != b &&
                    b.doScroll &&
                    (function q() {
                      if (!f.isReady) {
                        try {
                          b.doScroll("left");
                        } catch (n) {
                          a.utils.oSTO(q, 10);
                          return;
                        }
                        f.Pb();
                      }
                    })();
                } else a.error("M110");
                a.logInfo("M111");
              };
              f.Pb = function (b) {
                f.Yg ||
                  (a.lifecycle.ln(b && b.timeStamp),
                  a.command("mark", "onready", e()),
                  (f.Yg = !0));
              };
              f.ub = function (a) {
                document.addEventListener
                  ? (document.removeEventListener("DOMContentLoaded", f.ub, !1),
                    f.Pb(a))
                  : "complete" === document.readyState &&
                    (document.detachEvent("onreadystatechange", f.ub), f.Pb(a));
              };
              return f;
            })();
          f.isReady = !1;
          f.Yg = !1;
          f.Gc = !1;
          b.DOMEventsMonitor = f;
          f.prototype.setUpOnBeforeUnload = f.prototype.setUpOnBeforeUnload;
          b.domEventsMonitor = new b.DOMEventsMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.map,
            c = a.utils.cp,
            f = a.utils.isDefined,
            p = a.utils.isString,
            m = a.utils.Tk,
            n = a.utils.isFunction;
          b.Zg = function (a, b) {
            for (var f = !1, m = 0; m < b.length; m++) {
              var n = b[m];
              if (n && n.test(a)) {
                f = !0;
                break;
              }
            }
            return f;
          };
          b.Ac = function (a, m, n) {
            var p = !1;
            if (m && n)
              for (var e = 0; e < n.length; e++) {
                var c = n[e];
                if (
                  !(
                    (f(c.method) && a !== c.method) ||
                    (f(c.urls) && !b.Zg(m, c.urls))
                  )
                ) {
                  p = !0;
                  break;
                }
              }
            return p;
          };
          b.Wb = function (a, b) {
            return m(e(c(b), a));
          };
          b.Zc = function (a) {
            var f = b.yl(a);
            a = b.jg(a);
            return f || a;
          };
          b.yl = function (b) {
            var m = b.method;
            if (f(m)) {
              if (p(m)) return b;
              a.error("M112");
            }
          };
          b.Wo = function (a) {
            var f = b.jg(a);
            return b.Fn(a) && f;
          };
          b.Fn = function (b) {
            if (n(b.getFromBody)) return b;
            a.error("M113");
          };
          b.Mk = function (b) {
            for (var f = [], m = 0; m < b.length; m++) {
              var n = b[m].pattern;
              if (p(n))
                try {
                  f.push(new RegExp(n));
                } catch (e) {
                  a.exception(e, "M114");
                }
              else a.error("M115");
            }
            return f;
          };
          b.jg = function (a) {
            var f = a.urls;
            if (f && 0 < f.length && ((a.urls = b.Mk(f)), 0 < a.urls.length))
              return a;
          };
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isDefined,
            c = (function () {
              function f() {}
              f.setUp = function () {
                f.exclude = [
                  {
                    urls: [
                      new RegExp(
                        a.conf.beaconUrlHttp + a.conf.corsEndpointPath,
                      ),
                      new RegExp(
                        a.conf.beaconUrlHttps + a.conf.corsEndpointPath,
                      ),
                    ],
                  },
                ];
                f.include = [];
                f.maxPerPageView = f.En(a.conf.userConf && a.conf.userConf.xhr);
                f.payloadParams = [];
                f.parameter = {};
                f.oh(a.conf.userConf && a.conf.userConf.xhr);
              };
              f.oh = function (a) {
                e(a) &&
                  ((f.exclude = f.exclude.concat(b.Wb(b.Zc, a.exclude))),
                  (f.include = f.include.concat(b.Wb(b.Zc, a.include))),
                  (f.payloadParams = f.payloadParams.concat(
                    b.Wb(b.Zc, a.payloadParams),
                  )),
                  (f.parameter = b.Wb(b.Wo, a.parameter)));
              };
              f.En = function (p) {
                if (e(p)) {
                  p = p.maxPerPageView;
                  if (b.isNumber(p) && 0 < p) return p;
                  if ("UNLIMITED" === p) return Infinity;
                  a.reportAPIMessage(
                    a.Z.xi,
                    "Invalid maxPerPageView value: " + p,
                    "xhr.maxPerPageView",
                    [p],
                  );
                }
                return a.conf.spa2 ? f.Gi : f.Fi;
              };
              f.Tc = function (a, m) {
                var n = f.include,
                  l = f.exclude;
                return (
                  (e(n) && 0 < n.length && !b.Ac(m, a, n)) ||
                  (e(l) && 0 < l.length && b.Ac(m, a, l))
                );
              };
              f.xe = function (a, m) {
                var n = f.payloadParams;
                b.Ac(a.method(), a.url(), n) && a.dataObject({ data: m });
              };
              return f;
            })();
          c.Fi = 50;
          c.Gi = 250;
          b.Ja = c;
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          b.parseURI = function (a) {
            var b = String(a)
              .replace(/^\s+|\s+$/g, "")
              .match(
                /^([^:\/?#]+:)?(?:\/\/(?:([^:@\/?#]*)(?::([^:@\/?#]*))?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
              );
            a = b && null != a.match(b[1] + "//");
            return (
              b && {
                href: b[0] || "",
                protocol: b[1] || "",
                slash: a ? "//" : "",
                username: b[2] || "",
                password: b[3] || "",
                host: b[4] || "",
                hostname: b[5] || "",
                port: b[6] || "",
                pathname: b[7] || "",
                search: b[8] || "",
                hash: b[9] || "",
              }
            );
          };
          b.absolutizeURI = function (a, c) {
            function f(a) {
              var b = [];
              a.replace(/^(\.\.?(\/|$))+/, "")
                .replace(/\/(\.(\/|$))+/g, "/")
                .replace(/\/\.\.$/, "/../")
                .replace(/\/?[^\/]*/g, function (a) {
                  "/.." === a ? b.pop() : b.push(a);
                });
              return b.join("").replace(/^\//, "/" === a.charAt(0) ? "/" : "");
            }
            var p, m, n, l, q, t, x, s;
            s = c ? b.parseURI(c) : {};
            x = a ? b.parseURI(a) : {};
            s.protocol
              ? ((p = s.protocol),
                (m = s.slash),
                (n = s.username),
                (l = s.password),
                (q = s.host),
                (t = f(s.pathname)),
                (x = s.search))
              : s.host
                ? ((p = x.protocol),
                  (m = x.slash),
                  (n = s.username),
                  (l = s.password),
                  (q = s.host),
                  (t = f(s.pathname)),
                  (x = s.search))
                : ((p = x.protocol),
                  (m = x.slash),
                  (n = x.username),
                  (l = x.password),
                  (q = x.host),
                  s.pathname
                    ? ("/" === s.pathname.charAt(0)
                        ? (t = f(s.pathname))
                        : ((t = x.pathname
                            ? x.pathname.slice(
                                0,
                                x.pathname.lastIndexOf("/") + 1,
                              ) + s.pathname
                            : m
                              ? "/" + s.pathname
                              : s.pathname),
                          (t = f(t))),
                      (x = s.search))
                    : ((t = f(x.pathname)), (x = s.search || x.search)));
            return (
              p +
              m +
              (n ? n + (l ? ":" + l : "") + "@" : "") +
              q +
              t +
              x +
              (s.hash ? s.hash : "")
            );
          };
          b.getFullyQualifiedUrl = function (e) {
            try {
              var c,
                f = document.location.href,
                p;
              a: {
                for (
                  var m = document.getElementsByTagName("base"), n = 0;
                  n < m.length;
                  n++
                ) {
                  var l = m[n].href;
                  if (l) {
                    p = l;
                    break a;
                  }
                }
                p = void 0;
              }
              c = p ? b.absolutizeURI(f, p) : f;
              return b.absolutizeURI(c, e);
            } catch (q) {
              return (a.exception(q, "M116", e, c), e);
            }
          };
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isString,
            c = (function (f) {
              function p() {
                var a = f.call(this) || this;
                a.na = 0;
                a.na = 0;
                return a;
              }
              u(p, f);
              p.prototype.Pc = function () {
                this.na = 0;
              };
              p.B = function (b) {
                var f = b.message || b.description,
                  p = b.fileName || b.filename,
                  q = b.lineNumber,
                  t = b.columnNumber;
                e(b.description) &&
                  0 <= b.description.indexOf("Access is denied.") &&
                  (f += ": maybe you have CORS XHR error in IE");
                a.monitor.ia.va(f, p, q, t, b);
              };
              p.Kg = function (a) {
                var f = document.createElement("a");
                f.href = a;
                a = document.location;
                var l = a.protocol;
                return (
                  f.protocol === l &&
                  f.hostname === a.hostname &&
                  p.yn(b.XHRMonitor.Sk[l], f.port, a.port)
                );
              };
              p.yn = function (a, b, f) {
                return (b || a) === (f || a);
              };
              return p;
            })(b.fd);
          c.Ya = {};
          c.Sk = { "http:": "80", "https:": "443" };
          b.xa = c;
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          function e(b) {
            var f =
              a.utils.isDefined(window.crypto) &&
              a.utils.isFunction(window.crypto.getRandomValues)
                ? window.crypto
                : a.utils.isDefined(window.msCrypto) &&
                  a.utils.isFunction(window.msCrypto.getRandomValues) &&
                  window.msCrypto;
            if (f)
              return (
                (b = new Uint8Array(b / 2)),
                f.getRandomValues(b),
                [].slice
                  .call(b)
                  .map(function (a) {
                    a = a.toString(16);
                    return 1 === a.length ? "0" + a : a;
                  })
                  .join("")
              );
            for (f = ""; f.length < b; )
              f += "0123456789abcdef".charAt(Math.floor(16 * Math.random()));
            return f;
          }
          function c(a) {
            for (var b = 0; b < a.length; b++) if ("0" != a[b]) return !0;
            return !1;
          }
          function f(a) {
            for (var b = e(a); !c(b); ) b = e(a);
            return b;
          }
          b.createTraceparentHeaderValue = function () {
            var a;
            a = "00-" + f(32);
            a = a + "-" + f(16);
            return (a += "-01");
          };
        })(a.TraceParentGenerator || (a.TraceParentGenerator = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.Ja,
            c = a.utils.Zb,
            f = a.utils.mergeJSON,
            p = a.events.AdrumAjax,
            m = a.utils.isString,
            n = a.utils.isDefined,
            l = a.utils.isNumber,
            q = a.utils.getFullyQualifiedUrl,
            t = a.conf.spa2,
            x = a.conf.ja;
          b.ab = null;
          b.oi = window.fetch;
          var s = a.conf.isZonePromise,
            k = null,
            w = (function (w) {
              function r() {
                return (null !== w && w.apply(this, arguments)) || this;
              }
              u(r, w);
              r.prototype.im = function () {
                var f = this,
                  m = Object.getOwnPropertyDescriptor(window, "fetch");
                if (!m || m.configurable) {
                  m && delete m.writable;
                  m && delete m.value;
                  m || (m = { configurable: !0, enumerable: !0 });
                  var p = m.set,
                    l = m.get;
                  m.set = function (a) {
                    !0 !== a.isAgentFetch &&
                      (n(p) && p.apply(this, arguments), n(b.ab) || f.setUp(a));
                  };
                  m.get = function () {
                    var a = b.oi;
                    n(l) && (a = l.apply(this, arguments));
                    n(b.ab) && (a = b.ab);
                    return a;
                  };
                }
                Object.defineProperty(window, "fetch", m);
                s && a.utils.ae() && (window.fetch = window.fetch);
              };
              r.prototype.setUp = function (m) {
                var l = this;
                m = m || window.fetch || b.oi;
                a.logInfo("M117");
                if (n(m) && !m.isAgentFetch) {
                  var q = function (f) {
                    return function (m, p) {
                      var e = arguments;
                      if (l._adrumAjaxT) {
                        a.logInfo(
                          "M118",
                          l._adrumAjaxT.url(),
                          l._adrumAjaxT.method(),
                        );
                        var q = a.utils.now();
                        b.xa.Kg(l._adrumAjaxT.url()) && (e = r.Vj(arguments));
                        r.Zn(l._adrumAjaxT, e);
                        var t = f.apply(this, e),
                          x = new window.Promise(function (b, f) {
                            t.then(function (f) {
                              a.logInfo("M119", l._adrumAjaxT.url());
                              a.logInfo("M120", q, l._adrumAjaxT.url());
                              c.Lo(f, x._adrumAjaxT);
                              x._adrumAjaxT.markFirstByteTime(
                                x._adrumAjaxT.getFirstByteTime() ||
                                  a.utils.now(),
                              );
                              x._adrumAjaxT.response = f;
                              h(f.clone)
                                ? (a.logInfo("M121", l._adrumAjaxT.url()),
                                  f
                                    .clone()
                                    .text()
                                    .then(function (a) {
                                      r.Sl(a, x);
                                    })
                                    ["catch"](function (a) {
                                      r.$f(x, a);
                                    }))
                                : (a.logInfo("M122", l._adrumAjaxT.url()),
                                  r.no(x, f));
                              b(f);
                            })["catch"](function (b) {
                              a.logInfo("M123", l._adrumAjaxT.url());
                              x._adrumAjaxT.markFirstByteTime(
                                x._adrumAjaxT.getFirstByteTime() ||
                                  a.utils.now(),
                              );
                              r.$f(x);
                              f(b);
                            });
                          });
                        x._adrumAjaxT = l._adrumAjaxT;
                        x.L = !0;
                        x._adrumAjaxT.timestamp(q);
                        x._adrumAjaxT.markSendTime(q);
                        x._adrumAjaxT.parentPhase(a.lifecycle.getPhaseName());
                        a.conf.spa2 &&
                          n(b.AnySpaMonitor.vp) &&
                          n(b.AnySpaMonitor.vp.userPageName) &&
                          x._adrumAjaxT.parentPageName(
                            b.AnySpaMonitor.vp.userPageName,
                          );
                        r.bo(x._adrumAjaxT, arguments);
                        a.logInfo("M124", q, l._adrumAjaxT.url());
                        x.h = new a.$b(
                          a.b.ra(),
                          new a.Ka("window.fetch"),
                          a.CauseType.FETCH,
                        );
                        return x;
                      }
                      return f.apply(this, e);
                    };
                  };
                  q.isAgentFetch = !0;
                  b.ab = a.aop.around(
                    q(m),
                    function () {
                      var m = r.Ll(arguments),
                        n = Array.prototype.slice.call(arguments);
                      if (
                        (!t && ++l.na + b.xhrMonitor.na > e.maxPerPageView) ||
                        e.Tc(m.url, m.method)
                      )
                        (a.logInfo("M125", m.url), delete l._adrumAjaxT);
                      else
                        return (
                          (l._adrumAjaxT = new p(f(m, l.status))),
                          (l.h = a.b.Qa(
                            "window.fetch.send",
                            void 0,
                            a.b.ra(),
                            a.CauseType.FETCH,
                          )),
                          x &&
                            ((m = a.utils.Sa("window.fetch.send") || ""),
                            (l.h.oa = m)),
                          (n[n.length] = { adrumArgs: { cEventId: l.h.guid } }),
                          a.b.ua(l.h),
                          n
                        );
                    },
                    function () {
                      if (l._adrumAjaxT)
                        if (!t && l.na + b.xhrMonitor.na > e.maxPerPageView)
                          a.logInfo("M126", l._adrumAjaxT.url());
                        else if (
                          e.Tc(l._adrumAjaxT.url(), l._adrumAjaxT.method())
                        )
                          a.logInfo("M127", l._adrumAjaxT.url());
                        else {
                          var f = a.utils.Md(arguments, "cEventId");
                          a.l.w.I.vf(l._adrumAjaxT);
                          a.b.Q(f);
                        }
                    },
                    "fetch",
                    b.xa.B,
                  );
                  b.ab.isAgentFetch = !0;
                  window.fetch = b.ab;
                }
              };
              r.lg = function () {
                k || (k = new r());
                return k;
              };
              r.Sl = function (b, f) {
                var m = a.utils.now();
                if (r.ca(f)) {
                  f._adrumAjaxT.response.responseText = b;
                  r.Vg(f._adrumAjaxT, m);
                  var p = f._adrumAjaxT.getRespProcTime();
                  n(p) ||
                    (n(f._adrumAjaxT.C) && 0 !== f._adrumAjaxT.C) ||
                    (a.logInfo("M128", m, f._adrumAjaxT.url()),
                    f._adrumAjaxT.markRespProcTime(m),
                    r.pb(f));
                }
              };
              r.$f = function (b, f) {
                if ((!f || f.code !== f.ABORT_ERR) && b && b._adrumAjaxT) {
                  a.logInfo("M129", b._adrumAjaxT.url());
                  var m = a.utils.now();
                  r.ca(b) &&
                    (r.Vg(b._adrumAjaxT, m), r.Wg(b._adrumAjaxT, m), r.pb(b));
                }
              };
              r.Vg = function (b, f) {
                var m = b.getRespAvailTime();
                n(m) || (a.logInfo("M130", f, b.url()), b.markRespAvailTime(f));
              };
              r.Wg = function (b, f) {
                var m = b.getRespProcTime();
                if (n(m)) return !1;
                a.logInfo("M131", f, b.url());
                b.markRespProcTime(f);
                return !0;
              };
              r.no = function (a, b) {
                b.lk = r.Xb(a, b.lk);
                b.tk = r.Xb(a, b.tk);
                b.kl = r.Xb(a, b.kl);
                b.Vm = r.Xb(a, b.Vm);
                b.text = r.Xb(a, b.text);
              };
              r.Xb = function (b, f) {
                return a.aop.around(
                  f,
                  function () {
                    r.ca(b) && b._adrumAjaxT.markRespAvailTime(a.utils.now());
                  },
                  function () {
                    r.ca(b) &&
                      (b._adrumAjaxT.markRespProcTime(a.utils.now()), r.pb(b));
                  },
                  "wrapResponseReader",
                  a.monitor.ErrorMonitor.B,
                );
              };
              r.Vj = function (a) {
                1 == a.length
                  ? m(a[0])
                    ? ([].push.call(a, {}), r.pd(a[1]))
                    : r.pd(a[0])
                  : 2 == a.length && r.pd(a[1]);
                return a;
              };
              r.pd = function (b) {
                if (
                  n(b) &&
                  (n(b.headers) ||
                    ((b.headers = new Headers()), a.logInfo("M132")),
                  b.headers instanceof Headers
                    ? b.headers.has("ADRUM")
                      ? b.headers.set("ADRUM", "isAjax:true")
                      : b.headers.append("ADRUM", "isAjax:true")
                    : (b.headers.ADRUM = "isAjax:true"),
                  a.conf.traceparentHeaderEnabled)
                ) {
                  var f = a.TraceParentGenerator.createTraceparentHeaderValue();
                  b.headers.append("traceparent", f);
                }
              };
              r.Zn = function (b, f) {
                1 == f.length &&
                  !a.utils.isString(f[0]) &&
                  f[0] instanceof Request &&
                  (b.Ah = f[0].clone());
              };
              r.bo = function (b, f) {
                2 <= f.length &&
                  a.utils.isObject(f[1]) &&
                  n(f[1].body) &&
                  e.xe(b, f[1].body);
              };
              r.co = function (b) {
                return a.utils.isDefined(b.Ah)
                  ? b.Ah.text().then(function (a) {
                      e.xe(b, a);
                    })
                  : window.Promise.resolve();
              };
              r.Ll = function (b) {
                var f = { url: "", method: "" };
                a.utils.isObject(b[0])
                  ? ((f.url =
                      b[0].url ||
                      (a.utils.isDefined(b[0].toString)
                        ? b[0].toString()
                        : void 0)),
                    (f.method = b[0].method || "GET"))
                  : m(b[0]) &&
                    ((f.url = b[0]),
                    (f.method = (b[1] && b[1].method) || "GET"));
                f.url = n(f.url) ? f.url : "";
                f.url = q(f.url);
                f.method = f.method;
                return f;
              };
              r.cm = function (b) {
                var f;
                n(f) || (a.logInfo("M133", b._adrumAjaxT.url()), (f = 1));
                n(b._adrumAjaxT.C) &&
                  l(b._adrumAjaxT.C) &&
                  ((b._adrumAjaxT.C += f),
                  a.logInfo("M134", b._adrumAjaxT.C, b._adrumAjaxT.url()));
              };
              r.lc = function (b) {
                var f;
                n(f) || (a.logInfo("M135", b._adrumAjaxT.url()), (f = 1));
                n(b._adrumAjaxT.C) &&
                  l(b._adrumAjaxT.C) &&
                  ((b._adrumAjaxT.C -= f),
                  a.logInfo("M136", b._adrumAjaxT.C, b._adrumAjaxT.url()));
              };
              r.ca = function (a) {
                return n(a._adrumAjaxT);
              };
              r.uc = function (a) {
                return n(a._adrumAjaxT) && n(a._adrumAjaxT.C);
              };
              r.No = function (b, f) {
                b._adrumAjaxT = f._adrumAjaxT;
                b._adrumAjaxT.C += b.G;
                a.logInfo("M137", b._adrumAjaxT.C, f._adrumAjaxT.url());
                b.G = 0;
              };
              r.Xo = function (a) {
                var b = !1;
                r.ca(a) && n(a._adrumAjaxT.C) && (r.cm(a), (b = !0));
                return b;
              };
              r.pb = function (b) {
                r.co(b._adrumAjaxT)
                  ["catch"](function (f) {
                    a.logInfo("M138", b._adrumAjaxT.url(), f);
                  })
                  ["finally"](function () {
                    c.Oc(b, b._adrumAjaxT);
                  });
              };
              r.Ke = function (b) {
                var f = a.utils.now();
                return 0 === b._adrumAjaxT.C && n(b._adrumAjaxT)
                  ? r.Wg(b._adrumAjaxT, f)
                  : !1;
              };
              r.Je = function (b) {
                var f = !1,
                  m = a.utils.now(),
                  p = b._adrumAjaxT.getRespAvailTime();
                n(p) || (b._adrumAjaxT.markRespAvailTime(m), (f = !0));
                return f;
              };
              r.em = function (b) {
                a.logInfo("M139", b._adrumAjaxT.url());
                b._adrumAjaxT.C = 0;
              };
              return r;
            })(b.xa);
          b.Pi = w;
          b.Gb = w.lg();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isObject,
            c = a.utils.map,
            f = a.utils.reduce,
            p = a.utils.filter,
            m = a.utils.isDefined,
            n = a.utils.isString,
            l = a.utils.mergeJSON,
            q = a.utils.La,
            t = a.utils.Ja,
            x = a.utils.Zb,
            s = a.conf.spa2,
            k = a.conf.ja,
            w = (function (w) {
              function r() {
                var b = w.call(this) || this;
                b.Ce = !1;
                if (!0 === window["adrum-xhr-disable"])
                  return (a.logInfo("M140"), b);
                if (!window.XMLHttpRequest) return (a.logInfo("M141"), b);
                b.H = window.XMLHttpRequest.prototype;
                if (!b.H) return (a.logInfo("M142"), b);
                if (!("open" in b.H && "send" in b.H))
                  return (a.logInfo("M143"), b);
                b.Ce = a.aop.support(b.H.open) && a.aop.support(b.H.send);
                b.Ce || a.logInfo("M144");
                return b;
              }
              u(r, w);
              r.prototype.setUp = function () {
                if (this.Ce) {
                  a.logInfo("M145");
                  a.xhrConstructor = window.XMLHttpRequest;
                  a.xhrOpen = this.xhrOpen = this.H.open;
                  a.xhrSend = this.xhrSend = this.H.send;
                  t.setUp();
                  var f = this;
                  this.H.open = a.aop.around(
                    this.H.open,
                    function () {
                      r.Hm(this) &&
                        (4 === this.readyState
                          ? (a.logInfo("M146"),
                            r.bl(this._adrumAjaxT),
                            delete this.Ap,
                            x.reportXhr(this, this._adrumAjaxT))
                          : a.logInfo("M147", this._adrumAjaxT.url()));
                      var n = 1 <= arguments.length ? String(arguments[0]) : "",
                        p = 2 <= arguments.length ? String(arguments[1]) : "",
                        p = a.utils.getFullyQualifiedUrl(p);
                      (!s && f.na + b.Gb.na > t.maxPerPageView) ||
                        t.Tc(p, n) ||
                        ((this._adrumAjaxT = new a.events.AdrumAjax(
                          l({ method: n, url: p }, f.status),
                        )),
                        a.conf.spa2 &&
                          m(b.AnySpaMonitor.vp) &&
                          m(b.AnySpaMonitor.vp.userPageName) &&
                          this._adrumAjaxT.parentPageName(
                            b.AnySpaMonitor.vp.userPageName,
                          ));
                    },
                    null,
                    "XHR.open",
                    b.xa.B,
                  );
                  this.H.send = a.aop.around(
                    this.H.send,
                    function (m) {
                      var p = this,
                        l = this._adrumAjaxT,
                        e = !1;
                      if (
                        !(!l || (!s && ++f.na + b.Gb.na > t.maxPerPageView))
                      ) {
                        var q = a.utils.now(),
                          c = l.getSendTime();
                        a.assert(null === c, "M148");
                        l.timestamp(q);
                        l.markSendTime(c || q);
                        l.parentPhase(a.lifecycle.getPhaseName());
                        p.h = a.b.Qa(
                          "XHR.send",
                          void 0,
                          a.b.ra(),
                          a.CauseType.XHR,
                        );
                        k && ((q = a.utils.Sa("XHR.send") || ""), (p.h.oa = q));
                        b.xa.Kg(l.url())
                          ? (p.setRequestHeader("ADRUM", "isAjax:true"),
                            a.conf.traceparentHeaderEnabled &&
                              ((q =
                                a.TraceParentGenerator.createTraceparentHeaderValue()),
                              p.setRequestHeader("traceparent", q)))
                          : a.logInfo("M149", document.location.href, l.url());
                        t.xe(l, m);
                        m = r.Hl(l.url(), t.parameter, m);
                        l.parameter(m);
                        var x = 0,
                          w = function () {
                            if (4 == p.readyState)
                              e
                                ? a.logInfo("M150")
                                : (a.logInfo("M151"), f.bd(p));
                            else {
                              var b = null;
                              try {
                                a.conf.isAbapApp || (b = p.onreadystatechange);
                              } catch (m) {
                                if (e) {
                                  a.logInfo("M152", m);
                                  return;
                                }
                                a.logInfo("M153", m);
                                f.bd(p);
                                return;
                              }
                              x++;
                              b
                                ? a.aop.support(b)
                                  ? ((p.onreadystatechange = r.Rf(
                                      b,
                                      "XHR.onReadyStateChange",
                                    )),
                                    n && f.ri.call(p, "readystatechange", r.Tf),
                                    a.logInfo("M154", x))
                                  : n || (a.logInfo("M155"), f.bd(p))
                                : x < r.Rj
                                  ? setTimeout(w, 0)
                                  : e
                                    ? a.logInfo("M156")
                                    : (a.logInfo("M157"), f.bd(p));
                            }
                          };
                        if (n) {
                          a.logInfo("M158");
                          try {
                            (f.jp.call(p, "readystatechange", r.Tf), (e = !0));
                          } catch (v) {
                            a.error("M159", v);
                          }
                        }
                        w.usedByAgent = !0;
                        w();
                      }
                    },
                    function () {
                      if (s) {
                        var b = this._adrumAjaxT;
                        b && a.l.w.I.vf(b);
                      }
                    },
                    "XHR.send",
                    b.xa.B,
                  );
                  var n =
                    "addEventListener" in this.H &&
                    "removeEventListener" in this.H &&
                    a.aop.support(this.H.addEventListener) &&
                    a.aop.support(this.H.removeEventListener);
                  if (n) {
                    var p = a.utils.gg(this.H, "addEventListener");
                    this.jp = p.addEventListener;
                    p.addEventListener = a.aop.around(
                      p.addEventListener,
                      function (b, f, n) {
                        if (
                          m(f) &&
                          ((f.L = !0),
                          this instanceof XMLHttpRequest &&
                            /^(load|error|readystatechange)$/.test(b) &&
                            f)
                        ) {
                          var p = r.Ho(f);
                          if (p) {
                            var l = q(arguments);
                            l[1] = p;
                            a.logInfo("M160");
                            return l;
                          }
                          a.logInfo("M161", b, f);
                        }
                      },
                      null,
                      "XHR.addEventListener",
                    );
                    p = a.utils.gg(this.H, "removeEventListener");
                    this.ri = p.removeEventListener;
                    p.removeEventListener = a.aop.around(
                      p.removeEventListener,
                      function (b, m, n) {
                        if (
                          this instanceof XMLHttpRequest &&
                          this._adrumAjaxT
                        ) {
                          var p = q(arguments);
                          m.__adrumInterceptor
                            ? ((p[1] = m.__adrumInterceptor),
                              a.logInfo("M162"),
                              f.ri.apply(this, p))
                            : a.logInfo("M163");
                        }
                      },
                      null,
                      "XHR.removeEventListener",
                    );
                  } else a.logInfo("M164");
                  a.logInfo("M165");
                }
              };
              r.Hl = function (b, m, n) {
                if (
                  m &&
                  ((m = p(
                    c(
                      p(m, function (f) {
                        return a.utils.Zg(b, f.urls);
                      }),
                      function (a) {
                        return a.getFromBody(n);
                      },
                    ),
                    e,
                  )),
                  0 < m.length)
                )
                  return f(m, l, {});
              };
              r.Sd = function (b) {
                var f = b._adrumAjaxT;
                if (f) {
                  var m = a.utils.now();
                  2 == b.readyState
                    ? f.markFirstByteTime(f.getFirstByteTime() || m)
                    : 4 == b.readyState &&
                      (f.markRespAvailTime(f.getRespAvailTime() || m),
                      f.markFirstByteTime(f.getFirstByteTime() || m),
                      f.markRespProcTime(f.getRespProcTime() || m),
                      (this.Ya[f.guid()] = {
                        requestObj: b,
                        ajaxT: b._adrumAjaxT,
                      }),
                      (m = b.h =
                        a.b.Qa("XHR.load", void 0, b.h, a.CauseType.XHR)),
                      k &&
                        ((b =
                          a.utils.Sa(
                            "XHR.onreadystatechange." + b.readyState,
                          ) || ""),
                        (m.oa = b)),
                      a.b.ua(m),
                      (f.th = m.guid));
                }
              };
              r.tg = function (b) {
                var f = b._adrumAjaxT;
                if (f && 4 == b.readyState) {
                  delete this.Ya[f.guid()];
                  var m = a.utils.now(),
                    n = f.getRespProcTime();
                  f.markRespAvailTime(f.getRespAvailTime() || m);
                  m > n && f.markRespProcTime(m);
                  x.Oc(b, f);
                  a.b.Q(f.th);
                }
              };
              r.Rf = function (a, b) {
                return r.kp(
                  a,
                  function () {
                    r.Sd(this);
                  },
                  function () {
                    r.tg(this);
                  },
                  b,
                );
              };
              r.Tf = function () {
                r.Sd(this);
                r.tg(this);
              };
              r.Hm = function (a) {
                return m(a._adrumAjaxT) && n(a._adrumAjaxT._url);
              };
              r.bl = function (b) {
                var f = a.utils.now();
                b.markRespAvailTime(b.getRespAvailTime() || f);
                b.markFirstByteTime(b.getFirstByteTime() || f);
                b.markRespProcTime(b.getRespProcTime() || f);
              };
              r.prototype.bd = function (b) {
                if (b._adrumAjaxT) {
                  var f = a.utils.now() + 3e4,
                    m = function () {
                      r.Sd(b);
                      var n = b._adrumAjaxT;
                      if (n) {
                        var p = a.utils.now();
                        4 == b.readyState
                          ? (a.assert(null === n.getRespProcTime(), "M166"),
                            n.markRespProcTime(n.getRespProcTime() || p),
                            a.logInfo("M167"),
                            x.Oc(b, n),
                            a.b.Q(n.th))
                          : p < f
                            ? a.utils.oSTO(m, r.Ve)
                            : (delete b._adrumAjaxT, a.logInfo("M168"));
                      }
                    };
                  m();
                }
              };
              r.kp = function (b, f, m, n) {
                var p = b;
                b &&
                  "object" === typeof b &&
                  "toString" in b &&
                  "[xpconnect wrapped nsIDOMEventListener]" === b.toString() &&
                  "handleEvent" in b &&
                  (p = function () {
                    b.handleEvent.apply(this, q(arguments));
                  });
                return a.aop.around(p, f, m, n);
              };
              r.Ho = function (b) {
                if (b.__adrumInterceptor) return b.__adrumInterceptor;
                if (a.aop.support(b)) {
                  var f = r.Rf(b, "XHR.invokeEventListener");
                  return (b.__adrumInterceptor = f);
                }
              };
              return r;
            })(b.xa);
          w.Rj = 5;
          w.Ve = 50;
          b.XHRMonitor = w;
          b.xhrMonitor = new b.XHRMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.Zb,
            c = (function (f) {
              function p(b) {
                b = f.call(this, b) || this;
                b.perf = new a.PerformanceTracker();
                b.kc = !1;
                b.Cf = 0;
                return b;
              }
              u(p, f);
              p.prototype.type = function () {
                return a.EventType.VPageView;
              };
              p.prototype.Ld = function () {
                return b.EventTracker.od(this.guid(), this.url(), this.type());
              };
              p.prototype.ze = function () {
                var b = this.Ld();
                a.monitor.ia.set("parent", b);
                a.logInfo("M169", b.guid(), b.url());
              };
              p.prototype.startCorrelatingXhrs = function () {
                a.logInfo("M170");
                a.utils.isDefined(this.Bb) &&
                  !a.monitor.AnySpaMonitor.Ta &&
                  e.an(this, this.Bb.guid);
              };
              p.prototype.start = function () {
                this.startCorrelatingXhrs();
                this.ze();
              };
              return p;
            })(b.EventTracker);
          b.AnySpaVPageView = c;
          b.Ma(b.K[a.EventType.VPageView], c.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        a.report = function (b) {
          a.utils.isObject(b) && a.utils.isFunction(b.type)
            ? -1 ==
              [
                a.EventType.PageView,
                a.EventType.Ajax,
                a.EventType.VPageView,
                a.EventType.Error,
              ].indexOf(b.type())
              ? a.reportAPIMessage(
                  a.Z.wa,
                  b.type() + "is not a valid external event type",
                  "ADRUM.report",
                  Array.prototype.slice.call(arguments),
                )
              : a.conf.spa2 && a.EventType.VPageView == b.type()
                ? a.logInfo("M171")
                : a.utils.Ih(function () {
                    a.command("reportEvent", b);
                  })
            : a.reportAPIMessage(
                a.Z.Pe,
                "",
                "ADRUM.report",
                Array.prototype.slice.call(arguments),
              );
        };
        a.setVirtualPageName = function (b) {
          a.utils.isString(b) &&
            0 < a.utils.trim(b).length &&
            a.conf.spa2 &&
            a.monitor.AnySpaMonitor.vp &&
            a.monitor.AnySpaMonitor.Nh(b);
        };
        a.markVirtualPageBegin = function (b, e) {
          a.conf.spa2 &&
            ((this.hb = a.utils.isDefined(e) ? e : !0),
            a.logInfo("M172", document.URL),
            a.monitor.AnySpaMonitor.we(document.URL, b, !0),
            a.monitor.AnySpaMonitor.Ph());
        };
        a.markVirtualPageEnd = function () {
          a.conf.spa2 &&
            this.hb &&
            (a.logInfo("M173", a.monitor.AnySpaMonitor.la),
            a.monitor.AnySpaMonitor.Xg(
              a.monitor.AnySpaMonitor.vp.startTime,
              a.utils.now(),
            ),
            (this.hb = !1));
        };
        a.pauseReporting = function (b) {
          a.conf.isReportingPaused = b;
          a.logInfo("M174", b);
        };
        a.setAppReleaseId = function (b) {
          a.conf.releaseId = a.conf.releaseId || b;
        };
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isDefined,
            c = a.aop.after,
            f = a.aop.before,
            p = a.utils.getFullyQualifiedUrl,
            m = a.conf.disableUsingCauseStart,
            n = (function () {
              function n() {}
              n.prototype.setUp = function () {
                var b = !1;
                n.Aa = a.utils.fb();
                n.io();
                a.l.w.setUp(a.utils.now());
                n.la = document.URL;
                n.Id = [];
                a.utils.isDefined(window.history) &&
                  a.utils.isFunction(window.history.pushState) &&
                  ((b = !0), n.uf("push"));
                a.utils.isDefined(window.history) &&
                  a.utils.isFunction(window.history.replaceState) &&
                  ((b = !0), n.uf("replace"));
                n.Id = n.Id.concat(
                  a.utils.Wb(
                    a.utils.Zc,
                    a.conf.userConf &&
                      a.conf.userConf.spa &&
                      a.conf.userConf.spa.spa2 &&
                      a.utils.isObject(a.conf.userConf.spa.spa2) &&
                      a.conf.userConf.spa.spa2.vp &&
                      a.conf.userConf.spa.spa2.vp.exclude,
                  ),
                );
                if (a.utils.isDefined(window.addEventListener)) {
                  var b = !0,
                    f = function () {
                      n.la == document.URL || n.$d || n.Qh();
                    };
                  f.L = !0;
                  window.addEventListener("popstate", f);
                }
                b || a.logInfo("M175");
              };
              n.uf = function (a) {
                switch (a) {
                  case "push":
                    window.history.pushState = n.Th(
                      window.history.pushState,
                      a,
                    );
                    break;
                  case "replace":
                    window.history.replaceState = n.Th(
                      window.history.replaceState,
                      a,
                    );
                }
              };
              n.Th = function (f, m) {
                var p = m[0].toUpperCase() + m.slice(1);
                return a.aop.around(
                  f,
                  function (f, p, e) {
                    ((n.vp && n.vp.kc) || n.ug(e)) &&
                      b.DOMEventsMonitor.Gc &&
                      !a.hb &&
                      (a.logInfo("M176", m), n.we(document.URL));
                  },
                  function (f, p, e) {
                    if ((n.vp && n.vp.kc) || n.ug(e))
                      (b.DOMEventsMonitor.Gc &&
                        (a.hb
                          ? (a.logInfo("M177", m), n.vp.url(document.URL))
                          : (a.logInfo("M178", m), n.Ph())),
                        (n.la = document.URL));
                  },
                  "history" + p + "State",
                );
              };
              n.ug = function (a) {
                return a && n.la !== p(a);
              };
              n.Qh = function () {
                n.$d = !0;
                var f = document.URL;
                a.logInfo("M179", n.la, f);
                b.DOMEventsMonitor.Gc &&
                  (a.hb
                    ? (a.logInfo("M180"), n.vp.url(document.URL))
                    : (n.we(n.la), n.Ae(f)));
                n.la = f;
                n.$d = !1;
              };
              n.io = function () {
                var b;
                a.b.ua = c(a.b.ua, function () {
                  b = location.hash;
                });
                a.b.Q = f(a.b.Q, function () {
                  b == location.hash || n.la == document.URL || n.$d || n.Qh();
                });
              };
              n.we = function (a, b, f) {
                n.Xn();
                n.Ta = !1;
                n.Qf(a, b, f);
              };
              n.Ph = function () {
                var a = document.URL;
                n.Ae(a);
                n.la = a;
              };
              n.Np = function () {
                n.Ta = !0;
                n.Qf(n.la);
                n.Ae();
              };
              n.Xn = function () {
                var f = a.l.w;
                a.conf.N &&
                  a.l.ac.Wa &&
                  a.utils.isDefined(b.DOMEventsMonitor.currentBasePage) &&
                  (a.logInfo("M181"),
                  f.I.k || f.M.k
                    ? f.navComplete(a.utils.now())
                    : f.navComplete(a.utils.max(f.I.Ca, f.M.ka)),
                  f.reset());
                n.Ta ||
                  !a.utils.isDefined(n.vp) ||
                  n.vp.zh ||
                  (a.logInfo("M182"),
                  (f = n.vl(a.l.w.k)),
                  n.Xg(n.vp.startTime, f));
              };
              n.vl = function (b) {
                var f = a.utils.now();
                b ? ((f = n.wl(a.l.w.jb)), a.l.w.reset()) : (f = n.vp.endTime);
                return f;
              };
              n.qo = function (b, f) {
                return n.vp.kc
                  ? !1
                  : e(f) && 0 < f.length && a.utils.Ac(void 0, b, f);
              };
              n.wl = function (b) {
                var f = a.utils.now();
                b
                  ? a.l.w.M.jk() ||
                    a.l.w.I.kk() ||
                    (f = a.utils.max(a.l.w.M.ka, a.l.w.I.Ca))
                  : (f = a.l.w.startTime);
                return f;
              };
              n.Xg = function (a, b) {
                n.ce(a, b);
                n.Ug(a);
                n.report();
              };
              n.Nh = function (b) {
                a.utils.isDefined(b) && (n.vp.userPageName = b);
              };
              n.Qf = function (b, f, p) {
                n.reset();
                n.vp = new a.events.AnySpaVPageView();
                n.vp.startUrl = b;
                n.Nh(f);
                a.utils.isBoolean(p) && (n.vp.kc = p);
                b = a.b.rd();
                n.Ta
                  ? (n.vp.startTime = a.utils.fb())
                  : ((f = a.utils.now()),
                    (p = b ? b.start : f),
                    m || (f = p),
                    (n.vp.startTime = f));
                n.vp.endTime = n.vp.startTime;
                n.vp.timestamp(n.vp.startTime);
                n.vp.Bb = b;
              };
              n.Ae = function (b) {
                a.utils.isDefined(b) && n.vp.url(b);
                n.vp.start();
                a.hb || a.l.w.start(a.utils.now());
              };
              n.ce = function (b, f) {
                a.utils.isDefined(n.vp) &&
                  (a.conf.N && n.Ak(b),
                  a.utils.isDefined(f)
                    ? (n.vp.endTime = a.conf.N
                        ? f - b > n.vp.vct
                          ? f
                          : n.vp.vct + b
                        : f)
                    : (n.vp.endTime = b));
              };
              n.Ak = function (b) {
                a.logInfo("M183");
                b = a.c.td(b);
                n.vp.vct = b.vct;
                n.vp.spi = b.spi;
                a.c.reset();
              };
              n.Ug = function (f) {
                a.utils.isDefined(n.vp) &&
                  n.vp.resTiming(b.resourceMonitor.Nl(n.Aa, f));
              };
              n.vc = function () {
                var b = a.b.Ql();
                return (
                  a.utils.isDefined(b) &&
                  a.utils.isDefined(n.vp) &&
                  (!a.utils.isDefined(n.vp.Bb) || n.vp.Bb != b)
                );
              };
              n.report = function () {
                if (a.utils.isDefined(n.vp))
                  if (n.qo(n.vp.url(), n.Id)) a.logInfo("M185", n.vp.url());
                  else {
                    a.logInfo("M186");
                    var f = n.vp;
                    if (f.zh) a.logInfo("M187");
                    else {
                      var m = a.utils.isDefined(
                        b.DOMEventsMonitor.currentBasePage,
                      )
                        ? b.DOMEventsMonitor.currentBasePage.url()
                        : document.URL;
                      f.parentUrl(m);
                      a.command("call", function () {
                        a.reporter.reportEvent(f);
                      });
                      f.zh = !0;
                    }
                  }
                else a.logInfo("M184");
              };
              n.reset = function () {
                n.vp = null;
              };
              return n;
            })();
          b.AnySpaMonitor = n;
          b.ik = new b.AnySpaMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isDefined,
            c = (function (f) {
              function p() {
                var b = (null !== f && f.apply(this, arguments)) || this;
                b.Wm = function (f) {
                  var l = f.message,
                    e = f.filename,
                    c = f.lineno,
                    x = f.colno;
                  f = f.error;
                  a.logInfo("M188");
                  if (a.utils.isDefined(f) || p.Dc)
                    (a.logInfo("M189"), (p.Dc = !0), b.va(l, e, c, x, f));
                };
                b.Xm = function (f) {
                  var p = f.blockedURI,
                    e = f.columnNumber,
                    c = f.lineNumber,
                    x = f.effectiveDirective,
                    s = f.violatedDirective;
                  f = f.sourceFile;
                  a.logInfo("M190");
                  p = a.utils.isDefined(p) ? p : "";
                  x = a.utils.isDefined(x) ? x : "";
                  s = a.utils.isDefined(s) ? s : "";
                  f = a.utils.isDefined(f) ? f : "";
                  b.va(
                    "SecurityPolicyViolation: blockedURI = " +
                      p +
                      " & effectiveDirective = " +
                      x +
                      " & violatedDirective = " +
                      s +
                      " & sourceFile = " +
                      f,
                    void 0,
                    c,
                    e,
                    void 0,
                  );
                };
                return b;
              }
              u(p, f);
              p.B = function (b) {
                a.monitor.ia.va(
                  b.message || b.description,
                  b.fileName || b.filename,
                  b.lineNumber,
                  b.columnNumber,
                  b,
                );
              };
              p.op = function (b) {
                var f = a.utils.isDefined(b.blockedURI) ? b.blockedURI : "",
                  p = a.utils.isDefined(b.documentURI) ? b.documentURI : "";
                b = a.utils.isDefined(b.effectiveDirective)
                  ? b.effectiveDirective
                  : "";
                a.monitor.ia.va(
                  "blockedURI = " +
                    f +
                    "& documentURI = " +
                    p +
                    "? effectiveDirective = " +
                    b,
                  void 0,
                  void 0,
                  void 0,
                  void 0,
                );
              };
              p.prototype.setUp = function () {
                var b = this;
                f.prototype.setUp.call(this);
                a.utils.addEventListener(window, "error", this.Wm, !0);
                a.utils.addEventListener(
                  window,
                  "securitypolicyviolation",
                  this.Xm,
                  !0,
                );
                a.listenForErrors = function () {
                  b.Rg();
                };
                this.Rg();
              };
              p.prototype.On = function () {
                p.Hd = 0;
              };
              p.prototype.Qm = function (b) {
                return b
                  ? a.utils.isString(b)
                    ? 0 < b.length
                    : a.utils.isObject(b)
                      ? !0
                      : !1
                  : !1;
              };
              p.prototype.va = function (f, n, l, c, t) {
                this.Qm(f)
                  ? p.Hd >= a.conf.lj
                    ? a.logInfo("M192")
                    : ((t = a.utils.tryExtractingErrorStack(t)),
                      (f = new a.events.Error(
                        a.utils.mergeJSON(
                          {
                            msg: f + "",
                            url: a.utils.isString(n) ? n : void 0,
                            line: a.utils.isNumber(l) ? l : void 0,
                            col: a.utils.isNumber(c) ? c : void 0,
                            stack: t,
                          },
                          this.status,
                        ),
                      )),
                      a.conf.spa2 &&
                        e(b.AnySpaMonitor.vp) &&
                        e(b.AnySpaMonitor.vp.userPageName) &&
                        f.parentPageName(b.AnySpaMonitor.vp.userPageName),
                      a.command("reportPageError", f),
                      p.Hd++,
                      (p.hadErrors = !0))
                  : a.logInfo("M191");
              };
              p.prototype.Rg = function () {
                var b = this;
                p.Dc = !1;
                a.aop.support(window.onerror)
                  ? ((window.onerror = a.aop.around(
                      window.onerror,
                      function (f, l, e, c, x) {
                        p.Dc
                          ? a.logInfo("M193")
                          : p.Yd
                            ? a.logInfo("M195")
                            : (a.logInfo("M194"),
                              b.va(f, l, e, c, x),
                              (p.Yd = !0));
                      },
                      function () {
                        a.logInfo("M196");
                        p.Yd = !1;
                      },
                      "onerror",
                    )),
                    a.logInfo("M197"))
                  : a.logInfo("M198");
              };
              return p;
            })(b.fd);
          c.Yd = !1;
          c.Hd = 0;
          c.hadErrors = !1;
          c.Dc = !1;
          b.ErrorMonitor = c;
          b.ia = new b.ErrorMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.logInfo,
            c = a.aop.after,
            f = (function (f) {
              function m() {
                return (null !== f && f.apply(this, arguments)) || this;
              }
              u(m, f);
              m.prototype.setUp = function () {
                a.utils.map(["error", "exception"], function (b) {
                  var f = A[b];
                  a.utils.isFunction(f) && a.aop.support(f)
                    ? (e("M199", b),
                      (A[b] = c(f, function (a) {
                        e("M200", b, a);
                        m.Xj(a);
                      })))
                    : e("M201", b);
                });
                b.ia.va = c(b.ia.va, function () {
                  0 < m.Ba.length ? (e("M202"), (m.Ba = [])) : e("M203");
                });
              };
              m.Xj = function (b) {
                m.Ba.length >= a.conf.fj
                  ? e("M204")
                  : a.utils.isString(b)
                    ? (e("M205", b), m.Ba.push(b), a.utils.oSTO(m.yh))
                    : a.utils.isObject(b)
                      ? ((b = a.utils.toJSONString(b)),
                        null !== b
                          ? (e("M206", b), m.Ba.push(b), a.utils.oSTO(m.yh))
                          : a.error("M207"))
                      : e("M208", typeof b);
              };
              m.yh = function () {
                0 < m.Ba.length
                  ? (e("M209"),
                    m.Ba.forEach(function (a) {
                      b.ia.va(a);
                    }),
                    (m.Ba = []))
                  : e("M210");
              };
              return m;
            })(b.fd);
          f.Ba = [];
          b.pp = f;
          b.Gk = new f();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (b) {
            function f(a) {
              return b.call(this, a) || this;
            }
            u(f, b);
            f.prototype.type = function () {
              return a.EventType.WebVital;
            };
            return f;
          })(b.EventTracker);
          b.WebVitalView = e;
          b.Ma(b.K[a.EventType.WebVital], e.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function b(a) {
              this.De = null;
              this.k = !1;
              this.promise = null;
              this.fn = a;
            }
            b.prototype.start = function () {
              var b = this;
              this.k ||
                (this.promise = new window.Promise(function (a) {
                  b.De = setTimeout(function () {
                    b.k = !1;
                    a();
                  }, b.fn);
                  b.k = !0;
                }));
              if (this.promise) return this.promise;
              throw new a.Error("Timeout not started");
            };
            b.prototype.cancel = function () {
              this.k &&
                this.De &&
                (clearTimeout(this.De), (this.k = !1), (this.promise = null));
            };
            return b;
          })();
          b.Oj = e;
        })(a.utils || (a.utils = {}));
      })(k || (k = {}));
      (function (a) {
        var b = (function () {
          function b() {}
          b.Yj = function (c) {
            try {
              (b.mb.push(c), b.oo() && (b.qc(), b.timeout.cancel()));
            } catch (f) {
              a.logInfo("CWV - CoreWebVitalsQueue -- Error in addMetric");
            }
          };
          b.mo = function () {
            try {
              (a.logInfo("CWV - CoreWebVitalsQueue -- setup"),
                addEventListener("visibilitychange", function () {
                  "hidden" === document.visibilityState && b.qc();
                }),
                addEventListener("pagehide", b.qc),
                (b.timeout = new a.utils.Oj(b.xj)),
                b.Vh());
            } catch (c) {
              a.logInfo("CWV - CoreWebVitalsQueue -- Error in setup");
            }
          };
          b.ao = function () {
            b.pk = document.URL;
          };
          b.oo = function () {
            try {
              for (var c = [], f = 0; f < b.mb.length; f++) {
                var p = b.mb[f];
                c.push(p.name && p.name.toLocaleLowerCase());
              }
              return b.Hk.every(function (a) {
                return -1 !== c.indexOf(a);
              });
            } catch (m) {
              return (
                a.logInfo(
                  "CWV - CoreWebVitalsQueue -- Error in shouldFlushQueue",
                ),
                !1
              );
            }
          };
          b.qc = function () {
            try {
              if (0 < b.mb.length) {
                a.logInfo("CWV - CoreWebVitalsQueue -- Flushing Queue");
                var c = [];
                b.mb.forEach(function (a) {
                  var f = a.name && a.name.toLowerCase();
                  c.push({
                    webVitalValue: a.value && parseFloat(a.value.toFixed(3)),
                    webVitalRating: a.rating,
                    webVitalName: f,
                  });
                  b.ak(f);
                });
                var f = new a.events.WebVitalView({ coreWebVitalsMetrics: c });
                f.url(b.pk);
                a.command("reportWebVital", f);
                b.reset();
              }
              b.Ek();
            } catch (p) {
              a.logInfo("CWV - CoreWebVitalsQueue -- Error in flushQueue");
            }
          };
          b.Vh = function () {
            try {
              (b.timeout.cancel(),
                b.timeout.start().then(function () {
                  b.qc();
                }));
            } catch (c) {
              a.logInfo("CWV - CoreWebVitalsQueue -- Error in startTimer");
            }
          };
          b.reset = function () {
            b.mb = [];
          };
          b.ak = function (a) {
            -1 !== b.ue.indexOf(a) && b.ue.push(a);
          };
          b.Ek = function () {
            try {
              ["cls", "lcp"].every(function (a) {
                return -1 !== b.ue.indexOf(a);
              })
                ? (a.logInfo(
                    "CWV - CoreWebVitalsQueue -- All events collected",
                  ),
                  b.timeout.cancel())
                : b.Vh();
            } catch (c) {
              a.logInfo(
                "CWV - CoreWebVitalsQueue -- Error in checkForCompletion",
              );
            }
          };
          return b;
        })();
        b.mb = [];
        b.xj = 12e4;
        b.Hk = ["cls", "lcp", "fid"];
        b.ue = [];
        a.ed = b;
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.isDefined,
            c = (function () {
              function b() {}
              b.prototype.setUp = function () {
                function p() {
                  if (n >= m)
                    a.logInfo(
                      "CWV - Failed to load cwv script after " +
                        m +
                        " attempts.",
                    );
                  else {
                    var l = document.createElement("script"),
                      c = a.conf.elementIdWithNonce;
                    l.type = "text/javascript";
                    l.async = !0;
                    l.src =
                      "https://cdn.appdynamics.com/adrum/web-vitals/web-vitals.iife.3.3.2.js";
                    c &&
                      e(a.utils.trim(c)) &&
                      (c = document.getElementById(c)) &&
                      ((c = c.nonce),
                      (c = a.utils.trim(c)),
                      e(c) && !a.utils.um(c) && l.setAttribute("nonce", c));
                    l.onload = function () {
                      b.webVitalsGlobal = window.webVitals;
                      b.ko();
                    };
                    l.onerror = function () {
                      a.logInfo("CWV - Failed to load cwv script, retrying...");
                      n++;
                      p();
                    };
                    document.head.appendChild(l);
                  }
                }
                var m = 3,
                  n = 0;
                p();
              };
              b.ko = function () {
                if (e(b.webVitalsGlobal)) {
                  var p = { reportAllChanges: !1 };
                  b.webVitalsGlobal.onFID(b.ie, p);
                  b.webVitalsGlobal.onCLS(b.ie, p);
                  b.webVitalsGlobal.onLCP(b.ie, p);
                  a.ed.mo();
                  a.ed.ao();
                } else a.logInfo("CWV - webVitalsGlobal is not defined");
              };
              b.ie = function (b) {
                a.logInfo(
                  "CWV - Metric reported " +
                    b.name +
                    " -- " +
                    b.value +
                    " -- " +
                    b.rating,
                );
                a.ed.Yj(b);
              };
              return b;
            })();
          b.WebVitalsMonitor = c;
          b.bp = new b.WebVitalsMonitor();
        })(a.monitor || (a.monitor = {}));
      })(k || (k = {}));
      (function (a) {
        var b = a.utils.isDefined,
          e = a.utils.xm,
          c = a.utils.isNumber,
          f = a.monitor.Pi,
          p = a.conf.ja;
        a.ni = window.Promise;
        a.gc = null;
        a.Cq = null;
        a.nf = Object.defineProperty;
        var m = a.conf.spa2 && a.conf.modernBrowserFeaturesAvailable,
          n = a.conf.isZonePromise,
          l = a.conf.fetch,
          q = (function () {
            function l() {}
            l.km = function () {
              Object.defineProperty = a.aop.around(a.nf, function (a, f, n) {
                "Promise" === f && b(n) && l.Cg(n);
              });
              if (n && a.utils.ae()) {
                a.logInfo("M211");
                var f = Object.getOwnPropertyDescriptor(window, "Promise");
                l.Cg(f);
                a.nf(window, "Promise", f);
                window.Promise = window.Promise;
              }
            };
            l.Cg = function (f) {
              b(window.Zone) &&
                b(window.Zone.assertZonePatched) &&
                (window.Zone.assertZonePatched = function () {});
              f = f || Object.getOwnPropertyDescriptor(window, "Promise");
              var n = f.set,
                m = f.get;
              h(n) &&
                (f.set = function (f) {
                  !0 === f.agentPromise
                    ? a.logInfo("M212")
                    : (n.apply(this, arguments),
                      b(a.gc)
                        ? n.apply(this, arguments)
                        : (a.logInfo("M213"), l.setUp()));
                });
              h(m) &&
                (f.get = function () {
                  var f = m.apply(this, arguments);
                  b(a.gc) && (a.logInfo("M214"), (f = a.gc));
                  return f;
                });
            };
            l.setUp = function () {
              if (b(a.ni)) {
                l.nm();
                l.mm();
                var f = (function (f) {
                  function n(p) {
                    var e = this.constructor,
                      c = p;
                    this.aa = a.utils.generateGUID();
                    b(p) && (c = l.lm(p, this));
                    p = a.utils.Uj(this, f, [c], e);
                    m &&
                      (b(this.h) && (p.h = this.h),
                      b(this.Xa) ? (p.h = this.Xa.h) : (p.h = a.b.ra()));
                    p.aa = this.aa;
                    this.Xa = p;
                    a.logInfo("M215", p.aa);
                    m && b(p.h) && a.logInfo("M216", p.h.guid);
                    return p;
                  }
                  a.utils.kd(n, f);
                  return n;
                })(window.Promise);
                f.agentPromise = !0;
                a.gc = f;
                window.Promise = f;
                b(window.addEventListener)
                  ? window.addEventListener("unhandledrejection", this.ei)
                  : (window.nq = this.ei);
              }
            };
            l.Oa = function (f, n) {
              return function () {
                if (m) {
                  var e,
                    c = void 0;
                  e = void 0;
                  a.logInfo("M217", f);
                  switch (f) {
                    case l.J.df:
                    case l.J.cf:
                    case l.J.Te:
                    case l.J.Se:
                      a.utils.isDefined(n) &&
                        a.utils.isDefined(n.Xa) &&
                        (c = n.Xa.h);
                      e = a.b.ra() || c;
                      e = new a.$b(e, new a.Ka(f), a.CauseType.PROMISE);
                      break;
                    case l.J.af:
                    case l.J.bf:
                    case l.J.Ze:
                      ((e = n.h),
                        (e = new a.$b(e, new a.Ka(f), a.CauseType.PROMISE)),
                        a.b.ua(e));
                  }
                  p && ((c = a.utils.Sa(f) || ""), (e.oa = c));
                  b(n) &&
                    (b(n.Xa)
                      ? ((n.Xa.h = e), a.logInfo("M218", n.Xa.aa))
                      : (a.logInfo("M219", n.aa), (n.h = e)));
                }
              };
            };
            l.lm = function (f, n) {
              m &&
                (f = a.aop.around(
                  f,
                  function () {
                    n.h = new a.$b(
                      a.b.ra(),
                      new a.Ka(l.J.$e),
                      a.CauseType.PROMISE,
                    );
                    if (p) {
                      var f = a.utils.Sa(l.J.$e) || "";
                      n.h.oa = f;
                    }
                    a.b.ua(n.h);
                    a.logInfo("M220", n.h.guid, n.aa);
                    b(arguments[0]) &&
                      (a.logInfo("M221"),
                      (f = a.aop.around(arguments[0], l.Oa(l.J.df, n))),
                      (arguments[0] = f));
                    b(arguments[1]) &&
                      (a.logInfo("M222"),
                      (f = a.aop.around(arguments[1], l.Oa(l.J.cf, n))),
                      (arguments[1] = f));
                    return a.utils.La(arguments);
                  },
                  function () {
                    a.logInfo("M223");
                    a.b.Q(n.h ? n.h.guid : null);
                  },
                  "interceptPromiseExecutor",
                  l.Lc,
                ));
              return f;
            };
            l.mm = function () {
              a.utils.refs.promiseThen = window.Promise.prototype.then;
              var b = l.rh(),
                f = {
                  parentObject: window.Promise.prototype,
                  property: "then",
                  propertyWrappedFunctionName: "promiseThen",
                  wrapNewFunctionAgain: !0,
                };
              f.setUpFunc = function (b) {
                return function (f) {
                  a.utils.ae() || l.Ln(f, b);
                };
              }.call(this, f);
              f.bb = b;
              a.aop.forceWrap(f);
              a.utils.refs.promiseFinally = window.Promise.prototype["finally"];
              b = l.qh();
              f = {
                parentObject: window.Promise.prototype,
                property: "finally",
                propertyWrappedFunctionName: "promiseFinally",
                wrapNewFunctionAgain: !0,
              };
              f.setUpFunc = function (a) {
                return function (b) {
                  l.Kn(b, a);
                };
              }.call(this, f);
              f.bb = b;
              a.aop.forceWrap(f);
            };
            l.Ln = function (a, b) {
              b.bb = l.rh(a);
            };
            l.Kn = function (a, b) {
              b.bb = l.qh(a);
            };
            l.nm = function () {
              l.In();
              l.Hn();
            };
            l.Gm = function (b) {
              return b instanceof l || b instanceof a.ni;
            };
            l.bm = function (f) {
              var n;
              b(n) || (a.logInfo("M224"), (n = 1));
              b(f.G) && c(f.G) && ((f.G += n), a.logInfo("M225", f.G));
            };
            l.Qk = function (a) {
              var f;
              b(f) || (f = 1);
              b(a.G) && c(a.G) && (a.G -= f);
            };
            l.dm = function (f) {
              b(f.G) && a.utils.Bm(f.G)
                ? (a.logInfo("M226"), l.bm(f))
                : (f.G = 1);
            };
            l.Mo = function (b) {
              f.Xo(b) || (a.logInfo("M227"), l.dm(b));
            };
            l.Pn = function (a) {
              a.G = 0;
            };
            l.Zd = function (a) {
              return b(a.L);
            };
            l.rh = function (n) {
              var p = null;
              n = n || window.Promise.prototype.then;
              n = a.aop.around(
                n,
                function () {
                  var n = this;
                  p = n;
                  a.logInfo("M228", n.aa);
                  if (b(arguments[0]) && a.utils.isFunction(arguments[0])) {
                    l.Mo(n);
                    a.logInfo("M229", n.aa);
                    var e = a.aop.around(
                      arguments[0],
                      function () {
                        l.Oa(l.J.af, n)();
                        n &&
                          !n.G &&
                          f.ca(n) &&
                          !l.Zd(n) &&
                          ((n._adrumAjaxT.tempRespAvailAndProcTime =
                            a.utils.now()),
                          (f.Ya[n._adrumAjaxT.guid()] = {
                            requestObj: n,
                            ajaxT: n._adrumAjaxT,
                          }));
                      },
                      function () {
                        var p = a.utils.Md(arguments, "origFuncResult");
                        b(p) && b(p.G) && l.Gm(p) && f.ca(n)
                          ? (f.No(p, n), l.Pn(p))
                          : (f.ca(n) &&
                              !l.Zd(n) &&
                              f.uc(n) &&
                              (f.Je(n),
                              f.lc(n),
                              !0 === f.Ke(n) &&
                                (a.logInfo("M230"),
                                a.logInfo("M231"),
                                delete f.Ya[n._adrumAjaxT.guid()],
                                f.pb(n))),
                            m &&
                              (a.logInfo("M232"),
                              a.b.Q(n.h ? n.h.guid : null)));
                      },
                      "interceptPromiseThenFulfil",
                      function () {
                        f.ca(n) &&
                          f.uc(n) &&
                          (f.Je(n) && f.lc(n),
                          !0 === f.Ke(n) &&
                            (a.logInfo("M233"),
                            a.logInfo("M234"),
                            delete f.Ya[n._adrumAjaxT.guid()],
                            f.pb(n)));
                      },
                    );
                    arguments[0] = e;
                  }
                  b(arguments[1]) &&
                    a.utils.isFunction(arguments[1]) &&
                    (a.logInfo("M235", n.aa),
                    (e = a.aop.around(
                      arguments[1],
                      l.Oa(l.J.bf, n),
                      function () {
                        m && (a.logInfo("M236"), a.b.Q(n.h ? n.h.guid : null));
                      },
                      null,
                      l.Lc,
                    )),
                    (arguments[1] = e));
                  return a.utils.La(arguments);
                },
                function () {
                  var n = a.utils.Md(arguments, "origFuncResult");
                  !b(n) ||
                    (b(arguments[0]) && !a.utils.isFunction(arguments[0])) ||
                    (m && (n.h = this.h),
                    l.Zd(this) &&
                      f.ca(this) &&
                      ((n._adrumAjaxT = this._adrumAjaxT),
                      f.uc(this) || f.em(n)));
                },
                "interceptPromiseThenInterceptor",
                function () {
                  var b = p;
                  f.ca(b) &&
                    f.uc(b) &&
                    (f.Je(b) && f.lc(b),
                    !0 === f.Ke(b) &&
                      (a.logInfo("M237"),
                      a.logInfo("M238"),
                      delete f.Ya[b._adrumAjaxT.guid()],
                      f.pb(b)));
                },
              );
              n.usedByAgent = !0;
              return (window.Promise.prototype.then = n);
            };
            l.qh = function (n) {
              if (b(window.Promise.prototype["finally"]))
                return (
                  (n = n || window.Promise.prototype["finally"]),
                  (n = a.aop.around(
                    n,
                    function () {
                      var n = this;
                      b(n._adrumAjaxT) && b(n._adrumAjaxT.C)
                        ? f.lc(n)
                        : b(n.G) && l.Qk(n);
                      if (b(arguments[0])) {
                        a.logInfo("M239", n.aa);
                        var p = a.aop.around(
                          arguments[0],
                          l.Oa(l.J.Ze, n),
                          function () {
                            m &&
                              (a.logInfo("M240"), a.b.Q(n.h ? n.h.guid : null));
                          },
                        );
                        arguments[0] = p;
                        return a.utils.La(arguments);
                      }
                    },
                    function () {
                      a.logInfo("M241");
                      a.b.Q(this.h ? this.h.guid : null);
                    },
                    "interceptPromiseFinally",
                  )),
                  (n.usedByAgent = !0),
                  (window.Promise.prototype["finally"] = n)
                );
            };
            l.In = function () {
              window.Promise.resolve = a.aop.around(
                window.Promise.resolve,
                l.Oa(l.J.Te, null),
                null,
                "interceptPromiseResolve",
                l.Lc,
              );
            };
            l.Hn = function () {
              window.Promise.reject = a.aop.around(
                window.Promise.reject,
                l.Oa(l.J.Se, null),
                null,
                "interceptPromiseReject",
                l.Lc,
              );
            };
            l.ei = function (b) {
              var f = b.detail ? b.detail.reason : b.reason;
              if (b.promise && !b.promise.aa) b.preventDefault();
              else {
                if (!e(f))
                  try {
                    f = new window.Error(f);
                  } catch (n) {
                    f = n;
                  }
                a.monitor.ErrorMonitor.B(f);
              }
            };
            return l;
          })();
        q.J = {
          $e: "PromiseInstance.init",
          df: "PromiseInstance.resolve",
          cf: "PromiseInstance.reject",
          af: "PromiseInstance.onFulfilled",
          bf: "PromiseInstance.onRejected",
          Ze: "PromiseInstance.finally",
          Te: "PromiseConstructor.resolve",
          Se: "PromiseConstructor.reject",
        };
        q.Lc = function () {};
        a.Ej = q;
        n && l && (q.km(), f.lg().im());
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          function e(a, b) {
            var f = [],
              e = /^\s*(ADRUM_BT\w*)=(.*)\s*$/i.exec(a);
            if (e) {
              var c = e[1],
                e = e[2].replace(/^"|"$/g, ""),
                e = decodeURIComponent(e).split("|"),
                x = e[0].split(":");
              if ("R" === x[0] && Number(x[1]) === b)
                for (p(c), c = 1; c < e.length; c++) f.push(e[c]);
            }
            return f;
          }
          function c(a, b) {
            var f = /^\s*(ADRUM_(\d+)_(\d+)_(\d+))=(.*)\s*$/i.exec(a);
            if (f) {
              var e = f[1],
                c = f[4],
                x = f[5];
              if (Number(f[3]) === b)
                return (p(e), { index: Number(c), value: x });
            }
            return null;
          }
          function f(b) {
            var f = /^\s*ADRUM=s=([\d]+)&r=(.*)\s*/.exec(b);
            if (f) {
              a.logInfo("M244", b);
              if (3 === f.length)
                return (
                  p("ADRUM", "samesite=lax"),
                  { startTime: Number(f[1]), startPage: f[2] }
                );
              a.error("M245", b);
              return null;
            }
          }
          function p(b, f) {
            a.logInfo("M243", b);
            var p = new Date();
            p.setTime(p.getTime() - 1e3);
            document.cookie =
              b + "=;Expires=" + p.toUTCString() + ";" + (f || "");
          }
          b.startTimeCookie = null;
          b.cookieMetadataChunks = null;
          b.Uf = function (m, n) {
            a.logInfo("M242");
            for (
              var p = n ? n.length : 0, q = [], k = m.split(";"), x = 0;
              x < k.length;
              x++
            ) {
              var s = k[x],
                z = c(s, p);
              z
                ? q.push(z)
                : ((s = f(s)), null != s && (b.startTimeCookie = s));
            }
            Array.prototype.sort.call(q, function (a, b) {
              return a.index - b.index;
            });
            s = [];
            for (x = 0; x < q.length; x++) s.push(q[x].value);
            for (x = 0; x < k.length; x++)
              (q = e(k[x], p)) && 0 < q.length && (s = s.concat(q));
            b.cookieMetadataChunks = s;
          };
          a.correlation.eck = b.Uf;
        })(a.correlation || (a.correlation = {}));
      })(k || (k = {}));
      (function (a) {
        var b = window.addEventListener,
          e = a.utils.isDefined(window.EventTarget)
            ? window.EventTarget.prototype.addEventListener
            : function () {},
          c = a.utils.isDefined(window.EventTarget)
            ? window.EventTarget.prototype.removeEventListener
            : function () {},
          f = (function () {
            function f() {}
            f.setUp = function () {
              Array.prototype.push.apply(f.Cd, []);
              f.dp();
              a.utils.isDefined(window.EventTarget) ? (f.ep(), f.fp()) : f.bk();
              f.Dg("onload");
              f.Dg("onerror");
            };
            f.rq = function () {
              return [];
            };
            f.ul = function (b, n) {
              var l = "";
              if (a.utils.isDefined(b))
                if ("string" === typeof b.textContent)
                  ((l = a.utils.isDefined(String.prototype.trim)
                    ? b.textContent.trim()
                    : b.textContent),
                    (l = a.utils.isDefined(n) ? l.substring(0, n) : l));
                else
                  for (
                    b = b.firstChild;
                    a.utils.isDefined(b) &&
                    !((l += f.ul(b, n)), a.utils.isDefined(n) && l.length >= n);
                    b = b.nextSibling
                  );
              return l;
            };
            f.dp = function () {
              a.utils.forEach(f.Cd, function (f) {
                b(
                  f,
                  function (b) {
                    b = b.target || b.srcElement;
                    (b === document ||
                      b === window ||
                      b instanceof XMLHttpRequest ||
                      b instanceof HTMLElement) &&
                      null != b &&
                      b["on" + f] &&
                      ((b["on" + f] = a.b.cd(
                        f,
                        b["on" + f],
                        a.CauseType.USER,
                        !0,
                      )),
                      (b["on" + f].L = !0));
                  },
                  !0,
                );
              });
            };
            f.bk = function () {
              a.utils.forEach(f.Cd, function (f) {
                b(
                  f,
                  function (b) {
                    b = a.b.Qa(f, b, null, a.CauseType.USER);
                    a.b.ua(b);
                  },
                  !0,
                );
                b(
                  f,
                  function () {
                    a.b.Q();
                  },
                  !1,
                );
              });
            };
            f.hi = function (b) {
              var f = !1;
              a.utils.isBoolean(b)
                ? (f = b)
                : a.utils.isObject(b) &&
                  a.utils.isDefined(b.capture) &&
                  (f = !!b.capture);
              return f;
            };
            f.Kh = function (b, f, p, e) {
              if (
                !a.utils.isDefined(b.eventListenerMap) ||
                !a.utils.isDefined(b.eventListenerMap[f]) ||
                !a.utils.isDefined(p)
              )
                return -1;
              b = b.eventListenerMap[f];
              for (f = 0; f < b.length; f++)
                if (b[f][0] == p && b[f][1] == e) return f;
              return -1;
            };
            f.Bg = function (b, f, p, e, c) {
              a.utils.isDefined(b) &&
                a.utils.isDefined(c) &&
                (a.utils.isDefined(b.eventListenerMap) ||
                  (b.eventListenerMap = {}),
                a.utils.isDefined(b.eventListenerMap[f]) ||
                  (b.eventListenerMap[f] = []),
                b.eventListenerMap[f].push([p, e, c]));
            };
            f.Mn = function (a, b, f) {
              if (-1 < f) {
                var p = a.eventListenerMap[b];
                delete p[f];
                p.splice(f, 1);
                0 == p.length && delete a.eventListenerMap[b];
              }
            };
            f.ep = function () {
              EventTarget.prototype.addEventListener = function (b, n, l) {
                if ((a.utils.isDefined(n) && n.L) || (!a.b.Gg(n) && !h(n)))
                  return e.call(this, b, n, l);
                var c = f.hi(l),
                  k = a.utils.isDefined(this) ? this : window;
                if (!(-1 < f.Kh(k, b, n, c))) {
                  var x = n;
                  switch (b) {
                    case "click":
                    case "dblclick":
                    case "auxclick":
                    case "mousedown":
                    case "mouseup":
                    case "drop":
                    case "keyup":
                    case "keydown":
                    case "keypress":
                    case "contextmenu":
                    case "pageChanged":
                    case "close":
                      x = a.b.cd(b, n, a.CauseType.USER, !0);
                      f.Bg(k, b, n, c, x);
                      break;
                    case "load":
                    case "error":
                      ((x = a.b.cd(b, n, a.CauseType.USER, !1)),
                        f.Bg(k, b, n, c, x));
                  }
                  e.call(k, b, x, l);
                }
              };
            };
            f.fp = function () {
              EventTarget.prototype.removeEventListener = function (b, n, l) {
                if (a.utils.isDefined(n) && n.L) return c.call(this, b, n, l);
                var e = f.hi(l),
                  k = a.utils.isDefined(this) ? this : window,
                  e = f.Kh(k, b, n, e);
                0 <= e
                  ? (c.call(k, b, this.eventListenerMap[b][e][2], l),
                    f.Mn(k, b, e))
                  : c.call(k, b, n, l);
              };
            };
            f.Dg = function (b) {
              var f = HTMLElement.prototype,
                p = Object.getOwnPropertyDescriptor(f, b);
              a.utils.isDefined(p) &&
                a.utils.isDefined(p.set) &&
                Object.defineProperty(f, b, {
                  set: function (f) {
                    var n = f;
                    a.utils.isDefined(f) &&
                      (n = a.b.cd(b, f, a.CauseType.RESOURCE, !1));
                    var e;
                    try {
                      e = p.set.call(this, n);
                    } catch (c) {
                      throw c;
                    }
                    return e;
                  },
                });
            };
            return f;
          })();
        f.Cd =
          "click dblclick mousedown mouseup change select submit keydown keypress keyup load unload".split(
            " ",
          );
        a.Ni = f;
      })(k || (k = {}));
      (function (a) {
        "APP_KEY_NOT_SET" !== a.conf.appKey ||
          a.utils.isDefined(window.ADEUM_js_handler) ||
          a.utils.isDefined(window.webkit) ||
          A.log(
            "AppDynamics EUM cloud application key missing. Please specify window['adrum-app-key']",
          );
        a.correlation.Uf(document.cookie, document.referrer);
        a.b.setUp();
        a.command("mark", "firstbyte", window["adrum-start-time"]);
        a.monitor.setUpMonitors(
          a.monitor.ia,
          a.monitor.Gk,
          a.monitor.domEventsMonitor,
          a.monitor.navMonitor,
          a.monitor.xhrMonitor,
          a.monitor.resourceMonitor,
        );
        a.conf.disableWrappingEventListeners || a.Ni.setUp();
        a.conf.fetch &&
          !a.conf.isZonePromise &&
          (a.Ej.setUp(), a.monitor.setUpMonitors(a.monitor.Gb));
        a.conf.spa2 &&
          a.conf.modernBrowserFeaturesAvailable &&
          a.monitor.setUpMonitors(a.monitor.ik);
        a.conf.enablePrimaryMetrics &&
          a.utils.isDefined(window.MutationObserver) &&
          ((a.conf.N = !0),
          a.l.w.M.Rh(),
          a.l.w.start(a.utils.fb()),
          a.c.start());
        a.conf.enableCoreWebVitals && a.monitor.setUpMonitors(a.monitor.bp);
      })(k || (k = {}));
      (function (a) {
        a = a.ng || (a.ng = {});
        a = a.n || (a.n = {});
        a.Sg = "locationChangeStart";
        a.Ym = "locationChangeSuccess";
        a.Gh = "routeChangeStart";
        a.Hh = "routeChangeSuccess";
        a.Wh = "stateChangeStart";
        a.Xh = "stateChangeSuccess";
        a.ki = "viewContentLoaded";
        a.Yl = "includeContentRequested";
        a.Xl = "includeContentLoaded";
        a.Sf = "digest";
        a.oq = "outstandingRequestsComplete";
        a.Gf = "beforeNgXhrRequested";
        a.xf = "afterNgXhrRequested";
        a.mq = "ngXhrLoaded";
        a.Kf = "$$completeOutstandingRequest";
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          function e(a, f, n, l, e, c) {
            if (f)
              try {
                return f.apply(a, [n, l, e].concat(c));
              } catch (k) {
                return a.error(n, l, e, c, b.Error.Xi, "M246", k);
              }
          }
          function c(a, f) {
            return function () {
              var n = this.current,
                l = f[n] || f[b.cc] || n,
                c = Array.prototype.slice.call(arguments);
              if (this.Ck(a))
                return this.error(
                  a,
                  n,
                  l,
                  c,
                  b.Error.Yi,
                  "event " + a + "M247" + this.current,
                );
              if (!1 === e(this, this["onbefore" + a], a, n, l, c))
                return b.bc.Re;
              l === b.cc && (l = n);
              if (n === l)
                return (
                  e(this, this["onafter" + a] || this["on" + a], a, n, l, c),
                  b.bc.yj
                );
              var k = this;
              this.transition = function () {
                k.transition = null;
                k.current = l;
                e(k, k["onenter" + l] || k["on" + l], a, n, l, c);
                e(k, k["onafter" + a] || k["on" + a], a, n, l, c);
                return b.bc.Jj;
              };
              if (!1 === e(this, this["onleave" + n], a, n, l, c))
                return ((this.transition = null), b.bc.Re);
              if (this.transition) return this.transition();
            };
          }
          var f = a.utils.hasOwnPropertyDefined;
          b.VERSION = "2.3.5";
          b.bc = { Jj: 1, yj: 2, Re: 3, tp: 4 };
          b.Error = { Yi: 100, up: 200, Xi: 300 };
          b.cc = "*";
          b.create = function (a, m) {
            function n(a) {
              var f =
                a.from instanceof Array ? a.from : a.from ? [a.from] : [b.cc];
              s[a.name] = s[a.name] || {};
              for (var n = 0; n < f.length; n++)
                ((z[f[n]] = z[f[n]] || []),
                  z[f[n]].push(a.name),
                  (s[a.name][f[n]] = a.to || f[n]));
            }
            var l =
                "string" == typeof a.initial ? { state: a.initial } : a.initial,
              e = m || a.target || {},
              k = a.events || [],
              x = a.callbacks || {},
              s = {},
              z = {};
            l &&
              ((l.event = l.event || "startup"),
              n({ name: l.event, from: "none", to: l.state }));
            for (var w = 0; w < k.length; w++) n(k[w]);
            for (var v in s) f(s, v) && (e[v] = c(v, s[v]));
            for (v in x) f(x, v) && (e[v] = x[v]);
            e.current = "none";
            e.Xp = function (a) {
              return a instanceof Array
                ? 0 <= a.indexOf(this.current)
                : this.current === a;
            };
            e.Bk = function (a) {
              return (
                !this.transition && (f(s[a], this.current) || f(s[a], b.cc))
              );
            };
            e.Ck = function (a) {
              return !this.Bk(a);
            };
            e.Wc = function () {
              return z[this.current];
            };
            e.error =
              a.error ||
              function (a, b, f, n, p, m, l) {
                throw l || m;
              };
            if (l && !l.defer) e[l.event]();
            return e;
          };
        })(a.qf || (a.qf = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function (e) {
            function f(b) {
              b = e.call(this, b) || this;
              a.utils.isDefined(a.ng) &&
                b.constructor != a.ng.NgVPageView &&
                b.constructor != f &&
                a.reportAPIMessage(a.Z.wa, a.tb, "ADRUM.events.VPageView", []);
              if (a.conf.spa2) return b;
              b.perf = new a.PerformanceTracker();
              b.start();
              a.monitor.xhrMonitor.Pc();
              a.monitor.Gb.Pc();
              a.monitor.ia.On();
              return b;
            }
            u(f, e);
            f.prototype.type = function () {
              return a.EventType.VPageView;
            };
            f.prototype.Ld = function () {
              return b.EventTracker.od(this.guid(), this.url(), this.type());
            };
            f.prototype.Uh = function (b) {
              var f = this.Ld();
              b.set("parent", f);
              a.logInfo("M248", f.guid(), f.url());
            };
            f.prototype.startCorrelatingXhrs = function () {
              a.conf.spa2 || (a.logInfo("M249"), this.Uh(a.monitor.xhrMonitor));
            };
            f.prototype.stopCorrelatingXhrs = function () {
              a.conf.spa2 ||
                (a.monitor.xhrMonitor.set("parent", null), a.logInfo("M250"));
            };
            f.prototype.ze = function () {
              a.conf.spa2 || (a.logInfo("M251"), this.Uh(a.monitor.ia));
            };
            f.prototype.start = function () {
              a.conf.spa2 ||
                (this.markVirtualPageStart(), this.startCorrelatingXhrs());
            };
            f.prototype.end = function () {
              a.conf.spa2 ||
                (this.markVirtualPageEnd(), this.stopCorrelatingXhrs());
            };
            return f;
          })(b.EventTracker);
          b.VPageView = e;
          b.Ma(b.K[a.EventType.VPageView], e.prototype);
          b.Bf(b.metricSpec[a.EventType.VPageView], e.prototype);
        })(a.events || (a.events = {}));
      })(k || (k = {}));
      (function (a) {
        var b = a.ng || (a.ng = {}),
          b = b.conf || (b.conf = {});
        b.disabled =
          a.conf.userConf &&
          a.conf.userConf.spa &&
          a.conf.userConf.spa.angular &&
          a.conf.userConf.spa.angular.disable;
        b.distinguishVPwithItsTemplateUrl =
          a.conf.userConf &&
          a.conf.userConf.spa &&
          a.conf.userConf.spa.angular &&
          !0 === a.conf.userConf.spa.angular.distinguishVPwithItsTemplateUrl
            ? !0
            : !1;
        b.xhr = {};
        b.metrics = { includeResTimingInEndUserResponseTiming: !0 };
        a.conf.userConf &&
          a.conf.userConf.spa &&
          a.conf.userConf.spa.angular &&
          a.conf.userConf.spa.angular.vp &&
          (a.conf.userConf.spa.angular.vp.xhr &&
            a.utils.Ja.oh(a.conf.userConf.spa.angular.vp.xhr),
          a.conf.userConf.spa.angular.vp.metrics &&
            a.utils.mergeJSON(
              b.metrics,
              a.conf.userConf.spa.angular.vp.metrics,
            ));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.map,
            c = a.utils.reduce,
            f = a.utils.filter,
            p = (function (m) {
              function n(b) {
                b = m.call(this, b) || this;
                b.Ig = !0;
                b.Rb = {};
                b.sb = 0;
                b.Hq = [];
                b.digestCount(0);
                if (b.constructor != n)
                  return (
                    a.reportAPIMessage(a.Z.wa, a.tb, "ADRUM.events.Ajax", []),
                    b
                  );
                b.stopCorrelatingXhrs();
                return b;
              }
              u(n, m);
              n.prototype.type = function () {
                return a.EventType.VPageView;
              };
              n.prototype.Ne = function () {
                this.markViewChangeStart();
                this.markVirtualPageStart(this.getViewChangeStart());
                this.timestamp(this.getViewChangeStart());
              };
              n.prototype.Zl = function () {
                this.digestCount(this.digestCount() + 1);
              };
              n.prototype.$l = function () {
                this.sb++;
                a.logInfo("M252", this.sb);
              };
              n.prototype.Pk = function () {
                this.sb--;
                a.logInfo("M253", this.sb);
              };
              n.prototype.Tl = function () {
                var b = this.perf.getEntryByName(a.events.g.si);
                a.logInfo("M254", this.sb, b);
                return 0 < this.sb;
              };
              n.prototype.wk = function () {
                var a = { Vc: 0 },
                  b = document.querySelectorAll(
                    "ng-view, [ng-view], .ng-view, [ui-view]",
                  ),
                  b = e(b, angular.element),
                  f;
                for (f in n.Dh) {
                  var m = n.Dh[f];
                  e(b, function (b) {
                    b = b.find(f);
                    e(b, function (b) {
                      if ((b = b[m]))
                        ((b = decodeURIComponent(b)),
                          a[b] || ((a[b] = f), a.Vc++));
                    });
                  });
                }
                this.Rb = a;
              };
              n.prototype.sk = function (a) {
                return !!this.Rb[decodeURIComponent(a.name)];
              };
              n.prototype.xk = function () {
                var b = [],
                  f = this;
                0 < this.Rb.Vc &&
                  (b = a.monitor.resourceMonitor.Ib().filter(function (a) {
                    return f.sk(a);
                  }));
                this.resTiming(b);
              };
              n.fl = function (b) {
                return f(b, function (b) {
                  return (
                    (b.eventType === a.EventType.Ajax ||
                      b.eventType === a.EventType.ADRUM_XHR) &&
                    !a.utils.Ja.Tc(b.eventUrl, b.method)
                  );
                });
              };
              n.Bl = function (a) {
                return c(
                  a,
                  function (a, b) {
                    return Math.max(a, b.timestamp + b.metrics.PLT);
                  },
                  -1,
                );
              };
              n.prototype.fk = function () {
                if (b.conf.xhr) {
                  var f = n.fl(a.channel.getEventsWithParentGUID(this.guid())),
                    f = n.Bl(f);
                  if (0 < f) {
                    var m = this.perf.getEntryByName(a.events.g.si);
                    this.markXhrRequestsCompleted(
                      Math.min((m && m.startTime) || Number.MAX_VALUE, f),
                    );
                  }
                }
              };
              n.prototype.adjustTimings = function () {
                this.fk();
                var f = this.getViewDOMLoaded(),
                  n = this.getXhrRequestsCompleted(),
                  f = Math.max(f, n);
                b.conf.metrics.includeResTimingInEndUserResponseTiming &&
                  (this.ek(),
                  (n = this.getViewResourcesLoaded()),
                  (n = Math.max(f, n)),
                  a.logInfo("M255", f, n),
                  (f = n));
                this.markVirtualPageEnd(f);
              };
              n.prototype.ek = function () {
                if (0 < this.Rb.Vc) {
                  this.xk();
                  var b = this.resTiming();
                  b &&
                    b.length >= this.Rb.Vc &&
                    ((b = c(
                      b,
                      function (a, b) {
                        return Math.max(a, b.responseEnd);
                      },
                      0,
                    )),
                    this.markViewResourcesLoaded(a.PerformanceTracker.vd(b)));
                }
              };
              n.prototype.identifier = function (b) {
                var f = this.mi;
                a.utils.isDefined(b) &&
                  ((this.mi = n.dl(b)), this.url(this.mi.url));
                return f;
              };
              n.dl = function (b) {
                var f = {};
                b && b.R
                  ? ((f.R = { me: "" }),
                    a.utils.mergeJSON(f.R, {
                      me: b.R.originalPath,
                      Sb: b.R.template,
                      Tb: b.R.templateUrl,
                    }))
                  : b &&
                    b.state &&
                    ((f.state = { url: "" }),
                    a.utils.mergeJSON(f.state, {
                      url: b.state.url,
                      name: b.state.name,
                      Sb: b.state.template,
                      Tb: b.state.templateUrl,
                    }));
                return f;
              };
              return n;
            })(a.events.VPageView);
          p.Dh = { img: "src", script: "src", link: "href" };
          b.NgVPageView = p;
          a.events.Ma(a.events.K[a.EventType.NG_VIRTUAL_PAGE], p.prototype);
        })(a.ng || (a.ng = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function e() {
              this.F = new b.NgVPageView();
            }
            e.prototype.Wn = function () {
              var f = this,
                p = this.F;
              b.conf.metrics.includeResTimingInEndUserResponseTiming
                ? (a.logInfo("M256"),
                  a.utils.oSTO(function () {
                    f.qe(p);
                  }, e.Lj))
                : a.utils.oSTO(function () {
                    f.qe(p);
                  }, e.Mj);
            };
            e.prototype.qe = function (b) {
              a.logInfo("M257");
              b.parent(a.monitor.DOMEventsMonitor.currentBasePage);
              a.command("call", function () {
                b.adjustTimings();
                a.reporter.reportEvent(b);
              });
            };
            e.prototype.ho = function (a) {
              this.F = a;
            };
            return e;
          })();
          e.Lj = 5e3;
          e.Mj = 2 * a.monitor.XHRMonitor.Ve;
          b.VirtualPageStateMachine = e;
          a.qf.create(
            {
              events: [
                { name: "start", from: "none", to: "ChangeView" },
                { name: "viewLoaded", from: "ChangeView", to: "XhrPending" },
                { name: "xhrCompleted", from: "XhrPending", to: "End" },
                { name: "abort", from: "*", to: "none" },
                { name: "init", from: "*", to: "none" },
                { name: "locChange", from: "*", to: "*" },
                { name: "beforeXhrReq", from: "*", to: "*" },
                { name: "afterXhrReq", from: "*", to: "*" },
              ],
              error: function (b) {
                a.logError("M258", b);
              },
              callbacks: {
                onChangeView: function () {
                  this.F.Ne();
                  this.F.ze();
                },
                onviewLoaded: function () {
                  this.F.markViewDOMLoaded();
                },
                onXhrPending: function () {
                  this.F.Ig && this.xhrCompleted();
                },
                onleaveXhrPending: function (a, b, p) {
                  if ("abort" === a) return (this.qe(), !0);
                  if ("xhrCompleted" === a && "End" === p) {
                    if (this.F.Tl()) return !1;
                    this.F.markXhrRequestsCompleted();
                    return !0;
                  }
                },
                onEnd: function () {
                  this.F.wk();
                  this.Wn();
                },
                oninit: function (b, f, p, m) {
                  this.ho(m);
                  a.monitor.xhrMonitor.Pc();
                  a.monitor.Gb.Pc();
                },
                onlocChange: function (a, b, p, m) {
                  this.F.identifier.url = m;
                  this.F.Sc({ url: m });
                },
                onbeforeXhrReq: function (b, f, p, m) {
                  var n = this.F;
                  n.Ig = !1;
                  a.logInfo("M259", (m && m[1]) || "", n.guid());
                  n.$l();
                  n.startCorrelatingXhrs();
                  m[3] &&
                    (m[3] = a.aop.before(m[3], function (b, f, m) {
                      a.logInfo("M260");
                      n.Pk();
                      m &&
                        (b = a.utils.wn(m)["content-type"]) &&
                        0 <= b.indexOf("text/html") &&
                        n.markViewFragmentsLoaded();
                    }));
                  return m;
                },
                onafterXhrReq: function () {
                  this.F.stopCorrelatingXhrs();
                },
              },
            },
            e.prototype,
          );
        })(a.ng || (a.ng = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = (function () {
            function e() {
              this.S = new b.VirtualPageStateMachine();
              this.distinguishVPwithItsTemplateUrl =
                a.ng.conf.distinguishVPwithItsTemplateUrl;
            }
            e.prototype.W = function (f, p) {
              a.logInfo("M261", f);
              switch (f) {
                case b.n.Gh:
                case b.n.Wh:
                  this.S.start();
                  var m = p.next.url || document.URL,
                    n = new b.NgVPageView({ url: m, identifier: p.next });
                  this.distinguishVPwithItsTemplateUrl && e.wm(this.S.F, n)
                    ? this.S.F.Sc({ url: m, identifier: p.next })
                    : this.zo(n);
                  break;
                case b.n.Hh:
                case b.n.Xh:
                  this.S.F.markViewChangeEnd();
                  break;
                case b.n.ki:
                  this.S.viewLoaded();
                  break;
                case b.n.Gf:
                  this.S.beforeXhrReq(p);
                  break;
                case b.n.xf:
                  this.S.afterXhrReq();
                  break;
                case b.n.Kf:
                  this.S.xhrCompleted();
                  break;
                case b.n.Sg:
                  this.S.F.Sc({ url: p.next.url });
                  this.S.locChange(p.next.url);
                  break;
                case b.n.Sf:
                  this.S.F.Zl();
              }
            };
            e.prototype.zo = function (a) {
              this.S.abort();
              this.S.init(a);
              this.S.start();
            };
            e.wm = function (b, p) {
              var m = b.identifier(),
                n = p.identifier(),
                e = !1;
              return (e =
                (!a.utils.isDefined(m) && !a.utils.isDefined(n)) || m === n
                  ? !0
                  : a.utils.isDefined(m) && a.utils.isDefined(n)
                    ? m.state || n.state
                      ? a.utils.isDefined(m.state) && a.utils.isDefined(n.state)
                        ? m.state.name === n.state.name &&
                          m.state.Sb === n.state.Sb &&
                          m.state.Tb === n.state.Tb &&
                          m.state.url === n.state.url
                        : !1
                      : m.R && n.R
                        ? m.R.me === n.R.me &&
                          m.R.Sb === n.R.Sb &&
                          m.R.Tb === n.R.Tb
                        : m.url === n.url
                    : !1);
            };
            return e;
          })();
          b.Pj = e;
        })(a.ng || (a.ng = {}));
      })(k || (k = {}));
      (function (a) {
        (function (b) {
          var e = a.utils.addEventListener,
            c = (function () {
              function f() {
                this.Y = new b.Pj();
                this.Ag = !1;
              }
              f.prototype.setUp = function () {
                function b(n) {
                  return function () {
                    a.logInfo(n);
                    f.init();
                  };
                }
                var f = this;
                b("M262")();
                e(document, "DOMContentLoaded", b("M263"));
                e(window, "load", b("M264"));
              };
              f.prototype.init = function () {
                if ("loading" === document.readyState) a.logInfo("M265");
                else if ("undefined" != typeof angular && !this.Ag) {
                  this.Ag = !0;
                  a.logInfo("M266");
                  var b = this,
                    f = angular.module("ng");
                  f.config([
                    "$provide",
                    function (a) {
                      b.om(a);
                      b.jm(a);
                    },
                  ]);
                  f.run([
                    "$browser",
                    function (a) {
                      b.gm(a);
                    },
                  ]);
                  a.logInfo("M267");
                }
              };
              f.prototype.jm = function (f) {
                var m = a.aop,
                  n = this;
                f.decorator("$httpBackend", [
                  "$delegate",
                  function (a) {
                    return (a = m.around(
                      a,
                      function () {
                        var a = Array.prototype.slice.call(arguments);
                        n.Y.W(b.n.Gf, a);
                        return a;
                      },
                      function () {
                        n.Y.W(b.n.xf);
                      },
                      "ng.httpBackend",
                    ));
                  },
                ]);
              };
              f.prototype.om = function (f) {
                var m = a.aop,
                  n = this;
                f.decorator("$rootScope", [
                  "$delegate",
                  function (a) {
                    a.$digest = m.after(
                      a.$digest,
                      function () {
                        n.Y.W(b.n.Sf);
                      },
                      "ngevents.digest",
                    );
                    a.$on("$locationChangeStart", function (a, f) {
                      var m = { url: f },
                        p = a && a.Db && a.Db.$state && a.Db.$state.current;
                      p && (m.state = p);
                      n.Y.W(b.n.Sg, { next: m });
                    });
                    a.$on("$locationChangeSuccess", function () {
                      n.Y.W(b.n.Ym);
                    });
                    a.$on("$routeChangeStart", function (a, f) {
                      var m = { url: location.href },
                        p = f && f.$$route;
                      p && (m.R = p);
                      n.Y.W(b.n.Gh, { next: m });
                    });
                    a.$on("$routeChangeSuccess", function () {
                      n.Y.W(b.n.Hh);
                    });
                    a.$on("$stateChangeStart", function (a, f) {
                      n.Y.W(b.n.Wh, { next: { state: f } });
                    });
                    a.$on("$stateChangeSuccess", function () {
                      n.Y.W(b.n.Xh);
                    });
                    a.$on("$viewContentLoaded", function (a) {
                      var f = { url: location.href };
                      if ((a = a && a.Db && a.Db.$state && a.Db.$state.current))
                        f.state = a;
                      n.Y.W(b.n.ki, { next: f });
                    });
                    a.$on("$includeContentRequested", function () {
                      n.Y.W(b.n.Yl);
                    });
                    a.$on("$includeContentLoaded", function () {
                      n.Y.W(b.n.Xl);
                    });
                    return a;
                  },
                ]);
              };
              f.prototype.gm = function (f) {
                var m = this;
                f.$$completeOutstandingRequest = a.aop.before(
                  f.$$completeOutstandingRequest,
                  function () {
                    m.Y.W(b.n.Kf);
                  },
                );
              };
              return f;
            })();
          b.np = c;
          b.ngMonitor = new c();
        })(a.ng || (a.ng = {}));
      })(k || (k = {}));
      (function (a) {
        var b = a.ng || (a.ng = {});
        b.conf.disabled || a.conf.spa2 || a.monitor.setUpMonitors(b.ngMonitor);
      })(k || (k = {}));
    }
  })();
})();
