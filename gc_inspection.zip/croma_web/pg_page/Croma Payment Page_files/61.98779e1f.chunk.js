(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [61],
  {
    1075: function (e, a, t) {
      "use strict";
      (t.r(a),
        t.d(a, "mapStateToProps", function () {
          return c;
        }));
      var r = t(0),
        l = t.n(r),
        n = t(31),
        p = t(2);
      const c = (e) => ({ pdpData: e.pdpReducer.pdpData });
      a.default = Object(n.b)(c, null)(function (e) {
        let a,
          { pdpData: t } = e,
          r = "";
        (t &&
          t.storeoffer &&
          t.storeoffer.length > 0 &&
          Array.isArray(t.storeoffer) &&
          (a = t.storeoffer.filter((e) => e.hasOwnProperty("productLabel"))),
          a &&
            a.some(
              (e, a) => !!e.storeOfferLabel && ((r = e.storeOfferLabel), !0),
            ));
        try {
          return l.a.createElement(
            l.a.Fragment,
            null,
            a && a.length > 0 && Array.isArray(a)
              ? l.a.createElement(
                  "li",
                  { className: "info-item" },
                  l.a.createElement(
                    "div",
                    { className: "cp-offer" },
                    l.a.createElement(
                      "div",
                      { className: "info pdp-special-note-title" },
                      l.a.createElement(
                        "h2",
                        { className: "title" },
                        "" !== r ? r : p.a.SPECIAL_NOTE_HEADING,
                      ),
                    ),
                    l.a.createElement(
                      "div",
                      { className: "pdp-special-note" },
                      l.a.createElement(
                        "ul",
                        null,
                        a.map((e, a) =>
                          l.a.createElement("li", {
                            key: a,
                            dangerouslySetInnerHTML: { __html: e.productLabel },
                          }),
                        ),
                      ),
                    ),
                  ),
                )
              : "",
          );
        } catch (n) {
          return (console.log(n), l.a.createElement(l.a.Fragment, null, " "));
        }
      });
    },
  },
]);
