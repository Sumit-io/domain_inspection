(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [63],
  {
    1102: function (e, a, t) {
      "use strict";
      (t.r(a),
        t.d(a, "mapStateToProps", function () {
          return b;
        }));
      var c = t(0),
        r = t.n(c),
        o = t(80),
        l = t(31),
        n = t(1),
        p = t(212),
        m = t(7);
      const s = t(18).Link;
      var i = function (e) {
          let {
            item: a,
            removeProductFromCompareTray: t,
            pdpInfoData: c,
            shippingInfoGAEvent: l,
          } = e;
          const [i, u] = r.a.useState(""),
            [d, g] = r.a.useState(""),
            _ = Object(o.useHistory)();
          r.a.useEffect(() => {
            (u("slpTrayBg"), g("slpTrayColor"));
          }, []);
          try {
            return r.a.createElement(
              "div",
              { className: "compare-product ".concat(i) },
              r.a.createElement(
                "div",
                { className: "product-img" },
                r.a.createElement(
                  r.a.Fragment,
                  null,
                  Array.isArray(a.product_image_url)
                    ? r.a.createElement("img", {
                        src:
                          a.product_image_url.length > 0
                            ? Object(m.c)(a.product_image_url[0])
                            : Object(m.c)(
                                "".concat(
                                  n.a.localAssetUrl,
                                  "products/No_image.png",
                                ),
                              ),
                        alt: "".concat(a.product_image_text),
                        title: a.product_image_text,
                      })
                    : r.a.createElement("img", {
                        src: a.product_image_url
                          ? Object(m.c)(a.product_image_url)
                          : Object(m.c)(
                              "".concat(
                                n.a.localAssetUrl,
                                "products/No_image.png",
                              ),
                            ),
                        alt: "".concat(a.product_image_text),
                        title: a.product_image_text,
                      }),
                  " ",
                ),
              ),
              r.a.createElement(
                "div",
                { className: "product-info" },
                r.a.createElement(
                  "p",
                  { className: "product-title ".concat(d) },
                  r.a.createElement(
                    s,
                    {
                      to: "#",
                      onClick: (e) => {
                        var t;
                        (e.preventDefault(),
                          (t = a.product_detail_page_url),
                          _.push(t));
                      },
                    },
                    a.product_title,
                  ),
                ),
                r.a.createElement(
                  "div",
                  { className: "cp-price" },
                  n.a.PDP_STATUS_VISIBILITY &&
                    a.approvalStatus &&
                    "string" === typeof a.approvalStatus &&
                    ("prelaunch" === a.approvalStatus ||
                      "discontinued" === a.approvalStatus ||
                      "unavailable" === a.approvalStatus)
                    ? r.a.createElement(r.a.Fragment, null)
                    : r.a.createElement(
                        "span",
                        { className: "new-price ".concat(d) },
                        r.a.createElement("span", {
                          className: "icon icon-rupee",
                        }),
                        r.a.createElement(
                          "span",
                          { className: "amount" },
                          a.discount_price
                            ? parseFloat(a.discount_price)
                                .toFixed(2)
                                .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                            : a.product_price
                              ? parseFloat(a.product_price)
                                  .toFixed(2)
                                  .replace(/\d(?=(\d{3})+\.)/g, "$&,")
                              : 0,
                        ),
                      ),
                ),
              ),
              r.a.createElement("span", {
                className: "icon icon-close",
                onClick: (e) => {
                  (t(e, a.catalog_item_id, a),
                    Object(p.d)(
                      a,
                      c,
                      "compare_flow_36_remove_from_compare",
                      l,
                    ));
                },
              }),
            );
          } catch (f) {
            return (console.log(f), r.a.createElement(r.a.Fragment, null, " "));
          }
        },
        u = t(420);
      const d = t(18).Link,
        g = r.a.memo(i);
      var _ = function (e) {
          let {
            compareProductData: a,
            removeProductFromCompareTray: t,
            pdpInfoData: o,
            shippingInfoGAEvent: l,
          } = e;
          const [n, p] = Object(c.useState)(0);
          let m = "";
          (o &&
            o.pdpBreadcrumbs &&
            Array.isArray(o.pdpBreadcrumbs) &&
            o.pdpBreadcrumbs.length > 0 &&
            (m =
              o.pdpBreadcrumbs.length > 2
                ? o.pdpBreadcrumbs[1].url
                : o.pdpBreadcrumbs[0].url),
            Object(c.useEffect)(() => {
              a && a.length <= 5 && p(new Array(5 - a.length));
            }, [a]));
          try {
            return r.a.createElement(
              "div",
              { className: "compare-items pdp-compare-items" },
              r.a.createElement(
                "div",
                { className: "swiper-container" },
                r.a.createElement(
                  "div",
                  { className: "swiper-wrapper" },
                  a &&
                    Array.isArray(a) &&
                    a.map((e, a) =>
                      r.a.createElement(
                        "div",
                        { className: "swiper-slide", key: a },
                        r.a.createElement(g, {
                          item: e,
                          removeProductFromCompareTray: t,
                          pdpInfoData: o,
                          shippingInfoGAEvent: l,
                        }),
                      ),
                    ),
                  n &&
                    Array.isArray([...n]) &&
                    [...n].map((e, a) =>
                      r.a.createElement(
                        "div",
                        { className: "swiper-slide", key: a },
                        r.a.createElement(
                          d,
                          {
                            to: m,
                            onClick: () => Object(u.a)("add product"),
                            className: "navigate-to-plp",
                          },
                          r.a.createElement(
                            "div",
                            { className: "empty-compare" },
                            "\xa0",
                          ),
                        ),
                      ),
                    ),
                ),
              ),
            );
          } catch (s) {
            return (console.log(s), r.a.createElement(r.a.Fragment, null, " "));
          }
        },
        f = t(2),
        v = t(364),
        y = t(22);
      var E = (e, a, t, c) => {
        var r, o, l;
        const n = Object(y.c)(),
          {
            pagetype: p,
            source_page_url: m,
            previous_page_url: s,
            destination_page_url: i,
            customer_hash: u,
            platform: d,
          } = n,
          g = localStorage.getItem("login_trigger");
        var _;
        window.dataLayer.push({
          event: a,
          pagetype: p,
          source_page_url: m,
          previous_page_url: s,
          destination_page_url: i,
          click_text: t,
          interaction_type: "Click",
          sequence: "N/A",
          total_elements: null === e || void 0 === e ? void 0 : e.length,
          section: "N/A",
          item_name:
            ((_ = e),
            _ &&
              _.map((e) => ({
                item_name:
                  (null === e || void 0 === e ? void 0 : e.product_title) ||
                  "N/A",
                item_id:
                  (null === e || void 0 === e ? void 0 : e.catalog_item_id) ||
                  "N/A",
              }))),
          item_category: c
            ? null === (r = c[0]) || void 0 === r
              ? void 0
              : r.name
            : "N/A",
          item_category2: c
            ? null === (o = c[1]) || void 0 === o
              ? void 0
              : o.name
            : "N/A",
          item_category3: c
            ? null === (l = c[2]) || void 0 === l
              ? void 0
              : l.name
            : "N/A",
          brand: "N/A",
          platform: d,
          creative_id: "N/A",
          login_trigger: u ? g : "N/A",
          login_status: !!u,
          user_id: u,
        });
      };
      const N = r.a.memo(_);
      const b = (e) => ({ pdpInfoData: e.pdpReducer.pdpData });
      a.default = Object(l.b)(b, null)(function (e) {
        let {
          compareTrayExpanded: a,
          pdpInfoData: t,
          shippingInfoGAEvent: l,
        } = e;
        const n = Object(o.useHistory)(),
          p = Object(c.useRef)(),
          m = Object(c.useRef)(),
          [s, i] = Object(c.useState)(!1),
          [d, g] = Object(c.useState)([]);
        let _ = "/compare=products?",
          y = {};
        ("undefined" !== typeof Storage &&
          localStorage.getItem("breadCrumbDataGA") &&
          (y = JSON.parse(localStorage.getItem("breadCrumbDataGA"))),
          Object(c.useEffect)(() => {
            a && b();
          }, [a]),
          Object(c.useEffect)(() => {
            const e = localStorage.getItem("compareTrayItems");
            g(e ? JSON.parse(e) : []);
          }, []));
        const b = () => {
            const e = localStorage.getItem("compareTrayItems");
            if (e) {
              JSON.parse(e).length > 0 ? i(!0) : i(!1);
            }
            g(e ? JSON.parse(e) : []);
          },
          A = (e, a, t) => {
            if (document.querySelector(".compare".concat(a))) {
              const e = document.querySelectorAll(".compare".concat(a));
              for (let a = 0; a < e.length; a++) e[a].checked = !1;
            }
            let c = JSON.parse(localStorage.getItem("compareTrayItems"));
            ((c = c.filter((e) => e.catalog_item_id !== a)),
              localStorage.setItem("compareTrayItems", JSON.stringify(c)),
              g(
                localStorage.getItem("compareTrayItems")
                  ? JSON.parse(localStorage.getItem("compareTrayItems"))
                  : [],
              ),
              0 === c.length && i(!1),
              Object(v.a)(t, "remove"));
          };
        try {
          return r.a.createElement(
            "div",
            { className: "cp-compare typ-pdp pdp-compare-tray" },
            d &&
              Array.isArray(d) &&
              d.length > 0 &&
              r.a.createElement(
                "button",
                {
                  className: "compare-product-btn",
                  ref: m,
                  onClick: () => {
                    (b(),
                      E(
                        d,
                        "compare_flow_35_compare_cta_click",
                        "Compare CTA",
                        y,
                      ));
                  },
                },
                f.a.COMPARE_BUTTON_TEXT,
                " (",
                d.length,
                ")",
              ),
            r.a.createElement(
              "div",
              { ref: p, className: "product-wrap ".concat(s ? "active" : "") },
              r.a.createElement(
                "div",
                { className: "container" },
                r.a.createElement(N, {
                  compareProductData: d,
                  removeProductFromCompareTray: A,
                  pdpInfoData: t,
                  shippingInfoGAEvent: l,
                }),
                r.a.createElement(
                  "div",
                  { className: "action-wrap pdp-compare-buttons" },
                  r.a.createElement("button", {
                    className: "icon icon-close compare-close",
                    onClick: () => {
                      (i(!1), Object(u.a)("cancel"));
                    },
                  }),
                  r.a.createElement(
                    "button",
                    {
                      className: "btn btn-default compare-cta",
                      disabled: d.length <= 1,
                      onClick: () => {
                        ((() => {
                          const e = localStorage.getItem("compareTrayItems");
                          if (e) {
                            const a = JSON.parse(e);
                            (E(
                              d,
                              "compare_flow_38_compare_confirm_click",
                              "Confirm Compare",
                              y,
                            ),
                              a &&
                                Array.isArray(a) &&
                                a.length > 0 &&
                                (a.map(function (e, t) {
                                  e.catalog_item_id &&
                                    ((_ += "productCode"
                                      .concat(t, "=")
                                      .concat(e.catalog_item_id)),
                                    t !== a.length - 1 && (_ += "&"));
                                }),
                                n.push(_)));
                          }
                        })(),
                          Object(u.a)("compare"));
                      },
                    },
                    f.a.COMPARE_BUTTON_TEXT,
                  ),
                  r.a.createElement(
                    "button",
                    {
                      className: "btn btn-default compare-cancel-cta",
                      onClick: (e) => {
                        ((e) => {
                          Object(u.a)("clear all");
                          const a = JSON.parse(
                            localStorage.getItem("compareTrayItems"),
                          );
                          if (a) {
                            (E(
                              d,
                              "compare_flow_37_clear_all_click",
                              "Clear All CTA",
                              y,
                            ),
                              a.forEach((e) => {
                                if (
                                  document.querySelector(
                                    ".compare".concat(e.catalog_item_id),
                                  )
                                ) {
                                  const a = document.querySelectorAll(
                                    ".compare".concat(e.catalog_item_id),
                                  );
                                  for (let e = 0; e < a.length; e++)
                                    a[e].checked = !1;
                                }
                              }));
                            const e = [];
                            (localStorage.setItem(
                              "compareTrayItems",
                              JSON.stringify(e),
                            ),
                              g([]),
                              i(!1));
                          }
                        })();
                      },
                    },
                    f.a.CLEAR_ALL_BUTTON_TEXT,
                  ),
                ),
              ),
            ),
          );
        } catch (S) {
          return (console.log(S), r.a.createElement(r.a.Fragment, null, " "));
        }
      });
    },
  },
]);
