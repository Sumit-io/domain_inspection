(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [60],
  {
    1076: function (e, a, t) {
      "use strict";
      t.r(a);
      var c = t(0),
        l = t.n(c),
        p = t(2);
      a.default = function (e) {
        let {
          productTitle: a,
          productModel: t,
          productId: c,
          productMessage: r,
          productMessage1: d,
          productMessage2: s,
          productSustainability: n,
        } = e;
        try {
          return l.a.createElement(
            l.a.Fragment,
            null,
            l.a.createElement(
              "h1",
              { className: "pd-title pd-title-normal" },
              a,
              " ",
              t && "(".concat(t, ")"),
            ),
            (r || d || s || n) &&
              l.a.createElement(
                "div",
                { className: "pd-tag-wrapper" },
                r && l.a.createElement("div", { className: "pd-tag" }, r),
                d && l.a.createElement("div", { className: "pd-tag" }, d),
                s && l.a.createElement("div", { className: "pd-tag" }, s),
                n && l.a.createElement("div", { className: "pd-tag sus" }, n),
              ),
            c &&
              l.a.createElement(
                "label",
                {
                  className: "pd-meta hide-pdpProductId",
                  id: "product-sku-id",
                  value: c,
                },
                p.a.PRODUCT_ID_TEXT,
                " ",
                c,
              ),
          );
        } catch (m) {
          return (console.log(m), l.a.createElement(l.a.Fragment, null, " "));
        }
      };
    },
  },
]);
