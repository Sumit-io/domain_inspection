/*! For license information please see 51.51429703.chunk.js.LICENSE.txt */
(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [51],
  {
    1042: function (e, t, n) {
      var r;
      !(function () {
        "use strict";
        var n = {}.hasOwnProperty;
        function o() {
          for (var e = "", t = 0; t < arguments.length; t++) {
            var n = arguments[t];
            n && (e = i(e, a(n)));
          }
          return e;
        }
        function a(e) {
          if ("string" === typeof e || "number" === typeof e) return e;
          if ("object" !== typeof e) return "";
          if (Array.isArray(e)) return o.apply(null, e);
          if (
            e.toString !== Object.prototype.toString &&
            !e.toString.toString().includes("[native code]")
          )
            return e.toString();
          var t = "";
          for (var r in e) n.call(e, r) && e[r] && (t = i(t, r));
          return t;
        }
        function i(e, t) {
          return t ? (e ? e + " " + t : e + t) : e;
        }
        e.exports
          ? ((o.default = o), (e.exports = o))
          : void 0 ===
              (r = function () {
                return o;
              }.apply(t, [])) || (e.exports = r);
      })();
    },
    1084: function (e, t, n) {
      "use strict";
      (n.r(t),
        n.d(t, "ProductAction", function () {
          return ce;
        }),
        n.d(t, "mapStateToProps", function () {
          return le;
        }));
      var r = n(0),
        o = n.n(r),
        a = n(31);
      var i = function (e) {
          let { noOfViews: t } = e;
          try {
            return o.a.createElement(
              "button",
              { type: "button", className: "btn btn-icon hide-eye-icon" },
              o.a.createElement("span", { className: "icon icon-view" }),
              o.a.createElement("span", { className: "text" }, t),
            );
          } catch (n) {
            return (console.log(n), o.a.createElement(o.a.Fragment, null, " "));
          }
        },
        c = n(435),
        l = n(437),
        s = n(2),
        u = n(1),
        d = (function () {
          var e = function (t, n) {
            return (e =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var n in t)
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              })(t, n);
          };
          return function (t, n) {
            if ("function" !== typeof n && null !== n)
              throw new TypeError(
                "Class extends value " +
                  String(n) +
                  " is not a constructor or null",
              );
            function r() {
              this.constructor = t;
            }
            (e(t, n),
              (t.prototype =
                null === n
                  ? Object.create(n)
                  : ((r.prototype = n.prototype), new r())));
          };
        })(),
        p = (function (e) {
          function t(t) {
            var n = e.call(this, t) || this;
            return ((n.name = "AssertionError"), n);
          }
          return (d(t, e), t);
        })(Error);
      function f(e, t) {
        if (!e) throw new p(t);
      }
      function h(e) {
        var t = Object.entries(e)
          .filter(function (e) {
            var t = e[1];
            return void 0 !== t && null !== t;
          })
          .map(function (e) {
            var t = e[0],
              n = e[1];
            return ""
              .concat(encodeURIComponent(t), "=")
              .concat(encodeURIComponent(String(n)));
          });
        return t.length > 0 ? "?".concat(t.join("&")) : "";
      }
      var m = n(1042),
        w = n.n(m),
        v = (function () {
          var e = function (t, n) {
            return (e =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (e, t) {
                  e.__proto__ = t;
                }) ||
              function (e, t) {
                for (var n in t)
                  Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
              })(t, n);
          };
          return function (t, n) {
            if ("function" !== typeof n && null !== n)
              throw new TypeError(
                "Class extends value " +
                  String(n) +
                  " is not a constructor or null",
              );
            function r() {
              this.constructor = t;
            }
            (e(t, n),
              (t.prototype =
                null === n
                  ? Object.create(n)
                  : ((r.prototype = n.prototype), new r())));
          };
        })(),
        y = function () {
          return (y =
            Object.assign ||
            function (e) {
              for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var o in (t = arguments[n]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        },
        b = function (e, t, n, r) {
          return new (n || (n = Promise))(function (o, a) {
            function i(e) {
              try {
                l(r.next(e));
              } catch (t) {
                a(t);
              }
            }
            function c(e) {
              try {
                l(r.throw(e));
              } catch (t) {
                a(t);
              }
            }
            function l(e) {
              var t;
              e.done
                ? o(e.value)
                : ((t = e.value),
                  t instanceof n
                    ? t
                    : new n(function (e) {
                        e(t);
                      })).then(i, c);
            }
            l((r = r.apply(e, t || [])).next());
          });
        },
        g = function (e, t) {
          var n,
            r,
            o,
            a,
            i = {
              label: 0,
              sent: function () {
                if (1 & o[0]) throw o[1];
                return o[1];
              },
              trys: [],
              ops: [],
            };
          return (
            (a = { next: c(0), throw: c(1), return: c(2) }),
            "function" === typeof Symbol &&
              (a[Symbol.iterator] = function () {
                return this;
              }),
            a
          );
          function c(a) {
            return function (c) {
              return (function (a) {
                if (n) throw new TypeError("Generator is already executing.");
                for (; i; )
                  try {
                    if (
                      ((n = 1),
                      r &&
                        (o =
                          2 & a[0]
                            ? r.return
                            : a[0]
                              ? r.throw || ((o = r.return) && o.call(r), 0)
                              : r.next) &&
                        !(o = o.call(r, a[1])).done)
                    )
                      return o;
                    switch (((r = 0), o && (a = [2 & a[0], o.value]), a[0])) {
                      case 0:
                      case 1:
                        o = a;
                        break;
                      case 4:
                        return (i.label++, { value: a[1], done: !1 });
                      case 5:
                        (i.label++, (r = a[1]), (a = [0]));
                        continue;
                      case 7:
                        ((a = i.ops.pop()), i.trys.pop());
                        continue;
                      default:
                        if (
                          !(o = (o = i.trys).length > 0 && o[o.length - 1]) &&
                          (6 === a[0] || 2 === a[0])
                        ) {
                          i = 0;
                          continue;
                        }
                        if (
                          3 === a[0] &&
                          (!o || (a[1] > o[0] && a[1] < o[3]))
                        ) {
                          i.label = a[1];
                          break;
                        }
                        if (6 === a[0] && i.label < o[1]) {
                          ((i.label = o[1]), (o = a));
                          break;
                        }
                        if (o && i.label < o[2]) {
                          ((i.label = o[2]), i.ops.push(a));
                          break;
                        }
                        (o[2] && i.ops.pop(), i.trys.pop());
                        continue;
                    }
                    a = t.call(e, i);
                  } catch (c) {
                    ((a = [6, c]), (r = 0));
                  } finally {
                    n = o = 0;
                  }
                if (5 & a[0]) throw a[1];
                return { value: a[0] ? a[1] : void 0, done: !0 };
              })([a, c]);
            };
          }
        },
        _ = function (e, t) {
          var n = {};
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) &&
              t.indexOf(r) < 0 &&
              (n[r] = e[r]);
          if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
            var o = 0;
            for (r = Object.getOwnPropertySymbols(e); o < r.length; o++)
              t.indexOf(r[o]) < 0 &&
                Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
                (n[r[o]] = e[r[o]]);
          }
          return n;
        },
        k = function (e) {
          return (
            !!e &&
            ("object" === typeof e || "function" === typeof e) &&
            "function" === typeof e.then
          );
        },
        O = function (e, t) {
          return {
            left:
              window.outerWidth / 2 +
              (window.screenX || window.screenLeft || 0) -
              e / 2,
            top:
              window.outerHeight / 2 +
              (window.screenY || window.screenTop || 0) -
              t / 2,
          };
        },
        E = function (e, t) {
          return {
            top: (window.screen.height - t) / 2,
            left: (window.screen.width - e) / 2,
          };
        };
      function S(e, t, n) {
        var r = t.height,
          o = t.width,
          a = _(t, ["height", "width"]),
          i = y(
            {
              height: r,
              width: o,
              location: "no",
              toolbar: "no",
              status: "no",
              directories: "no",
              menubar: "no",
              scrollbars: "yes",
              resizable: "no",
              centerscreen: "yes",
              chrome: "yes",
            },
            a,
          ),
          c = window.open(
            e,
            "",
            Object.keys(i)
              .map(function (e) {
                return "".concat(e, "=").concat(i[e]);
              })
              .join(", "),
          );
        if (n)
          var l = window.setInterval(function () {
            try {
              (null === c || c.closed) && (window.clearInterval(l), n(c));
            } catch (e) {
              console.error(e);
            }
          }, 1e3);
        return c;
      }
      var C = (function (e) {
          function t() {
            var t = (null !== e && e.apply(this, arguments)) || this;
            return (
              (t.openShareDialog = function (e) {
                var n = t.props,
                  r = n.onShareWindowClose,
                  o = n.windowHeight,
                  a = void 0 === o ? 400 : o,
                  i = n.windowPosition,
                  c = void 0 === i ? "windowCenter" : i,
                  l = n.windowWidth,
                  s = void 0 === l ? 550 : l;
                S(
                  e,
                  y(
                    { height: a, width: s },
                    "windowCenter" === c ? O(s, a) : E(s, a),
                  ),
                  r,
                );
              }),
              (t.handleClick = function (e) {
                return b(t, void 0, void 0, function () {
                  var t, n, r, o, a, i, c, l, s, u;
                  return g(this, function (d) {
                    switch (d.label) {
                      case 0:
                        return (
                          (t = this.props),
                          (n = t.beforeOnClick),
                          (r = t.disabled),
                          (o = t.networkLink),
                          (a = t.onClick),
                          (i = t.url),
                          (c = t.openShareDialogOnClick),
                          (l = t.opts),
                          (s = o(i, l)),
                          r
                            ? [2]
                            : (e.preventDefault(),
                              n ? ((u = n()), k(u) ? [4, u] : [3, 2]) : [3, 2])
                        );
                      case 1:
                        (d.sent(), (d.label = 2));
                      case 2:
                        return (
                          c && this.openShareDialog(s),
                          a && a(e, s),
                          [2]
                        );
                    }
                  });
                });
              }),
              t
            );
          }
          return (
            v(t, e),
            (t.prototype.render = function () {
              var e = this.props,
                t = (e.beforeOnClick, e.children),
                n = e.className,
                r = e.disabled,
                a = e.disabledStyle,
                i = e.forwardedRef,
                c = (e.networkLink, e.networkName),
                l =
                  (e.onShareWindowClose,
                  e.openShareDialogOnClick,
                  e.opts,
                  e.resetButtonStyle),
                s = e.style,
                u =
                  (e.url,
                  e.windowHeight,
                  e.windowPosition,
                  e.windowWidth,
                  _(e, [
                    "beforeOnClick",
                    "children",
                    "className",
                    "disabled",
                    "disabledStyle",
                    "forwardedRef",
                    "networkLink",
                    "networkName",
                    "onShareWindowClose",
                    "openShareDialogOnClick",
                    "opts",
                    "resetButtonStyle",
                    "style",
                    "url",
                    "windowHeight",
                    "windowPosition",
                    "windowWidth",
                  ])),
                d = w()(
                  "react-share__ShareButton",
                  { "react-share__ShareButton--disabled": !!r, disabled: !!r },
                  n,
                ),
                p = y(
                  y(
                    l
                      ? {
                          backgroundColor: "transparent",
                          border: "none",
                          padding: 0,
                          font: "inherit",
                          color: "inherit",
                          cursor: "pointer",
                        }
                      : {},
                    s,
                  ),
                  r && a,
                );
              return o.a.createElement(
                "button",
                y({}, u, {
                  "aria-label": u["aria-label"] || c,
                  className: d,
                  onClick: this.handleClick,
                  ref: i,
                  style: p,
                }),
                t,
              );
            }),
            (t.defaultProps = {
              disabledStyle: { opacity: 0.6 },
              openShareDialogOnClick: !0,
              resetButtonStyle: !0,
            }),
            t
          );
        })(r.Component),
        j = function () {
          return (j =
            Object.assign ||
            function (e) {
              for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var o in (t = arguments[n]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        };
      var A = function (e, t, n, a) {
        function i(r, i) {
          var c = n(r),
            l = j({}, r);
          return (
            Object.keys(c).forEach(function (e) {
              delete l[e];
            }),
            o.a.createElement(
              C,
              j({}, a, l, {
                forwardedRef: i,
                networkName: e,
                networkLink: t,
                opts: n(r),
              }),
            )
          );
        }
        return (
          (i.displayName = "ShareButton-".concat(e)),
          Object(r.forwardRef)(i)
        );
      };
      var I = A(
          "facebook",
          function (e, t) {
            var n = t.quote,
              r = t.hashtag;
            return (
              f(e, "facebook.url"),
              "https://www.facebook.com/sharer/sharer.php" +
                h({ u: e, quote: n, hashtag: r })
            );
          },
          function (e) {
            return { quote: e.quote, hashtag: e.hashtag };
          },
          { windowWidth: 550, windowHeight: 400 },
        ),
        N = function () {
          return (N =
            Object.assign ||
            function (e) {
              for (var t, n = 1, r = arguments.length; n < r; n++)
                for (var o in (t = arguments[n]))
                  Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
              return e;
            }).apply(this, arguments);
        },
        P = function (e, t) {
          var n = {};
          for (var r in e)
            Object.prototype.hasOwnProperty.call(e, r) &&
              t.indexOf(r) < 0 &&
              (n[r] = e[r]);
          if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
            var o = 0;
            for (r = Object.getOwnPropertySymbols(e); o < r.length; o++)
              t.indexOf(r[o]) < 0 &&
                Object.prototype.propertyIsEnumerable.call(e, r[o]) &&
                (n[r[o]] = e[r[o]]);
          }
          return n;
        };
      function D(e) {
        var t = function (t) {
          var n = t.bgStyle,
            r = t.borderRadius,
            a = t.iconFillColor,
            i = t.round,
            c = t.size,
            l = P(t, [
              "bgStyle",
              "borderRadius",
              "iconFillColor",
              "round",
              "size",
            ]);
          return o.a.createElement(
            "svg",
            N({ viewBox: "0 0 64 64", width: c, height: c }, l),
            i
              ? o.a.createElement("circle", {
                  cx: "32",
                  cy: "32",
                  r: "31",
                  fill: e.color,
                  style: n,
                })
              : o.a.createElement("rect", {
                  width: "64",
                  height: "64",
                  rx: r,
                  ry: r,
                  fill: e.color,
                  style: n,
                }),
            o.a.createElement("path", { d: e.path, fill: a }),
          );
        };
        return (
          (t.defaultProps = {
            bgStyle: {},
            borderRadius: 0,
            iconFillColor: "white",
            size: 64,
          }),
          t
        );
      }
      var x = D({
        color: "#3b5998",
        networkName: "facebook",
        path: "M34.1,47V33.3h4.6l0.7-5.3h-5.3v-3.4c0-1.5,0.4-2.6,2.6-2.6l2.8,0v-4.8c-0.5-0.1-2.2-0.2-4.1-0.2 c-4.1,0-6.9,2.5-6.9,7V28H24v5.3h4.6V47H34.1z",
      });
      var z = A(
          "twitter",
          function (e, t) {
            var n = t.title,
              r = t.via,
              o = t.hashtags,
              a = void 0 === o ? [] : o,
              i = t.related,
              c = void 0 === i ? [] : i;
            return (
              f(e, "twitter.url"),
              f(Array.isArray(a), "twitter.hashtags is not an array"),
              f(Array.isArray(c), "twitter.related is not an array"),
              "https://twitter.com/share" +
                h({
                  url: e,
                  text: n,
                  via: r,
                  hashtags: a.length > 0 ? a.join(",") : void 0,
                  related: c.length > 0 ? c.join(",") : void 0,
                })
            );
          },
          function (e) {
            return {
              hashtags: e.hashtags,
              title: e.title,
              via: e.via,
              related: e.related,
            };
          },
          { windowWidth: 550, windowHeight: 400 },
        ),
        L = D({
          color: "#00aced",
          networkName: "twitter",
          path: "M48,22.1c-1.2,0.5-2.4,0.9-3.8,1c1.4-0.8,2.4-2.1,2.9-3.6c-1.3,0.8-2.7,1.3-4.2,1.6 C41.7,19.8,40,19,38.2,19c-3.6,0-6.6,2.9-6.6,6.6c0,0.5,0.1,1,0.2,1.5c-5.5-0.3-10.3-2.9-13.5-6.9c-0.6,1-0.9,2.1-0.9,3.3 c0,2.3,1.2,4.3,2.9,5.5c-1.1,0-2.1-0.3-3-0.8c0,0,0,0.1,0,0.1c0,3.2,2.3,5.8,5.3,6.4c-0.6,0.1-1.1,0.2-1.7,0.2c-0.4,0-0.8,0-1.2-0.1 c0.8,2.6,3.3,4.5,6.1,4.6c-2.2,1.8-5.1,2.8-8.2,2.8c-0.5,0-1.1,0-1.6-0.1c2.9,1.9,6.4,2.9,10.1,2.9c12.1,0,18.7-10,18.7-18.7 c0-0.3,0-0.6,0-0.8C46,24.5,47.1,23.4,48,22.1z",
        }),
        M = D({
          color: "#7f7f7f",
          networkName: "email",
          path: "M17,22v20h30V22H17z M41.1,25L32,32.1L22.9,25H41.1z M20,39V26.6l12,9.3l12-9.3V39H20z",
        });
      var H = A(
          "pinterest",
          function (e, t) {
            var n = t.media,
              r = t.description;
            return (
              f(e, "pinterest.url"),
              f(n, "pinterest.media"),
              "https://pinterest.com/pin/create/button/" +
                h({ url: e, media: n, description: r })
            );
          },
          function (e) {
            return { media: e.media, description: e.description };
          },
          { windowWidth: 1e3, windowHeight: 730 },
        ),
        R = D({
          color: "#cb2128",
          networkName: "pinterest",
          path: "M32,16c-8.8,0-16,7.2-16,16c0,6.6,3.9,12.2,9.6,14.7c0-1.1,0-2.5,0.3-3.7 c0.3-1.3,2.1-8.7,2.1-8.7s-0.5-1-0.5-2.5c0-2.4,1.4-4.1,3.1-4.1c1.5,0,2.2,1.1,2.2,2.4c0,1.5-0.9,3.7-1.4,5.7 c-0.4,1.7,0.9,3.1,2.5,3.1c3,0,5.1-3.9,5.1-8.5c0-3.5-2.4-6.1-6.7-6.1c-4.9,0-7.9,3.6-7.9,7.7c0,1.4,0.4,2.4,1.1,3.1 c0.3,0.3,0.3,0.5,0.2,0.9c-0.1,0.3-0.3,1-0.3,1.3c-0.1,0.4-0.4,0.6-0.8,0.4c-2.2-0.9-3.3-3.4-3.3-6.1c0-4.5,3.8-10,11.4-10 c6.1,0,10.1,4.4,10.1,9.2c0,6.3-3.5,11-8.6,11c-1.7,0-3.4-0.9-3.9-2c0,0-0.9,3.7-1.1,4.4c-0.3,1.2-1,2.5-1.6,3.4 c1.4,0.4,3,0.7,4.5,0.7c8.8,0,16-7.2,16-16C48,23.2,40.8,16,32,16z",
        });
      var T = A(
          "linkedin",
          function (e, t) {
            var n = t.title,
              r = t.summary,
              o = t.source;
            return (
              f(e, "linkedin.url"),
              "https://linkedin.com/shareArticle" +
                h({ url: e, mini: "true", title: n, summary: r, source: o })
            );
          },
          function (e) {
            return { title: e.title, summary: e.summary, source: e.source };
          },
          { windowWidth: 750, windowHeight: 600 },
        ),
        W = D({
          color: "#007fb1",
          networkName: "linkedin",
          path: "M20.4,44h5.4V26.6h-5.4V44z M23.1,18c-1.7,0-3.1,1.4-3.1,3.1c0,1.7,1.4,3.1,3.1,3.1 c1.7,0,3.1-1.4,3.1-3.1C26.2,19.4,24.8,18,23.1,18z M39.5,26.2c-2.6,0-4.4,1.4-5.1,2.8h-0.1v-2.4h-5.2V44h5.4v-8.6 c0-2.3,0.4-4.5,3.2-4.5c2.8,0,2.8,2.6,2.8,4.6V44H46v-9.5C46,29.8,45,26.2,39.5,26.2z",
        });
      var B = A(
          "reddit",
          function (e, t) {
            var n = t.title;
            return (
              f(e, "reddit.url"),
              "https://www.reddit.com/submit" + h({ url: e, title: n })
            );
          },
          function (e) {
            return { title: e.title };
          },
          {
            windowWidth: 660,
            windowHeight: 460,
            windowPosition: "windowCenter",
          },
        ),
        V = D({
          color: "#ff4500",
          networkName: "reddit",
          path: "m 52.8165,31.942362 c 0,-2.4803 -2.0264,-4.4965 -4.5169,-4.4965 -1.2155,0 -2.3171,0.4862 -3.128,1.2682 -3.077,-2.0247 -7.2403,-3.3133 -11.8507,-3.4782 l 2.5211,-7.9373 6.8272,1.5997 -0.0102,0.0986 c 0,2.0281 1.6575,3.6771 3.6958,3.6771 2.0366,0 3.6924,-1.649 3.6924,-3.6771 0,-2.0281 -1.6575,-3.6788 -3.6924,-3.6788 -1.564,0 -2.8968,0.9758 -3.4357,2.3443 l -7.3593,-1.7255 c -0.3213,-0.0782 -0.6477,0.1071 -0.748,0.4233 L 32,25.212062 c -4.8246,0.0578 -9.1953,1.3566 -12.41,3.4425 -0.8058,-0.7446 -1.8751,-1.2104 -3.0583,-1.2104 -2.4905,0 -4.5152,2.0179 -4.5152,4.4982 0,1.649 0.9061,3.0787 2.2389,3.8607 -0.0884,0.4794 -0.1462,0.9639 -0.1462,1.4569 0,6.6487 8.1736,12.0581 18.2223,12.0581 10.0487,0 18.224,-5.4094 18.224,-12.0581 0,-0.4658 -0.0493,-0.9248 -0.1275,-1.377 1.4144,-0.7599 2.3885,-2.2304 2.3885,-3.9406 z m -29.2808,3.0872 c 0,-1.4756 1.207,-2.6775 2.6894,-2.6775 1.4824,0 2.6877,1.2019 2.6877,2.6775 0,1.4756 -1.2053,2.6758 -2.6877,2.6758 -1.4824,0 -2.6894,-1.2002 -2.6894,-2.6758 z m 15.4037,7.9373 c -1.3549,1.3481 -3.4816,2.0043 -6.5008,2.0043 l -0.0221,-0.0051 -0.0221,0.0051 c -3.0209,0 -5.1476,-0.6562 -6.5008,-2.0043 -0.2465,-0.2448 -0.2465,-0.6443 0,-0.8891 0.2465,-0.2465 0.6477,-0.2465 0.8942,0 1.105,1.0999 2.9393,1.6337 5.6066,1.6337 l 0.0221,0.0051 0.0221,-0.0051 c 2.6673,0 4.5016,-0.5355 5.6066,-1.6354 0.2465,-0.2465 0.6477,-0.2448 0.8942,0 0.2465,0.2465 0.2465,0.6443 0,0.8908 z m -0.3213,-5.2615 c -1.4824,0 -2.6877,-1.2002 -2.6877,-2.6758 0,-1.4756 1.2053,-2.6775 2.6877,-2.6775 1.4824,0 2.6877,1.2019 2.6877,2.6775 0,1.4756 -1.2053,2.6758 -2.6877,2.6758 z",
        });
      var F = A(
          "whatsapp",
          function (e, t) {
            var n = t.title,
              r = t.separator;
            return (
              f(e, "whatsapp.url"),
              "https://" +
                (/(android|iphone|ipad|mobile)/i.test(navigator.userAgent)
                  ? "api"
                  : "web") +
                ".whatsapp.com/send" +
                h({ text: n ? n + r + e : e })
            );
          },
          function (e) {
            return { title: e.title, separator: e.separator || " " };
          },
          { windowWidth: 550, windowHeight: 400 },
        ),
        q = D({
          color: "#25D366",
          networkName: "whatsapp",
          path: "m42.32286,33.93287c-0.5178,-0.2589 -3.04726,-1.49644 -3.52105,-1.66732c-0.4712,-0.17346 -0.81554,-0.2589 -1.15987,0.2589c-0.34175,0.51004 -1.33075,1.66474 -1.63108,2.00648c-0.30032,0.33658 -0.60064,0.36247 -1.11327,0.12945c-0.5178,-0.2589 -2.17994,-0.80259 -4.14759,-2.56312c-1.53269,-1.37217 -2.56312,-3.05503 -2.86603,-3.57283c-0.30033,-0.5178 -0.03366,-0.80259 0.22524,-1.06149c0.23301,-0.23301 0.5178,-0.59547 0.7767,-0.90616c0.25372,-0.31068 0.33657,-0.5178 0.51262,-0.85437c0.17088,-0.36246 0.08544,-0.64725 -0.04402,-0.90615c-0.12945,-0.2589 -1.15987,-2.79613 -1.58964,-3.80584c-0.41424,-1.00971 -0.84142,-0.88027 -1.15987,-0.88027c-0.29773,-0.02588 -0.64208,-0.02588 -0.98382,-0.02588c-0.34693,0 -0.90616,0.12945 -1.37736,0.62136c-0.4712,0.5178 -1.80194,1.76053 -1.80194,4.27186c0,2.51134 1.84596,4.945 2.10227,5.30747c0.2589,0.33657 3.63497,5.51458 8.80262,7.74113c1.23237,0.5178 2.1903,0.82848 2.94111,1.08738c1.23237,0.38836 2.35599,0.33657 3.24402,0.20712c0.99159,-0.15534 3.04985,-1.24272 3.47963,-2.45956c0.44013,-1.21683 0.44013,-2.22654 0.31068,-2.45955c-0.12945,-0.23301 -0.46601,-0.36247 -0.98382,-0.59548m-9.40068,12.84407l-0.02589,0c-3.05503,0 -6.08417,-0.82849 -8.72495,-2.38189l-0.62136,-0.37023l-6.47252,1.68286l1.73463,-6.29129l-0.41424,-0.64725c-1.70875,-2.71846 -2.6149,-5.85116 -2.6149,-9.07706c0,-9.39809 7.68934,-17.06155 17.15993,-17.06155c4.58253,0 8.88029,1.78642 12.11655,5.02268c3.23625,3.21036 5.02267,7.50812 5.02267,12.06476c-0.0078,9.3981 -7.69712,17.06155 -17.14699,17.06155m14.58906,-31.58846c-3.93529,-3.80584 -9.1133,-5.95471 -14.62789,-5.95471c-11.36055,0 -20.60848,9.2065 -20.61625,20.52564c0,3.61684 0.94757,7.14565 2.75211,10.26282l-2.92557,10.63564l10.93337,-2.85309c3.0136,1.63108 6.4052,2.4958 9.85634,2.49839l0.01037,0c11.36574,0 20.61884,-9.2091 20.62403,-20.53082c0,-5.48093 -2.14111,-10.64081 -6.03239,-14.51915",
        }),
        G = n(47),
        J = n(22);
      var K = (e, t, n) => {
          var r, o, a;
          const i = Object(J.c)(),
            {
              pagetype: c,
              source_page_url: l,
              previous_page_url: s,
              destination_page_url: u,
              login_trigger: d,
              customer_hash: p,
              platform: f,
            } = i,
            { code: h, pdpBreadcrumbs: m, classifications: w } = e,
            v = Object(J.d)(w);
          let y = "";
          y = (null === e || void 0 === e ? void 0 : e.name)
            ? null === e || void 0 === e
              ? void 0
              : e.name
            : "N/A";
          const b = null === (r = m[0]) || void 0 === r ? void 0 : r.name,
            g = null === (o = m[1]) || void 0 === o ? void 0 : o.name,
            _ = null === (a = m[2]) || void 0 === a ? void 0 : a.name;
          window.dataLayer.push({
            event: "product_pages_28_product_share_click",
            pagetype: c,
            source_page_url: l,
            previous_page_url: s,
            destination_page_url: u,
            interaction_type: n,
            click_text: t,
            platform: f,
            login_trigger: p ? d : "N/A",
            login_status: !!p,
            user_id: p,
            section: "N/A",
            item_id: h,
            item_name: y,
            item_category: b,
            item_category2: g,
            item_category3: _,
            brand: v,
            creative_id: "N/A",
          });
        },
        Y = n(7);
      var U = function (e) {
          let {
            activeSecTabState: t,
            backSectionBtn: n,
            isMobile: r,
            isTablet: a,
            sharePixelCall: i,
            pdpInfoData: d,
            productPrice: p,
          } = e;
          const f = window.location.href,
            h = d.name ? d.name : "",
            m = "mailto:?body=" + f + "&subject=" + h;
          let w = "";
          var v;
          if (
            "undefined" !== typeof Storage &&
            d &&
            d.imageInfo &&
            Array.isArray(d.imageInfo) &&
            (null === d ||
            void 0 === d ||
            null === (v = d.imageInfo) ||
            void 0 === v
              ? void 0
              : v.length) > 0
          ) {
            let e = d.imageInfo[0];
            w = (null === e || void 0 === e ? void 0 : e.code)
              ? e.url
              : u.a.FALLBACK_IMG;
          }
          try {
            return o.a.createElement(
              c.a,
              { open: "offer" === t, onClose: n, disableEscapeKeyDown: !0 },
              !r || a
                ? o.a.createElement("button", {
                    className: "icon icon-close",
                    type: "button",
                    onClick: n,
                  })
                : null,
              o.a.createElement(
                l.a,
                null,
                o.a.createElement(
                  "div",
                  {
                    className: "modal-wrap modal-xs modal-dock pdp-modal-share",
                  },
                  o.a.createElement(
                    "div",
                    { className: "cp-offer-modal" },
                    o.a.createElement(
                      "div",
                      { className: "offer-title" },
                      s.a.SHARE_HEADING,
                    ),
                    o.a.createElement(
                      "div",
                      { className: "offer-modal-desc" },
                      o.a.createElement(
                        I,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo",
                          quote: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "facebook"),
                              K(d, "share:facebook", "click"));
                          },
                        },
                        o.a.createElement(x, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                      o.a.createElement(
                        z,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo1",
                          title: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "twitter"),
                              K(d, "share:twitter", "click"));
                          },
                        },
                        o.a.createElement(L, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                      o.a.createElement(
                        "a",
                        { href: m, className: "email-share-options" },
                        o.a.createElement(M, {
                          size: 32,
                          round: !0,
                          onClick: () => {
                            (i(),
                              Object(G.a)(d, p, "share", "Email"),
                              K(d, "share:Email", "click"));
                          },
                        }),
                      ),
                      o.a.createElement(
                        H,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo3",
                          media: Object(Y.c)(w),
                          description: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "pinterest"),
                              K(d, "share:pinterest", "click"));
                          },
                        },
                        o.a.createElement(R, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                      o.a.createElement(
                        T,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo4",
                          title: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "linkedIn"),
                              K(d, "share:linkedIn", "click"));
                          },
                        },
                        o.a.createElement(W, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                      o.a.createElement(
                        B,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo5",
                          title: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "Reddit"),
                              K(d, "share:Reddit", "click"));
                          },
                        },
                        o.a.createElement(V, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                      o.a.createElement(
                        F,
                        {
                          url: f,
                          className: "Demo__some-network__share-button",
                          "data-testid": "pdpInfo6",
                          title: h,
                          onClick: () => {
                            (Object(G.a)(d, p, "share", "whatsapp"),
                              K(d, "share:whatsapp", "click"));
                          },
                        },
                        o.a.createElement(q, {
                          size: 32,
                          round: !0,
                          onClick: i,
                        }),
                      ),
                    ),
                  ),
                ),
              ),
            );
          } catch (y) {
            return (console.log(y), o.a.createElement(o.a.Fragment, null, " "));
          }
        },
        X = n(13),
        Z = n(102),
        Q = n(86),
        $ = n(45);
      async function ee(e) {
        const t = new Date().getTime(),
          n = Object($.b)(),
          r = {
            page_type: "cdp",
            content_type: "product",
            action_name: "click",
            event_name: "social_share",
            correlation_id: u.a.MSD_API_CORRELATION_ID,
            medium: "pixel",
            metadata: {},
            source: "CROMA",
            user_id: ["".concat(n.user_id)],
            user_id_type: ["".concat(n.user_id_type)],
            mad_uuid: "".concat(n.mad_uuid),
            utm: { utm_source: "", utm_medium: "", utm_campaign: "" },
            epoch: "".concat(t),
            content_info: { source_id: "".concat(e) },
            pincode:
              "undefined" !== typeof Storage &&
              localStorage.getItem("3hrPincode")
                ? JSON.parse(localStorage.getItem("3hrPincode"))
                : "",
          };
        Object(Q.a)(r);
      }
      const te = o.a.memo(U);
      var ne = function (e) {
          let { itemId: t, pdpInfoData: n, productPrice: r } = e;
          const [a, i] = o.a.useState(""),
            c = (e) => {
              (e.preventDefault(), i(""));
            },
            l = n.name ? n.name : "",
            s = () => {
              ee(t);
            };
          let d = "";
          var p;
          if (
            "undefined" !== typeof Storage &&
            n &&
            n.imageInfo &&
            Array.isArray(n.imageInfo) &&
            (null === n ||
            void 0 === n ||
            null === (p = n.imageInfo) ||
            void 0 === p
              ? void 0
              : p.length) > 0
          ) {
            let e = n.imageInfo[0];
            d = (null === e || void 0 === e ? void 0 : e.code)
              ? e.url
              : u.a.FALLBACK_IMG;
          }
          try {
            return o.a.createElement(
              o.a.Fragment,
              null,
              o.a.createElement(
                "button",
                {
                  type: "button",
                  className: "btn btn-icon",
                  dataid: "share",
                  onClick: () => {
                    navigator.share
                      ? navigator
                          .share({
                            url: window.location.href,
                            title: window.document.title,
                            text: l,
                          })
                          .then(() => {
                            ee(t);
                          })
                          .catch((e) => {})
                      : i("offer");
                  },
                },
                o.a.createElement("span", {
                  className: "icon icon-share",
                  onClick: () => {
                    (Object(G.a)(n, r, "share"), K(n, "Share Button", "click"));
                  },
                }),
              ),
              "" !== d &&
                o.a.createElement(
                  Z.a,
                  null,
                  o.a.createElement("meta", { property: "image", content: d }),
                  o.a.createElement("meta", {
                    property: "og:image",
                    content: d,
                  }),
                  o.a.createElement("meta", {
                    content: "image/*",
                    property: "og:image:type",
                  }),
                ),
              "offer" === a
                ? o.a.createElement(te, {
                    activeSecTabState: a,
                    backSectionBtn: c,
                    isMobile: X.isMobile,
                    isTablet: X.isTablet,
                    sharePixelCall: s,
                    pdpInfoData: n,
                    productPrice: r,
                  })
                : "",
            );
          } catch (f) {
            return (console.log(f), o.a.createElement(o.a.Fragment, null, " "));
          }
        },
        re = n(551);
      const oe = o.a.memo(i),
        ae = o.a.memo(ne),
        ie = o.a.memo(re.a);
      function ce(e) {
        let {
          wishlistData: t,
          noOfViews: n,
          showToastMsg: a,
          pdpData: c,
          productPrice: l,
          shippingOptionData: s,
          approvalStatus: u,
          setWishListed: d,
          wishListed: p,
          standaloneConfig: f,
        } = e;
        const [h, m] = Object(r.useState)(!1),
          [w, v] = Object(r.useState)(!1);
        let y = "";
        Object(r.useEffect)(() => {
          "undefined" !== typeof Storage &&
            v("true" === localStorage.getItem("isCSC"));
        }, []);
        const b = null === c || void 0 === c ? void 0 : c.pdpBreadcrumbs,
          g = null === c || void 0 === c ? void 0 : c.code;
        (Object(r.useEffect)(() => {
          if (t && t.length > 0) {
            t.find((e) => e.product.code === g)
              ? (m(!0), d(!0))
              : (m(!1), d(!1));
          }
        }, [t]),
          b &&
            Array.isArray(b) &&
            b.length > 0 &&
            (y = b.length > 2 ? b[1].name : b[0].name));
        let _ = 0,
          k = 0,
          O = 0;
        (l && l.sellingPrice
          ? ((_ = l.sellingPrice.value), (O = l.sellingPrice.value))
          : l && l.mrp && ((_ = l.mrp.value), (O = l.mrp.value)),
          l && l.mrp && (k = l.mrp.value));
        try {
          return o.a.createElement(
            "div",
            { className: "action-wrap" },
            o.a.createElement(
              "ul",
              { className: "list" },
              o.a.createElement(
                "li",
                { className: "item" },
                n && Array.isArray(n) && n.length > 0
                  ? o.a.createElement(oe, {
                      noOfViews:
                        n[0].data &&
                        Array.isArray(n[0].data) &&
                        n[0].data.length > 0 &&
                        n[0].data[0].no_of_views
                          ? n[0].data[0].no_of_views
                          : n[0].no_of_views
                            ? n[0].no_of_views
                            : 0,
                    })
                  : o.a.createElement(i, { noOfViews: "0" }),
                !(
                  ("ZEXW" === c.SAP_MATERIAL_TYPE ||
                    "ZCHG" === c.SAP_MATERIAL_TYPE) &&
                  !f
                ) &&
                  o.a.createElement(ie, {
                    pdpInfoData: c,
                    isActive: h,
                    itemId: g,
                    showToastMsg: a,
                    productPrice: l,
                    productCat: y,
                    shippingOptionData: s,
                    approvalStatus: u,
                    setWishListed: d,
                    wishListed: p,
                  }),
                !w &&
                  o.a.createElement(ae, {
                    itemId: g,
                    pdpInfoData: c,
                    productPrice: l,
                  }),
              ),
            ),
          );
        } catch (E) {
          return (console.log(E), o.a.createElement(o.a.Fragment, null, " "));
        }
      }
      const le = (e) => ({ pdpData: e.pdpReducer.pdpData });
      t.default = Object(a.b)(le, null)(ce);
    },
  },
]);
