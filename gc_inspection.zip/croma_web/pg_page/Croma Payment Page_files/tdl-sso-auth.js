/*! For license information please see main.js.LICENSE.txt */
(() => {
  var t = {
      633: (t, e, r) => {
        var n = r(738).default;
        function a() {
          "use strict";
          ((t.exports = a =
            function () {
              return r;
            }),
            (t.exports.__esModule = !0),
            (t.exports.default = t.exports));
          var e,
            r = {},
            o = Object.prototype,
            i = o.hasOwnProperty,
            s =
              Object.defineProperty ||
              function (t, e, r) {
                t[e] = r.value;
              },
            c = "function" == typeof Symbol ? Symbol : {},
            d = c.iterator || "@@iterator",
            u = c.asyncIterator || "@@asyncIterator",
            l = c.toStringTag || "@@toStringTag";
          function p(t, e, r) {
            return (
              Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              }),
              t[e]
            );
          }
          try {
            p({}, "");
          } catch (e) {
            p = function (t, e, r) {
              return (t[e] = r);
            };
          }
          function f(t, e, r, n) {
            var a = e && e.prototype instanceof P ? e : P,
              o = Object.create(a.prototype),
              i = new B(n || []);
            return (s(o, "_invoke", { value: C(t, r, i) }), o);
          }
          function y(t, e, r) {
            try {
              return { type: "normal", arg: t.call(e, r) };
            } catch (t) {
              return { type: "throw", arg: t };
            }
          }
          r.wrap = f;
          var h = "suspendedStart",
            v = "suspendedYield",
            m = "executing",
            A = "completed",
            T = {};
          function P() {}
          function w() {}
          function g() {}
          var I = {};
          p(I, d, function () {
            return this;
          });
          var E = Object.getPrototypeOf,
            S = E && E(E(R([])));
          S && S !== o && i.call(S, d) && (I = S);
          var b = (g.prototype = P.prototype = Object.create(I));
          function L(t) {
            ["next", "throw", "return"].forEach(function (e) {
              p(t, e, function (t) {
                return this._invoke(e, t);
              });
            });
          }
          function O(t, e) {
            function r(a, o, s, c) {
              var d = y(t[a], t, o);
              if ("throw" !== d.type) {
                var u = d.arg,
                  l = u.value;
                return l && "object" == n(l) && i.call(l, "__await")
                  ? e.resolve(l.__await).then(
                      function (t) {
                        r("next", t, s, c);
                      },
                      function (t) {
                        r("throw", t, s, c);
                      },
                    )
                  : e.resolve(l).then(
                      function (t) {
                        ((u.value = t), s(u));
                      },
                      function (t) {
                        return r("throw", t, s, c);
                      },
                    );
              }
              c(d.arg);
            }
            var a;
            s(this, "_invoke", {
              value: function (t, n) {
                function o() {
                  return new e(function (e, a) {
                    r(t, n, e, a);
                  });
                }
                return (a = a ? a.then(o, o) : o());
              },
            });
          }
          function C(t, r, n) {
            var a = h;
            return function (o, i) {
              if (a === m) throw Error("Generator is already running");
              if (a === A) {
                if ("throw" === o) throw i;
                return { value: e, done: !0 };
              }
              for (n.method = o, n.arg = i; ; ) {
                var s = n.delegate;
                if (s) {
                  var c = N(s, n);
                  if (c) {
                    if (c === T) continue;
                    return c;
                  }
                }
                if ("next" === n.method) n.sent = n._sent = n.arg;
                else if ("throw" === n.method) {
                  if (a === h) throw ((a = A), n.arg);
                  n.dispatchException(n.arg);
                } else "return" === n.method && n.abrupt("return", n.arg);
                a = m;
                var d = y(t, r, n);
                if ("normal" === d.type) {
                  if (((a = n.done ? A : v), d.arg === T)) continue;
                  return { value: d.arg, done: n.done };
                }
                "throw" === d.type &&
                  ((a = A), (n.method = "throw"), (n.arg = d.arg));
              }
            };
          }
          function N(t, r) {
            var n = r.method,
              a = t.iterator[n];
            if (a === e)
              return (
                (r.delegate = null),
                ("throw" === n &&
                  t.iterator.return &&
                  ((r.method = "return"),
                  (r.arg = e),
                  N(t, r),
                  "throw" === r.method)) ||
                  ("return" !== n &&
                    ((r.method = "throw"),
                    (r.arg = new TypeError(
                      "The iterator does not provide a '" + n + "' method",
                    )))),
                T
              );
            var o = y(a, t.iterator, r.arg);
            if ("throw" === o.type)
              return (
                (r.method = "throw"),
                (r.arg = o.arg),
                (r.delegate = null),
                T
              );
            var i = o.arg;
            return i
              ? i.done
                ? ((r[t.resultName] = i.value),
                  (r.next = t.nextLoc),
                  "return" !== r.method && ((r.method = "next"), (r.arg = e)),
                  (r.delegate = null),
                  T)
                : i
              : ((r.method = "throw"),
                (r.arg = new TypeError("iterator result is not an object")),
                (r.delegate = null),
                T);
          }
          function k(t) {
            var e = { tryLoc: t[0] };
            (1 in t && (e.catchLoc = t[1]),
              2 in t && ((e.finallyLoc = t[2]), (e.afterLoc = t[3])),
              this.tryEntries.push(e));
          }
          function W(t) {
            var e = t.completion || {};
            ((e.type = "normal"), delete e.arg, (t.completion = e));
          }
          function B(t) {
            ((this.tryEntries = [{ tryLoc: "root" }]),
              t.forEach(k, this),
              this.reset(!0));
          }
          function R(t) {
            if (t || "" === t) {
              var r = t[d];
              if (r) return r.call(t);
              if ("function" == typeof t.next) return t;
              if (!isNaN(t.length)) {
                var a = -1,
                  o = function r() {
                    for (; ++a < t.length; )
                      if (i.call(t, a))
                        return ((r.value = t[a]), (r.done = !1), r);
                    return ((r.value = e), (r.done = !0), r);
                  };
                return (o.next = o);
              }
            }
            throw new TypeError(n(t) + " is not iterable");
          }
          return (
            (w.prototype = g),
            s(b, "constructor", { value: g, configurable: !0 }),
            s(g, "constructor", { value: w, configurable: !0 }),
            (w.displayName = p(g, l, "GeneratorFunction")),
            (r.isGeneratorFunction = function (t) {
              var e = "function" == typeof t && t.constructor;
              return (
                !!e &&
                (e === w || "GeneratorFunction" === (e.displayName || e.name))
              );
            }),
            (r.mark = function (t) {
              return (
                Object.setPrototypeOf
                  ? Object.setPrototypeOf(t, g)
                  : ((t.__proto__ = g), p(t, l, "GeneratorFunction")),
                (t.prototype = Object.create(b)),
                t
              );
            }),
            (r.awrap = function (t) {
              return { __await: t };
            }),
            L(O.prototype),
            p(O.prototype, u, function () {
              return this;
            }),
            (r.AsyncIterator = O),
            (r.async = function (t, e, n, a, o) {
              void 0 === o && (o = Promise);
              var i = new O(f(t, e, n, a), o);
              return r.isGeneratorFunction(e)
                ? i
                : i.next().then(function (t) {
                    return t.done ? t.value : i.next();
                  });
            }),
            L(b),
            p(b, l, "Generator"),
            p(b, d, function () {
              return this;
            }),
            p(b, "toString", function () {
              return "[object Generator]";
            }),
            (r.keys = function (t) {
              var e = Object(t),
                r = [];
              for (var n in e) r.push(n);
              return (
                r.reverse(),
                function t() {
                  for (; r.length; ) {
                    var n = r.pop();
                    if (n in e) return ((t.value = n), (t.done = !1), t);
                  }
                  return ((t.done = !0), t);
                }
              );
            }),
            (r.values = R),
            (B.prototype = {
              constructor: B,
              reset: function (t) {
                if (
                  ((this.prev = 0),
                  (this.next = 0),
                  (this.sent = this._sent = e),
                  (this.done = !1),
                  (this.delegate = null),
                  (this.method = "next"),
                  (this.arg = e),
                  this.tryEntries.forEach(W),
                  !t)
                )
                  for (var r in this)
                    "t" === r.charAt(0) &&
                      i.call(this, r) &&
                      !isNaN(+r.slice(1)) &&
                      (this[r] = e);
              },
              stop: function () {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval;
              },
              dispatchException: function (t) {
                if (this.done) throw t;
                var r = this;
                function n(n, a) {
                  return (
                    (s.type = "throw"),
                    (s.arg = t),
                    (r.next = n),
                    a && ((r.method = "next"), (r.arg = e)),
                    !!a
                  );
                }
                for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                  var o = this.tryEntries[a],
                    s = o.completion;
                  if ("root" === o.tryLoc) return n("end");
                  if (o.tryLoc <= this.prev) {
                    var c = i.call(o, "catchLoc"),
                      d = i.call(o, "finallyLoc");
                    if (c && d) {
                      if (this.prev < o.catchLoc) return n(o.catchLoc, !0);
                      if (this.prev < o.finallyLoc) return n(o.finallyLoc);
                    } else if (c) {
                      if (this.prev < o.catchLoc) return n(o.catchLoc, !0);
                    } else {
                      if (!d)
                        throw Error("try statement without catch or finally");
                      if (this.prev < o.finallyLoc) return n(o.finallyLoc);
                    }
                  }
                }
              },
              abrupt: function (t, e) {
                for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                  var n = this.tryEntries[r];
                  if (
                    n.tryLoc <= this.prev &&
                    i.call(n, "finallyLoc") &&
                    this.prev < n.finallyLoc
                  ) {
                    var a = n;
                    break;
                  }
                }
                a &&
                  ("break" === t || "continue" === t) &&
                  a.tryLoc <= e &&
                  e <= a.finallyLoc &&
                  (a = null);
                var o = a ? a.completion : {};
                return (
                  (o.type = t),
                  (o.arg = e),
                  a
                    ? ((this.method = "next"), (this.next = a.finallyLoc), T)
                    : this.complete(o)
                );
              },
              complete: function (t, e) {
                if ("throw" === t.type) throw t.arg;
                return (
                  "break" === t.type || "continue" === t.type
                    ? (this.next = t.arg)
                    : "return" === t.type
                      ? ((this.rval = this.arg = t.arg),
                        (this.method = "return"),
                        (this.next = "end"))
                      : "normal" === t.type && e && (this.next = e),
                  T
                );
              },
              finish: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                  var r = this.tryEntries[e];
                  if (r.finallyLoc === t)
                    return (this.complete(r.completion, r.afterLoc), W(r), T);
                }
              },
              catch: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                  var r = this.tryEntries[e];
                  if (r.tryLoc === t) {
                    var n = r.completion;
                    if ("throw" === n.type) {
                      var a = n.arg;
                      W(r);
                    }
                    return a;
                  }
                }
                throw Error("illegal catch attempt");
              },
              delegateYield: function (t, r, n) {
                return (
                  (this.delegate = {
                    iterator: R(t),
                    resultName: r,
                    nextLoc: n,
                  }),
                  "next" === this.method && (this.arg = e),
                  T
                );
              },
            }),
            r
          );
        }
        ((t.exports = a),
          (t.exports.__esModule = !0),
          (t.exports.default = t.exports));
      },
      738: (t) => {
        function e(r) {
          return (
            (t.exports = e =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (t) {
                    return typeof t;
                  }
                : function (t) {
                    return t &&
                      "function" == typeof Symbol &&
                      t.constructor === Symbol &&
                      t !== Symbol.prototype
                      ? "symbol"
                      : typeof t;
                  }),
            (t.exports.__esModule = !0),
            (t.exports.default = t.exports),
            e(r)
          );
        }
        ((t.exports = e),
          (t.exports.__esModule = !0),
          (t.exports.default = t.exports));
      },
      756: (t, e, r) => {
        var n = r(633)();
        t.exports = n;
        try {
          regeneratorRuntime = n;
        } catch (t) {
          "object" == typeof globalThis
            ? (globalThis.regeneratorRuntime = n)
            : Function("r", "regeneratorRuntime = r")(n);
        }
      },
    },
    e = {};
  function r(n) {
    var a = e[n];
    if (void 0 !== a) return a.exports;
    var o = (e[n] = { exports: {} });
    return (t[n](o, o.exports, r), o.exports);
  }
  ((r.n = (t) => {
    var e = t && t.__esModule ? () => t.default : () => t;
    return (r.d(e, { a: e }), e);
  }),
    (r.d = (t, e) => {
      for (var n in e)
        r.o(e, n) &&
          !r.o(t, n) &&
          Object.defineProperty(t, n, { enumerable: !0, get: e[n] });
    }),
    (r.o = (t, e) => Object.prototype.hasOwnProperty.call(t, e)),
    (() => {
      "use strict";
      function t(t, e, r, n, a, o, i) {
        try {
          var s = t[o](i),
            c = s.value;
        } catch (t) {
          return void r(t);
        }
        s.done ? e(c) : Promise.resolve(c).then(n, a);
      }
      function e(e) {
        return function () {
          var r = this,
            n = arguments;
          return new Promise(function (a, o) {
            var i = e.apply(r, n);
            function s(e) {
              t(i, a, o, s, c, "next", e);
            }
            function c(e) {
              t(i, a, o, s, c, "throw", e);
            }
            s(void 0);
          });
        };
      }
      var n = r(756),
        a = r.n(n),
        o = function (t) {
          var e,
            r =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
            n = new Uint8Array(t),
            a = n.length,
            o = "";
          for (e = 0; e < a; e += 3)
            ((o += r[n[e] >> 2]),
              (o += r[((3 & n[e]) << 4) | (n[e + 1] >> 4)]),
              (o += r[((15 & n[e + 1]) << 2) | (n[e + 2] >> 6)]),
              (o += r[63 & n[e + 2]]));
          return (
            a % 3 == 2
              ? (o = "".concat(o.substring(0, o.length - 1), "="))
              : a % 3 == 1 &&
                (o = "".concat(o.substring(0, o.length - 2), "==")),
            o
          );
        },
        i = (function () {
          var t = e(
            a().mark(function t(e) {
              var r, n, i, s;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (
                        (r = new TextEncoder()),
                        (n = r.encode(e)),
                        (t.next = 4),
                        window.crypto.subtle.digest("SHA-256", n)
                      );
                    case 4:
                      return (
                        (i = t.sent),
                        (s = o(i)),
                        t.abrupt(
                          "return",
                          s
                            .replace(/\+/g, "-")
                            .replace(/\//g, "_")
                            .replace(/=/g, ""),
                        )
                      );
                    case 7:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })();
      function s(t) {
        for (var e = "", r = 0; r < t; r += 1)
          e +=
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~".charAt(
              Math.floor(66 * Math.random()),
            );
        return e;
      }
      ((window.codeVerifierTdlSsoAuth = s(128)),
        (window.codeChallengeTdlSsoAuth = i(window.codeVerifierTdlSsoAuth)));
      var c,
        d,
        u,
        l = window.location.href,
        p =
          (u =
            null !==
              (d = null == (c = document.currentScript) ? void 0 : c.src) &&
            void 0 !== d
              ? d
              : "").includes("localhost") || u.includes("0.0.0.0")
            ? "http://localhost:8080/v2/"
            : u.includes("dev")
              ? "https://dev-account.tatadigital.com/v2/"
              : u.includes("sit-account")
                ? "https://sit-account.tatadigital.com/v2/"
                : u.includes("pt")
                  ? "https://pt-account.tatadigital.com/v2/"
                  : u.includes("sit-r2-account")
                    ? "https://sit-r2-account.tatadigital.com/v2/"
                    : u.includes("accounts")
                      ? "https://accounts.tatadigital.com/v2/"
                      : u.includes("bf")
                        ? "https://bf-account.tatadigital.com/v2/"
                        : "https://dev-account.tatadigital.com/v2/",
        f = function () {
          var t = p;
          return t.includes("localhost") ||
            t.includes("0.0.0.0") ||
            t.includes("dev")
            ? "https://dapi.tatadigital.com"
            : t.includes("sit-account")
              ? "https://sapi.tatadigital.com"
              : t.includes("sit-r2-account")
                ? "https://ppapi.tatadigital.com"
                : t.includes("pt")
                  ? "https://pfapi.tatadigital.com"
                  : t.includes("accounts")
                    ? "https://api.tatadigital.com"
                    : t.includes("bf")
                      ? "https://bapi.tatadigital.com"
                      : "https://dapi.tatadigital.com";
        },
        y = function () {
          var t = p;
          return t.includes("dev")
            ? "https://tatadigital-dev.adobecqms.net"
            : t.includes("sit-r2-account") || t.includes("pt")
              ? "https://aem-sit-r2.tatadigital.com"
              : t.includes("accounts")
                ? "https://tatadigital.com"
                : "https://tatadigital-dev.adobecqms.net";
        };
      window.ssoSdkGetClientId = function (t) {
        return [
          "tajhotels.com",
          "amastaysandtrails.com",
          "vivantahotels.com",
          "seleqtionshotels.com",
          "taj-dev65-02.adobecqms.net",
          "taj-stage65-1.adobecqms.net",
          "gingerhotels",
        ].find(function (e) {
          return t.includes(e);
        })
          ? "IHCL-WEB-APP"
          : "";
      };
      var h = {};
      ((window.ssoSdkGenerateAuthCodeForTargetDomain = (function () {
        var t = e(
          a().mark(function t(e, r, n, o) {
            var i, s, c;
            return a().wrap(function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    return (
                      (i = "".concat(
                        f(),
                        "/api/v2/sso/redirect-client-auth-code",
                      )),
                      (s = {
                        redirectClientId: window.ssoSdkGetClientId(r.origin),
                        redirectUrl: r.href,
                        codeChallenge: h.codeChallenge,
                      }),
                      (t.next = 4),
                      fetch(i, {
                        method: "POST",
                        credentials: "include",
                        headers: {
                          client_id: n,
                          client_secret: o,
                          "Access-Control-Allow-Origin": f(),
                          Authorization: "Bearer ".concat(e),
                          "Content-Type": "application/json",
                        },
                        body: JSON.stringify(s),
                      })
                    );
                  case 4:
                    return ((c = (c = t.sent).json()), t.abrupt("return", c));
                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
          }),
        );
        return function (e, r, n, a) {
          return t.apply(this, arguments);
        };
      })()),
        (window.tdlSsoAuth = {}));
      var v = {
          bufferArrayLength: 0,
          bufferIntervalInSeconds: 5,
          bufferSizeInKb: 0,
          sessionIdExpiresInS: 86400,
          redirectedFromTCPFlagExpiresInS: 86400,
          urls: [],
          customerHashValidityInS: 86400,
          defaultDlArgsEventsToRecord: [],
          defaultDlObjectEventsToRecord: [],
          dataLayerCheckRetryCount: 10,
        },
        m = {
          "AIRASIA-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/rateus/api/feedbackrequests/generate_customer_feedback_url",
              "/b2c-booking/v1/breakup/state",
              "/b2c-flightsearch/v1/search-availability",
            ],
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [
              "fb_proceed-to-guestDetail",
              "gtm.load",
            ],
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "AIRASIA",
            clientId: "AIRASIA-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "AXIO-CAPITALFLOAT-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "FS",
            clientId: "AXIO-CAPITALFLOAT-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "BIGBASKET-WEB-DESKTOP-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/complete/orderv3/",
              "/order/place_web_order/",
              "/order/v1/order",
              "/mapi/v3.5.2/order/list-new/",
              "/api/v1/order/orders",
              "/mapi/v3.5.0/order/order-assistant/",
              "/co/delivery-preferences-new/",
              "/order/v1/potentialorder/",
              "/mapi/v3.5.2/order/delivery-preferences",
              "/basketService/update-qty/",
              "/mapi/v3.5.2/c-incr-i/",
              "/mapi/v3.5.2/c-set-i/",
              "/basketService/del-item/",
              "/mapi/v3.5.2/c-decr-i/",
              "/msl/add-item/",
              "/mapi/v3.5.2/member/add-to-sfl/",
              "/mapi/v4.2.0/member/remove-from-sfl/",
              "/msl/remove-item/",
              "/msl/delete-shoppinglist-items/",
              "/_next/data/",
            ],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "BIGBASKET",
            clientId: "BIGBASKET-WEB-DESKTOP-APP",
            browserEventsToRecord: ["click"],
            htmlPageScriptTagKeywords: { "/pd/": "window.__PRELOADED_STATE__" },
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "BIGBASKET-WEB-MOBILE-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/complete/orderv3/",
              "/order/place_web_order/",
              "/order/v1/order",
              "/mapi/v3.5.2/order/list-new/",
              "/api/v1/order/orders",
              "/mapi/v3.5.0/order/order-assistant/",
              "/co/delivery-preferences-new/",
              "/order/v1/potentialorder/",
              "/mapi/v3.5.2/order/delivery-preferences",
              "/basketService/update-qty/",
              "/mapi/v3.5.2/c-incr-i/",
              "/mapi/v3.5.2/c-set-i/",
              "/basketService/del-item/",
              "/mapi/v3.5.2/c-decr-i/",
              "/msl/add-item/",
              "/mapi/v3.5.2/member/add-to-sfl/",
              "/mapi/v4.2.0/member/remove-from-sfl/",
              "/msl/remove-item/",
              "/msl/delete-shoppinglist-items/",
              "/_next/data/",
            ],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "BIGBASKET",
            clientId: "BIGBASKET-WEB-MOBILE-APP",
            browserEventsToRecord: ["click"],
            htmlPageScriptTagKeywords: { "/pd/": "window.__PRELOADED_STATE__" },
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "CROMA-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/paymentconfirmation",
              "/ocs/v1/order-confirmation",
              "/order/oms/v2/list/details-pwa",
              "/useraccount/allchannels/v1",
              "/floatingcart",
              "/attachProduct",
              "/detail",
              "/addition",
              "/deletion",
              "/inventory/oms/v2/tms/details-pwa/",
              "/inventory/oms/v2/details-pwa/",
              "/price",
            ],
            cartAndWishListConfig: {
              "detail?isGetCart": {
                products: ["entries"],
                type: "cart",
                keysToCapture: {
                  price: ["product", "price", "value"],
                  productId: ["product", "code"],
                  productName: ["product", "name"],
                  quantity: ["quantity"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [
              "add_to_wishlist",
              "add_to_cart",
              "remove_from_cart",
            ],
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "CROMA",
            clientId: "CROMA-WEB-APP",
            keyToCheckLoginState: ["ls", "customer_hash"],
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
            recordNonNeuLed: !0,
          },
          "CULTFIT-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: ["/paymentSuccess", "/api/order/checkout"],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "CULTFIT",
            clientId: "CULTFIT-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "FS-BNPL-FINBOX-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "FS",
            clientId: "FS-BNPL-FINBOX-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "FS-PL-FINBOX-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [],
            recordGtmEvents: !1,
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "FS",
            clientId: "FS-PL-FINBOX-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "IHCL-AMA-WEB-APP": {},
          "IHCL-GINGER-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/bin/bookHotelInitiateServlet",
              "postPaymentServlet",
              "/bin/bookCartAvailabilityServlet",
              "/ratesCache.json",
              "/destinationRatesCache.json",
            ],
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: ["rooms.add", "removeFromCart"],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "IHCL",
            clientId: "IHCL-GINGER-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "IHCL-SELEQTIONS-WEB-APP": {},
          "IHCL-VIVANTA-WEB-APP": {},
          "IHCL-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/bin/bookHotelInitiateServlet",
              "postPaymentServlet",
              "/bin/bookCartAvailabilityServlet",
              "/ratesCache.json",
              "/destinationRatesCache.json",
            ],
            recordGtmEvents: !0,
            addAnalyticsParamsToHref: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: ["rooms.add", "removeFromCart"],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "IHCL",
            clientId: "IHCL-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "MAGICPIN-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "MAGICPIN",
            clientId: "MAGICPIN-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "NEUPOLICY-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "NEUPOLICY",
            clientId: "NEUPOLICY-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "ONEMG-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/v1/track",
              "/pharmacy_api/prescription-order",
              "/tracking_details?city",
              "/pharmacy_api/cart/summary",
              "/doctor_api/v5/conversations/",
              "/pharmacy_api/cart",
              "/pwa-api/cart/add",
              "/pwa-api/api/v4/carts/skus",
              "/pharmacy_api/v2/cart",
              "/labs_api/cart/replace",
              "/labs_api/cart/item",
              "/pwa-api/labs/cart/replace",
              "/v1/page",
              "1mg.com/pwa-api/api/v5/carts/skus",
            ],
            cartAndWishListConfig: {
              "pwa-api/api/v4/carts/skus": {
                type: "cart",
                products: ["data", "brief", "items"],
                keysToCapture: {
                  productId: ["sku_id"],
                  quantity: ["quantity"],
                  productName: ["sku_name"],
                  price: [],
                },
              },
              "1mg.com/pwa-api/api/v5/carts/skus": {
                type: "cart",
                products: [
                  "data",
                  "widgets",
                  "1",
                  "data",
                  "grouped_items",
                  "_processArray_",
                  "items",
                  "_flattenArray_",
                ],
                keysToCapture: {
                  productId: ["sku_id"],
                  quantity: ["cta", "details", "quantity"],
                  productName: ["header"],
                  price: ["prices", "discounted_price"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [
              "Add To Cart",
              "Add To Cart ",
              "Otc_upsell_widget_add",
              "Add To Cart Spotlight Products",
              "Add to cart widget",
              "Add to cart",
              "Remove SKU",
            ],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "ONEMG",
            clientId: "ONEMG-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "QMIN-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/order-status/",
              "/v12/orders",
              "/api/v12/cart/v2",
              "/v12/restaurants/",
            ],
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "QMIN",
            clientId: "QMIN-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TATACLIQ-LUXURY-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payments/getPrepaidOrderPaymentConfirmation",
              "/payments/updateTransactionDetailsforCOD",
              "/orderConfirmation/",
              "/getSelectedOrder_V1/",
              "/orderhistorylist_V1",
              "/displayOrderSummary_V2",
              "/productAdditionToCart_V1",
              "/productAdditionToCart?addedToCartWl",
              "/cartDetails?access_token",
              "/cartDetails_V2?access_token",
              "/getAllWishlist?access_token",
              "/addProductInWishlist",
              "/checkPincode",
              "/marketplacewebservices/v2/lux/products/productDetails/",
              "/buyNow/expressBuy",
            ],
            cartAndWishListConfig: {
              "cartDetails?access_token": {
                type: "cart",
                products: ["products"],
                keysToCapture: {
                  productId: ["productcode"],
                  quantity: ["quantity"],
                  productName: ["productName"],
                  price: ["price"],
                },
              },
              getAllWishlist: {
                type: "wishlist",
                products: ["wishList", 0, "products"],
                keysToCapture: {
                  productId: ["productcode"],
                  quantity: ["quantity"],
                  productName: ["productName"],
                  price: ["mrp", "value"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [
              "add_to_cart",
              "add_to_wishlist",
              "remove_from_cart",
              "Buy now",
            ],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "TATACLIQ-LUXURY",
            clientId: "TATACLIQ-LUXURY-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TATACLIQ-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payments/getPrepaidOrderPaymentConfirmation",
              "/getSelectedOrder_V2/",
              "/orderConfirmation/",
              "getSelectedOrder",
              "/displayOrderSummary_V2",
              "/productAdditionToCart_V1",
              "/cartDetails_V2?access_token",
              "/addProductInWishlist",
              "/getAllWishlist",
              "/checkPincode",
              "/marketplacewebservices/v2/mpl/products/productDetails/",
              "/buyNow/expressBuy",
            ],
            cartAndWishListConfig: {
              getAllWishlist: {
                products: ["wishList", ["0"], "products"],
                type: "wishlist",
                keysToCapture: {
                  productId: ["productcode"],
                  quantity: ["quantity"],
                  productName: ["productName"],
                  price: ["mrp", "value"],
                },
              },
              cartDetails_V2: {
                products: ["products"],
                type: "cart",
                keysToCapture: {
                  productId: ["productcode"],
                  quantity: ["qtySelectedByUser"],
                  productName: ["productName"],
                  price: ["price"],
                },
              },
            },
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "TATACLIQ",
            clientId: "TATACLIQ-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TATAMOTORS-WEB-APP": {},
          "TCP-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/api/orch/v2/payment/status/ui",
              "api/orderdetails?brand",
              "fetch-referral-bulk",
              "kymacart/updatebundle",
              "/api/v1/search/click",
              "/api/v1/search/auto-complete",
              "/api/v1/search/composite/click",
              "/api/v1/search/composite",
              "/api/v1/billpay/cart/viewsummary",
              "/api/v2/digitalgold/buygold/BuyInputSubmit",
            ],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            recordAdobeEvents: !0,
            adobeEventsToRecord: [
              "tap",
              "SLP : Launcher",
              "SLP : Click",
              "SLP : Banner",
              "SLP : Brands",
              "OfferZone : Banner",
              "OfferZone : FilterByCategory",
              "OfferZone : CTAClick",
              "OfferZone : Brands",
              "OfferZone : FilterByCategory",
              "Error Event",
              "view",
            ],
            modifyHistoryOwnMethods: !0,
            recordWebVitals: !1,
            brand: "TATADIGITAL",
            clientId: "TCP-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-EYEPLUS-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/googletagmanager/index/orderdetails/",
              "/payment.json",
              "/googletagmanager/index/cartdetails/",
              "/customer/section/load/?sections=cart",
              "/customer/section/load/?sections=cart,wishlist",
              "/customer/section/load/?sections=cart%2Cwishlist",
              "/customer/section/load/?sections=wishlist",
              "/googletagmanager/index/productdetails/",
              "/delivery/delivery/checkdelivery/",
            ],
            cartAndWishListConfig: {
              "/section/load/?sections=cart%2Cwishlist": {
                type: "wishlist",
                products: ["wishlist", "items"],
                keysToCapture: {
                  productName: ["product_name"],
                  price: ["product_price"],
                  productId: ["product_sku"],
                  quantity: [""],
                },
              },
              "/section/load/?sections=cart%2Cmessages": {
                type: "cart",
                products: ["cart", "items"],
                keysToCapture: {
                  price: ["product_price_value"],
                  productId: ["product_sku"],
                  productName: ["product_name"],
                  quantity: ["qty"],
                },
              },
              "/section/load/?sections=wishlist%2Cmessages": {
                type: "wishlist",
                products: ["wishlist", "items"],
                keysToCapture: {
                  productName: ["product_name"],
                  price: ["product_price"],
                  productId: ["product_sku"],
                  quantity: [""],
                },
              },
              cartdetails: {
                type: "cart",
                products: ["items", 0],
                keysToCapture: {
                  productId: ["item_id"],
                  quantity: ["quantity"],
                  productName: ["item_name"],
                  price: ["price"],
                },
              },
            },
            cartOrWishListStateGtmEvents: {
              view_cart: {
                type: "cart",
                products: ["ecommerce", "items"],
                keysToCapture: {
                  productId: ["item_id"],
                  quantity: ["quantity"],
                  productName: ["item_name"],
                  price: ["price"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [
              "add_to_cart",
              "buy_confirmation_click",
              "remove_from_cart",
              "add_to_wishlist",
              "purchase",
            ],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "EYEPLUS",
            clientId: "TITAN-EYEPLUS-WEB-APP",
            browserEventsToRecord: ["click"],
            htmlPageScriptTagKeywords: { "/app/shopping-cart": "cartItems" },
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-FASTRACK-WATCH-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/productview/productDetailsbyId",
              "/cart/review",
              "/serviceabilityComponent",
            ],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "FASTRACK-WATCH",
            clientId: "TITAN-FASTRACK-WATCH-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-FASTRACK-WEB-APP": {},
          "TITAN-IRTH-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/productview/productDetailsbyId",
              "/cart/review",
              "/serviceabilityComponent",
            ],
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "IRTH",
            clientId: "TITAN-IRTH-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-MIA-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payment/@self/order_summary/",
              "/cart/addtocart",
              "/cart/review",
              "/cart/@self_cart",
              "/wishlist/checkItemPresentInWishlist",
              "/productview/productDetailsbyId",
              "/serviceabilityComponent",
            ],
            cartAndWishListConfig: {
              "/cart/@self_cart": {
                type: "cart",
                products: ["orderItem"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantity"],
                  productName: ["productDetail", "itemName"],
                  price: ["orderItemPrice"],
                },
              },
              "/wishlist/@self": {
                type: "wishlist",
                products: ["GiftList", 0, "item"],
                keysToCapture: {
                  price: ["itemListPrice"],
                  productId: ["partNumber"],
                  productName: ["productName"],
                  quantity: ["quantityRequested"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: ["cart_add"],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "MIA",
            clientId: "TITAN-MIA-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-SKINN-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payment/@self/order_summary/",
              "/cart/addtocart",
              "/cart/review",
              "/cart/@self_cart",
              "/wishlist/checkItemPresentInWishlist",
              "/wishlist/custom",
              "/productview/productDetailsbyId",
              "/serviceabilityComponent",
            ],
            cartAndWishListConfig: {
              "/cart/@self_cart": {
                type: "cart",
                products: ["orderItem"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantity"],
                  productName: ["productDetail", "itemName"],
                  price: ["orderItemPrice"],
                },
              },
              "/wishlist/custom": {
                type: "wishlist",
                products: ["GiftList", 0, "item"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantityRequested"],
                  price: ["itemListPrice"],
                  productName: ["productName"],
                },
              },
            },
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "SKINN",
            clientId: "TITAN-SKINN-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-SONATA-WEB-APP": {},
          "TITAN-TANEIRA-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payment/@self/order_summary/",
              "/cart/addtocart",
              "/cart/review",
              "/cart/@self_cart",
              "/wishlist/checkItemPresentInWishlist",
              "/wishlist/custom",
              "/productview/productDetailsbyId",
              "/serviceabilityComponent",
            ],
            cartAndWishListConfig: {
              "/cart/@self_cart": {
                type: "cart",
                products: ["orderItem"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantity"],
                  productName: ["productDetail", "itemName"],
                  price: ["orderItemPrice"],
                },
              },
              "/wishlist/custom": {
                type: "wishlist",
                products: ["Giftlist", 0, "item"],
                keystoCapture: {
                  price: ["itemListPrice"],
                  productId: ["partNumber"],
                  productName: ["productName"],
                  quantity: ["quantityRequested"],
                },
              },
            },
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "TANEIRA",
            clientId: "TITAN-TANEIRA-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-TANISHQ-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payment/@self/order_summary/",
              "/cart/addtocart",
              "/cart/review",
              "/cart/@self_cart",
              "/wishlist/checkItemPresentInWishlist",
              "/productview/productDetailsbyId",
              "/serviceabilityComponent",
            ],
            cartAndWishListConfig: {
              "/cart/@self_cart": {
                type: "cart",
                products: ["orderItem"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantity"],
                  productName: ["productDetail", "itemName"],
                  price: ["orderItemPrice"],
                },
              },
              "/wishlist/@self": {
                type: "wishlist",
                products: ["GiftList", 0, "item"],
                keysToCapture: {
                  price: ["itemListPrice"],
                  productId: ["partNumber"],
                  productName: ["productName"],
                  quantity: ["quantityRequested"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: ["cart_add"],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "TANISHQ",
            clientId: "TITAN-TANISHQ-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-TRAQ-WEB-APP": {},
          "TITAN-WATCH-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "/payment/@self/order_summary/",
              "/cart/review",
              "/cart/@self_cart",
              "/wishlist/checkItemPresentInWishlist",
              "/wishlist/custom/",
              "/productview/productDetailsbyId",
              "/serviceabilityComponent",
            ],
            cartAndWishListConfig: {
              "/cart/@self_cart": {
                type: "cart",
                products: ["orderItem"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantity"],
                  productName: ["productDetail", "itemName"],
                  price: ["orderItemPrice"],
                },
              },
              "/wishlist/custom": {
                type: "wishlist",
                products: ["GiftList", 0, "item"],
                keysToCapture: {
                  productId: ["partNumber"],
                  quantity: ["quantityRequested"],
                  price: ["itemListPrice"],
                  productName: ["productName"],
                },
              },
            },
            recordGtmEvents: !0,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: ["cart_add"],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "TITAN",
            clientId: "TITAN-WATCH-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !0,
            recordJsDispatchedClicks: !1,
          },
          "TITAN-ZOYA-WEB-APP": {},
          "WESTSIDE-WEB-APP": {
            recordAnalytics: !0,
            syncTrackingUrls: [
              "thank_you",
              "/cart.json",
              "/cart.js",
              "/cart/update.js",
              "storecart",
            ],
            cartAndWishListConfig: {
              "update.js": {
                type: "cart",
                products: ["items"],
                keysToCapture: {
                  productId: ["variant_id"],
                  quantity: ["quantity"],
                  productName: ["title"],
                  price: ["price"],
                },
              },
            },
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "WESTSIDE",
            clientId: "WESTSIDE-WEB-APP",
            browserEventsToRecord: ["click"],
            htmlPageScriptTagKeywords: {
              "/thank_you": "Shopify.checkout",
              "/products/": "Shopify.OptionSelectors('product-selectors",
            },
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
          "INSPEKTLABS-WEB-APP": {
            recordAnalytics: !0,
            recordGtmEvents: !1,
            dataLayerArgumentEventsToRecord: [],
            dataLayerObjectEventsToRecord: [],
            modifyHistoryOwnMethods: !1,
            recordWebVitals: !1,
            brand: "INSPEKTLABS",
            clientId: "INSPEKTLABS-WEB-APP",
            browserEventsToRecord: ["click"],
            listenToPastDataLayerEvents: !1,
            recordJsDispatchedClicks: !1,
          },
        };
      function A(t) {
        return (
          (A =
            "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
              ? function (t) {
                  return typeof t;
                }
              : function (t) {
                  return t &&
                    "function" == typeof Symbol &&
                    t.constructor === Symbol &&
                    t !== Symbol.prototype
                    ? "symbol"
                    : typeof t;
                }),
          A(t)
        );
      }
      function T(t, e, r) {
        return (
          (e = (function (t) {
            var e = (function (t) {
              if ("object" != A(t) || !t) return t;
              var e = t[Symbol.toPrimitive];
              if (void 0 !== e) {
                var r = e.call(t, "string");
                if ("object" != A(r)) return r;
                throw new TypeError(
                  "@@toPrimitive must return a primitive value.",
                );
              }
              return String(t);
            })(t);
            return "symbol" == A(e) ? e : e + "";
          })(e)) in t
            ? Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              })
            : (t[e] = r),
          t
        );
      }
      var P = function () {
        return "".concat(
          (function () {
            var t,
              e =
                null !== (t = window.tdlSsoAuthScriptSrc) && void 0 !== t
                  ? t
                  : "",
              r = "d";
            return (
              e.includes("sit-account")
                ? (r = "s")
                : e.includes("pt") || e.includes("sit-r2-account")
                  ? (r = "pp")
                  : e.includes("accounts") || e.includes("members")
                    ? (r = "")
                    : e.includes("bf") && (r = "bf"),
              "https://".concat(r, "api.tatadigital.com")
            );
          })(),
          "/analytics-engine",
        );
      };
      function w(t, e) {
        var r = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(t);
          (e &&
            (n = n.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            r.push.apply(r, n));
        }
        return r;
      }
      function g(t) {
        for (var e = 1; e < arguments.length; e++) {
          var r = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? w(Object(r), !0).forEach(function (e) {
                T(t, e, r[e]);
              })
            : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
              : w(Object(r)).forEach(function (e) {
                  Object.defineProperty(
                    t,
                    e,
                    Object.getOwnPropertyDescriptor(r, e),
                  );
                });
        }
        return t;
      }
      var I = function () {
          var t;
          return null !== (t = window.tdplAnalyticsEndpoint) && void 0 !== t
            ? t
            : "".concat(P(), "/events/v1");
        },
        E = function () {
          var t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "TCP-WEB-APP",
            e = localStorage.getItem("tdl-sso-analytics-v2");
          if (!e) {
            var r = I();
            return (
              (e = g(g(g({}, v), m[t]), {}, { dataPublishEndpoint: r })),
              localStorage.setItem("tdl-sso-analytics-v2", JSON.stringify(e)),
              void (window.tdplConfig = e)
            );
          }
          window.tdplConfig = JSON.parse(e);
        };
      function S() {
        var t;
        return (
          window.tdplConfig || E(),
          null !== (t = window.tdplConfig) && void 0 !== t ? t : {}
        );
      }
      var b,
        L = function () {
          window.tdplAnalyticsEndpoint = I();
        },
        O = ["TATADIGITAL", "FS"],
        C = function () {
          var t,
            e,
            r,
            n = {
              "finbox.in": "FS-BNPL-FINBOX-WEB-APP",
              "bigbasket.com": "BIGBASKET-WEB-MOBILE-APP",
              "tatadigital.com": "TCP-WEB-APP",
              "tataneu.com": "TCP-WEB-APP",
              "tataneu.in": "TCP-WEB-APP",
              "tataneupolicy.com": "NEUPOLICY-WEB-APP",
              "superapp.inspektlabs.com": "INSPEKTLABS-WEB-APP",
              "cult.fit": "CULTFIT-WEB-APP",
              "cultsport.com": "CULTFIT-WEB-APP",
              "tatacliq.com": "TATACLIQ-WEB-APP",
              "tataunistore.com": "TATACLIQ-WEB-APP",
              qmin: "QMIN-WEB-APP",
              "luxury.tatacliq": "TATACLIQ-LUXURY-WEB-APP",
              "luxpreprod1.tataunistore": "TATACLIQ-LUXURY-WEB-APP",
              "1mg.com": "ONEMG-WEB-APP",
              "croma.com": "CROMA-WEB-APP",
              "tajhotels.com": "IHCL-WEB-APP",
              "amastaysandtrails.com": "IHCL-AMA-WEB-APP",
              "vivantahotels.com": "IHCL-VIVANTA-WEB-APP",
              "seleqtionshotels.com": "IHCL-SELEQTIONS-WEB-APP",
              "taj-dev65-02.adobecqms.net": "IHCL-WEB-APP",
              "taj-stage65-1.adobecqms.net": "IHCL-WEB-APP",
              airindiaexpress: "AIRASIA-WEB-APP",
              westside: "WESTSIDE-WEB-APP",
              tatamotor: "TATAMOTORS-WEB-APP",
              "qe-fastrack": "TITAN-FASTRACK-WEB-APP",
              titaneyeplus: "TITAN-EYEPLUS-WEB-APP",
              taneira: "TITAN-TANEIRA-WEB-APP",
              traqgear: "TITAN-TRAQ-WEB-APP",
              zoya: "TITAN-ZOYA-WEB-APP",
              sonatawatches: "TITAN-SONATA-WEB-APP",
              fastrack: "TITAN-FASTRACK-WATCH-WEB-APP",
              skinn: "TITAN-SKINN-WEB-APP",
              miabytanishq: "TITAN-MIA-WEB-APP",
              "tanishq.co.in": "TITAN-TANISHQ-WEB-APP",
              capitalfloat: "AXIO-CAPITALFLOAT-WEB-APP",
              titan: "TITAN-WATCH-WEB-APP",
              gingerhotels: "IHCL-GINGER-WEB-APP",
              simplotel: "IHCL-GINGER-WEB-APP",
              magicpin: "MAGICPIN-WEB-APP",
            },
            a = {
              "clientId=IHCL-WEB-APP": "IHCL-WEB-APP",
              "clientId=GINGER-WEB-APP": "IHCL-GINGER-WEB-APP",
            },
            o = window.location,
            i = o.origin,
            s = o.href,
            c = Object.keys(n).find(function (t) {
              return i.includes(t);
            });
          return (
            c ||
              (r = Object.keys(a).find(function (t) {
                return s.includes(t);
              })),
            c ? (e = n[c]) : r && (e = a[r]),
            {
              brand: (b =
                null !==
                  (t = {
                    "TCP-WEB-APP": "TATADIGITAL",
                    "BIGBASKET-WEB-DESKTOP-APP": "BIGBASKET",
                    "BIGBASKET-WEB-MOBILE-APP": "BIGBASKET",
                    "ONEMG-WEB-APP": "ONEMG",
                    "TATACLIQ-WEB-APP": "TATACLIQ",
                    "TATACLIQ-LUXURY-WEB-APP": "TATACLIQ-LUXURY",
                    "CULTFIT-WEB-APP": "CULTFIT",
                    "CROMA-WEB-APP": "CROMA",
                    "AIRASIA-WEB-APP": "AIRASIA",
                    "IHCL-AMA-WEB-APP": "IHCL",
                    "IHCL-SELEQTIONS-WEB-APP": "IHCL",
                    "IHCL-VIVANTA-WEB-APP": "IHCL",
                    "IHCL-WEB-APP": "IHCL",
                    "IHCL-GINGER-WEB-APP": "IHCL",
                    "QMIN-WEB-APP": "QMIN",
                    "WESTSIDE-WEB-APP": "WESTSIDE",
                    "TATAMOTORS-WEB-APP": "TATAMOTORS",
                    "TITAN-FASTRACK-WEB-APP": "FASTRACK-EYEWEAR",
                    "TITAN-EYEPLUS-WEB-APP": "EYEPLUS",
                    "TITAN-TANEIRA-WEB-APP": "TANEIRA",
                    "TITAN-TRAQ-WEB-APP": "TRAQ",
                    "TITAN-ZOYA-WEB-APP": "ZOYA",
                    "TITAN-SONATA-WEB-APP": "SONATA",
                    "TITAN-FASTRACK-WATCH-WEB-APP": "FASTRACK-WATCH",
                    "TITAN-SKINN-WEB-APP": "SKINN",
                    "TITAN-MIA-WEB-APP": "MIA",
                    "TITAN-TANISHQ-WEB-APP": "TANISHQ",
                    "TITAN-IRTH-WEB-APP": "IRTH",
                    "TITAN-WATCH-WEB-APP": "TITAN",
                    "AXIO-CAPITALFLOAT-WEB-APP": "CAPITALFLOAT",
                    "FS-BNPL-FINBOX-WEB-APP": "FS",
                    "MAGICPIN-WEB-APP": "MAGICPIN",
                    "NEUPOLICY-WEB-APP": "NEUPOLICY",
                  }[(e = null != e ? e : "DEFAULT")]) && void 0 !== t
                  ? t
                  : "DEFAULT"),
              clientId: e,
            }
          );
        },
        N = function () {
          var t;
          return null ===
            (t = document.head.querySelector("meta[name=tdl-sso-client_id]")) ||
            void 0 === t
            ? void 0
            : t.content;
        },
        k = function () {
          var t,
            e,
            r =
              null !== (t = N()) && void 0 !== t
                ? t
                : null === (e = window.tdplConfig) || void 0 === e
                  ? void 0
                  : e.clientId;
          return ((r && "CLIENT-ID" !== r) || (r = C().clientId), r);
        };
      function W() {
        var t, e, r;
        return null !==
          (t =
            null !==
              (e = {
                "TCP-WEB-APP": "TATADIGITAL",
                "BIGBASKET-WEB-DESKTOP-APP": "BIGBASKET",
                "BIGBASKET-WEB-MOBILE-APP": "BIGBASKET",
                "ONEMG-WEB-APP": "ONEMG",
                "TATACLIQ-WEB-APP": "TATACLIQ",
                "TATACLIQ-LUXURY-WEB-APP": "TATACLIQ-LUXURY",
                "CULTFIT-WEB-APP": "CULTFIT",
                "CROMA-WEB-APP": "CROMA",
                "AIRASIA-WEB-APP": "AIRASIA",
                "IHCL-AMA-WEB-APP": "IHCL",
                "IHCL-SELEQTIONS-WEB-APP": "IHCL",
                "IHCL-VIVANTA-WEB-APP": "IHCL",
                "IHCL-WEB-APP": "IHCL",
                "IHCL-GINGER-WEB-APP": "IHCL",
                "QMIN-WEB-APP": "QMIN",
                "WESTSIDE-WEB-APP": "WESTSIDE",
                "TATAMOTORS-WEB-APP": "TATAMOTORS",
                "TITAN-FASTRACK-WEB-APP": "FASTRACK-EYEWEAR",
                "TITAN-EYEPLUS-WEB-APP": "EYEPLUS",
                "TITAN-TANEIRA-WEB-APP": "TANEIRA",
                "TITAN-TRAQ-WEB-APP": "TRAQ",
                "TITAN-ZOYA-WEB-APP": "ZOYA",
                "TITAN-SONATA-WEB-APP": "SONATA",
                "TITAN-FASTRACK-WATCH-WEB-APP": "FASTRACK-WATCH",
                "TITAN-SKINN-WEB-APP": "SKINN",
                "TITAN-MIA-WEB-APP": "MIA",
                "TITAN-TANISHQ-WEB-APP": "TANISHQ",
                "TITAN-IRTH-WEB-APP": "IRTH",
                "TITAN-WATCH-WEB-APP": "TITAN",
                "AXIO-CAPITALFLOAT-WEB-APP": "CAPITALFLOAT",
                "FS-BNPL-FINBOX-WEB-APP": "FS",
                "MAGICPIN-WEB-APP": "MAGICPIN",
                "NEUPOLICY-WEB-APP": "NEUPOLICY",
              }[N()]) && void 0 !== e
              ? e
              : null === (r = window.tdplConfig) || void 0 === r
                ? void 0
                : r.brand) && void 0 !== t
          ? t
          : C().brand;
      }
      var B = function (t) {
          if (!t) return null;
          for (
            var e = [], r = 0;
            r < t.length && "body" !== t[r].localName;
            r += 1
          )
            e.push({
              elementType: t[r].localName,
              id: t[r].id,
              class: t[r].className,
            });
          return e;
        },
        R = function () {
          var t = S().htmlPageScriptTagKeywords;
          if (!t) return [];
          var e = [];
          try {
            var r = Object.keys(t).find(function (t) {
              return window.location.href.includes(t);
            });
            if (!r) return [];
            var n = t[r];
            e = Array.from(document.scripts)
              .filter(function (t) {
                return t.innerHTML.includes(n);
              })
              .map(function (t) {
                return null == t ? void 0 : t.innerHTML;
              });
          } catch (t) {
            return e;
          }
          return e;
        };
      function D() {
        b || (b = W());
        var t = JSON.parse(localStorage.getItem("tdl-sso-redirect-tcp-flag"));
        return null != t && t.isRedirectedFromTCP && null != t && t.setAt
          ? (Date.now() - t.setAt < 1e3 * S().redirectedFromTCPFlagExpiresInS ||
              ((t.isRedirectedFromTCP = !1),
              sessionStorage.setItem("isRedirectedFromTCP", "false"),
              localStorage.setItem(
                "tdl-sso-redirect-tcp-flag",
                JSON.stringify(t),
              )),
            t.isRedirectedFromTCP)
          : !(null == t || !t.isRedirectedFromTCP || !O.includes(b));
      }
      function _(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var r = 0, n = Array(e); r < e; r++) n[r] = t[r];
        return n;
      }
      function x(t, e) {
        if (t) {
          if ("string" == typeof t) return _(t, e);
          var r = {}.toString.call(t).slice(8, -1);
          return (
            "Object" === r && t.constructor && (r = t.constructor.name),
            "Map" === r || "Set" === r
              ? Array.from(t)
              : "Arguments" === r ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                ? _(t, e)
                : void 0
          );
        }
      }
      function H(t, e) {
        return (
          (function (t) {
            if (Array.isArray(t)) return t;
          })(t) ||
          (function (t, e) {
            var r =
              null == t
                ? null
                : ("undefined" != typeof Symbol && t[Symbol.iterator]) ||
                  t["@@iterator"];
            if (null != r) {
              var n,
                a,
                o,
                i,
                s = [],
                c = !0,
                d = !1;
              try {
                if (((o = (r = r.call(t)).next), 0 === e)) {
                  if (Object(r) !== r) return;
                  c = !1;
                } else
                  for (
                    ;
                    !(c = (n = o.call(r)).done) &&
                    (s.push(n.value), s.length !== e);
                    c = !0
                  );
              } catch (t) {
                ((d = !0), (a = t));
              } finally {
                try {
                  if (
                    !c &&
                    null != r.return &&
                    ((i = r.return()), Object(i) !== i)
                  )
                    return;
                } finally {
                  if (d) throw a;
                }
              }
              return s;
            }
          })(t, e) ||
          x(t, e) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
            );
          })()
        );
      }
      function j(t) {
        return (
          (function (t) {
            if (Array.isArray(t)) return _(t);
          })(t) ||
          (function (t) {
            if (
              ("undefined" != typeof Symbol && null != t[Symbol.iterator]) ||
              null != t["@@iterator"]
            )
              return Array.from(t);
          })(t) ||
          x(t) ||
          (function () {
            throw new TypeError(
              "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
            );
          })()
        );
      }
      function q(t) {
        return (
          !t.includes("/analytics-engine/") &&
          S().urls.find(function (e) {
            return t.toLowerCase().includes(e.toLowerCase());
          })
        );
      }
      function M(t) {
        return S().syncTrackingUrls.find(function (e) {
          return t.toLowerCase().includes(e.toLowerCase());
        });
      }
      function U() {
        var t, e;
        (null !== (e = window.tdlSsoAuthScriptSrc) &&
          void 0 !== e &&
          e.includes("accounts")) ||
          (t = console).log.apply(t, arguments);
      }
      var G = function (t, e) {
          if (t) {
            var r = e;
            "string" != typeof e && (r = JSON.stringify(e));
            try {
              localStorage.setItem(t, r);
            } catch (t) {
              U("TDPL-SSO: localStorage may be full.");
            }
          } else U("TDPL-SSO: can't set in local storage: key missing");
        },
        F = function (t) {
          var e,
            r =
              null ===
                (e = document.cookie.split("; ").find(function (e) {
                  return e.startsWith("".concat(t, "="));
                })) || void 0 === e
                ? void 0
                : e.split("=")[1];
          return null != r ? r : "";
        };
      function J(t, e) {
        switch (t) {
          case "local":
            try {
              var r;
              return JSON.parse(
                null !== (r = localStorage.getItem(e)) && void 0 !== r ? r : "",
              );
            } catch (t) {
              return {};
            }
          case "session":
            try {
              var n;
              return JSON.parse(
                null !== (n = sessionStorage.getItem(e)) && void 0 !== n
                  ? n
                  : "",
              );
            } catch (t) {
              return {};
            }
          default:
            return {};
        }
      }
      var V,
        K = function (t) {
          localStorage.setItem(
            "tdl-sso-c-hash",
            JSON.stringify({
              value: t,
              expires:
                Date.now() +
                (S().customerHashValidityInS
                  ? 1e3 * S().customerHashValidityInS
                  : 864e5),
            }),
          );
        },
        Q = function () {
          var t,
            e,
            r,
            n,
            a,
            o,
            i,
            s,
            c,
            d = "";
          try {
            switch (W()) {
              case "CROMA":
                d = localStorage.getItem("customer_hash");
                break;
              case "TATADIGITAL":
                if (
                  !(d =
                    F("_CHSH_") ||
                    localStorage.getItem("customer_hash") ||
                    (null === (t = J("local", "microsegment")) || void 0 === t
                      ? void 0
                      : t.customerHash))
                )
                  try {
                    var u = window.CryptoJS;
                    u &&
                      (d = H(
                        u.AES.decrypt(
                          localStorage.getItem("__ENCY__"),
                          "tdl-encrypt",
                        )
                          .toString(u.enc.Utf8)
                          .split("|"),
                        2,
                      )[1]);
                  } catch (t) {}
                break;
              case "ONEMG":
                d =
                  localStorage.getItem("tata_customer_hash") ||
                  F("tata_customer_hash");
                break;
              case "CULTFIT":
                d =
                  null === (e = J("local", "user")) || void 0 === e
                    ? void 0
                    : e.userId;
                break;
              case "AIRASIA":
                d = sessionStorage.getItem("customerhash");
                break;
              case "WESTSIDE":
              default:
                d = localStorage.getItem("customerHash");
                break;
              case "BIGBASKET":
                d =
                  sessionStorage.getItem("customerHash") || F("customer_hash");
                break;
              case "IHCL":
                d =
                  localStorage.getItem("customerHash") ||
                  (null === (r = J("local", "user")) || void 0 === r
                    ? void 0
                    : r.customerHash);
                break;
              case "QMIN":
                d =
                  (null === (n = J("local", "__QWEMNB__")) || void 0 === n
                    ? void 0
                    : n.customer_hash) ||
                  (null === (a = J("local", "__POIZXC__")) || void 0 === a
                    ? void 0
                    : a.customer_hash);
                break;
              case "TATACLIQ":
              case "TATACLIQ-LUXURY":
                d =
                  localStorage.getItem("customerHash") ||
                  localStorage.getItem("customerHashTD") ||
                  (null === (o = J("local", "customerDetailsTd")) ||
                  void 0 === o
                    ? void 0
                    : o.customerHash) ||
                  (function () {
                    var t,
                      e = "",
                      r = F("ssoAccessToken");
                    if (
                      (r &&
                        (e =
                          null === (t = JSON.parse(r)) ||
                          void 0 === t ||
                          null === (t = t.idToken) ||
                          void 0 === t
                            ? void 0
                            : t.customerHash),
                      !e)
                    ) {
                      var n,
                        a = F("customerAccessTokenTD");
                      a &&
                        (e =
                          null === (n = JSON.parse(a)) ||
                          void 0 === n ||
                          null === (n = n.idToken) ||
                          void 0 === n
                            ? void 0
                            : n.customerHash);
                    }
                    if (!e) {
                      var o,
                        i = F("ssoUserDetails");
                      i &&
                        (e =
                          null === (o = JSON.parse(i)) || void 0 === o
                            ? void 0
                            : o.customerHash);
                    }
                    return e;
                  })();
                break;
              case "TANEIRA":
              case "TRAQ":
              case "ZOYA":
              case "SONATA":
              case "TITAN":
              case "FASTRACK-EYEWEAR":
              case "FASTRACK-WATCH":
              case "SKINN":
              case "MIA":
              case "EYEPLUS":
              case "TANISHQ":
                d =
                  (null === (i = J("local", "user")) || void 0 === i
                    ? void 0
                    : i.customerHash) || F("customerHash");
                break;
              case "FS":
                d =
                  null === (s = J("local", "FinBox-client-user")) ||
                  void 0 === s
                    ? void 0
                    : s.uniqueID;
                break;
              case "MAGICPIN":
                d =
                  (null === (c = J("local", "user_details")) || void 0 === c
                    ? void 0
                    : c.clientUserId) || F("client_customer_id");
            }
          } catch (t) {
            U(t);
          }
          return "string" == typeof d && d.length > 0
            ? (K(d), d)
            : (function () {
                if (
                  (function () {
                    var t = localStorage.getItem("tdl-sso-c-hash");
                    if (!t) return !1;
                    try {
                      var e;
                      return (
                        (null !== (e = JSON.parse(t)) && void 0 !== e ? e : {})
                          .expires > Date.now() ||
                        (localStorage.removeItem("tdl-sso-c-hash"), !1)
                      );
                    } catch (e) {
                      return (
                        U(
                          "TDPL-SSO: fetching customer hash from local storage failed with",
                          e,
                        ),
                        K(t),
                        !0
                      );
                    }
                  })()
                ) {
                  var t,
                    e =
                      null === (t = J("local", "tdl-sso-c-hash")) ||
                      void 0 === t
                        ? void 0
                        : t.value;
                  if ("string" == typeof e) return e;
                }
                return "";
              })();
        },
        Y = new TextEncoder(),
        X = function (t) {
          var e = t.target,
            r = void 0 === e ? {} : e,
            n = t.type,
            a = void 0 === n ? "" : n,
            o = t.composedPath,
            i = void 0 === o ? [] : o,
            s = {
              url: window.location,
              path: B(i),
              target: r.outerHTML,
              timeStamp: Date.now(),
              type: a,
            };
          return JSON.stringify(s, null, 2);
        },
        Z = function (t, e) {
          return {
            "Content-Type": "application/json",
            "customer-hash": t,
            client_id: k(),
            session: e,
            "tdl-sso-version": localStorage.getItem("tdl-sso-version"),
          };
        },
        z = function (t, e, r) {
          return fetch(
            I() || "https://ppapi.tatadigital.com/analytics-engine/events/v1",
            { method: "POST", body: t, headers: Z(e, r) },
          );
        },
        $ = function (t) {
          var e =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : "TCP-WEB-APP";
          return fetch(t, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              "Client-Id": e,
              client_id: e,
              "Site-Origin": window.location.origin,
            },
          });
        },
        tt = function (t) {
          return navigator.sendBeacon(
            I() || "https://ppapi.tatadigital.com/analytics-engine/events/v1",
            t,
          );
        },
        et = new Uint8Array(16);
      function rt() {
        if (
          !V &&
          !(V =
            ("undefined" != typeof crypto &&
              crypto.getRandomValues &&
              crypto.getRandomValues.bind(crypto)) ||
            ("undefined" != typeof msCrypto &&
              "function" == typeof msCrypto.getRandomValues &&
              msCrypto.getRandomValues.bind(msCrypto)))
        )
          throw new Error(
            "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported",
          );
        return V(et);
      }
      const nt =
        /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
      for (var at = [], ot = 0; ot < 256; ++ot)
        at.push((ot + 256).toString(16).substr(1));
      const it = function (t) {
          var e =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : 0,
            r = (
              at[t[e + 0]] +
              at[t[e + 1]] +
              at[t[e + 2]] +
              at[t[e + 3]] +
              "-" +
              at[t[e + 4]] +
              at[t[e + 5]] +
              "-" +
              at[t[e + 6]] +
              at[t[e + 7]] +
              "-" +
              at[t[e + 8]] +
              at[t[e + 9]] +
              "-" +
              at[t[e + 10]] +
              at[t[e + 11]] +
              at[t[e + 12]] +
              at[t[e + 13]] +
              at[t[e + 14]] +
              at[t[e + 15]]
            ).toLowerCase();
          if (
            !(function (t) {
              return "string" == typeof t && nt.test(t);
            })(r)
          )
            throw TypeError("Stringified UUID is invalid");
          return r;
        },
        st = function (t, e, r) {
          var n = (t = t || {}).random || (t.rng || rt)();
          if (((n[6] = (15 & n[6]) | 64), (n[8] = (63 & n[8]) | 128), e)) {
            r = r || 0;
            for (var a = 0; a < 16; ++a) e[r + a] = n[a];
            return e;
          }
          return it(n);
        };
      var ct = function () {
          var t = localStorage.getItem("tdl-sso-user-id"),
            e = localStorage.getItem("anonymousId");
          return (
            t
              ? t && e !== t && G("anonymousId", t)
              : ((t = st()), G("tdl-sso-user-id", t), G("anonymousId", t)),
            t
          );
        },
        dt = function (t) {
          t ? (G("tdl-sso-user-id", t), G("anonymousId", t)) : ct();
        },
        ut = function () {
          var t = JSON.parse(localStorage.getItem("tdl-sso-session-id"));
          if (
            t &&
            t.sessionId &&
            (Date.now() - t.setAt) / 1e3 < S().sessionIdExpiresInS
          )
            return t.sessionId;
          var e = st();
          return (
            G(
              "tdl-sso-session-id",
              JSON.stringify({ sessionId: e, setAt: Date.now() }),
            ),
            e
          );
        },
        lt = function (t) {
          t
            ? G(
                "tdl-sso-session-id",
                JSON.stringify({ sessionId: t, setAt: Date.now() }),
              )
            : ut();
        },
        pt = function () {
          var t;
          (t = JSON.parse(localStorage.getItem("tdl-sso-redirect-tcp-flag"))) &&
            Date.now() - t.setAt < 1e3 * S().redirectedFromTCPFlagExpiresInS &&
            (sessionStorage.getItem("isRedirectedFromTCP") !==
              t.isRedirectedFromTCP &&
              sessionStorage.setItem(
                "isRedirectedFromTCP",
                t.isRedirectedFromTCP,
              ),
            (t.setAt = Date.now()),
            G("tdl-sso-redirect-tcp-flag", JSON.stringify(t)));
          var e = JSON.parse(localStorage.getItem("tdl-sso-session-id"));
          e
            ? Date.now() - e.setAt < 1e3 * S().sessionIdExpiresInS &&
              ((e.setAt = Date.now()),
              G("tdl-sso-session-id", JSON.stringify(e)))
            : (function () {
                var t = { sessionId: st(), setAt: Date.now() };
                G("tdl-sso-session-id", JSON.stringify(t));
              })();
        },
        ft = function () {
          return "".concat(ut(), ".").concat(ct());
        },
        yt = function () {
          return window.tdplJarvisId || F("jarvis-id");
        };
      function ht(t, e) {
        var r = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(t);
          (e &&
            (n = n.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            r.push.apply(r, n));
        }
        return r;
      }
      function vt(t) {
        for (var e = 1; e < arguments.length; e++) {
          var r = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? ht(Object(r), !0).forEach(function (e) {
                T(t, e, r[e]);
              })
            : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
              : ht(Object(r)).forEach(function (e) {
                  Object.defineProperty(
                    t,
                    e,
                    Object.getOwnPropertyDescriptor(r, e),
                  );
                });
        }
        return t;
      }
      var mt = new Set(["TATADIGITAL", "NEUPOLICY"]),
        At = ["TATADIGITAL", "FS"],
        Tt = {
          bufferData: [],
          pushEvent: function (t) {
            (this.bufferData.push({ timestamp: Date.now(), data: t }),
              (new Blob(this.bufferData).size > S().bufferSizeInKb ||
                this.bufferData.length >= S().bufferArrayLength) &&
                this.sendAnalyticsData());
          },
          sendAnalyticsData: function () {
            var t = this;
            return e(
              a().mark(function e() {
                var r;
                return a().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          (t.restartBufferTimer(), 0 !== t.bufferData.length)
                        ) {
                          e.next = 3;
                          break;
                        }
                        return e.abrupt("return");
                      case 3:
                        ((r = j(t.bufferData)),
                          (t.bufferData = []),
                          t.fireAnalyticsEvent(r, !0));
                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
              }),
            )();
          },
          constructPayload: function (t) {
            var e,
              r,
              n,
              a = W(),
              o = !!At.includes(a) || D(),
              i = window.location.href,
              s = Q(),
              c = JSON.stringify(
                vt(
                  vt(
                    {
                      isRedirectedFromTCP: o,
                      url: i,
                      eventData: t,
                      customerHash: s,
                      ecid:
                        ((n =
                          null !==
                            (r = JSON.parse(
                              localStorage.getItem(
                                "com.adobe.reactor.dataElements.ECID",
                              ),
                            )) && void 0 !== r
                            ? r
                            : JSON.parse(
                                sessionStorage.getItem(
                                  "com.adobe.reactor.dataElements.ECID",
                                ),
                              )),
                        null != n ? n : "Unknown"),
                      clientId: k(),
                      sessionId: ft(),
                      brand: a,
                      timestamp: Date.now(),
                      device: window.navigator.userAgent,
                      jarvisId: yt(),
                      advertisingId: localStorage.getItem("tdl-sso-ad-id"),
                      appVersion:
                        null ===
                          (e = JSON.parse(
                            localStorage.getItem("tneu.deviceInfo"),
                          )) || void 0 === e
                          ? void 0
                          : e.deviceVersion,
                    },
                    "ONEMG" === a
                      ? { city: F("city"), pincode: F("pincode") }
                      : {},
                  ),
                  mt.has(a) ? { fbc: F("_fbc"), fbp: F("_fbp") } : {},
                ),
              );
            return (
              localStorage.getItem("tdl-analytics-tester") ||
                (c = (function (t) {
                  try {
                    var e = "";
                    try {
                      e = window.btoa(t);
                    } catch (a) {
                      var r = Y.encode(t),
                        n = Array.from(r, function (t) {
                          return String.fromCodePoint(t);
                        }).join("");
                      e = window.btoa(n);
                    }
                    return '{"secure": "true", "ePayload": "'.concat(e, '"}');
                  } catch (e) {
                    return (U("Encoding payload failed with", e), t);
                  }
                })(c)),
              [c, s, o]
            );
          },
          fireAnalyticsEvent: function (t) {
            var r = arguments,
              n = this;
            return e(
              a().mark(function e() {
                var o, i, s, c, d, u, l, p;
                return a().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((i = r.length > 1 && void 0 !== r[1] && r[1]),
                            (s = n.constructPayload(t)),
                            (c = H(s, 3)),
                            (d = c[0]),
                            (u = c[1]),
                            (l = c[2]),
                            !i ||
                              null === (o = window.navigator) ||
                              void 0 === o ||
                              !o.sendBeacon)
                          ) {
                            e.next = 7;
                            break;
                          }
                          if (!tt(d)) {
                            e.next = 6;
                            break;
                          }
                          return e.abrupt("return", !0);
                        case 6:
                          U("(sendBeacon) Browser could not queue the data.");
                        case 7:
                          return ((e.prev = 7), (e.next = 10), z(d, u, l));
                        case 10:
                          ((p = e.sent), (e.next = 16));
                          break;
                        case 13:
                          ((e.prev = 13),
                            (e.t0 = e.catch(7)),
                            U("TDPL-SSO: POST request failed with", e.t0));
                        case 16:
                          return e.abrupt("return", p);
                        case 17:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[7, 13]],
                );
              }),
            )();
          },
          restartBufferTimer: function () {
            var t,
              e = this;
            (this.analyticsTimeout && clearTimeout(this.analyticsTimeout),
              (this.analyticsTimeout = setTimeout(
                function () {
                  return e.sendAnalyticsData();
                },
                null !== (t = 1e3 * S().bufferIntervalInSeconds) && void 0 !== t
                  ? t
                  : 3e4,
              )));
          },
        },
        Pt = function (t, e) {
          var r = new URL(null == t ? void 0 : t.href);
          r.origin !== window.location.origin &&
            (r.searchParams.append("sessionId", e.sessionId),
            r.searchParams.append("jarvisId", e.jarvisId),
            e.source && r.searchParams.append("utm_source", e.source),
            (t.href = r.href));
        },
        wt = function () {
          var t,
            r = document.querySelectorAll("a"),
            n = {
              sessionId: ft(),
              jarvisId: yt(),
              source:
                null !==
                  (t = JSON.parse(
                    localStorage.getItem("tdl-sso-redirect-tcp-flag"),
                  )) &&
                void 0 !== t &&
                t.isRedirectedFromTCP
                  ? "tcp"
                  : "",
            };
          r.forEach(
            (function () {
              var t = e(
                a().mark(function t(e) {
                  var r;
                  return a().wrap(function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            null !== (r = e.href) &&
                            void 0 !== r &&
                            r.startsWith("https")
                          )
                            try {
                              Pt(e, n);
                            } catch (t) {
                              U(
                                "TDPL-SSO: adding analytics params to the href failed with",
                                t,
                              );
                            }
                        case 1:
                        case "end":
                          return t.stop();
                      }
                  }, t);
                }),
              );
              return function (e) {
                return t.apply(this, arguments);
              };
            })(),
          );
        },
        gt = function (t) {
          Tt.fireAnalyticsEvent([
            {
              timestamp: Date.now(),
              data: JSON.stringify({ event: "pageLoad", payload: t }),
            },
          ]);
        },
        It = function (t) {
          var e,
            r =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {};
          pt();
          var n,
            a = {
              url: window.location.href,
              dataSource: t,
              isTrusted: r.isTrusted,
            };
          ("IHCL" === W() &&
            (window.location.href.includes("booking-cart") ||
              window.location.href.includes("booking-confirmation")) &&
            window.location.href.includes("status") &&
            (e = JSON.stringify(
              null === (n = JSON.parse(sessionStorage.getItem("tajData"))) ||
                void 0 === n
                ? void 0
                : n.bookingDetailsRequest,
            )) &&
            (a.tajData = e),
            R().length > 0 && (a.htmlContentScriptData = JSON.stringify(R())),
            gt(a));
          try {
            S().addAnalyticsParamsToHref && setTimeout(wt, 0);
          } catch (t) {
            U("TDPL-SSO: adding analytics params to the hrefs failed with", t);
          }
        };
      function Et(t, e) {
        var r = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(t);
          (e &&
            (n = n.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            r.push.apply(r, n));
        }
        return r;
      }
      function St(t) {
        for (var e = 1; e < arguments.length; e++) {
          var r = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? Et(Object(r), !0).forEach(function (e) {
                T(t, e, r[e]);
              })
            : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
              : Et(Object(r)).forEach(function (e) {
                  Object.defineProperty(
                    t,
                    e,
                    Object.getOwnPropertyDescriptor(r, e),
                  );
                });
        }
        return t;
      }
      var bt = function (t) {
          var e,
            r = S().cartAndWishListConfig;
          return (
            !!r &&
            null !==
              (e =
                r[
                  Object.keys(r).find(function (e) {
                    return t.includes(e);
                  })
                ]) &&
            void 0 !== e &&
            e
          );
        },
        Lt = function (t) {
          var e,
            r = S().cartOrWishListStateGtmEvents;
          return (
            !!r &&
            null !==
              (e =
                r[
                  Object.keys(r).find(function (e) {
                    return t.includes(e);
                  })
                ]) &&
            void 0 !== e &&
            e
          );
        },
        Ot = function (t, e) {
          if (!e || !e.length) return "";
          for (
            var r,
              n = t,
              a = function (t) {
                if (!n) return { v: "" };
                var r,
                  a = e[t];
                ("_processArray_" === a
                  ? ((n =
                      null === (r = n) || void 0 === r
                        ? void 0
                        : r.map(function (r) {
                            return r[e[t + 1]];
                          })),
                    (t += 1))
                  : (n = "_flattenArray_" === a ? n.flat() : n[a]),
                  (o = t));
              },
              o = 0;
            o < e.length;
            o += 1
          )
            if ((r = a(o))) return r.v;
          return n;
        },
        Ct = (function () {
          var t = e(
            a().mark(function t(e, r) {
              var n, o, i;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (
                        (o = Ot(e, r.products)),
                        (i =
                          null == o || null === (n = o.map) || void 0 === n
                            ? void 0
                            : n.call(o, function (t) {
                                var e,
                                  n,
                                  a = {};
                                return (
                                  null ===
                                    (e = Object.entries(r.keysToCapture)) ||
                                    void 0 === e ||
                                    null === (n = e.forEach) ||
                                    void 0 === n ||
                                    n.call(e, function (e) {
                                      var r = H(e, 2),
                                        n = r[0],
                                        o = r[1];
                                      a[n] = Ot(t, o);
                                    }),
                                  a
                                );
                              })),
                        t.abrupt("return", i)
                      );
                    case 3:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          );
          return function (e, r) {
            return t.apply(this, arguments);
          };
        })(),
        Nt = (function () {
          var t = e(
            a().mark(function t(e) {
              var r, n;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (
                        (n = {}),
                        null == e ||
                          null === (r = e.forEach) ||
                          void 0 === r ||
                          r.call(e, function (t) {
                            var e = 1;
                            (t.quantity && (e = parseInt(t.quantity, 10)),
                              n[t.productId]
                                ? (n[t.productId].quantity += e)
                                : (n[t.productId] = St(
                                    St({}, t),
                                    {},
                                    { quantity: e },
                                  )));
                          }),
                        t.abrupt("return", n)
                      );
                    case 3:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })(),
        kt = (function () {
          var t = e(
            a().mark(function t(e, r) {
              var n, o, i, s, c, d;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (
                        (c = []),
                        (d = []),
                        null === (n = Object.entries(e)) ||
                          void 0 === n ||
                          null === (o = n.forEach) ||
                          void 0 === o ||
                          o.call(n, function (t) {
                            var n = H(t, 2),
                              a = n[0],
                              o = n[1];
                            if (r[a]) {
                              var i = r[a].quantity,
                                s = e[a].quantity - i;
                              s > 0
                                ? c.push(St(St({}, o), {}, { quantity: s }))
                                : s < 0 &&
                                  d.push(
                                    St(
                                      St({}, o),
                                      {},
                                      { quantity: Math.abs(s) },
                                    ),
                                  );
                            } else c.push(o);
                          }),
                        null === (i = Object.entries(r)) ||
                          void 0 === i ||
                          null === (s = i.forEach) ||
                          void 0 === s ||
                          s.call(i, function (t) {
                            var r = H(t, 2),
                              n = r[0],
                              a = r[1];
                            e[n] || d.push(a);
                          }),
                        t.abrupt("return", {
                          productsAdded: c,
                          productsRemoved: d,
                        })
                      );
                    case 5:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          );
          return function (e, r) {
            return t.apply(this, arguments);
          };
        })(),
        Wt = (function () {
          var t = e(
            a().mark(function t() {
              var e, r, n, o, i;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      if (
                        !(e = JSON.parse(
                          localStorage.getItem("tdl-sso-cart-wishlist"),
                        ))
                      ) {
                        t.next = 13;
                        break;
                      }
                      if (null === (r = e.cart) || void 0 === r || !r.length) {
                        t.next = 7;
                        break;
                      }
                      return ((t.next = 5), Nt(e.cart));
                    case 5:
                      ((o = t.sent),
                        localStorage.setItem(
                          "tdl-sso-cart-state",
                          JSON.stringify(o),
                        ));
                    case 7:
                      if (
                        null === (n = e.wishlist) ||
                        void 0 === n ||
                        !n.length
                      ) {
                        t.next = 12;
                        break;
                      }
                      return ((t.next = 10), Nt(e.wishlist));
                    case 10:
                      ((i = t.sent),
                        localStorage.setItem(
                          "tdl-sso-wishlist-state",
                          JSON.stringify(i),
                        ));
                    case 12:
                      localStorage.removeItem("tdl-sso-cart-wishlist");
                    case 13:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          );
          return function () {
            return t.apply(this, arguments);
          };
        })(),
        Bt = (function () {
          var t = e(
            a().mark(function t(e, r) {
              var n, o, i, s, c, d, u, l, p, f;
              return a().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          (n = {
                            addedToCart: [],
                            removedFromCart: [],
                            addedToWishlist: [],
                            removedFromWishlist: [],
                          }),
                          (t.prev = 1),
                          (s =
                            "cart" === r.type
                              ? "addedToCart"
                              : "addedToWishlist"),
                          (c =
                            "cart" === r.type
                              ? "removedFromCart"
                              : "removedFromWishlist"),
                          (t.next = 6),
                          Ct(e, r)
                        );
                      case 6:
                        return ((d = t.sent), (t.next = 9), Nt(d));
                      case 9:
                        return ((u = t.sent), (t.next = 12), Wt());
                      case 12:
                        return (
                          (t.next = 14),
                          kt(
                            u,
                            null !==
                              (i = JSON.parse(
                                localStorage.getItem(
                                  "tdl-sso-".concat(r.type, "-state"),
                                ),
                              )) && void 0 !== i
                              ? i
                              : {},
                          )
                        );
                      case 14:
                        if (
                          ((t.t1 = o = t.sent), (t.t0 = null !== t.t1), !t.t0)
                        ) {
                          t.next = 18;
                          break;
                        }
                        t.t0 = void 0 !== o;
                      case 18:
                        if (!t.t0) {
                          t.next = 22;
                          break;
                        }
                        ((t.t2 = o), (t.next = 23));
                        break;
                      case 22:
                        t.t2 = {};
                      case 23:
                        return (
                          (l = t.t2),
                          (p = l.productsAdded),
                          (f = l.productsRemoved),
                          localStorage.setItem(
                            "tdl-sso-".concat(r.type, "-state"),
                            JSON.stringify(u),
                          ),
                          (n[s] = p),
                          (n[c] = f),
                          t.abrupt("return", n)
                        );
                      case 32:
                        return (
                          (t.prev = 32),
                          (t.t3 = t.catch(1)),
                          U(
                            "TDPL-SSO: recording cart events using state comparison failed with",
                            t.t3,
                          ),
                          t.abrupt("return", n)
                        );
                      case 36:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                null,
                [[1, 32]],
              );
            }),
          );
          return function (e, r) {
            return t.apply(this, arguments);
          };
        })();
      function Rt(t, e) {
        var r = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(t);
          (e &&
            (n = n.filter(function (e) {
              return Object.getOwnPropertyDescriptor(t, e).enumerable;
            })),
            r.push.apply(r, n));
        }
        return r;
      }
      function Dt(t) {
        for (var e = 1; e < arguments.length; e++) {
          var r = null != arguments[e] ? arguments[e] : {};
          e % 2
            ? Rt(Object(r), !0).forEach(function (e) {
                T(t, e, r[e]);
              })
            : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
              : Rt(Object(r)).forEach(function (e) {
                  Object.defineProperty(
                    t,
                    e,
                    Object.getOwnPropertyDescriptor(r, e),
                  );
                });
        }
        return t;
      }
      function _t(t) {
        Tt.fireAnalyticsEvent([
          {
            timestamp: Date.now(),
            data: JSON.stringify({ event: "request", payload: t }),
          },
        ]);
      }
      function xt(t) {
        Tt.pushEvent(JSON.stringify({ event: "request", payload: t }));
      }
      function Ht() {
        if (D()) {
          document.cookie = "isRedirectedFromTCP=".concat(!0, "; Path=/;");
          var t = ft();
          document.cookie = "tneuSessionId=".concat(t, "; Path=/;");
        }
      }
      var jt = function () {
          try {
            S().browserEventsToRecord.forEach(function (t) {
              window.addEventListener(
                t,
                function (e) {
                  (pt(),
                    "click" === t
                      ? (function (t) {
                          if (t.isTrusted || S().recordJsDispatchedClicks) {
                            var e = (function (t) {
                                var e = t.target,
                                  r = void 0 === e ? {} : e,
                                  n = t.type;
                                return [
                                  r,
                                  void 0 === n ? "" : n,
                                  t.composedPath ? t.composedPath() : [],
                                ];
                              })(t),
                              r = H(e, 3),
                              n = r[0],
                              a = r[1],
                              o = r[2];
                            Tt.pushEvent(
                              X({ target: n, type: a, composedPath: o }),
                            );
                          }
                        })(e)
                      : (function (t) {
                          Tt.pushEvent(X(t));
                        })(e));
                },
                !0,
              );
            });
          } catch (t) {
            U("Error in capturing events", t);
          }
        },
        qt = (function () {
          var t = e(
            a().mark(function t(e) {
              var r, n;
              return a().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          (t.prev = 0),
                          (t.next = 3),
                          $("".concat(P(), "/config/v2"), e)
                        );
                      case 3:
                        return ((r = t.sent), (t.next = 6), r.json());
                      case 6:
                        ("Config fetched" === (n = t.sent).success &&
                          (localStorage.setItem(
                            "tdl-sso-analytics-v2",
                            JSON.stringify(n.config),
                          ),
                          (window.tdplConfig = n.config)),
                          (t.next = 13));
                        break;
                      case 10:
                        ((t.prev = 10), (t.t0 = t.catch(0)), U(t.t0));
                      case 13:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                null,
                [[0, 10]],
              );
            }),
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })();
      function Mt(t) {
        var e = t || new URLSearchParams(window.location.search);
        if (!D())
          if ("true" === F("isRedirectedFromTCP"))
            ((document.cookie = "".concat(
              "isRedirectedFromTCP",
              "=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;",
            )),
              sessionStorage.setItem("isRedirectedFromTCP", "true"),
              localStorage.setItem(
                "tdl-sso-redirect-tcp-flag",
                JSON.stringify({ isRedirectedFromTCP: !0, setAt: Date.now() }),
              ));
          else if ("TATADIGITAL" === W() || "FS" === W())
            (sessionStorage.setItem("isRedirectedFromTCP", "true"),
              localStorage.setItem(
                "tdl-sso-redirect-tcp-flag",
                JSON.stringify({ isRedirectedFromTCP: !0 }),
              ));
          else {
            var r = (function (t) {
              var e = [
                  "tcp",
                  "tatadigital.com",
                  "tata neu",
                  "tataneu",
                  "Website",
                  "neu",
                ],
                r = t.getAll("utm_source");
              return Boolean(
                r.find(function (t) {
                  return !!e.includes(t);
                }),
              );
            })(e);
            (localStorage.setItem(
              "tdl-sso-redirect-tcp-flag",
              JSON.stringify({ isRedirectedFromTCP: r, setAt: Date.now() }),
            ),
              sessionStorage.setItem("isRedirectedFromTCP", r.toString()));
          }
        var n,
          a = e.get("sessionId"),
          o = e.get("anonymousId"),
          i = e.get("jarvisId"),
          s = e.get("tneuAdId");
        if (
          (2 === (null == (n = a) ? void 0 : n.split(".").length)
            ? (function (t) {
                if (!t) return (dt(), void lt());
                var e = H(t.split("."), 2),
                  r = e[0],
                  n = e[1];
                r ? (lt(r), n && dt(n)) : U("Invalid jarvis-id");
              })(a)
            : (lt(a), dt(o)),
          (function (t) {
            var e = t || yt() || st();
            ((document.cookie = "jarvis-id="
              .concat(e, "; max-age=")
              .concat(3456e4, "; path=/; Secure")),
              (window.tdplJarvisId = e));
          })(i),
          (function (t) {
            t &&
              (document.cookie = "tdl-sso-ad-id="
                .concat(t, "; max-age=")
                .concat(3456e4, "; path=/; Secure"));
            var e = t || F("tdl-sso-ad-id");
            e &&
              (function (t) {
                localStorage.setItem("tdl-sso-ad-id", t);
              })(e);
          })(s),
          e.has("authCode"))
        ) {
          var c = Date.now(),
            d = new Date(c + 864e5).toUTCString();
          document.cookie = "isTataNue=true; expires=".concat(d, "; path=/");
        }
        if (e.has("jarvis_appVersion")) {
          var u = {
            platform: "native",
            deviceVersion: e.get("jarvis_appVersion"),
          };
          localStorage.setItem("tneu.deviceInfo", JSON.stringify(u));
        } else
          localStorage.getItem("tneu.deviceInfo") ||
            localStorage.setItem(
              "tneu.deviceInfo",
              JSON.stringify({ platform: "web", deviceVersion: "0" }),
            );
      }
      var Ut,
        Gt,
        Ft =
          ((Ut = function () {
            Tt.fireAnalyticsEvent([
              {
                timestamp: Date.now(),
                data: JSON.stringify({
                  event: "pageLoad",
                  payload: {
                    url: window.location.toString(),
                    dataSource: "replaceState",
                  },
                }),
              },
            ]);
          }),
          function () {
            (clearTimeout(Gt), (Gt = setTimeout(Ut, 500)));
          });
      var Jt = {
        DataLayerHelper: function (t, e, r) {
          ((this.dataLayer = t),
            (this.listener = e || function () {}),
            (this.executingListener = !1),
            (this.unprocessed = []),
            this.processStates(t, !r));
          var n = t.push,
            a = this;
          this.dataLayer.push = function () {
            for (var e = arguments.length, r = new Array(e), o = 0; o < e; o++)
              r[o] = arguments[o];
            var i = [].slice.call(r, 0),
              s = n.apply(t, i);
            return (a.processStates(i), s);
          };
        },
      };
      ((window.TdlDataLayerHelper = Jt.DataLayerHelper),
        (Jt.DataLayerHelper.prototype.processStates = function (t, e) {
          var r;
          for (
            (r = this.unprocessed).push.apply(r, j(t));
            !1 === this.executingListener && this.unprocessed.length > 0;
          ) {
            var n = this.unprocessed.shift();
            e ||
              ((this.executingListener = !0),
              this.listener(n),
              (this.executingListener = !1));
          }
        }));
      var Vt,
        Kt = function (t) {
          try {
            return "tcp_journey_url" === t[1];
          } catch (t) {
            return !1;
          }
        },
        Qt = function (t) {
          try {
            Mt(new URL(t[2].redirectionUrl).searchParams);
          } catch (t) {
            U("TDPL-SSO: reading URL search params failed with", t);
          }
        };
      function Yt(t) {
        return Xt.apply(this, arguments);
      }
      function Xt() {
        return (Xt = e(
          a().mark(function t(e) {
            return a().wrap(function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    return t.abrupt(
                      "return",
                      new Promise(function (t) {
                        setTimeout(function () {
                          var r;
                          t(
                            JSON.stringify(
                              e,
                              ((r = new WeakSet()),
                              function (t, e) {
                                if ("object" === A(e) && null !== e) {
                                  if (r.has(e) || void 0 !== e.isConnected)
                                    return;
                                  r.add(e);
                                }
                                return e;
                              }),
                            ),
                          );
                        }, 0);
                      }),
                    );
                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
          }),
        )).apply(this, arguments);
      }
      function Zt(t) {
        return zt.apply(this, arguments);
      }
      function zt() {
        return (
          (zt = e(
            a().mark(function t(e) {
              var r, n, o, i, s, c, d, u, l, p, f, y, h, v, m, A, T, P, w;
              return a().wrap(function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      if (
                        (Vt || (Vt = W()),
                        (r = {}),
                        (n = !1),
                        (o = S()),
                        (i = o.dataLayerArgumentEventsToRecord),
                        (s = o.dataLayerObjectEventsToRecord),
                        (c = o.defaultDlArgsEventsToRecord),
                        (d = o.defaultDlObjectEventsToRecord),
                        !e.length)
                      ) {
                        t.next = 37;
                        break;
                      }
                      ((u = Array.from(e)),
                        (p = null != c ? c : []),
                        (l = null != i ? i : []).push.apply(l, j(p)),
                        (f = 0));
                    case 10:
                      if (!(f < l.length)) {
                        t.next = 17;
                        break;
                      }
                      if (!u.includes(l[f])) {
                        t.next = 14;
                        break;
                      }
                      return ((n = !0), t.abrupt("break", 17));
                    case 14:
                      ((f += 1), (t.next = 10));
                      break;
                    case 17:
                      if (!n) {
                        t.next = 23;
                        break;
                      }
                      return ((t.next = 20), Yt(u));
                    case 20:
                      ((r = t.sent), (t.next = 35));
                      break;
                    case 23:
                      if ("QMIN" !== W() || !Kt(u)) {
                        t.next = 27;
                        break;
                      }
                      (Qt(u), (t.next = 35));
                      break;
                    case 27:
                      if (!(y = Lt(u))) {
                        t.next = 35;
                        break;
                      }
                      return ((t.next = 31), Bt(u, y));
                    case 31:
                      return ((h = t.sent), (t.next = 34), Yt(h));
                    case 34:
                      r = t.sent;
                    case 35:
                      t.next = 63;
                      break;
                    case 37:
                      ((m = null != d ? d : []),
                        (v = null != s ? s : []).push.apply(v, j(m)),
                        (A = Object.values(e)),
                        (T = 0));
                    case 42:
                      if (!(T < v.length)) {
                        t.next = 49;
                        break;
                      }
                      if (!A.includes(v[T])) {
                        t.next = 46;
                        break;
                      }
                      return ((n = !0), t.abrupt("break", 49));
                    case 46:
                      ((T += 1), (t.next = 42));
                      break;
                    case 49:
                      if (!n) {
                        t.next = 55;
                        break;
                      }
                      return ((t.next = 52), Yt(e));
                    case 52:
                      ((r = t.sent), (t.next = 63));
                      break;
                    case 55:
                      if (!(P = Lt(A))) {
                        t.next = 63;
                        break;
                      }
                      return ((t.next = 59), Bt(e, P));
                    case 59:
                      return ((w = t.sent), (t.next = 62), Yt(w));
                    case 62:
                      r = t.sent;
                    case 63:
                      "string" == typeof r &&
                        Tt.fireAnalyticsEvent([
                          {
                            timestamp: Date.now(),
                            data: JSON.stringify({
                              event: "gtm-event",
                              data: r,
                            }),
                          },
                        ]);
                    case 64:
                    case "end":
                      return t.stop();
                  }
              }, t);
            }),
          )),
          zt.apply(this, arguments)
        );
      }
      var $t = 0,
        te = -1,
        ee = function () {
          var t;
          if (
            ((te += 1),
            window.dataLayer ||
              !(
                te <
                (null !== (t = S().dataLayerCheckRetryCount) && void 0 !== t
                  ? t
                  : 10)
              ))
          )
            if (!window.dataLayer && te >= 5) clearInterval($t);
            else {
              clearInterval($t);
              var e = S().listenToPastDataLayerEvents;
              new window.TdlDataLayerHelper(window.dataLayer, Zt, e);
            }
        };
      const re = function () {
        try {
          (ee(), window.dataLayer || ($t = setInterval(ee, 1e3)));
        } catch (t) {
          U("Error recording GTM data: ".concat(t));
        }
      };
      var ne,
        ae = 5,
        oe = function () {
          ae < 0 ||
            (Object.hasOwn(window, "analytics")
              ? (window.analytics.realPushEvent ||
                  (window.analytics.realPushEvent = window.analytics.pushEvent),
                (window.analytics.pushEvent = function (t) {
                  try {
                    if (S().adobeEventsToRecord.includes(t.event)) {
                      var e = t.digitalData;
                      Tt.fireAnalyticsEvent([
                        {
                          timestamp: Date.now(),
                          data: JSON.stringify({
                            event: "aem-click",
                            payload: e,
                          }),
                        },
                      ]);
                    }
                  } catch (t) {
                    U("TDPL-SSO: recording adobe event failed with", t);
                  }
                  window.analytics.realPushEvent(t);
                }))
              : ((ae -= 1), setTimeout(oe, 1e3)));
        };
      try {
        (!(function () {
          var t = document.head.querySelector(
            "[name=tdl-sso-client_id][content]",
          );
          if (t) {
            var r = t.content;
            r &&
              ((window.tdlSsoAuth.createSession = (function () {
                var t = e(
                  a().mark(function t(e) {
                    var n;
                    return a().wrap(function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            return (
                              (t.next = 2),
                              fetch(
                                "".concat(f(), "/api/v2/sso/create-session"),
                                {
                                  mode: "cors",
                                  method: "POST",
                                  credentials: "include",
                                  headers: {
                                    "Content-Type": "application/json",
                                    "Access-Control-Allow-Origin": f(),
                                    client_id: r,
                                    Authorization: "Bearer ".concat(e),
                                  },
                                },
                              )
                            );
                          case 2:
                            return (
                              (n = t.sent),
                              t.abrupt(
                                "return",
                                200 === (null == n ? void 0 : n.status),
                              )
                            );
                          case 4:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                  }),
                );
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()),
              (window.tdlSsoAuth.getSession = e(
                a().mark(function t() {
                  var e;
                  return a().wrap(function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (t.t0 = fetch),
                            (t.t1 = "".concat(
                              f(),
                              "/api/v2/sso/check-session",
                            )),
                            (t.t2 = JSON),
                            (t.next = 5),
                            window.codeChallengeTdlSsoAuth
                          );
                        case 5:
                          return (
                            (t.t3 = t.sent),
                            (t.t4 = l),
                            (t.t5 = { codeChallenge: t.t3, redirectUrl: t.t4 }),
                            (t.t6 = t.t2.stringify.call(t.t2, t.t5)),
                            (t.t7 = {
                              "Content-Type": "application/json",
                              "Access-Control-Allow-Origin": f(),
                              client_id: r,
                            }),
                            (t.t8 = {
                              mode: "cors",
                              method: "POST",
                              body: t.t6,
                              credentials: "include",
                              headers: t.t7,
                            }),
                            (t.next = 13),
                            (0, t.t0)(t.t1, t.t8)
                          );
                        case 13:
                          if (
                            200 !== (null == (e = t.sent) ? void 0 : e.status)
                          ) {
                            t.next = 16;
                            break;
                          }
                          return t.abrupt(
                            "return",
                            e.json().then(function (t) {
                              return t.authCode
                                ? {
                                    authCode: t.authCode,
                                    codeVerifier: window.codeVerifierTdlSsoAuth,
                                  }
                                : { authCode: null, codeVerifier: null };
                            }),
                          );
                        case 16:
                          return t.abrupt("return", {
                            authCode: null,
                            codeVerifier: null,
                          });
                        case 17:
                        case "end":
                          return t.stop();
                      }
                  }, t);
                }),
              )),
              (window.tdlSsoAuth.deleteSession = (function () {
                var t = e(
                  a().mark(function t(e) {
                    var n, o;
                    return a().wrap(function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            return (
                              (n = localStorage.getItem("anonymousId")),
                              (t.next = 3),
                              fetch("".concat(f(), "/api/v2/sso/signout"), {
                                mode: "cors",
                                method: "POST",
                                credentials: "include",
                                headers: {
                                  "Content-Type": "application/json",
                                  "Access-Control-Allow-Origin": f(),
                                  client_id: r,
                                  Authorization: "Bearer ".concat(e),
                                  anonymous_id: n,
                                },
                              })
                            );
                          case 3:
                            return (
                              (o = t.sent),
                              t.abrupt(
                                "return",
                                200 === (null == o ? void 0 : o.status),
                              )
                            );
                          case 5:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                  }),
                );
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()),
              (window.tdlSsoAuth.openBrandUrlWithAuthCode = (function () {
                var t = e(
                  a().mark(function t(e) {
                    var n, o, c, d, u, l, p;
                    return a().wrap(
                      function (t) {
                        for (;;)
                          switch ((t.prev = t.next)) {
                            case 0:
                              if (
                                ((n = e.accessToken),
                                (o = e.url),
                                (c = e.clientSecret),
                                (d = e.target),
                                o)
                              ) {
                                t.next = 4;
                                break;
                              }
                              return (
                                console.log(
                                  "TDPL-SSO: please pass in the URL to be opened in the url property.",
                                ),
                                t.abrupt("return")
                              );
                            case 4:
                              if (n && c) {
                                t.next = 8;
                                break;
                              }
                              return (
                                console.log(
                                  "TDPL-SSO: missing accessToken or clientSecret.",
                                ),
                                d ? window.open(o, d) : window.open(o),
                                t.abrupt("return")
                              );
                            case 8:
                              return (
                                (h.codeVerifier = s(128)),
                                (t.next = 11),
                                i(h.codeVerifier)
                              );
                            case 11:
                              ((h.codeChallenge = t.sent),
                                (t.prev = 12),
                                (u = new URL(o)),
                                (t.next = 21));
                              break;
                            case 16:
                              return (
                                (t.prev = 16),
                                (t.t0 = t.catch(12)),
                                console.log(
                                  "Passed in url couldn't be parsed into a URL object.",
                                ),
                                d ? window.open(o, d) : window.open(o),
                                t.abrupt("return")
                              );
                            case 21:
                              return (
                                (l = o),
                                (t.next = 24),
                                window.ssoSdkGenerateAuthCodeForTargetDomain(
                                  n,
                                  u,
                                  r,
                                  c,
                                )
                              );
                            case 24:
                              ((p = t.sent).authCode &&
                                ((l += l.includes("?") ? "&" : "?"),
                                (l += "authCode=".concat(p.authCode)),
                                (l += "&codeVerifier=".concat(h.codeVerifier))),
                                d ? window.open(l, d) : window.open(l));
                            case 27:
                            case "end":
                              return t.stop();
                          }
                      },
                      t,
                      null,
                      [[12, 16]],
                    );
                  }),
                );
                return function (e) {
                  return t.apply(this, arguments);
                };
              })()),
              (window.tdlSsoAuth.doNativeLogin = function () {
                var t = (
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {}
                ).returnURL;
                window.location = t
                  ? "".concat(y(), "/auth/login?next=").concat(t)
                  : "".concat(y(), "/auth/login");
              }),
              (window.tdlSsoAuth.passLoginStatus = function () {
                var t,
                  e =
                    arguments.length > 0 &&
                    void 0 !== arguments[0] &&
                    arguments[0];
                if (window.webkit && window.webkit.messageHandlers)
                  null ===
                    (t = window.webkit.messageHandlers.brandLoginStatus) ||
                    void 0 === t ||
                    t.postMessage(e);
                else if ("undefined" != typeof TnAndroid) {
                  var r, n;
                  null === (r = (n = TnAndroid).brandLoginStatus) ||
                    void 0 === r ||
                    r.call(n, e);
                } else console.warn("TDPL-SSO: Native interface unavailable.");
              }));
          } else
            console.log(
              'TDPL-SSO [Error Log]: Please add <meta name="tdl-sso-client_id" content="CLIENT-ID"> in html head',
            );
        })(),
          /crawler|bot/i.test(
            null === (ne = window.navigator) || void 0 === ne
              ? void 0
              : ne.userAgent,
          ) ||
            (function () {
              try {
                var t;
                (localStorage.setItem("tdl-sso-version", "4.1.15"),
                  (window.tdlSsoAuthScriptSrc =
                    null === (t = document.currentScript) || void 0 === t
                      ? void 0
                      : t.src));
                var r = k();
                try {
                  (E(r),
                    qt(r).catch(function (t) {
                      return U("TDL-SSO: config set failed with", t);
                    }));
                } catch (t) {
                  U("TDPL-SSO: config set failed with", t);
                }
                if ((Tt.restartBufferTimer(), S().recordAnalytics)) {
                  try {
                    Mt();
                  } catch (t) {
                    U("TDPL-SSO: cookie and session set failed with", t);
                  }
                  if (!S().recordNonNeuLed && !D()) return;
                  try {
                    setTimeout(Q, 0);
                  } catch (t) {
                    U("TDPL-SSO: setting customerHash failed with", t);
                  }
                  try {
                    setTimeout(L, 0);
                  } catch (t) {
                    U(
                      "TDPL-SSO: setting analytics endpoint on window failed with",
                      t,
                    );
                  }
                  try {
                    ("complete" === document.readyState && It("readystate"),
                      window.addEventListener("load", function (t) {
                        It("load", t);
                      }),
                      window.addEventListener("popstate", function (t) {
                        var e = {
                          url: window.location.href,
                          dataSource: "popstate",
                          isTrusted: t.isTrusted,
                        };
                        gt(e);
                      }));
                  } catch (t) {
                    U("TDPL-SSO: pageLoad capturing failed with", t);
                  }
                  try {
                    (window.realOpen || (window.realOpen = window.open),
                      (window.open = function () {
                        for (
                          var t = arguments.length, e = new Array(t), r = 0;
                          r < t;
                          r++
                        )
                          e[r] = arguments[r];
                        var n = [].concat(e);
                        try {
                          if (0 !== e.length) {
                            var a;
                            if ("object" === A(e[0])) a = e[0];
                            else {
                              var o;
                              if ("string" != typeof e[0])
                                return (
                                  Ht(),
                                  (o = this.realOpen).apply.apply(o, e)
                                );
                              (e[0].startsWith("/") &&
                                (n[0] = window.location.origin + e[0]),
                                e[0].startsWith("?") &&
                                  (n[0] =
                                    window.location.origin +
                                    window.location.pathname +
                                    e[0]));
                              try {
                                a = new URL(n[0]);
                              } catch (t) {
                                return (
                                  U(t),
                                  Ht(),
                                  this.realOpen.apply(this, e)
                                );
                              }
                            }
                            ("http:" !== a.protocol &&
                              "https:" !== a.protocol) ||
                              a.origin === window.location.origin ||
                              (a.searchParams.get("sessionId") ||
                                a.searchParams.append("sessionId", ft()),
                              a.searchParams.get("jarvisId") ||
                                a.searchParams.append("jarvisId", yt()));
                          }
                          return (Ht(), this.realOpen.apply(this, j(n)));
                        } catch (t) {
                          var i;
                          return (
                            U(
                              "TDPL-SSO: adding sessionId and jarvisId search parameters to the URL failed with",
                              t,
                            ),
                            (i = window).realOpen.apply(i, e)
                          );
                        }
                      }),
                      document.addEventListener("click", function (t) {
                        t.target.closest("a[target=_blank]") && Ht();
                      }),
                      XMLHttpRequest.prototype.realOpen ||
                        (XMLHttpRequest.prototype.realOpen =
                          XMLHttpRequest.prototype.open),
                      (XMLHttpRequest.prototype.open = function () {
                        for (
                          var t = arguments.length, e = new Array(t), r = 0;
                          r < t;
                          r++
                        )
                          e[r] = arguments[r];
                        ((this.requestType = e[0]),
                          (this.requestUrl = e[1]),
                          this.realOpen.apply(this, e));
                      }),
                      XMLHttpRequest.prototype.realSetRequestHeader ||
                        (XMLHttpRequest.prototype.realSetRequestHeader =
                          XMLHttpRequest.prototype.setRequestHeader),
                      (XMLHttpRequest.prototype.setRequestHeader = function () {
                        this.requestHeaders || (this.requestHeaders = {});
                        for (
                          var t = arguments.length, e = new Array(t), r = 0;
                          r < t;
                          r++
                        )
                          e[r] = arguments[r];
                        ((this.requestHeaders[e[0]] = e[1]),
                          this.realSetRequestHeader.apply(this, e));
                      }),
                      XMLHttpRequest.prototype.realSend ||
                        (XMLHttpRequest.prototype.realSend =
                          XMLHttpRequest.prototype.send),
                      (XMLHttpRequest.prototype.send = function () {
                        for (
                          var t = this,
                            r = arguments.length,
                            n = new Array(r),
                            o = 0;
                          o < r;
                          o++
                        )
                          n[o] = arguments[o];
                        try {
                          (M(this.requestUrl) || q(this.requestUrl)) &&
                            this.addEventListener(
                              "load",
                              e(
                                a().mark(function r() {
                                  var o, i;
                                  return a().wrap(function (r) {
                                    for (;;)
                                      switch ((r.prev = r.next)) {
                                        case 0:
                                          if (
                                            ((o = function () {
                                              if (
                                                t.requestType &&
                                                ("post" ===
                                                  t.requestType.toLowerCase() ||
                                                  "put" ===
                                                    t.requestType.toLowerCase() ||
                                                  "delete" ===
                                                    t.requestType.toLowerCase())
                                              )
                                                try {
                                                  var e = n[0];
                                                  t.requestBody =
                                                    e instanceof FormData ||
                                                    e instanceof URLSearchParams
                                                      ? j(e).toString()
                                                      : e;
                                                } catch (e) {
                                                  t.requestBody = n[0];
                                                }
                                              return {
                                                requestHeaders:
                                                  t.requestHeaders,
                                                requestType: t.requestType,
                                                requestUrl: t.requestUrl,
                                                requestBody: t.requestBody,
                                                response: t.response,
                                                status: t.status,
                                              };
                                            }),
                                            M)
                                          ) {
                                            r.next = 4;
                                            break;
                                          }
                                          return (xt(o()), r.abrupt("return"));
                                        case 4:
                                          if (!(i = bt(t.requestUrl))) {
                                            r.next = 8;
                                            break;
                                          }
                                          return (
                                            window.requestIdleCallback(
                                              e(
                                                a().mark(function e() {
                                                  var r, n;
                                                  return a().wrap(
                                                    function (e) {
                                                      for (;;)
                                                        switch (
                                                          (e.prev = e.next)
                                                        ) {
                                                          case 0:
                                                            return (
                                                              (e.prev = 0),
                                                              (r =
                                                                "string" ==
                                                                typeof t.response
                                                                  ? JSON.parse(
                                                                      t.response,
                                                                    )
                                                                  : t.response),
                                                              (e.next = 4),
                                                              Bt(r, i)
                                                            );
                                                          case 4:
                                                            (_t(
                                                              (n = e.sent)
                                                                ? Dt(
                                                                    Dt({}, o()),
                                                                    {},
                                                                    {
                                                                      cartOrWishListUpdate:
                                                                        n,
                                                                    },
                                                                  )
                                                                : o(),
                                                            ),
                                                              (e.next = 11));
                                                            break;
                                                          case 8:
                                                            ((e.prev = 8),
                                                              (e.t0 =
                                                                e.catch(0)),
                                                              U(
                                                                "TDPL-SSO: recording cart or wish list change event failed with",
                                                                e.t0,
                                                              ));
                                                          case 11:
                                                          case "end":
                                                            return e.stop();
                                                        }
                                                    },
                                                    e,
                                                    null,
                                                    [[0, 8]],
                                                  );
                                                }),
                                              ),
                                              { timeout: 500 },
                                            ),
                                            r.abrupt("return")
                                          );
                                        case 8:
                                          _t(o());
                                        case 9:
                                        case "end":
                                          return r.stop();
                                      }
                                  }, r);
                                }),
                              ),
                              !1,
                            );
                        } catch (t) {
                          U("TDPL-SSO: recording xhr.send failed with", t);
                        }
                        this.realSend.apply(this, n);
                      }),
                      window.realFetch || (window.realFetch = fetch),
                      (window.fetch = function () {
                        for (
                          var t, r = arguments.length, n = new Array(r), o = 0;
                          o < r;
                          o++
                        )
                          n[o] = arguments[o];
                        return (t = window).realFetch
                          .apply(t, n)
                          .then(
                            (function () {
                              var t = e(
                                a().mark(function t(r) {
                                  var o, i;
                                  return a().wrap(function (t) {
                                    for (;;)
                                      switch ((t.prev = t.next)) {
                                        case 0:
                                          return (
                                            (i = function (t) {
                                              var e, r, a, i;
                                              return {
                                                requestHeaders:
                                                  null === (e = n[1]) ||
                                                  void 0 === e
                                                    ? void 0
                                                    : e.headers,
                                                requestType:
                                                  (null === (r = n[1]) ||
                                                  void 0 === r
                                                    ? void 0
                                                    : r.method) || "GET",
                                                requestUrl: o.url,
                                                requestBody:
                                                  ((i =
                                                    null === (a = n[1]) ||
                                                    void 0 === a
                                                      ? void 0
                                                      : a.body),
                                                  i instanceof
                                                    URLSearchParams ||
                                                  i instanceof FormData
                                                    ? j(i).toString()
                                                    : i),
                                                response: t,
                                                status:
                                                  null == o ? void 0 : o.status,
                                              };
                                            }),
                                            (o = r.clone()),
                                            setTimeout(
                                              e(
                                                a().mark(function t() {
                                                  var n, s, c;
                                                  return a().wrap(
                                                    function (t) {
                                                      for (;;)
                                                        switch (
                                                          (t.prev = t.next)
                                                        ) {
                                                          case 0:
                                                            if (
                                                              ((t.prev = 0),
                                                              !M(
                                                                "".concat(
                                                                  r.url,
                                                                ),
                                                              ))
                                                            ) {
                                                              t.next = 15;
                                                              break;
                                                            }
                                                            if (
                                                              null ===
                                                                (n =
                                                                  r.headers) ||
                                                              void 0 === n ||
                                                              null ===
                                                                (n =
                                                                  n.get(
                                                                    "content-type",
                                                                  )) ||
                                                              void 0 === n ||
                                                              !n.includes(
                                                                "application/json",
                                                              )
                                                            ) {
                                                              t.next = 12;
                                                              break;
                                                            }
                                                            return (
                                                              (s = bt(r.url)),
                                                              (t.next = 6),
                                                              o.json()
                                                            );
                                                          case 6:
                                                            if (
                                                              ((c = t.sent), !s)
                                                            ) {
                                                              t.next = 10;
                                                              break;
                                                            }
                                                            return (
                                                              window.requestIdleCallback(
                                                                e(
                                                                  a().mark(
                                                                    function t() {
                                                                      var e;
                                                                      return a().wrap(
                                                                        function (
                                                                          t,
                                                                        ) {
                                                                          for (;;)
                                                                            switch (
                                                                              (t.prev =
                                                                                t.next)
                                                                            ) {
                                                                              case 0:
                                                                                return (
                                                                                  (t.prev = 0),
                                                                                  (t.next = 3),
                                                                                  Bt(
                                                                                    c,
                                                                                    s,
                                                                                  )
                                                                                );
                                                                              case 3:
                                                                                (_t(
                                                                                  (e =
                                                                                    t.sent)
                                                                                    ? Dt(
                                                                                        Dt(
                                                                                          {},
                                                                                          i(
                                                                                            c,
                                                                                          ),
                                                                                        ),
                                                                                        {},
                                                                                        {
                                                                                          cartOrWishListUpdate:
                                                                                            e,
                                                                                        },
                                                                                      )
                                                                                    : i(
                                                                                        c,
                                                                                      ),
                                                                                ),
                                                                                  (t.next = 10));
                                                                                break;
                                                                              case 7:
                                                                                ((t.prev = 7),
                                                                                  (t.t0 =
                                                                                    t.catch(
                                                                                      0,
                                                                                    )),
                                                                                  U(
                                                                                    "TDPL-SSO: recording cart or wish list change event failed with",
                                                                                    t.t0,
                                                                                  ));
                                                                              case 10:
                                                                              case "end":
                                                                                return t.stop();
                                                                            }
                                                                        },
                                                                        t,
                                                                        null,
                                                                        [
                                                                          [
                                                                            0,
                                                                            7,
                                                                          ],
                                                                        ],
                                                                      );
                                                                    },
                                                                  ),
                                                                ),
                                                                {
                                                                  timeout: 500,
                                                                },
                                                              ),
                                                              t.abrupt("return")
                                                            );
                                                          case 10:
                                                            return (
                                                              _t(i(c)),
                                                              t.abrupt("return")
                                                            );
                                                          case 12:
                                                            (_t(i(o)),
                                                              (t.next = 16));
                                                            break;
                                                          case 15:
                                                            q(
                                                              "".concat(r.url),
                                                            ) && xt(i(o));
                                                          case 16:
                                                            t.next = 21;
                                                            break;
                                                          case 18:
                                                            ((t.prev = 18),
                                                              (t.t0 =
                                                                t.catch(0)),
                                                              U(t.t0));
                                                          case 21:
                                                          case "end":
                                                            return t.stop();
                                                        }
                                                    },
                                                    t,
                                                    null,
                                                    [[0, 18]],
                                                  );
                                                }),
                                              ),
                                              0,
                                            ),
                                            t.abrupt("return", r)
                                          );
                                        case 4:
                                        case "end":
                                          return t.stop();
                                      }
                                  }, t);
                                }),
                              );
                              return function (e) {
                                return t.apply(this, arguments);
                              };
                            })(),
                          )
                          .catch(function (t) {
                            return (U(t), t);
                          });
                      }));
                  } catch (t) {
                    U(
                      "TDPL-SSO: modification of native methods failed with",
                      t,
                    );
                  }
                  try {
                    (Object.hasOwn(window.history, "pushState")
                      ? (Object.hasOwn(window.history, "realPushState") ||
                          (window.history.realPushState =
                            window.history.pushState),
                        (window.history.pushState = function () {
                          var t;
                          ((t = window.history).realPushState.apply(
                            t,
                            arguments,
                          ),
                            Tt.fireAnalyticsEvent([
                              {
                                timestamp: Date.now(),
                                data: JSON.stringify({
                                  event: "pageLoad",
                                  payload: {
                                    url: window.location.toString(),
                                    dataSource: "pushState",
                                  },
                                }),
                              },
                            ]));
                        }))
                      : (History.prototype.realPushState ||
                          (History.prototype.realPushState =
                            History.prototype.pushState),
                        (History.prototype.pushState = function () {
                          for (
                            var t = arguments.length, e = new Array(t), r = 0;
                            r < t;
                            r++
                          )
                            e[r] = arguments[r];
                          (History.prototype.realPushState.apply(
                            window.history,
                            e,
                          ),
                            Tt.fireAnalyticsEvent([
                              {
                                timestamp: Date.now(),
                                data: JSON.stringify({
                                  event: "pageLoad",
                                  payload: {
                                    url: window.location.toString(),
                                    dataSource: "pushState",
                                  },
                                }),
                              },
                            ]));
                        })),
                      Object.hasOwn(window.history, "replaceState")
                        ? (Object.hasOwn(window.history, "realReplaceState") ||
                            (window.history.realReplaceState =
                              window.history.replaceState),
                          (window.history.replaceState = function () {
                            var t;
                            ((t = window.history).realReplaceState.apply(
                              t,
                              arguments,
                            ),
                              Ft());
                          }))
                        : "WESTSIDE" !== W() &&
                          (History.prototype.realReplaceState ||
                            (History.prototype.realReplaceState =
                              History.prototype.replaceState),
                          (History.prototype.replaceState = function () {
                            for (
                              var t = arguments.length, e = new Array(t), r = 0;
                              r < t;
                              r++
                            )
                              e[r] = arguments[r];
                            (History.prototype.realReplaceState.apply(
                              window.history,
                              e,
                            ),
                              Ft.apply(void 0, e));
                          })));
                  } catch (t) {
                    U(
                      "TDPL-SSO: modification of history's own methods failed with",
                      t,
                    );
                  }
                  try {
                    setTimeout(jt, 0);
                  } catch (t) {
                    U("TDPL-SSO: events capture failed with", t);
                  }
                  try {
                    S().recordAdobeEvents && oe();
                  } catch (t) {
                    U("TDPL-SSO: Adobe data capture failed with", t);
                  }
                  try {
                    S().recordGtmEvents && setTimeout(re, 0);
                  } catch (t) {
                    U("TDPL-SSO: GTM data capture failed with", t);
                  }
                }
              } catch (t) {
                U("TDPL-SSO: analytics start failed with", t);
              }
            })());
      } catch (t) {
        console.warn(
          "Some error occurred in starting the tdl-sso-auth.js script",
          t,
        );
      }
    })());
})();
