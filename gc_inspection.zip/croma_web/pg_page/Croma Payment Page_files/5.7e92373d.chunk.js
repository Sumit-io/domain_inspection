(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [5],
  {
    447: function (e, t, n) {
      "use strict";
      (n.r(t),
        function (e) {
          (n.d(t, "deSalting", function () {
            return a;
          }),
            n.d(t, "fetchGetPublicKeyService", function () {
              return i;
            }),
            n.d(t, "Encryption", function () {
              return l;
            }));
          var s = n(1),
            r = n(224),
            o = n.n(r),
            c = n(1055);
          function a(t) {
            if (t && "" !== t && null !== t) {
              let n = e.from(t, "base64").toString("utf8"),
                s = n.indexOf("|");
              const r = parseInt(n.substring(0, s));
              ((n = n.substring(s + 1)), (s = n.indexOf("|")));
              const o = parseInt(n.substring(0, s));
              ((n = n.substring(s + 1)), (s = n.indexOf("|")));
              const c = parseInt(n.substring(0, s));
              ((n = n.substring(s + 1)), (s = n.indexOf("|")));
              const a = parseInt(n.substring(0, s));
              ((n = n.substring(s + 1)),
                (n = n.substring(0, n.length - r - 18)));
              let i = e.from(n, "base64").toString("utf8");
              i = i.substring(o);
              return i.substring(0, c) + i.substring(c + a);
            }
            return "";
          }
          async function i(e, t, n, r) {
            const o = document.head.querySelector(
                "[name=tdl-sso-client_id][content]",
              ),
              c = o ? o.content : "CROMA-WEB-APP",
              a = localStorage.getItem("userSource");
            return await fetch("".concat(s.a.apiUrl).concat(e), {
              method: "GET",
              headers: {
                client_id: c,
                source: a,
                csc_code: r,
                accessToken: t,
                customerHash: n,
                "Cache-Control": "no-cache",
              },
            });
          }
          async function l(e) {
            let t,
              n = !1;
            if (
              ((t =
                "undefined" !== typeof Storage &&
                "" !== localStorage.getItem("InCallResponse") &&
                null !== localStorage.getItem("InCallResponse")
                  ? localStorage.getItem("InCallResponse")
                  : await (async function () {
                      const e = localStorage.getItem("customer_hash"),
                        t = localStorage.getItem("csc_code"),
                        n = localStorage.getItem("access_token"),
                        s = await i(
                          "security/allchannels/v1/pkey/issuance",
                          n,
                          e,
                          t,
                        );
                      return s.ok && s.headers.get("incallresponse")
                        ? s.headers.get("incallresponse")
                        : "";
                    })()),
              t && "" !== t)
            ) {
              const r = a(t),
                i = o.a.SHA256(JSON.stringify(e)).toString();
              var s = new c.a();
              if ((s.setPublicKey(r), (n = s.encrypt(i)), !n))
                return (localStorage.removeItem("InCallResponse"), l(e));
              localStorage.setItem("InCallResponse", t);
            }
            return n;
          }
        }.call(this, n(255).Buffer));
    },
  },
]);
