(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [15],
  { 985: function (p, a, c) {} },
]);
