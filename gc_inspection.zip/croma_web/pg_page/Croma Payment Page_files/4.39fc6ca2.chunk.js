(this["webpackJsonpcroma-pdp-app"] =
  this["webpackJsonpcroma-pdp-app"] || []).push([
  [4],
  {
    925: function (e, o, l) {
      "use strict";
      var a = l(9),
        n = l(17),
        d = l(15),
        i = (l(56), l(972)),
        t = l(27);
      o.a = function (e, o) {
        var l, u, v, r, c;
        let s =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
          m =
            arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : [];
        const p = Object(a.a)(),
          y = Object(n.a)();
        let g = "",
          h = "",
          f = "",
          D = "";
        const P = [],
          I = [],
          x = [],
          M = [],
          S = [],
          C = [],
          T = Object(d.a)(),
          N = y && (y.previousPagename ? y.previousPagename : "");
        let E = "No",
          b = 0,
          w = 0,
          O = 0,
          A = 0;
        const B = (null === o || void 0 === o ? void 0 : o.totalPriceWithTax)
          ? null === (l = o.totalPriceWithTax) || void 0 === l
            ? void 0
            : l.value
          : 0;
        let k = (null === o || void 0 === o ? void 0 : o.totalDiscounts)
          ? null === (u = o.totalDiscounts) || void 0 === u
            ? void 0
            : u.value
          : 0;
        const j = (null === o || void 0 === o ? void 0 : o.deliveryCost)
            ? null === o ||
              void 0 === o ||
              null === (v = o.deliveryCost) ||
              void 0 === v
              ? void 0
              : v.value
            : 0,
          L = [],
          V = [],
          J = [],
          F = [],
          R = [],
          W = [];
        let z,
          H = [],
          U = [],
          _ = [],
          q = "",
          K = [],
          Q = [],
          Y = [],
          G = [],
          X = "",
          Z = [],
          $ = [],
          ee = [],
          oe = [],
          le = [],
          ae = [],
          ne = [];
        const de = {
          cromaHomeDelivery: "standardDelivery",
          cromaExpressDelivery: "3hourDelivery",
          cromaStorePickup: "storePickUp",
          "": "",
        };
        var ie;
        "" === m &&
          (null === o ||
          void 0 === o ||
          null === (r = o.deliveryMode) ||
          void 0 === r
            ? void 0
            : r.code) &&
          (m =
            de[
              null === o ||
              void 0 === o ||
              null === (ie = o.deliveryMode) ||
              void 0 === ie
                ? void 0
                : ie.code
            ]);
        (p
          ? ((h = "registered user"), (g = p))
          : ((h = "guest user"), (g = "")),
          (X = "tcp" === localStorage.getItem("isTCPBody") ? "yes" : "No"),
          (f = localStorage.getItem("3hrPincode")
            ? JSON.parse(localStorage.getItem("3hrPincode"))
            : ""),
          (D = localStorage.getItem("preferredStore")
            ? JSON.parse(localStorage.getItem("preferredStore"))
            : ""),
          localStorage.getItem("findingMethodForThankPage")
            ? ((z = JSON.parse(
                localStorage.getItem("findingMethodForThankPage"),
              )),
              ($ = [...z.map((e) => e.intent)]),
              (Z = [...z.map((e) => e.prodDesc)]))
            : (z = ""),
          (null === o || void 0 === o ? void 0 : o.entries) &&
            (null === o ||
            void 0 === o ||
            null === (c = o.entries) ||
            void 0 === c
              ? void 0
              : c.length) > 0 &&
            o.entries.forEach((o) => {
              if ("1382" === o.product.code) return !1;
              if ("178701" === o.product.code && "" === s)
                return ("order summary" === e && (E = "yes"), !1);
              if ("178701" === o.product.code && "confirm" === s)
                ((b = o.product.price.value), (w = o.quantity));
              else {
                var l, a, n, d, i, t, u, v, r, c, m;
                (O++, (A += o.quantity));
                const s = o.product.name.replace(/[`|;'",]/gi, "");
                if (
                  (C.push(s),
                  S.push("".concat(o.quantity)),
                  I.push("".concat(o.product.code)),
                  null === (l = o.product) || void 0 === l
                    ? void 0
                    : l.pdpBreadcrumbs)
                ) {
                  let e = [];
                  if (o.product.pdpBreadcrumbs.length > 2)
                    for (
                      let l = 0;
                      l <= o.product.pdpBreadcrumbs.length - 2;
                      l++
                    )
                      e.push(
                        o.product.pdpBreadcrumbs[l].name.replace(
                          /[`|;'",]/gi,
                          "",
                        ),
                      );
                  else
                    e.push(
                      o.product.pdpBreadcrumbs[0].name.replace(
                        /[`|;'",]/gi,
                        "",
                      ),
                    );
                  e.length > 0 ? ((e = e.join(":")), P.push(e)) : P.push("");
                } else {
                  var p, y;
                  const e =
                    null === (p = o.product) ||
                    void 0 === p ||
                    null === (y = p.categories) ||
                    void 0 === y
                      ? void 0
                      : y
                          .map(function (e) {
                            return (
                              null === e || void 0 === e ? void 0 : e.name
                            )
                              ? null === e || void 0 === e
                                ? void 0
                                : e.name.replace(/[`|;'",]/gi, "")
                              : "";
                          })
                          .join(":");
                  e ? P.push(e) : P.push("");
                }
                (x.push(
                  "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (a = o.product) ||
                      void 0 === a ||
                      null === (n = a.price) ||
                      void 0 === n
                      ? void 0
                      : n.value,
                  ),
                ),
                  M.push(
                    "".concat(
                      null === o ||
                        void 0 === o ||
                        null === (d = o.cartEntryQunatityRespectivePriceData) ||
                        void 0 === d ||
                        null === (i = d.mrp) ||
                        void 0 === i
                        ? void 0
                        : i.value,
                    ),
                  ));
                const E =
                  null === o ||
                  void 0 === o ||
                  null === (t = o.cartEntryRewardsData) ||
                  void 0 === t
                    ? void 0
                    : t
                        .map(function (e) {
                          return (
                            null === e || void 0 === e
                              ? void 0
                              : e.promotionTypeId
                          )
                            ? null === e || void 0 === e
                              ? void 0
                              : e.promotionTypeId
                            : "";
                        })
                        .join("}");
                E ? H.push("".concat(E)) : H.push("");
                const b =
                  null === o ||
                  void 0 === o ||
                  null === (u = o.cartEntryRewardsData) ||
                  void 0 === u
                    ? void 0
                    : u
                        .map(function (e) {
                          return (
                            null === e || void 0 === e
                              ? void 0
                              : e.customerDisplayText
                          )
                            ? null === e || void 0 === e
                              ? void 0
                              : e.customerDisplayText
                            : "";
                        })
                        .join("}");
                if (
                  (b ? U.push(b) : U.push(""),
                  _.push(
                    (
                      null === o ||
                      void 0 === o ||
                      null === (v = o.cartEntryRewardsData) ||
                      void 0 === v
                        ? void 0
                        : v.length
                    )
                      ? "".concat(
                          null === o ||
                            void 0 === o ||
                            null === (r = o.cartEntryRewardsData) ||
                            void 0 === r
                            ? void 0
                            : r.length,
                        )
                      : "0",
                  ),
                  (q =
                    !0 ===
                    (null === o ||
                    void 0 === o ||
                    null === (c = o.product) ||
                    void 0 === c
                      ? void 0
                      : c.isPODAvailable)
                      ? "yes"
                      : "No"),
                  K.push(q),
                  Y.push(
                    (
                      null === o || void 0 === o
                        ? void 0
                        : o.exchangeProductName
                    )
                      ? null === o ||
                        void 0 === o ||
                        null === (m = o.exchangeProductName) ||
                        void 0 === m
                        ? void 0
                        : m.replace(/[`|;'",]/gi, "")
                      : "",
                  ),
                  G.push(
                    !0 === (null === o || void 0 === o ? void 0 : o.vasProduct)
                      ? "yes"
                      : "NA",
                  ),
                  "thank you" === e)
                ) {
                  var g;
                  let e = "";
                  var h, f, D, T, N, B, k, j, L;
                  if (
                    null === o ||
                    void 0 === o ||
                    null === (g = o.tradeInExchangeDetails) ||
                    void 0 === g
                      ? void 0
                      : g.hasOwnProperty("exchangeProductServiceProvider")
                  ) {
                    if (
                      (le.push(
                        (null === o ||
                        void 0 === o ||
                        null === (h = o.tradeInExchangeDetails) ||
                        void 0 === h
                          ? void 0
                          : h.exchangeProductExchangeBonus) || "",
                      ),
                      oe.push("yes"),
                      Q.push(
                        "".concat(
                          (
                            null === o ||
                            void 0 === o ||
                            null === (f = o.discountPrice) ||
                            void 0 === f
                              ? void 0
                              : f.value
                          )
                            ? null === o ||
                              void 0 === o ||
                              null === (D = o.discountPrice) ||
                              void 0 === D
                              ? void 0
                              : D.value
                            : "",
                        ),
                      ),
                      "cashify" ===
                        (null === o ||
                        void 0 === o ||
                        null === (T = o.tradeInExchangeDetails) ||
                        void 0 === T
                          ? void 0
                          : T.exchangeProductServiceProvider.toLowerCase()))
                    )
                      e = (
                        null === o ||
                        void 0 === o ||
                        null === (B = o.tradeInExchangeDetails) ||
                        void 0 === B
                          ? void 0
                          : B.exchangeProductName
                      )
                        ? null === o ||
                          void 0 === o ||
                          null === (k = o.tradeInExchangeDetails) ||
                          void 0 === k
                          ? void 0
                          : k.exchangeProductName
                        : "";
                    else if (
                      "croma" ===
                      (null === o ||
                      void 0 === o ||
                      null === (N = o.tradeInExchangeDetails) ||
                      void 0 === N
                        ? void 0
                        : N.exchangeProductServiceProvider.toLowerCase())
                    ) {
                      var V, J, F, R, W, z, X, Z, $, ae, ne, de, ie, te, ue;
                      e =
                        ((null === o ||
                        void 0 === o ||
                        null === (V = o.tradeInExchangeDetails) ||
                        void 0 === V
                          ? void 0
                          : V.exchangeProductBrandName) &&
                        null !==
                          (null === o ||
                          void 0 === o ||
                          null === (J = o.tradeInExchangeDetails) ||
                          void 0 === J
                            ? void 0
                            : J.exchangeProductBrandName)
                          ? null === o ||
                            void 0 === o ||
                            null === (F = o.tradeInExchangeDetails) ||
                            void 0 === F
                            ? void 0
                            : F.exchangeProductBrandName
                          : "") +
                        " " +
                        ((null === o ||
                        void 0 === o ||
                        null === (R = o.tradeInExchangeDetails) ||
                        void 0 === R
                          ? void 0
                          : R.exchangeProductType) &&
                        null !==
                          (null === o ||
                          void 0 === o ||
                          null === (W = o.tradeInExchangeDetails) ||
                          void 0 === W
                            ? void 0
                            : W.exchangeProductType)
                          ? null === o ||
                            void 0 === o ||
                            null === (z = o.tradeInExchangeDetails) ||
                            void 0 === z
                            ? void 0
                            : z.exchangeProductType
                          : "") +
                        " " +
                        ((null === o ||
                        void 0 === o ||
                        null === (X = o.tradeInExchangeDetails) ||
                        void 0 === X
                          ? void 0
                          : X.exchangeProductScreenSize) &&
                        null !==
                          (null === o ||
                          void 0 === o ||
                          null === (Z = o.tradeInExchangeDetails) ||
                          void 0 === Z
                            ? void 0
                            : Z.exchangeProductScreenSize)
                          ? null === o ||
                            void 0 === o ||
                            null === ($ = o.tradeInExchangeDetails) ||
                            void 0 === $
                            ? void 0
                            : $.exchangeProductScreenSize
                          : "") +
                        " " +
                        ((null === o ||
                        void 0 === o ||
                        null === (ae = o.tradeInExchangeDetails) ||
                        void 0 === ae
                          ? void 0
                          : ae.exchangeProductTonnage) &&
                        null !==
                          (null === o ||
                          void 0 === o ||
                          null === (ne = o.tradeInExchangeDetails) ||
                          void 0 === ne
                            ? void 0
                            : ne.exchangeProductTonnage)
                          ? null === o ||
                            void 0 === o ||
                            null === (de = o.tradeInExchangeDetails) ||
                            void 0 === de
                            ? void 0
                            : de.exchangeProductTonnage
                          : "") +
                        " " +
                        ((null === o ||
                        void 0 === o ||
                        null === (ie = o.tradeInExchangeDetails) ||
                        void 0 === ie
                          ? void 0
                          : ie.exchangeProductCategoryName) &&
                        null !==
                          (null === o ||
                          void 0 === o ||
                          null === (te = o.tradeInExchangeDetails) ||
                          void 0 === te
                            ? void 0
                            : te.exchangeProductCategoryName)
                          ? null === o ||
                            void 0 === o ||
                            null === (ue = o.tradeInExchangeDetails) ||
                            void 0 === ue
                            ? void 0
                            : ue.exchangeProductCategoryName
                          : "");
                    }
                  } else
                    (oe.push("no"),
                      le.push(""),
                      Q.push(
                        "".concat(
                          (
                            null === o ||
                            void 0 === o ||
                            null === (j = o.discountPrice) ||
                            void 0 === j
                              ? void 0
                              : j.value
                          )
                            ? null === o ||
                              void 0 === o ||
                              null === (L = o.discountPrice) ||
                              void 0 === L
                              ? void 0
                              : L.value
                            : "",
                        ),
                      ));
                  ee.push(e);
                }
                if (
                  "cart summary" === e ||
                  "order summary" === e ||
                  "payment method" === e
                ) {
                  let e = "";
                  var ve, re;
                  if (
                    null === o || void 0 === o
                      ? void 0
                      : o.hasOwnProperty("exchangeProductServiceProvider")
                  )
                    (le.push(
                      (null === o || void 0 === o
                        ? void 0
                        : o.exchangeProductExchangeBonus) || "",
                    ),
                      oe.push("yes"),
                      Q.push(
                        "".concat(
                          (
                            null === o || void 0 === o
                              ? void 0
                              : o.exchangeAmount
                          )
                            ? null === o || void 0 === o
                              ? void 0
                              : o.exchangeAmount
                            : "",
                        ),
                      ),
                      (null === o || void 0 === o
                        ? void 0
                        : o.exchangeProductServiceProvider) &&
                      "cashify" ===
                        (null === o || void 0 === o
                          ? void 0
                          : o.exchangeProductServiceProvider.toLowerCase())
                        ? (e = (
                            null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductName
                          )
                            ? null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductName
                            : "")
                        : (null === o || void 0 === o
                            ? void 0
                            : o.exchangeProductServiceProvider) &&
                          "croma" ===
                            (null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductServiceProvider.toLowerCase()) &&
                          (e =
                            ((null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductBrandName) &&
                            null !==
                              (null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductBrandName)
                              ? null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductBrandName
                              : "") +
                            " " +
                            ((null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductType) &&
                            null !==
                              (null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductType)
                              ? null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductType
                              : "") +
                            " " +
                            ((null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductScreenSize) &&
                            null !==
                              (null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductScreenSize)
                              ? null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductScreenSize
                              : "") +
                            " " +
                            ((null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductTonnage) &&
                            null !==
                              (null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductTonnage)
                              ? null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductTonnage
                              : "") +
                            " " +
                            ((null === o || void 0 === o
                              ? void 0
                              : o.exchangeProductCategoryName) &&
                            null !==
                              (null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductCategoryName)
                              ? null === o || void 0 === o
                                ? void 0
                                : o.exchangeProductCategoryName
                              : "")));
                  else
                    (oe.push("no"),
                      le.push(""),
                      Q.push(
                        "".concat(
                          (
                            null === o ||
                            void 0 === o ||
                            null === (ve = o.discountPrice) ||
                            void 0 === ve
                              ? void 0
                              : ve.value
                          )
                            ? null === o ||
                              void 0 === o ||
                              null === (re = o.discountPrice) ||
                              void 0 === re
                              ? void 0
                              : re.value
                            : "",
                        ),
                      ));
                  ee.push(e);
                }
              }
            }));
        const te = {};
        let ue = e;
        if (
          ("cart summary" === e
            ? (ue = "cart")
            : "order summary" === e && (ue = "checkout"),
          "cart summary" === e)
        ) {
          var ve, re, ce;
          const e = JSON.parse(localStorage.getItem("getAllFulfilmentOption"));
          (!0 ===
            (null === e ||
            void 0 === e ||
            null === (ve = e.HDEL) ||
            void 0 === ve
              ? void 0
              : ve.status) &&
            e.HDEL.products.forEach((e) => {
              let o = { id: "", deliveryMode: "" };
              ((o.id = e.id),
                (o.deliveryMode = e.option.fulfillmentType),
                ne.push(o));
            }),
            !0 ===
              (null === e ||
              void 0 === e ||
              null === (re = e.SDEL) ||
              void 0 === re
                ? void 0
                : re.status) &&
              e.SDEL.products.forEach((e) => {
                let o = { id: "", deliveryMode: "" };
                ((o.id = e.id),
                  (o.deliveryMode = e.option.fulfillmentType),
                  ne.push(o));
              }),
            !0 ===
              (null === e ||
              void 0 === e ||
              null === (ce = e.STOR) ||
              void 0 === ce
                ? void 0
                : ce.status) &&
              e.STOR.products.forEach((e) => {
                let o = { id: "", deliveryMode: "" };
                ((o.id = e.id),
                  (o.deliveryMode = e.option.fulfillmentType),
                  ne.push(o));
              }),
            I.forEach((e) => {
              let o = new Set(),
                l = "";
              (ne.forEach((a) => {
                a.id == e && o.add(a.deliveryMode);
                let n = Array.from(o);
                for (let e = 0; e < n.length; e++)
                  ("HDEL" === n[e] && (n[e] = "standard delivery"),
                    "SDEL" === n[e] && (n[e] = "express delivery"),
                    "STOR" === n[e] && (n[e] = "store pickup"));
                let d = "";
                for (let e = 0; e < n.length - 1; e++) d = d + n[e] + " + ";
                ((d += n.slice(-1)), (l = d));
              }),
                ae.push(l));
            }),
            localStorage.setItem("adobeDeliveryOptions", JSON.stringify(ae)));
        }
        if (
          ("order summary" === e
            ? (ae = JSON.parse(localStorage.getItem("adobeDeliveryOptions")))
            : ("payment method" !== e &&
                "confirm" !== s &&
                "/payment" !== window.location.pathname) ||
              (ae = Object(i.a)(o)),
          (te.page = {
            pageName: "".concat(e),
            channel: "croma:".concat(ue),
            prevPageName:
              "cart" === N || "checkout" === N ? "".concat(N, " summary") : N,
            pinCode: f,
            loginStatus: h,
            customerID: g,
            storeName: D,
            emailID: T.user_email,
            mobNo: T.user_mobile,
            tcpCustomer: X,
          }),
          (te.product = {
            productName: C,
            productCategory: P,
            productSKU: I,
            price: x,
            originalPrice: M,
            quantity: S,
            totalOffers: _,
            offerCode: H,
            offerValue: U,
            PayOnDelivery: K,
            exchangeDiscount: Q,
            exchangeProductName: ee,
            exchangeBonus: le,
            exchangeProductSKU: [""],
            valueAddedService: G,
            findingMethod:
              "undefined" !== typeof Storage && localStorage.getItem("PFMOrder")
                ? JSON.parse(localStorage.getItem("PFMOrder"))
                : [],
            findingMethodDetails:
              "undefined" !== typeof Storage &&
              localStorage.getItem("PFMOrderDet")
                ? JSON.parse(localStorage.getItem("PFMOrderDet"))
                : [],
            buyWithExchange: oe,
            deliveryOption: ae,
          }),
          ("cart summary" !== e &&
            "order summary" !== e &&
            "payment method" !== e &&
            "confirm" !== s &&
            "/payment" !== window.location.pathname) ||
            (te.summary = {
              totalItems: "".concat(O),
              totalQuantity: "".concat(A),
              totalAmount: "".concat(B),
              totalDiscount: "".concat(k),
              deliveryCharges: "".concat(j),
            }),
          "order summary" === e && (te.product.gift = E),
          "confirm" === s)
        ) {
          var se,
            me,
            pe,
            ye,
            ge,
            he,
            fe,
            De,
            Pe,
            Ie,
            xe,
            Me,
            Se,
            Ce,
            Te,
            Ne,
            Ee,
            be,
            we,
            Oe,
            Ae,
            Be;
          ((te.page.prevPageName = "payment method"),
            S.push("0"),
            C.push("tax"),
            I.push("tax"),
            P.push("tax"),
            x.push(
              (
                null === o ||
                void 0 === o ||
                null === (se = o.totalTax) ||
                void 0 === se
                  ? void 0
                  : se.value
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (me = o.totalTax) ||
                      void 0 === me
                      ? void 0
                      : me.value,
                  )
                : "0",
            ),
            M.push(
              (
                null === o ||
                void 0 === o ||
                null === (pe = o.totalTax) ||
                void 0 === pe
                  ? void 0
                  : pe.value
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (ye = o.totalTax) ||
                      void 0 === ye
                      ? void 0
                      : ye.value,
                  )
                : "0",
            ),
            S.push("0"),
            I.push("shipping"),
            C.push("shipping"),
            P.push("shipping"),
            x.push(
              (
                null === o ||
                void 0 === o ||
                null === (ge = o.deliveryCost) ||
                void 0 === ge
                  ? void 0
                  : ge.value
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (he = o.deliveryCost) ||
                      void 0 === he
                      ? void 0
                      : he.value,
                  )
                : "0",
            ),
            M.push(
              (
                null === o ||
                void 0 === o ||
                null === (fe = o.deliveryCost) ||
                void 0 === fe
                  ? void 0
                  : fe.value
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (De = o.deliveryCost) ||
                      void 0 === De
                      ? void 0
                      : De.value,
                  )
                : "0",
            ),
            S.push("".concat(w)),
            I.push("gift"),
            C.push("gift"),
            P.push("gift"),
            x.push("".concat(b)),
            M.push("".concat(b)),
            (k = (null === o || void 0 === o ? void 0 : o.orderDiscounts)
              ? o.orderDiscounts.value
              : 0));
          try {
            if (
              (null === o || void 0 === o ? void 0 : o.allOfferSavingsData) &&
              Array.isArray(
                null === o || void 0 === o ? void 0 : o.allOfferSavingsData,
              )
            ) {
              var ke;
              const e =
                null === o ||
                void 0 === o ||
                null === (ke = o.allOfferSavingsData) ||
                void 0 === ke
                  ? void 0
                  : ke.filter(
                      (e) =>
                        !!(null === e || void 0 === e
                          ? void 0
                          : e.allCouponData),
                    );
              if (e && Array.isArray(e))
                for (let o = 0; o < e.length; o++)
                  (V.push(e[o].allCouponData[0].couponId),
                    L.push(e[o].promotionSavings));
            }
          } catch (Ro) {
            console.log(Ro);
          }
          if (
            ((te.page.giftCardAmount = J),
            (te.page.giftCode = F),
            (te.page.voucherValue = R),
            (te.page.voucherCode = W),
            (te.page.couponValue = L),
            (te.page.couponCode = V),
            (te.orderDetail = {
              paymentMethod: (
                null === o ||
                void 0 === o ||
                null === (Pe = o.paymentInfoData) ||
                void 0 === Pe
                  ? void 0
                  : Pe.paymentMode
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (Ie = o.paymentInfoData) ||
                      void 0 === Ie
                      ? void 0
                      : Ie.paymentMode,
                  )
                : (null === o || void 0 === o ? void 0 : o.paymentMode)
                  ? "".concat(
                      null === o || void 0 === o ? void 0 : o.paymentMode,
                    )
                  : "",
              orderAmount: "".concat(
                null === o ||
                  void 0 === o ||
                  null === (xe = o.totalPriceWithTax) ||
                  void 0 === xe
                  ? void 0
                  : xe.value,
              ),
              orderID: (null === o || void 0 === o ? void 0 : o.orderId)
                ? "".concat(null === o || void 0 === o ? void 0 : o.orderId)
                : "",
              paymentStatus: (
                null === o ||
                void 0 === o ||
                null === (Me = o.paymentInfoData) ||
                void 0 === Me
                  ? void 0
                  : Me.jusPayStatus
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Se = o.paymentInfoData) ||
                  void 0 === Se
                  ? void 0
                  : Se.jusPayStatus
                : null === o || void 0 === o
                  ? void 0
                  : o.status,
              issureName: "",
              emi: "no",
              emiTenure: "",
              emiDescription: "",
              walletType: "",
              upiType: "",
              card: "",
              cardType: "",
              neuCoinsValue: "".concat(
                null === o ||
                  void 0 === o ||
                  null === (Ce = o.loyaltyPaymentInfoData) ||
                  void 0 === Ce
                  ? void 0
                  : Ce.loyaltyPoint,
              ),
              offerAmount: "".concat(k),
              gateWayID: (
                null === o ||
                void 0 === o ||
                null === (Te = o.paymentInfoData) ||
                void 0 === Te
                  ? void 0
                  : Te.gatewayName
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Ne = o.paymentInfoData) ||
                  void 0 === Ne
                  ? void 0
                  : Ne.gatewayName
                : "",
            }),
            "cromaCCPaymentMode" ===
              (null === o || void 0 === o ? void 0 : o.paymentModeCode) ||
              "cromaDCPaymentMode" ===
                (null === o || void 0 === o ? void 0 : o.paymentModeCode))
          )
            ((te.orderDetail.card = (
              null === o ||
              void 0 === o ||
              null === (Ee = o.paymentInfoData) ||
              void 0 === Ee
                ? void 0
                : Ee.paymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (be = o.paymentInfoData) ||
                void 0 === be
                ? void 0
                : be.paymentMode
              : ""),
              (te.orderDetail.cardType = (
                null === o ||
                void 0 === o ||
                null === (we = o.paymentInfoData) ||
                void 0 === we
                  ? void 0
                  : we.subPaymentMode
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Oe = o.paymentInfoData) ||
                  void 0 === Oe
                  ? void 0
                  : Oe.subPaymentMode
                : ""),
              (te.orderDetail.issureName = (
                null === o ||
                void 0 === o ||
                null === (Ae = o.paymentInfoData) ||
                void 0 === Ae
                  ? void 0
                  : Ae.issuername
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Be = o.paymentInfoData) ||
                  void 0 === Be
                  ? void 0
                  : Be.issuername
                : ""));
          else if (
            "cromaWalletPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var je, Le;
            te.orderDetail.walletType = (
              null === o ||
              void 0 === o ||
              null === (je = o.paymentInfoData) ||
              void 0 === je
                ? void 0
                : je.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (Le = o.paymentInfoData) ||
                void 0 === Le
                ? void 0
                : Le.subPaymentMode
              : "";
          } else if (
            "cromaNBPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var Ve, Je;
            te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (Ve = o.paymentInfoData) ||
              void 0 === Ve
                ? void 0
                : Ve.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (Je = o.paymentInfoData) ||
                void 0 === Je
                ? void 0
                : Je.subPaymentMode
              : "";
          } else if (
            "cromaUPIPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var Fe, Re;
            te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (Fe = o.paymentInfoData) ||
              void 0 === Fe
                ? void 0
                : Fe.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (Re = o.paymentInfoData) ||
                void 0 === Re
                ? void 0
                : Re.subPaymentMode
              : "";
          } else if (
            "cromaEMIPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var We, ze, He, Ue, _e, qe;
            ((te.orderDetail.emi = "yes"),
              (te.orderDetail.emiTenure = (
                null === o ||
                void 0 === o ||
                null === (We = o.paymentInfoData) ||
                void 0 === We
                  ? void 0
                  : We.emiTenure
              )
                ? null === o ||
                  void 0 === o ||
                  null === (ze = o.paymentInfoData) ||
                  void 0 === ze
                  ? void 0
                  : ze.emiTenure
                : ""),
              (te.orderDetail.issureName = (
                null === o ||
                void 0 === o ||
                null === (He = o.paymentInfoData) ||
                void 0 === He
                  ? void 0
                  : He.issuername
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Ue = o.paymentInfoData) ||
                  void 0 === Ue
                  ? void 0
                  : Ue.issuername
                : ""),
              (te.orderDetail.emiDescription = (
                null === o ||
                void 0 === o ||
                null === (_e = o.paymentInfoData) ||
                void 0 === _e
                  ? void 0
                  : _e.emiType
              )
                ? null === o ||
                  void 0 === o ||
                  null === (qe = o.paymentInfoData) ||
                  void 0 === qe
                  ? void 0
                  : qe.emiType
                : ""));
          } else {
            var Ke, Qe, Ye, Ge;
            ((te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (Ke = o.paymentInfoData) ||
              void 0 === Ke
                ? void 0
                : Ke.issuername
            )
              ? null === o ||
                void 0 === o ||
                null === (Qe = o.paymentInfoData) ||
                void 0 === Qe
                ? void 0
                : Qe.issuername
              : ""),
              (te.orderDetail.card = (
                null === o || void 0 === o ? void 0 : o.paymentMode
              )
                ? null === o || void 0 === o
                  ? void 0
                  : o.paymentMode
                : ""),
              (te.orderDetail.cardType = (
                null === o ||
                void 0 === o ||
                null === (Ye = o.paymentInfoData) ||
                void 0 === Ye
                  ? void 0
                  : Ye.subPaymentMode
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Ge = o.paymentInfoData) ||
                  void 0 === Ge
                  ? void 0
                  : Ge.subPaymentMode
                : ""));
          }
          try {
            var Xe, Ze;
            if (
              null === o ||
              void 0 === o ||
              null === (Xe = o.gvPaymentInfoData) ||
              void 0 === Xe
                ? void 0
                : Xe.giftCardAmount
            ) {
              const e = [];
              for (
                let l = 0;
                l <
                (null === o ||
                void 0 === o ||
                null === ($e = o.gvPaymentInfoData) ||
                void 0 === $e
                  ? void 0
                  : $e.giftCardAmount.length);
                l++
              ) {
                var $e, eo;
                e.push(
                  "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (eo = o.gvPaymentInfoData) ||
                      void 0 === eo
                      ? void 0
                      : eo.giftCardAmount[l],
                  ),
                );
              }
              te.page.giftCardAmount = e;
            }
            if (
              null === o ||
              void 0 === o ||
              null === (Ze = o.gvPaymentInfoData) ||
              void 0 === Ze
                ? void 0
                : Ze.giftCode
            ) {
              const e = [];
              for (
                let l = 0;
                l <
                (null === o ||
                void 0 === o ||
                null === (oo = o.gvPaymentInfoData) ||
                void 0 === oo
                  ? void 0
                  : oo.giftCode.length);
                l++
              ) {
                var oo, lo;
                e.push(
                  "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (lo = o.gvPaymentInfoData) ||
                      void 0 === lo
                      ? void 0
                      : lo.giftCode[l],
                  ),
                );
              }
              te.page.giftCode = e;
            }
          } catch (Ro) {}
          try {
            var ao, no;
            if (
              null === o ||
              void 0 === o ||
              null === (ao = o.gvPaymentInfoData) ||
              void 0 === ao
                ? void 0
                : ao.voucherValue
            ) {
              const e = [];
              for (
                let l = 0;
                l <
                (null === o ||
                void 0 === o ||
                null === (io = o.gvPaymentInfoData) ||
                void 0 === io
                  ? void 0
                  : io.voucherValue.length);
                l++
              ) {
                var io, to;
                e.push(
                  "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (to = o.gvPaymentInfoData) ||
                      void 0 === to
                      ? void 0
                      : to.voucherValue[l],
                  ),
                );
              }
              te.page.voucherValue = e;
            }
            if (
              null === o ||
              void 0 === o ||
              null === (no = o.gvPaymentInfoData) ||
              void 0 === no
                ? void 0
                : no.voucherCode
            ) {
              const e = [];
              for (
                let l = 0;
                l <
                (null === o ||
                void 0 === o ||
                null === (uo = o.gvPaymentInfoData) ||
                void 0 === uo
                  ? void 0
                  : uo.voucherCode.length);
                l++
              ) {
                var uo, vo;
                e.push(
                  "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (vo = o.gvPaymentInfoData) ||
                      void 0 === vo
                      ? void 0
                      : vo.voucherCode[l],
                  ),
                );
              }
              te.page.voucherCode = e;
            }
          } catch (Ro) {}
        }
        var ro, co, so, mo, po, yo, go, ho, fo, Do, Po, Io, xo, Mo;
        if ("" !== s && "confirm" !== s)
          if (
            ((te.page.failureReason = (
              null === o || void 0 === o ? void 0 : o.paymentTransactionMsg
            )
              ? "".concat(
                  null === o || void 0 === o ? void 0 : o.paymentTransactionMsg,
                )
              : ""),
            (te.page.channel = "croma:failure"),
            (te.page.pageName = "Failure"),
            (te.page.prevPageName = "payment method"),
            (te.page.giftCardAmount = J),
            (te.page.giftCode = F),
            (te.page.voucherValue = R),
            (te.page.voucherCode = W),
            (te.page.couponValue = L),
            (te.page.couponCode = V),
            (te.orderDetail = {
              orderAmount: "".concat(
                null === o ||
                  void 0 === o ||
                  null === (ro = o.totalPriceWithTax) ||
                  void 0 === ro
                  ? void 0
                  : ro.value,
              ),
              paymentMethod: (
                null === o ||
                void 0 === o ||
                null === (co = o.paymentInfoData) ||
                void 0 === co
                  ? void 0
                  : co.paymentMode
              )
                ? "".concat(
                    null === o ||
                      void 0 === o ||
                      null === (so = o.paymentInfoData) ||
                      void 0 === so
                      ? void 0
                      : so.paymentMode,
                  )
                : (null === o || void 0 === o ? void 0 : o.paymentMode)
                  ? "".concat(
                      null === o || void 0 === o ? void 0 : o.paymentMode,
                    )
                  : "",
              orderID: "".concat(
                null === o || void 0 === o ? void 0 : o.orderId,
              ),
              paymentStatus: (
                null === o ||
                void 0 === o ||
                null === (mo = o.paymentInfoData) ||
                void 0 === mo
                  ? void 0
                  : mo.jusPayStatus
              )
                ? null === o ||
                  void 0 === o ||
                  null === (po = o.paymentInfoData) ||
                  void 0 === po
                  ? void 0
                  : po.jusPayStatus
                : null === o || void 0 === o
                  ? void 0
                  : o.status,
              issureName: "",
              emi: "",
              card: "",
              cardType: "",
              emiTenure: "",
              emiDescription: "",
              walletType: "",
              upiType: "",
              neuCoinsValue: "".concat(
                null === o ||
                  void 0 === o ||
                  null === (yo = o.loyaltyPaymentInfoData) ||
                  void 0 === yo
                  ? void 0
                  : yo.loyaltyPoint,
              ),
              offerAmount: "".concat(k),
              gateWayID: (
                null === o ||
                void 0 === o ||
                null === (go = o.paymentInfoData) ||
                void 0 === go
                  ? void 0
                  : go.gatewayName
              )
                ? null === o ||
                  void 0 === o ||
                  null === (ho = o.paymentInfoData) ||
                  void 0 === ho
                  ? void 0
                  : ho.gatewayName
                : "",
            }),
            "cromaCCPaymentMode" ===
              (null === o || void 0 === o ? void 0 : o.paymentModeCode) ||
              "cromaDCPaymentMode" ===
                (null === o || void 0 === o ? void 0 : o.paymentModeCode))
          )
            ((te.orderDetail.card = (
              null === o ||
              void 0 === o ||
              null === (fo = o.paymentInfoData) ||
              void 0 === fo
                ? void 0
                : fo.paymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (Do = o.paymentInfoData) ||
                void 0 === Do
                ? void 0
                : Do.paymentMode
              : ""),
              (te.orderDetail.cardType = (
                null === o ||
                void 0 === o ||
                null === (Po = o.paymentInfoData) ||
                void 0 === Po
                  ? void 0
                  : Po.subPaymentMode
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Io = o.paymentInfoData) ||
                  void 0 === Io
                  ? void 0
                  : Io.subPaymentMode
                : ""),
              (te.orderDetail.issureName = (
                null === o ||
                void 0 === o ||
                null === (xo = o.paymentInfoData) ||
                void 0 === xo
                  ? void 0
                  : xo.issuername
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Mo = o.paymentInfoData) ||
                  void 0 === Mo
                  ? void 0
                  : Mo.issuername
                : ""));
          else if (
            "cromaWalletPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var So, Co;
            te.orderDetail.walletType = (
              null === o ||
              void 0 === o ||
              null === (So = o.paymentInfoData) ||
              void 0 === So
                ? void 0
                : So.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (Co = o.paymentInfoData) ||
                void 0 === Co
                ? void 0
                : Co.subPaymentMode
              : "";
          } else if (
            "cromaNBPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var To, No;
            te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (To = o.paymentInfoData) ||
              void 0 === To
                ? void 0
                : To.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (No = o.paymentInfoData) ||
                void 0 === No
                ? void 0
                : No.subPaymentMode
              : "";
          } else if (
            "cromaUPIPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var Eo, bo;
            te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (Eo = o.paymentInfoData) ||
              void 0 === Eo
                ? void 0
                : Eo.subPaymentMode
            )
              ? null === o ||
                void 0 === o ||
                null === (bo = o.paymentInfoData) ||
                void 0 === bo
                ? void 0
                : bo.subPaymentMode
              : "";
          } else if (
            "cromaEMIPaymentMode" ===
            (null === o || void 0 === o ? void 0 : o.paymentModeCode)
          ) {
            var wo, Oo, Ao, Bo, ko, jo;
            ((te.orderDetail.emi = "yes"),
              (te.orderDetail.emiTenure = (
                null === o ||
                void 0 === o ||
                null === (wo = o.paymentInfoData) ||
                void 0 === wo
                  ? void 0
                  : wo.emiTenure
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Oo = o.paymentInfoData) ||
                  void 0 === Oo
                  ? void 0
                  : Oo.emiTenure
                : ""),
              (te.orderDetail.issureName = (
                null === o ||
                void 0 === o ||
                null === (Ao = o.paymentInfoData) ||
                void 0 === Ao
                  ? void 0
                  : Ao.issuername
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Bo = o.paymentInfoData) ||
                  void 0 === Bo
                  ? void 0
                  : Bo.issuername
                : ""),
              (te.orderDetail.emiDescription = (
                null === o ||
                void 0 === o ||
                null === (ko = o.paymentInfoData) ||
                void 0 === ko
                  ? void 0
                  : ko.emiType
              )
                ? null === o ||
                  void 0 === o ||
                  null === (jo = o.paymentInfoData) ||
                  void 0 === jo
                  ? void 0
                  : jo.emiType
                : ""));
          } else {
            var Lo, Vo, Jo, Fo;
            ((te.orderDetail.issureName = (
              null === o ||
              void 0 === o ||
              null === (Lo = o.paymentInfoData) ||
              void 0 === Lo
                ? void 0
                : Lo.issuername
            )
              ? null === o ||
                void 0 === o ||
                null === (Vo = o.paymentInfoData) ||
                void 0 === Vo
                ? void 0
                : Vo.issuername
              : ""),
              (te.orderDetail.card = (
                null === o || void 0 === o ? void 0 : o.paymentMode
              )
                ? null === o || void 0 === o
                  ? void 0
                  : o.paymentMode
                : ""),
              (te.orderDetail.cardType = (
                null === o ||
                void 0 === o ||
                null === (Jo = o.paymentInfoData) ||
                void 0 === Jo
                  ? void 0
                  : Jo.subPaymentMode
              )
                ? null === o ||
                  void 0 === o ||
                  null === (Fo = o.paymentInfoData) ||
                  void 0 === Fo
                  ? void 0
                  : Fo.subPaymentMode
                : ""));
          }
        if (
          ("undefined" !== typeof window && (window.digitalData = te),
          sessionStorage.calledFromTDNative)
        )
          Object(t.k)("ANALYTICS", "", "", "", te);
        else
          try {
            "undefined" !== typeof window._satellite &&
              (window._satellite, window._satellite.track("pageload"));
          } catch (Wo) {}
      };
    },
    972: function (e, o, l) {
      "use strict";
      o.a = (e) => {
        let o = [];
        return (
          (o = [
            ...(null === e || void 0 === e
              ? void 0
              : e.entries
                  .filter((e) => {
                    var o;
                    return (
                      null !=
                        (null === e || void 0 === e
                          ? void 0
                          : e.deliveryMode) &&
                      null !=
                        (null === e ||
                        void 0 === e ||
                        null === (o = e.deliveryMode) ||
                        void 0 === o
                          ? void 0
                          : o.code)
                    );
                  })
                  .map((e) => {
                    var o, l, a;
                    return "cromaHomeDelivery" ===
                      (null === e ||
                      void 0 === e ||
                      null === (o = e.deliveryMode) ||
                      void 0 === o
                        ? void 0
                        : o.code)
                      ? "standard delivery"
                      : "cromaStorePickup" ===
                          (null === e ||
                          void 0 === e ||
                          null === (l = e.deliveryMode) ||
                          void 0 === l
                            ? void 0
                            : l.code)
                        ? "storepickup"
                        : "cromaExpressDelivery" ===
                            (null === e ||
                            void 0 === e ||
                            null === (a = e.deliveryMode) ||
                            void 0 === a
                              ? void 0
                              : a.code)
                          ? "express delivery"
                          : void 0;
                  })),
          ]),
          o
        );
      };
    },
  },
]);
