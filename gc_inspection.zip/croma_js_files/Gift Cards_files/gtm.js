// Copyright 2012 Google Inc. All rights reserved.

(function () {
  var data = {
    resource: {
      version: "2",

      macros: [
        { function: "__e" },
        { function: "__e" },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "uuid",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "storeName",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "storeID",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "domain",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "path",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "locale",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "selectedLanguage",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "message",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "redirectUrl",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "bannerName",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "denominationSelected",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "label",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "currencyName",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "deliveryOption",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "promoCode",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "menuLabel",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "productName",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "categoryName",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "deliveryMode",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "orderRefNumber",
        },
        {
          function: "__gas",
          vtp_cookieDomain: "auto",
          vtp_useEcommerceDataLayer: true,
          vtp_doubleClick: false,
          vtp_setTrackerName: false,
          vtp_useDebugVersion: false,
          vtp_useGA4SchemaForEcommerce: false,
          vtp_useHashAutoLink: false,
          vtp_decorateFormsAutoLink: false,
          vtp_enableLinkId: false,
          vtp_dimension: [
            "list",
            ["map", "index", "1", "dimension", ["macro", 2]],
            ["map", "index", "2", "dimension", ["macro", 3]],
            ["map", "index", "3", "dimension", ["macro", 4]],
            ["map", "index", "4", "dimension", ["macro", 5]],
            ["map", "index", "5", "dimension", ["macro", 6]],
            ["map", "index", "6", "dimension", ["macro", 7]],
            ["map", "index", "7", "dimension", ["macro", 8]],
            ["map", "index", "8", "dimension", ["macro", 9]],
            ["map", "index", "9", "dimension", ["macro", 10]],
            ["map", "index", "10", "dimension", ["macro", 11]],
            ["map", "index", "11", "dimension", ["macro", 12]],
            ["map", "index", "12", "dimension", ["macro", 13]],
            ["map", "index", "13", "dimension", ["macro", 14]],
            ["map", "index", "14", "dimension", ["macro", 15]],
            ["map", "index", "15", "dimension", ["macro", 16]],
            ["map", "index", "16", "dimension", ["macro", 17]],
            ["map", "index", "17", "dimension", ["macro", 18]],
            ["map", "index", "18", "dimension", ["macro", 19]],
            ["map", "index", "19", "dimension", ["macro", 20]],
            ["map", "index", "20", "dimension", ["macro", 21]],
          ],
          vtp_enableEcommerce: true,
          vtp_trackingId: "UA-208906132-1",
          vtp_enableRecaptchaOption: false,
          vtp_enableUaRlsa: false,
          vtp_enableUseInternalVersion: false,
          vtp_ecommerceIsEnabled: true,
          vtp_enableGA4Schema: true,
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "orderAmount",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "denomination",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "payments",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "orderStatusLabel",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "dateOfSchedule",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "orderNumber",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "discountReceived",
        },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "productCategory",
        },
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "HOST",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "PATH",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        { function: "__f", vtp_component: "URL" },
      ],
      tags: [
        {
          function: "__ua",
          metadata: ["map"],
          once_per_event: true,
          vtp_nonInteraction: false,
          vtp_overrideGaSettings: false,
          vtp_eventValue: ["macro", 1],
          vtp_eventCategory: ["macro", 1],
          vtp_trackType: "TRACK_EVENT",
          vtp_gaSettings: ["macro", 22],
          vtp_eventAction: ["macro", 1],
          vtp_eventLabel: ["macro", 1],
          vtp_enableRecaptchaOption: false,
          vtp_enableUaRlsa: false,
          vtp_enableUseInternalVersion: false,
          vtp_enableFirebaseCampaignData: true,
          vtp_trackTypeIsEvent: true,
          vtp_enableGA4Schema: true,
          tag_id: 53,
        },
        {
          function: "__ua",
          metadata: ["map"],
          once_per_event: true,
          vtp_overrideGaSettings: false,
          vtp_trackType: "TRACK_PAGEVIEW",
          vtp_gaSettings: ["macro", 22],
          vtp_enableRecaptchaOption: false,
          vtp_enableUaRlsa: false,
          vtp_enableUseInternalVersion: false,
          vtp_enableFirebaseCampaignData: true,
          vtp_enableGA4Schema: true,
          tag_id: 54,
        },
        {
          function: "__ua",
          metadata: ["map"],
          once_per_event: true,
          vtp_overrideGaSettings: false,
          vtp_trackType: "TRACK_PAGEVIEW",
          vtp_gaSettings: ["macro", 22],
          vtp_enableRecaptchaOption: false,
          vtp_enableUaRlsa: false,
          vtp_enableUseInternalVersion: false,
          vtp_enableFirebaseCampaignData: true,
          vtp_enableGA4Schema: true,
          tag_id: 56,
        },
        {
          function: "__googtag",
          metadata: ["map"],
          once_per_event: true,
          vtp_tagId: "G-W6M733P0Y3",
          vtp_configSettingsTable: [
            "list",
            ["map", "parameter", "send_page_view", "parameterValue", "true"],
          ],
          tag_id: 60,
        },
        {
          function: "__gaawe",
          metadata: ["map"],
          once_per_event: true,
          vtp_sendEcommerceData: false,
          vtp_eventName: ["macro", 1],
          vtp_measurementIdOverride: "G-W6M733P0Y3",
          vtp_enableUserProperties: true,
          vtp_enableMoreSettingsOption: true,
          vtp_enableEuid: false,
          vtp_migratedToV2: true,
          vtp_demoV2: false,
          tag_id: 61,
        },
      ],
      predicates: [
        { function: "_re", arg0: ["macro", 0], arg1: "addedToHomeScreen" },
        { function: "_re", arg0: ["macro", 0], arg1: "Banner-clicked" },
        { function: "_re", arg0: ["macro", 0], arg1: "Changed-Currency" },
        { function: "_re", arg0: ["macro", 0], arg1: "Changed-Language" },
        { function: "_re", arg0: ["macro", 0], arg1: "Clicked-Same-as-Sender" },
        { function: "_re", arg0: ["macro", 0], arg1: "Clicked-Top-Menu" },
        { function: "_eq", arg0: ["macro", 0], arg1: "gtm.init_consent" },
        { function: "_eq", arg0: ["macro", 0], arg1: "gtm.init" },
        {
          function: "_re",
          arg0: ["macro", 0],
          arg1: "Initiated-Order-Status-Check",
        },
        { function: "_re", arg0: ["macro", 0], arg1: "Initiated-Payment" },
        { function: "_re", arg0: ["macro", 0], arg1: "Initiated-Reload" },
        { function: "_re", arg0: ["macro", 0], arg1: "Initiated-View-Balance" },
        {
          function: "_re",
          arg0: ["macro", 0],
          arg1: "Landed-on-Order-Success-Page",
        },
        { function: "_re", arg0: ["macro", 0], arg1: "loggedInFromPWA" },
        { function: "_re", arg0: ["macro", 0], arg1: "Logo-Clicked" },
        {
          function: "_re",
          arg0: ["macro", 0],
          arg1: "Mode-of-Delivery-Selected",
        },
        { function: "_re", arg0: ["macro", 0], arg1: "Page-Visited" },
        { function: "_re", arg0: ["macro", 0], arg1: "Preview-Viewed" },
        { function: "_re", arg0: ["macro", 0], arg1: "productClick" },
        { function: "_re", arg0: ["macro", 0], arg1: "Promo-Code-Applied" },
        { function: "_re", arg0: ["macro", 0], arg1: "Request-Order-OTP" },
        { function: "_re", arg0: ["macro", 0], arg1: "Resend-OTP" },
        {
          function: "_re",
          arg0: ["macro", 0],
          arg1: "Selected-Delivery-Options",
        },
        { function: "_re", arg0: ["macro", 0], arg1: "Selected-Denomination" },
        { function: "_re", arg0: ["macro", 0], arg1: "Selected-Schedule" },
        { function: "_re", arg0: ["macro", 0], arg1: "Selected-Theme" },
        { function: "_re", arg0: ["macro", 0], arg1: "transaction" },
        { function: "_eq", arg0: ["macro", 0], arg1: "gtm.js" },
      ],
      rules: [
        [
          ["if", 0],
          ["add", 0, 4],
        ],
        [
          ["if", 1],
          ["add", 0, 4],
        ],
        [
          ["if", 2],
          ["add", 0, 4],
        ],
        [
          ["if", 3],
          ["add", 0, 4],
        ],
        [
          ["if", 4],
          ["add", 0, 4],
        ],
        [
          ["if", 5],
          ["add", 0, 4],
        ],
        [
          ["if", 6],
          ["add", 0, 4],
        ],
        [
          ["if", 7],
          ["add", 0, 4],
        ],
        [
          ["if", 8],
          ["add", 0, 4],
        ],
        [
          ["if", 9],
          ["add", 0, 4],
        ],
        [
          ["if", 10],
          ["add", 0, 4],
        ],
        [
          ["if", 11],
          ["add", 0, 4],
        ],
        [
          ["if", 12],
          ["add", 0, 4],
        ],
        [
          ["if", 13],
          ["add", 0, 4],
        ],
        [
          ["if", 14],
          ["add", 0, 4],
        ],
        [
          ["if", 15],
          ["add", 0, 4],
        ],
        [
          ["if", 16],
          ["add", 0, 4],
        ],
        [
          ["if", 17],
          ["add", 0, 4],
        ],
        [
          ["if", 18],
          ["add", 0, 4],
        ],
        [
          ["if", 19],
          ["add", 0, 4],
        ],
        [
          ["if", 20],
          ["add", 0, 4],
        ],
        [
          ["if", 21],
          ["add", 0, 4],
        ],
        [
          ["if", 22],
          ["add", 0, 4],
        ],
        [
          ["if", 23],
          ["add", 0, 4],
        ],
        [
          ["if", 24],
          ["add", 0, 4],
        ],
        [
          ["if", 25],
          ["add", 0, 4],
        ],
        [
          ["if", 26],
          ["add", 0, 4],
        ],
        [
          ["if", 27],
          ["add", 1, 2, 3, 4],
        ],
      ],
    },
    runtime: [
      [
        50,
        "__e",
        [46, "a"],
        [
          36,
          [
            13,
            [41, "$0"],
            [3, "$0", ["require", "internal.getEventData"]],
            ["$0", "event"],
          ],
        ],
      ],
      [
        50,
        "__f",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getReferrerUrl"]],
        [52, "d", ["require", "makeString"]],
        [52, "e", ["require", "parseUrl"]],
        [52, "f", [15, "__module_legacyUrls"]],
        [52, "g", [30, ["b", "gtm.referrer", 1], ["c"]]],
        [22, [28, [15, "g"]], [46, [36, ["d", [15, "g"]]]]],
        [
          38,
          [17, [15, "a"], "component"],
          [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
          [
            46,
            [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "C",
                    [7, [15, "g"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "E",
                    [7, [15, "g"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [
              5,
              [
                46,
                [
                  22,
                  [17, [15, "a"], "queryKey"],
                  [
                    46,
                    [
                      53,
                      [
                        36,
                        [
                          2,
                          [15, "f"],
                          "H",
                          [7, [15, "g"], [17, [15, "a"], "queryKey"]],
                        ],
                      ],
                    ],
                  ],
                ],
                [52, "h", ["e", [15, "g"]]],
                [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__gas",
        [46, "a"],
        [
          50,
          "d",
          [46, "e", "f", "g"],
          [
            43,
            [15, "e"],
            "fieldsToSet",
            [30, [17, [15, "e"], "fieldsToSet"], [7]],
          ],
          [52, "h", [16, [15, "e"], [15, "f"]]],
          [
            22,
            [21, [15, "h"], [44]],
            [
              46,
              [
                53,
                [
                  2,
                  [17, [15, "e"], "fieldsToSet"],
                  "push",
                  [7, [8, "fieldName", [15, "g"], "value", [15, "h"]]],
                ],
                [2, [15, "b"], "delete", [7, [15, "e"], [15, "f"]]],
              ],
            ],
          ],
        ],
        [52, "b", ["require", "Object"]],
        [52, "c", [8]],
        [
          65,
          "e",
          [2, [15, "b"], "entries", [7, [15, "a"]]],
          [
            46,
            [
              53,
              [52, "f", [16, [15, "e"], 0]],
              [
                22,
                [
                  30,
                  [20, [15, "f"], "function"],
                  [20, [15, "f"], "instance_name"],
                ],
                [46, [53, [43, [15, "c"], [15, "f"], [45]]]],
                [46, [53, [43, [15, "c"], [15, "f"], [16, [15, "e"], 1]]]],
              ],
            ],
          ],
        ],
        ["d", [15, "c"], "cookieDomain", "cookieDomain"],
        [
          65,
          "e",
          [2, [15, "b"], "keys", [7, [15, "c"]]],
          [
            46,
            [
              53,
              [
                43,
                [15, "c"],
                [0, "vtp_", [15, "e"]],
                [16, [15, "c"], [15, "e"]],
              ],
            ],
          ],
        ],
        [36, [15, "c"]],
      ],
      [
        50,
        "__googtag",
        [46, "a"],
        [
          50,
          "m",
          [46, "v", "w"],
          [
            66,
            "x",
            [2, [15, "b"], "keys", [7, [15, "w"]]],
            [46, [53, [43, [15, "v"], [15, "x"], [16, [15, "w"], [15, "x"]]]]],
          ],
        ],
        [
          50,
          "n",
          [46],
          [36, [7, [17, [15, "f"], "HU"], [17, [15, "f"], "IN"]]],
        ],
        [
          50,
          "o",
          [46, "v"],
          [52, "w", ["n"]],
          [
            65,
            "x",
            [15, "w"],
            [
              46,
              [
                53,
                [52, "y", [16, [15, "v"], [15, "x"]]],
                [22, [15, "y"], [46, [36, [15, "y"]]]],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "Object"]],
        [52, "c", ["require", "createArgumentsQueue"]],
        [52, "d", [15, "__module_gtag"]],
        [52, "e", ["require", "internal.gtagConfig"]],
        [52, "f", [15, "__module_gtagSchema"]],
        [52, "g", ["require", "getType"]],
        [52, "h", ["require", "internal.loadGoogleTag"]],
        [52, "i", ["require", "logToConsole"]],
        [52, "j", ["require", "makeNumber"]],
        [52, "k", ["require", "makeString"]],
        [52, "l", ["require", "makeTableMap"]],
        [52, "p", [30, [17, [15, "a"], "tagId"], ""]],
        [
          22,
          [
            30,
            [21, ["g", [15, "p"]], "string"],
            [24, [2, [15, "p"], "indexOf", [7, "-"]], 0],
          ],
          [
            46,
            [
              53,
              [
                "i",
                [
                  0,
                  "Invalid Measurement ID for the GA4 Configuration tag: ",
                  [15, "p"],
                ],
              ],
              [2, [15, "a"], "gtmOnFailure", [7]],
              [36],
            ],
          ],
        ],
        [52, "q", [30, [17, [15, "a"], "configSettingsVariable"], [8]]],
        [
          52,
          "r",
          [
            30,
            [
              "l",
              [30, [17, [15, "a"], "configSettingsTable"], [7]],
              "parameter",
              "parameterValue",
            ],
            [8],
          ],
        ],
        ["m", [15, "q"], [15, "r"]],
        [52, "s", [30, [17, [15, "a"], "eventSettingsVariable"], [8]]],
        [
          52,
          "t",
          [
            30,
            [
              "l",
              [30, [17, [15, "a"], "eventSettingsTable"], [7]],
              "parameter",
              "parameterValue",
            ],
            [8],
          ],
        ],
        ["m", [15, "s"], [15, "t"]],
        [52, "u", [15, "q"]],
        ["m", [15, "u"], [15, "s"]],
        [
          22,
          [
            30,
            [2, [15, "u"], "hasOwnProperty", [7, [17, [15, "f"], "JJ"]]],
            [17, [15, "a"], "userProperties"],
          ],
          [
            46,
            [
              53,
              [52, "v", [30, [16, [15, "u"], [17, [15, "f"], "JJ"]], [8]]],
              [
                "m",
                [15, "v"],
                [
                  30,
                  [
                    "l",
                    [30, [17, [15, "a"], "userProperties"], [7]],
                    "name",
                    "value",
                  ],
                  [8],
                ],
              ],
              [43, [15, "u"], [17, [15, "f"], "JJ"], [15, "v"]],
            ],
          ],
        ],
        [
          2,
          [15, "d"],
          "E",
          [
            7,
            [15, "u"],
            [17, [15, "d"], "B"],
            [
              51,
              "",
              [7, "v"],
              [
                36,
                [
                  39,
                  [20, "false", [2, ["k", [15, "v"]], "toLowerCase", [7]]],
                  false,
                  [28, [28, [15, "v"]]],
                ],
              ],
            ],
          ],
        ],
        [
          2,
          [15, "d"],
          "E",
          [
            7,
            [15, "u"],
            [17, [15, "d"], "D"],
            [51, "", [7, "v"], [36, ["j", [15, "v"]]]],
          ],
        ],
        ["h", [15, "p"], [8, "firstPartyUrl", ["o", [15, "u"]]]],
        ["e", [15, "p"], [15, "u"], [8, "noTargetGroup", true]],
        [2, [15, "a"], "gtmOnSuccess", [7]],
      ],
      [
        50,
        "__u",
        [46, "a"],
        [
          50,
          "k",
          [46, "l", "m"],
          [52, "n", [17, [15, "m"], "multiQueryKeys"]],
          [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
          [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
          [
            22,
            [20, [15, "o"], ""],
            [
              46,
              [
                53,
                [
                  52,
                  "r",
                  [
                    2,
                    [17, ["i", [15, "l"]], "search"],
                    "replace",
                    [7, "?", ""],
                  ],
                ],
                [36, [39, [1, [28, [15, "r"]], [15, "p"]], [44], [15, "r"]]],
              ],
            ],
          ],
          [41, "q"],
          [
            22,
            [15, "n"],
            [
              46,
              [
                53,
                [
                  22,
                  [20, ["e", [15, "o"]], "array"],
                  [46, [53, [3, "q", [15, "o"]]]],
                  [
                    46,
                    [
                      53,
                      [52, "r", ["c", "\\s+", "g"]],
                      [
                        3,
                        "q",
                        [
                          2,
                          [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]],
                          "split",
                          [7, ","],
                        ],
                      ],
                    ],
                  ],
                ],
              ],
            ],
            [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]],
          ],
          [
            65,
            "r",
            [15, "q"],
            [
              46,
              [
                53,
                [52, "s", [2, [15, "h"], "H", [7, [15, "l"], [15, "r"]]]],
                [
                  22,
                  [29, [15, "s"], [44]],
                  [
                    46,
                    [
                      53,
                      [
                        22,
                        [1, [15, "p"], [20, [15, "s"], ""]],
                        [46, [53, [6]]],
                      ],
                      [36, [15, "s"]],
                    ],
                  ],
                ],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getUrl"]],
        [52, "e", ["require", "getType"]],
        [52, "f", ["require", "makeString"]],
        [52, "g", ["require", "parseUrl"]],
        [52, "h", [15, "__module_legacyUrls"]],
        [52, "i", ["require", "internal.legacyParseUrl"]],
        [41, "j"],
        [
          22,
          [17, [15, "a"], "customUrlSource"],
          [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
          [46, [53, [3, "j", ["b", "gtm.url", 1]]]],
        ],
        [3, "j", [30, [15, "j"], ["d"]]],
        [
          38,
          [17, [15, "a"], "component"],
          [
            46,
            "PROTOCOL",
            "HOST",
            "PORT",
            "PATH",
            "EXTENSION",
            "QUERY",
            "FRAGMENT",
            "URL",
          ],
          [
            46,
            [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "C",
                    [7, [15, "j"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "E",
                    [7, [15, "j"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
            [5, [46, [36, ["k", [15, "j"], [15, "a"]]]]],
            [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__v",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getType"]],
        [52, "e", [17, [15, "a"], "name"]],
        [
          22,
          [30, [28, [15, "e"]], [21, ["d", [15, "e"]], "string"]],
          [46, [36, false]],
        ],
        [52, "f", [2, [15, "e"], "replace", [7, ["c", "\\\\.", "g"], "."]]],
        [
          52,
          "g",
          ["b", [15, "f"], [30, [17, [15, "a"], "dataLayerVersion"], 1]],
        ],
        [
          36,
          [
            39,
            [21, [15, "g"], [44]],
            [15, "g"],
            [17, [15, "a"], "defaultValue"],
          ],
        ],
      ],
      [
        52,
        "__module_gtagSchema",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", "ad_personalization"],
                [52, "c", "ad_storage"],
                [52, "d", "ad_user_data"],
                [52, "e", "consent_updated"],
                [52, "f", "app_remove"],
                [52, "g", "app_store_refund"],
                [52, "h", "app_store_subscription_cancel"],
                [52, "i", "app_store_subscription_convert"],
                [52, "j", "app_store_subscription_renew"],
                [52, "k", "conversion"],
                [52, "l", "purchase"],
                [52, "m", "first_open"],
                [52, "n", "first_visit"],
                [52, "o", "gtag.config"],
                [52, "p", "in_app_purchase"],
                [52, "q", "page_view"],
                [52, "r", "session_start"],
                [52, "s", "user_engagement"],
                [52, "t", "ads_data_redaction"],
                [52, "u", "allow_ad_personalization_signals"],
                [52, "v", "allow_custom_scripts"],
                [52, "w", "allow_direct_google_requests"],
                [52, "x", "allow_enhanced_conversions"],
                [52, "y", "allow_google_signals"],
                [52, "z", "auid"],
                [52, "aA", "aw_remarketing_only"],
                [52, "aB", "discount"],
                [52, "aC", "aw_feed_country"],
                [52, "aD", "aw_feed_language"],
                [52, "aE", "items"],
                [52, "aF", "aw_merchant_id"],
                [52, "aG", "aw_basket_type"],
                [52, "aH", "client_id"],
                [52, "aI", "conversion_cookie_prefix"],
                [52, "aJ", "conversion_id"],
                [52, "aK", "conversion_linker"],
                [52, "aL", "conversion_api"],
                [52, "aM", "cookie_deprecation"],
                [52, "aN", "cookie_expires"],
                [52, "aO", "cookie_prefix"],
                [52, "aP", "cookie_update"],
                [52, "aQ", "country"],
                [52, "aR", "currency"],
                [52, "aS", "customer_buyer_stage"],
                [52, "aT", "customer_lifetime_value"],
                [52, "aU", "customer_loyalty"],
                [52, "aV", "customer_ltv_bucket"],
                [52, "aW", "debug_mode"],
                [52, "aX", "developer_id"],
                [52, "aY", "shipping"],
                [52, "aZ", "engagement_time_msec"],
                [52, "bA", "estimated_delivery_date"],
                [52, "bB", "event_developer_id_string"],
                [52, "bC", "event"],
                [52, "bD", "event_timeout"],
                [52, "bE", "first_party_collection"],
                [52, "bF", "match_id"],
                [52, "bG", "gdpr_applies"],
                [52, "bH", "google_analysis_params"],
                [52, "bI", "_google_ng"],
                [52, "bJ", "gpp_sid"],
                [52, "bK", "gpp_string"],
                [52, "bL", "gsa_experiment_id"],
                [52, "bM", "gtag_event_feature_usage"],
                [52, "bN", "iframe_state"],
                [52, "bO", "ignore_referrer"],
                [52, "bP", "is_passthrough"],
                [52, "bQ", "language"],
                [52, "bR", "merchant_feed_label"],
                [52, "bS", "merchant_feed_language"],
                [52, "bT", "merchant_id"],
                [52, "bU", "new_customer"],
                [52, "bV", "page_hostname"],
                [52, "bW", "page_path"],
                [52, "bX", "page_referrer"],
                [52, "bY", "page_title"],
                [52, "bZ", "_platinum_request_status"],
                [52, "cA", "quantity"],
                [52, "cB", "restricted_data_processing"],
                [52, "cC", "screen_resolution"],
                [52, "cD", "send_page_view"],
                [52, "cE", "server_container_url"],
                [52, "cF", "session_duration"],
                [52, "cG", "session_engaged_time"],
                [52, "cH", "session_id"],
                [52, "cI", "_shared_user_id"],
                [52, "cJ", "delivery_postal_code"],
                [52, "cK", "testonly"],
                [52, "cL", "topmost_url"],
                [52, "cM", "transaction_id"],
                [52, "cN", "transaction_id_source"],
                [52, "cO", "transport_url"],
                [52, "cP", "update"],
                [52, "cQ", "_user_agent_architecture"],
                [52, "cR", "_user_agent_bitness"],
                [52, "cS", "_user_agent_full_version_list"],
                [52, "cT", "_user_agent_mobile"],
                [52, "cU", "_user_agent_model"],
                [52, "cV", "_user_agent_platform"],
                [52, "cW", "_user_agent_platform_version"],
                [52, "cX", "_user_agent_wow64"],
                [52, "cY", "user_data"],
                [52, "cZ", "user_data_auto_latency"],
                [52, "dA", "user_data_auto_meta"],
                [52, "dB", "user_data_auto_multi"],
                [52, "dC", "user_data_auto_selectors"],
                [52, "dD", "user_data_auto_status"],
                [52, "dE", "user_data_mode"],
                [52, "dF", "user_id"],
                [52, "dG", "user_properties"],
                [52, "dH", "us_privacy_string"],
                [52, "dI", "value"],
                [52, "dJ", "_fpm_parameters"],
                [52, "dK", "_host_name"],
                [52, "dL", "_in_page_command"],
                [52, "dM", "_measurement_type"],
                [52, "dN", "non_personalized_ads"],
                [52, "dO", "conversion_label"],
                [52, "dP", "page_location"],
                [52, "dQ", "_extracted_data"],
                [52, "dR", "global_developer_id_string"],
                [52, "dS", "tc_privacy_string"],
                [
                  36,
                  [
                    8,
                    "A",
                    [15, "b"],
                    "B",
                    [15, "c"],
                    "C",
                    [15, "d"],
                    "F",
                    [15, "e"],
                    "H",
                    [15, "f"],
                    "I",
                    [15, "g"],
                    "J",
                    [15, "h"],
                    "K",
                    [15, "i"],
                    "L",
                    [15, "j"],
                    "N",
                    [15, "k"],
                    "Z",
                    [15, "l"],
                    "AE",
                    [15, "m"],
                    "AF",
                    [15, "n"],
                    "AG",
                    [15, "o"],
                    "AI",
                    [15, "p"],
                    "AJ",
                    [15, "q"],
                    "AL",
                    [15, "r"],
                    "AP",
                    [15, "s"],
                    "AZ",
                    [15, "t"],
                    "BG",
                    [15, "u"],
                    "BH",
                    [15, "v"],
                    "BI",
                    [15, "w"],
                    "BK",
                    [15, "x"],
                    "BL",
                    [15, "y"],
                    "BR",
                    [15, "z"],
                    "BV",
                    [15, "aA"],
                    "BW",
                    [15, "aB"],
                    "BX",
                    [15, "aC"],
                    "BY",
                    [15, "aD"],
                    "BZ",
                    [15, "aE"],
                    "CA",
                    [15, "aF"],
                    "CB",
                    [15, "aG"],
                    "CJ",
                    [15, "aH"],
                    "CO",
                    [15, "aI"],
                    "CP",
                    [15, "aJ"],
                    "JX",
                    [15, "dO"],
                    "CQ",
                    [15, "aK"],
                    "CS",
                    [15, "aL"],
                    "CT",
                    [15, "aM"],
                    "CV",
                    [15, "aN"],
                    "CZ",
                    [15, "aO"],
                    "DA",
                    [15, "aP"],
                    "DB",
                    [15, "aQ"],
                    "DC",
                    [15, "aR"],
                    "DD",
                    [15, "aS"],
                    "DE",
                    [15, "aT"],
                    "DF",
                    [15, "aU"],
                    "DG",
                    [15, "aV"],
                    "DK",
                    [15, "aW"],
                    "DL",
                    [15, "aX"],
                    "DX",
                    [15, "aY"],
                    "DZ",
                    [15, "aZ"],
                    "ED",
                    [15, "bA"],
                    "EG",
                    [15, "bB"],
                    "EI",
                    [15, "bC"],
                    "EK",
                    [15, "bD"],
                    "JZ",
                    [15, "dQ"],
                    "EP",
                    [15, "bE"],
                    "EY",
                    [15, "bF"],
                    "FI",
                    [15, "bG"],
                    "KA",
                    [15, "dR"],
                    "FM",
                    [15, "bH"],
                    "FN",
                    [15, "bI"],
                    "FQ",
                    [15, "bJ"],
                    "FR",
                    [15, "bK"],
                    "FT",
                    [15, "bL"],
                    "FU",
                    [15, "bM"],
                    "FW",
                    [15, "bN"],
                    "FX",
                    [15, "bO"],
                    "GC",
                    [15, "bP"],
                    "GE",
                    [15, "bQ"],
                    "GL",
                    [15, "bR"],
                    "GM",
                    [15, "bS"],
                    "GN",
                    [15, "bT"],
                    "GR",
                    [15, "bU"],
                    "GU",
                    [15, "bV"],
                    "JY",
                    [15, "dP"],
                    "GV",
                    [15, "bW"],
                    "GW",
                    [15, "bX"],
                    "GX",
                    [15, "bY"],
                    "HF",
                    [15, "bZ"],
                    "HH",
                    [15, "cA"],
                    "HL",
                    [15, "cB"],
                    "HP",
                    [15, "cC"],
                    "HS",
                    [15, "cD"],
                    "HU",
                    [15, "cE"],
                    "HW",
                    [15, "cF"],
                    "HY",
                    [15, "cG"],
                    "HZ",
                    [15, "cH"],
                    "IB",
                    [15, "cI"],
                    "IC",
                    [15, "cJ"],
                    "KB",
                    [15, "dS"],
                    "IG",
                    [15, "cK"],
                    "II",
                    [15, "cL"],
                    "IL",
                    [15, "cM"],
                    "IM",
                    [15, "cN"],
                    "IN",
                    [15, "cO"],
                    "IP",
                    [15, "cP"],
                    "IS",
                    [15, "cQ"],
                    "IT",
                    [15, "cR"],
                    "IU",
                    [15, "cS"],
                    "IV",
                    [15, "cT"],
                    "IW",
                    [15, "cU"],
                    "IX",
                    [15, "cV"],
                    "IY",
                    [15, "cW"],
                    "IZ",
                    [15, "cX"],
                    "JA",
                    [15, "cY"],
                    "JB",
                    [15, "cZ"],
                    "JC",
                    [15, "dA"],
                    "JD",
                    [15, "dB"],
                    "JE",
                    [15, "dC"],
                    "JF",
                    [15, "dD"],
                    "JG",
                    [15, "dE"],
                    "JI",
                    [15, "dF"],
                    "JJ",
                    [15, "dG"],
                    "JL",
                    [15, "dH"],
                    "JM",
                    [15, "dI"],
                    "JO",
                    [15, "dJ"],
                    "JP",
                    [15, "dK"],
                    "JQ",
                    [15, "dL"],
                    "JT",
                    [15, "dM"],
                    "JU",
                    [15, "dN"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_metadataSchema",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", "accept_by_default"],
                [52, "c", "allow_ad_personalization"],
                [52, "d", "consent_state"],
                [52, "e", "consent_updated"],
                [52, "f", "conversion_linker_enabled"],
                [52, "g", "cookie_options"],
                [52, "h", "em_event"],
                [52, "i", "event_start_timestamp_ms"],
                [52, "j", "event_usage"],
                [52, "k", "ga4_collection_subdomain"],
                [52, "l", "handle_internally"],
                [52, "m", "hit_type"],
                [52, "n", "hit_type_override"],
                [52, "o", "is_conversion"],
                [52, "p", "is_external_event"],
                [52, "q", "is_first_visit"],
                [52, "r", "is_first_visit_conversion"],
                [52, "s", "is_fpm_encryption"],
                [52, "t", "is_fpm_split"],
                [52, "u", "is_gcp_conversion"],
                [52, "v", "is_google_signals_allowed"],
                [52, "w", "is_server_side_destination"],
                [52, "x", "is_session_start"],
                [52, "y", "is_session_start_conversion"],
                [52, "z", "is_sgtm_ga_ads_conversion_study_control_group"],
                [52, "aA", "is_sgtm_prehit"],
                [52, "aB", "is_split_conversion"],
                [52, "aC", "is_syn"],
                [52, "aD", "is_test_event"],
                [52, "aE", "prehit_for_retry"],
                [52, "aF", "redact_ads_data"],
                [52, "aG", "redact_click_ids"],
                [52, "aH", "send_ccm_parallel_ping"],
                [52, "aI", "send_user_data_hit"],
                [52, "aJ", "speculative"],
                [52, "aK", "syn_or_mod"],
                [52, "aL", "transient_ecsid"],
                [52, "aM", "transmission_type"],
                [52, "aN", "user_data"],
                [52, "aO", "user_data_from_automatic"],
                [52, "aP", "user_data_from_automatic_getter"],
                [52, "aQ", "user_data_from_code"],
                [52, "aR", "user_data_from_manual"],
                [
                  36,
                  [
                    8,
                    "A",
                    [15, "b"],
                    "E",
                    [15, "c"],
                    "K",
                    [15, "d"],
                    "L",
                    [15, "e"],
                    "M",
                    [15, "f"],
                    "N",
                    [15, "g"],
                    "T",
                    [15, "h"],
                    "Z",
                    [15, "i"],
                    "AA",
                    [15, "j"],
                    "AI",
                    [15, "k"],
                    "AL",
                    [15, "l"],
                    "AM",
                    [15, "m"],
                    "AN",
                    [15, "n"],
                    "AR",
                    [15, "o"],
                    "AU",
                    [15, "p"],
                    "AW",
                    [15, "q"],
                    "AX",
                    [15, "r"],
                    "AZ",
                    [15, "s"],
                    "BA",
                    [15, "t"],
                    "BB",
                    [15, "u"],
                    "BC",
                    [15, "v"],
                    "BH",
                    [15, "w"],
                    "BI",
                    [15, "x"],
                    "BJ",
                    [15, "y"],
                    "BK",
                    [15, "z"],
                    "BL",
                    [15, "aA"],
                    "BN",
                    [15, "aB"],
                    "BO",
                    [15, "aC"],
                    "BP",
                    [15, "aD"],
                    "BV",
                    [15, "aE"],
                    "BY",
                    [15, "aF"],
                    "BZ",
                    [15, "aG"],
                    "CB",
                    [15, "aH"],
                    "CF",
                    [15, "aI"],
                    "CI",
                    [15, "aJ"],
                    "CL",
                    [15, "aK"],
                    "CM",
                    [15, "aL"],
                    "CN",
                    [15, "aM"],
                    "CO",
                    [15, "aN"],
                    "CP",
                    [15, "aO"],
                    "CQ",
                    [15, "aP"],
                    "CR",
                    [15, "aQ"],
                    "CS",
                    [15, "aR"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_featureFlags",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [52, "b", 33],
                [52, "c", 44],
                [52, "d", 45],
                [52, "e", 46],
                [52, "f", 47],
                [52, "g", 113],
                [52, "h", 129],
                [52, "i", 174],
                [52, "j", 178],
                [52, "k", 243],
                [52, "l", 252],
                [52, "m", 276],
                [
                  36,
                  [
                    8,
                    "CD",
                    [15, "l"],
                    "L",
                    [15, "b"],
                    "P",
                    [15, "c"],
                    "Q",
                    [15, "d"],
                    "R",
                    [15, "e"],
                    "S",
                    [15, "f"],
                    "BE",
                    [15, "i"],
                    "BF",
                    [15, "j"],
                    "CR",
                    [15, "m"],
                    "AL",
                    [15, "g"],
                    "CB",
                    [15, "k"],
                    "AR",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_legacyUrls",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "h",
                  [46, "p"],
                  [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                  [
                    36,
                    [
                      39,
                      [23, [15, "q"], 0],
                      [15, "p"],
                      [2, [15, "p"], "substring", [7, 0, [15, "q"]]],
                    ],
                  ],
                ],
                [
                  50,
                  "i",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                  [
                    36,
                    [
                      39,
                      [15, "q"],
                      [2, [15, "q"], "replace", [7, ":", ""]],
                      "",
                    ],
                  ],
                ],
                [
                  50,
                  "j",
                  [46, "p", "q"],
                  [41, "r"],
                  [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                  [22, [28, [15, "r"]], [46, [36, ""]]],
                  [52, "s", ["b", ":[0-9]+"]],
                  [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                  [
                    22,
                    [15, "q"],
                    [
                      46,
                      [
                        53,
                        [52, "t", ["b", "^www\\d*\\."]],
                        [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                        [
                          22,
                          [1, [15, "u"], [16, [15, "u"], 0]],
                          [
                            46,
                            [
                              3,
                              "r",
                              [
                                2,
                                [15, "r"],
                                "substring",
                                [7, [17, [16, [15, "u"], 0], "length"]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "r"]],
                ],
                [
                  50,
                  "k",
                  [46, "p"],
                  [52, "q", ["e", [15, "p"]]],
                  [41, "r"],
                  [3, "r", ["f", [17, [15, "q"], "port"]]],
                  [
                    22,
                    [28, [15, "r"]],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [20, [17, [15, "q"], "protocol"], "http:"],
                          [46, [53, [3, "r", 80]]],
                          [
                            46,
                            [
                              22,
                              [20, [17, [15, "q"], "protocol"], "https:"],
                              [46, [53, [3, "r", 443]]],
                              [46, [53, [3, "r", ""]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, ["g", [15, "r"]]],
                ],
                [
                  50,
                  "l",
                  [46, "p", "q"],
                  [52, "r", ["e", [15, "p"]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [
                        20,
                        [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]],
                        0,
                      ],
                      [17, [15, "r"], "pathname"],
                      [0, "/", [17, [15, "r"], "pathName"]],
                    ],
                  ],
                  [
                    22,
                    [20, ["d", [15, "q"]], "array"],
                    [
                      46,
                      [
                        53,
                        [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                        [
                          22,
                          [
                            19,
                            [
                              2,
                              [15, "q"],
                              "indexOf",
                              [
                                7,
                                [
                                  16,
                                  [15, "t"],
                                  [37, [17, [15, "t"], "length"], 1],
                                ],
                              ],
                            ],
                            0,
                          ],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "t"],
                                [37, [17, [15, "t"], "length"], 1],
                                "",
                              ],
                              [3, "s", [2, [15, "t"], "join", [7, "/"]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "s"]],
                ],
                [
                  50,
                  "m",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                  [52, "r", [2, [15, "q"], "split", [7, "."]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [18, [17, [15, "r"], "length"], 1],
                      [16, [15, "r"], [37, [17, [15, "r"], "length"], 1]],
                      "",
                    ],
                  ],
                  [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]],
                ],
                [
                  50,
                  "n",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "hash"]],
                  [36, [2, [15, "q"], "replace", [7, "#", ""]]],
                ],
                [
                  50,
                  "o",
                  [46, "p", "q"],
                  [
                    50,
                    "s",
                    [46, "t"],
                    [
                      36,
                      [
                        "c",
                        [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]],
                      ],
                    ],
                  ],
                  [
                    52,
                    "r",
                    [
                      2,
                      [17, ["e", [15, "p"]], "search"],
                      "replace",
                      [7, "?", ""],
                    ],
                  ],
                  [
                    65,
                    "t",
                    [2, [15, "r"], "split", [7, "&"]],
                    [
                      46,
                      [
                        53,
                        [52, "u", [2, [15, "t"], "split", [7, "="]]],
                        [
                          22,
                          [21, ["s", [16, [15, "u"], 0]], [15, "q"]],
                          [46, [6]],
                        ],
                        [
                          36,
                          [
                            "s",
                            [
                              2,
                              [2, [15, "u"], "slice", [7, 1]],
                              "join",
                              [7, "="],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36],
                ],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "decodeUriComponent"]],
                [52, "d", ["require", "getType"]],
                [52, "e", ["require", "internal.legacyParseUrl"]],
                [52, "f", ["require", "makeNumber"]],
                [52, "g", ["require", "makeString"]],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "m"],
                    "H",
                    [15, "o"],
                    "G",
                    [15, "n"],
                    "C",
                    [15, "j"],
                    "E",
                    [15, "l"],
                    "D",
                    [15, "k"],
                    "B",
                    [15, "i"],
                    "A",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
      [
        52,
        "__module_gtag",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "n",
                  [46, "r", "s", "t"],
                  [
                    65,
                    "u",
                    [15, "s"],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [2, [15, "r"], "hasOwnProperty", [7, [15, "u"]]],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "r"],
                                [15, "u"],
                                ["t", [16, [15, "r"], [15, "u"]]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                ],
                [
                  50,
                  "o",
                  [46, "r", "s"],
                  [
                    "n",
                    [15, "r"],
                    [15, "s"],
                    [
                      51,
                      "",
                      [7, "t"],
                      [
                        36,
                        [
                          39,
                          [
                            20,
                            "false",
                            [2, ["e", [15, "t"]], "toLowerCase", [7]],
                          ],
                          false,
                          [28, [28, [15, "t"]]],
                        ],
                      ],
                    ],
                  ],
                ],
                [
                  50,
                  "p",
                  [46, "r", "s"],
                  ["n", [15, "r"], [15, "s"], [15, "d"]],
                ],
                [
                  50,
                  "q",
                  [46, "r", "s"],
                  [52, "t", ["h"]],
                  [
                    22,
                    [
                      1,
                      [15, "t"],
                      [18, [2, [15, "t"], "indexOf", [7, [15, "s"]]], [27, 1]],
                    ],
                    [46, [53, [43, [15, "r"], [17, [15, "i"], "AL"], true]]],
                  ],
                ],
                [52, "b", ["require", "Object"]],
                [52, "c", [15, "__module_gtagSchema"]],
                [52, "d", ["require", "makeNumber"]],
                [52, "e", ["require", "makeString"]],
                [52, "f", ["require", "internal.isFeatureEnabled"]],
                [52, "g", [15, "__module_featureFlags"]],
                [52, "h", ["require", "internal.getDestinationIds"]],
                [52, "i", [15, "__module_metadataSchema"]],
                [
                  52,
                  "j",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "BG"],
                        [17, [15, "c"], "BI"],
                        [17, [15, "c"], "BL"],
                        [17, [15, "c"], "DA"],
                        [17, [15, "c"], "FX"],
                        [17, [15, "c"], "IP"],
                        [17, [15, "c"], "EP"],
                        [17, [15, "c"], "HS"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "k",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "BG"],
                        [17, [15, "c"], "BI"],
                        [17, [15, "c"], "BL"],
                        [17, [15, "c"], "DA"],
                        [17, [15, "c"], "FX"],
                        [17, [15, "c"], "IP"],
                        [17, [15, "c"], "EP"],
                        [17, [15, "c"], "HS"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "l",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "CV"],
                        [17, [15, "c"], "EK"],
                        [17, [15, "c"], "HW"],
                        [17, [15, "c"], "HY"],
                        [17, [15, "c"], "DZ"],
                      ],
                    ],
                  ],
                ],
                [
                  52,
                  "m",
                  [
                    2,
                    [15, "b"],
                    "freeze",
                    [
                      7,
                      [
                        7,
                        [17, [15, "c"], "CV"],
                        [17, [15, "c"], "EK"],
                        [17, [15, "c"], "HW"],
                        [17, [15, "c"], "HY"],
                        [17, [15, "c"], "DZ"],
                      ],
                    ],
                  ],
                ],
                [
                  36,
                  [
                    8,
                    "B",
                    [15, "k"],
                    "D",
                    [15, "m"],
                    "A",
                    [15, "j"],
                    "C",
                    [15, "l"],
                    "F",
                    [15, "o"],
                    "G",
                    [15, "p"],
                    "E",
                    [15, "n"],
                    "H",
                    [15, "q"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
    ],
    entities: {
      __e: { 2: true, 5: true },
      __f: { 2: true, 5: true },
      __gas: { 5: true },
      __googtag: { 1: 10, 5: true },
      __u: { 2: true, 5: true },
      __v: { 2: true, 5: true },
    },
    blob: {
      1: "2",
      10: "GTM-NBDJ387",
      14: "6241",
      15: "1",
      16: "ChEIgOKbzAYQ6aO/gdGii7vYARIcAABC3EPr6Qf8HfeXxXzhz0Y1oxwvHDKaEXdwQhoCGgo=",
      19: "dataLayer",
      20: "",
      21: "www.googletagmanager.com",
      22: "eyIwIjoiSU4iLCIxIjoiSU4tQlIiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jby5pbiIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiIsIjgiOiIifQ",
      23: "google.tagmanager.debugui2.queue",
      24: "tagassistant.google.com",
      27: 0.005,
      3: "www.googletagmanager.com",
      30: "IN",
      31: "IN-BR",
      32: true,
      36: "https://adservice.google.com/pagead/regclk",
      37: "__TAGGY_INSTALLED",
      38: "cct.google",
      39: "googTaggyReferrer",
      40: "https://cct.google/taggy/agent.js",
      41: "google.tagmanager.ta.prodqueue",
      42: 0.01,
      43: '{"keys":[{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BOGL9Y2o/MQJk4okMBZIJXzTonoC0fk617TINTXhsbHfB3RMc4sBc0ZSP+HLVK3AtN1I4kPdHE3+dAoNm34nSJg=","version":0},"id":"f074c16a-c230-4ad6-815d-60589c82acd4"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BFJVOUwvyewmHiWzSpua/g2QNeurrAUTXIkCW2THj8lYzCwL8RZyt4JIA/HL0unOc3QWM34Wu5thrPrB8knz+TQ=","version":0},"id":"aa6d91e6-d754-4784-b58c-38636aa3bb30"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BPdU47pK0MAWNNvGxsYHbeIUhrc/E16BrXdZszgovJ41kxFlnKRV21oi0lgKEB4SkluGWHwdDFmsSg3deMfZ7fo=","version":0},"id":"9ae5b97b-d9b8-4bcd-9c82-307a8fdb2874"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BLUpqaAlXeuZlutRJOL02fMYPhLhfXXk1I4f6Fa1bWZ0eDvcH0u8h0Ar+e9/yxi90bPnfwAMHe43qAey1bgzcLk=","version":0},"id":"61a6cc95-68a9-4c32-8403-8b9e6359738f"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BKagiEMjVHXIqCI95bkoEGPCbkURYWFUcjvoypPOPcWm4b3aDBrVZC+T3vCq64DMuP7X0S3AMQvoqqyibavnfJo=","version":0},"id":"23aeb76c-ec36-4f37-bbd4-6ba1d81f7c4e"}]}',
      44: "102015666~103116026~103200004~104684208~104684211~116185181~116185182~116988315",
      46: {
        1: "1000",
        10: "61k0",
        11: "61k0",
        14: "1000",
        16: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        17: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        2: "9",
        20: "5000",
        21: "5000",
        22: "4.2.0",
        23: "0.0.0",
        25: "1",
        26: "4000",
        27: "100",
        3: "5",
        4: "ad_storage|analytics_storage|ad_user_data|ad_personalization",
        44: "15000",
        48: "30000",
        5: "ad_storage|analytics_storage|ad_user_data",
        6: "1",
        62: "A6ONHRY7/bvBro+IMZd/a6LNjn7SSv999SkN/hFAE9L6vMr34dNgfdSVdYmv4U+NHZg1sxd38RtciRpRUtIRPgQAAACCeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiU2hhcmVkV29ya2VyRXh0ZW5kZWRMaWZldGltZSIsImV4cGlyeSI6MTc3NjcyOTYwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
        7: "10",
      },
      48: true,
      5: "GTM-NBDJ387",
      55: ["GTM-NBDJ387"],
      56: [
        { 1: 403, 3: 0.5, 4: 115938465, 5: 115938466, 6: 0, 7: 2 },
        { 1: 404, 3: 0.5, 4: 115938468, 5: 115938469, 6: 0, 7: 1 },
        { 1: 454, 2: true },
        { 1: 448, 2: true },
        { 1: 453, 2: true },
        { 1: 433, 2: true },
        { 1: 430, 2: true },
        { 1: 457, 3: 0.1, 4: 117231333, 5: 117231334, 6: 117231354, 7: 1 },
        { 1: 429, 2: true },
        { 1: 437, 2: true },
        { 1: 409, 2: true },
        { 1: 456, 2: true },
        { 1: 455, 2: true },
        { 1: 447, 2: true },
        { 1: 405, 2: true },
        { 1: 407, 2: true },
        { 1: 439, 3: 0.001, 4: 117416194, 5: 117416195, 6: 0, 7: 1 },
        { 1: 417, 2: true },
        { 1: 420, 2: true },
        { 1: 451, 3: 0.1, 4: 117127390, 5: 117127391, 6: 117127392, 7: 1 },
        { 1: 450, 3: 0.01, 4: 117227714, 5: 117227715, 6: 117227716, 7: 3 },
        { 1: 444, 3: 0.01, 4: 117384405, 5: 117384406, 6: 0, 7: 1 },
        { 1: 443, 3: 0.001, 4: 117292734, 5: 117292735, 6: 117292736, 7: 3 },
        { 1: 426, 2: true },
        { 1: 460, 3: 0.001, 4: 117395003, 5: 117395004, 6: 117395005, 7: 1 },
        { 1: 406, 2: true },
        { 1: 449, 2: true },
        { 1: 414, 2: true },
        { 1: 415, 2: true },
        { 1: 461, 2: true },
        { 1: 423, 3: 0.01, 4: 116491844, 5: 116491845, 6: 116491846, 7: 2 },
        { 1: 412, 2: true },
        { 1: 441, 2: true },
      ],
      59: ["GTM-NBDJ387"],
      6: "119110468",
    },
    permissions: {
      __e: {
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __f: {
        read_data_layer: { keyPatterns: ["gtm.referrer"] },
        get_referrer: { urlParts: "any" },
      },
      __gas: {},
      __googtag: {
        logging: { environments: "debug" },
        access_globals: {
          keys: [
            { key: "gtag", read: true, write: true, execute: true },
            { key: "dataLayer", read: true, write: true, execute: false },
          ],
        },
        configure_google_tags: { allowedTagIds: "any" },
        load_google_tags: {
          allowedTagIds: "any",
          allowFirstPartyUrls: true,
          allowedFirstPartyUrls: "any",
        },
      },
      __u: {
        read_data_layer: { keyPatterns: ["gtm.url"] },
        get_url: { urlParts: "any" },
      },
      __v: { read_data_layer: { allowedKeys: "any" } },
    },

    security_groups: {
      google: ["__e", "__f", "__gas", "__googtag", "__u", "__v"],
    },
  };

  var k,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    da = function (a) {
      for (
        var b = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ],
          c = 0;
        c < b.length;
        ++c
      ) {
        var d = b[c];
        if (d && d.Math == Math) return d;
      }
      throw Error("Cannot find global object");
    },
    ha = da(this),
    ia = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    ja = {},
    na = {},
    oa = function (a, b, c) {
      if (!c || a != null) {
        var d = na[b];
        if (d == null) return a[b];
        var e = a[d];
        return e !== void 0 ? e : a[b];
      }
    },
    ra = function (a, b, c) {
      if (b)
        a: {
          var d = a.split("."),
            e = d.length === 1,
            f = d[0],
            g;
          !e && f in ja ? (g = ja) : (g = ha);
          for (var h = 0; h < d.length - 1; h++) {
            var l = d[h];
            if (!(l in g)) break a;
            g = g[l];
          }
          var n = d[d.length - 1],
            p = ia && c === "es6" ? g[n] : null,
            q = b(p);
          if (q != null)
            if (e) ba(ja, n, { configurable: !0, writable: !0, value: q });
            else if (q !== p) {
              if (na[n] === void 0) {
                var r = (Math.random() * 1e9) >>> 0;
                na[n] = ia ? ha.Symbol(n) : "$jscp$" + r + "$" + n;
              }
              ba(g, na[n], { configurable: !0, writable: !0, value: q });
            }
        }
    },
    sa;
  if (ia && typeof Object.setPrototypeOf == "function")
    sa = Object.setPrototypeOf;
  else {
    var ta;
    a: {
      var ua = { a: !0 },
        va = {};
      try {
        va.__proto__ = ua;
        ta = va.a;
        break a;
      } catch (a) {}
      ta = !1;
    }
    sa = ta
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var wa = sa,
    xa = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (wa) wa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.vs = b.prototype;
    },
    ya = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    m = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: ya(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    za = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    Aa = function (a) {
      return a instanceof Array ? a : za(m(a));
    },
    Ca = function (a) {
      return Ba(a, a);
    },
    Ba = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    Da =
      ia && typeof oa(Object, "assign") == "function"
        ? oa(Object, "assign")
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d)
                for (var e in d)
                  Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  ra(
    "Object.assign",
    function (a) {
      return a || Da;
    },
    "es6",
  );
  var Ea = function (a) {
      if (!(a instanceof Object))
        throw new TypeError("Iterator result " + a + " is not an object");
    },
    Ga = function () {
      this.fa = !1;
      this.T = null;
      this.ma = void 0;
      this.D = 1;
      this.N = this.V = 0;
      this.rb = this.J = null;
    },
    Ha = function (a) {
      if (a.fa) throw new TypeError("Generator is already running");
      a.fa = !0;
    };
  Ga.prototype.Sa = function (a) {
    this.ma = a;
  };
  var Ia = function (a, b) {
    a.J = { yn: b, isException: !0 };
    a.D = a.V || a.N;
  };
  Ga.prototype.getNextAddressJsc = function () {
    return this.D;
  };
  Ga.prototype.getYieldResultJsc = function () {
    return this.ma;
  };
  Ga.prototype.return = function (a) {
    this.J = { return: a };
    this.D = this.N;
  };
  Ga.prototype["return"] = Ga.prototype.return;
  Ga.prototype.ij = function (a) {
    this.J = { Yc: a };
    this.D = this.N;
  };
  Ga.prototype.jumpThroughFinallyBlocks = Ga.prototype.ij;
  Ga.prototype.Xb = function (a, b) {
    this.D = b;
    return { value: a };
  };
  Ga.prototype.yield = Ga.prototype.Xb;
  Ga.prototype.wq = function (a, b) {
    var c = m(a),
      d = c.next();
    Ea(d);
    if (d.done) ((this.ma = d.value), (this.D = b));
    else return ((this.T = c), this.Xb(d.value, b));
  };
  Ga.prototype.yieldAll = Ga.prototype.wq;
  Ga.prototype.Yc = function (a) {
    this.D = a;
  };
  Ga.prototype.jumpTo = Ga.prototype.Yc;
  Ga.prototype.jj = function () {
    this.D = 0;
  };
  Ga.prototype.jumpToEnd = Ga.prototype.jj;
  Ga.prototype.nq = function (a, b) {
    this.V = a;
    b != void 0 && (this.N = b);
  };
  Ga.prototype.setCatchFinallyBlocks = Ga.prototype.nq;
  Ga.prototype.jg = function (a) {
    this.V = 0;
    this.N = a || 0;
  };
  Ga.prototype.setFinallyBlock = Ga.prototype.jg;
  Ga.prototype.kj = function (a, b) {
    this.D = a;
    this.V = b || 0;
  };
  Ga.prototype.leaveTryBlock = Ga.prototype.kj;
  Ga.prototype.gj = function (a) {
    this.V = a || 0;
    var b = this.J.yn;
    this.J = null;
    return b;
  };
  Ga.prototype.enterCatchBlock = Ga.prototype.gj;
  Ga.prototype.Uc = function (a, b, c) {
    c ? (this.rb[c] = this.J) : (this.rb = [this.J]);
    this.V = a || 0;
    this.N = b || 0;
  };
  Ga.prototype.enterFinallyBlock = Ga.prototype.Uc;
  Ga.prototype.Md = function (a, b) {
    var c = this.rb.splice(b || 0)[0],
      d = (this.J = this.J || c);
    d
      ? d.isException
        ? (this.D = this.V || this.N)
        : d.Yc != void 0 && this.N < d.Yc
          ? ((this.D = d.Yc), (this.J = null))
          : (this.D = this.N)
      : (this.D = a);
  };
  Ga.prototype.leaveFinallyBlock = Ga.prototype.Md;
  Ga.prototype.Ld = function (a) {
    return new Ja(a);
  };
  Ga.prototype.forIn = Ga.prototype.Ld;
  var Ja = function (a) {
    this.J = a;
    this.D = [];
    for (var b in a) this.D.push(b);
    this.D.reverse();
  };
  Ja.prototype.Dn = function () {
    for (; this.D.length > 0; ) {
      var a = this.D.pop();
      if (a in this.J) return a;
    }
    return null;
  };
  Ja.prototype.getNext = Ja.prototype.Dn;
  var Ka = function (a) {
      this.D = new Ga();
      this.J = a;
    },
    Na = function (a, b) {
      Ha(a.D);
      var c = a.D.T;
      if (c)
        return La(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.D.return,
        );
      a.D.return(b);
      return Ma(a);
    },
    La = function (a, b, c, d) {
      try {
        var e = b.call(a.D.T, c);
        Ea(e);
        if (!e.done) return ((a.D.fa = !1), e);
        var f = e.value;
      } catch (g) {
        return ((a.D.T = null), Ia(a.D, g), Ma(a));
      }
      a.D.T = null;
      d.call(a.D, f);
      return Ma(a);
    },
    Ma = function (a) {
      for (; a.D.D; )
        try {
          var b = a.J(a.D);
          if (b) return ((a.D.fa = !1), { value: b.value, done: !1 });
        } catch (d) {
          ((a.D.ma = void 0), Ia(a.D, d));
        }
      a.D.fa = !1;
      if (a.D.J) {
        var c = a.D.J;
        a.D.J = null;
        if (c.isException) throw c.yn;
        return { value: c.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Oa = function (a) {
      this.next = function (b) {
        var c;
        Ha(a.D);
        a.D.T ? (c = La(a, a.D.T.next, b, a.D.Sa)) : (a.D.Sa(b), (c = Ma(a)));
        return c;
      };
      this.throw = function (b) {
        var c;
        Ha(a.D);
        a.D.T
          ? (c = La(a, a.D.T["throw"], b, a.D.Sa))
          : (Ia(a.D, b), (c = Ma(a)));
        return c;
      };
      this.return = function (b) {
        return Na(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Pa = function (a, b) {
      var c = new Oa(new Ka(b));
      wa && a.prototype && wa(c, a.prototype);
      return c;
    },
    Qa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    },
    Ra = function (a) {
      return a;
    }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Sa = this || self,
    Ta = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.vs = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Yt = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Ua = function (a, b) {
    this.type = a;
    this.data = b;
  };
  var Wa = function () {
    this.map = {};
    this.D = {};
  };
  Wa.prototype.get = function (a) {
    return this.map["dust." + a];
  };
  Wa.prototype.set = function (a, b) {
    var c = "dust." + a;
    this.D.hasOwnProperty(c) || (this.map[c] = b);
  };
  Wa.prototype.has = function (a) {
    return this.map.hasOwnProperty("dust." + a);
  };
  Wa.prototype.remove = function (a) {
    var b = "dust." + a;
    this.D.hasOwnProperty(b) || delete this.map[b];
  };
  var Xa = function (a, b) {
    var c = [],
      d;
    for (d in a.map)
      if (a.map.hasOwnProperty(d)) {
        var e = d.substring(5);
        switch (b) {
          case 1:
            c.push(e);
            break;
          case 2:
            c.push(a.map[d]);
            break;
          case 3:
            c.push([e, a.map[d]]);
        }
      }
    return c;
  };
  Wa.prototype.za = function () {
    return Xa(this, 1);
  };
  Wa.prototype.Bc = function () {
    return Xa(this, 2);
  };
  Wa.prototype.fc = function () {
    return Xa(this, 3);
  };
  var Ya = function () {};
  Ya.prototype.reset = function () {};
  var Za = function (a, b) {
    this.T = a;
    this.parent = b;
    this.N = this.D = void 0;
    this.Eb = !1;
    this.J = function (c, d, e) {
      return c.apply(d, e);
    };
    this.values = new Wa();
  };
  Za.prototype.add = function (a, b) {
    $a(this, a, b, !1);
  };
  Za.prototype.Kh = function (a, b) {
    $a(this, a, b, !0);
  };
  var $a = function (a, b, c, d) {
    if (!a.Eb)
      if (d) {
        var e = a.values;
        e.set(b, c);
        e.D["dust." + b] = !0;
      } else a.values.set(b, c);
  };
  k = Za.prototype;
  k.set = function (a, b) {
    this.Eb ||
      (!this.values.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.values.set(a, b));
  };
  k.get = function (a) {
    return this.values.has(a)
      ? this.values.get(a)
      : this.parent
        ? this.parent.get(a)
        : void 0;
  };
  k.has = function (a) {
    return !!this.values.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.sb = function () {
    var a = new Za(this.T, this);
    this.D && a.Pb(this.D);
    a.ed(this.J);
    a.Zd(this.N);
    return a;
  };
  k.Qd = function () {
    return this.T;
  };
  k.Pb = function (a) {
    this.D = a;
  };
  k.Cn = function () {
    return this.D;
  };
  k.ed = function (a) {
    this.J = a;
  };
  k.wj = function () {
    return this.J;
  };
  k.Ua = function () {
    this.Eb = !0;
  };
  k.Zd = function (a) {
    this.N = a;
  };
  k.ub = function () {
    return this.N;
  };
  var ab = function () {
    this.value = {};
    this.prefix = "gtm.";
  };
  k = ab.prototype;
  k.set = function (a, b) {
    this.value[this.prefix + String(a)] = b;
  };
  k.get = function (a) {
    return this.value[this.prefix + String(a)];
  };
  k.has = function (a) {
    return this.value.hasOwnProperty(this.prefix + String(a));
  };
  k.delete = function (a) {
    var b = this.prefix + String(a);
    return this.value.hasOwnProperty(b) ? (delete this.value[b], !0) : !1;
  };
  k.clear = function () {
    this.value = {};
  };
  k.values = function () {
    var a = this;
    return (function c() {
      var d, e, f;
      return Pa(c, function (g) {
        switch (g.D) {
          case 1:
            (g.jg(2), (e = g.Ld(a.value)));
          case 4:
            if ((d = e.Dn()) == null) {
              g.Yc(2);
              break;
            }
            if (!a.value.hasOwnProperty(d)) {
              g.Yc(4);
              break;
            }
            f = Ra;
            return g.Xb(a.value[d], 8);
          case 8:
            f(g.ma);
            g.Yc(4);
            break;
          case 2:
            (g.Uc(), g.Md(0));
        }
      });
    })();
  };
  ha.Object.defineProperties(ab.prototype, {
    size: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.keys(this.value).length;
      },
    },
  });
  function bb() {
    try {
      if (Map) return new Map();
    } catch (a) {}
    return new ab();
  }
  var cb = function () {
    this.values = [];
  };
  cb.prototype.add = function (a) {
    this.values.indexOf(a) === -1 && this.values.push(a);
  };
  cb.prototype.has = function (a) {
    return this.values.indexOf(a) > -1;
  };
  var db = function (a, b) {
    this.fa = a;
    this.parent = b;
    this.T = this.J = void 0;
    this.Eb = !1;
    this.N = function (d, e, f) {
      return d.apply(e, f);
    };
    this.D = bb();
    var c;
    a: {
      try {
        if (Set) {
          c = new Set();
          break a;
        }
      } catch (d) {}
      c = new cb();
    }
    this.V = c;
  };
  db.prototype.add = function (a, b) {
    eb(this, a, b, !1);
  };
  db.prototype.Kh = function (a, b) {
    eb(this, a, b, !0);
  };
  var eb = function (a, b, c, d) {
    a.Eb || a.V.has(b) || (d && a.V.add(b), a.D.set(b, c));
  };
  k = db.prototype;
  k.set = function (a, b) {
    this.Eb ||
      (!this.D.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.V.has(a) || this.D.set(a, b));
  };
  k.get = function (a) {
    return this.D.has(a)
      ? this.D.get(a)
      : this.parent
        ? this.parent.get(a)
        : void 0;
  };
  k.has = function (a) {
    return !!this.D.has(a) || !(!this.parent || !this.parent.has(a));
  };
  k.sb = function () {
    var a = new db(this.fa, this);
    this.J && a.Pb(this.J);
    a.ed(this.N);
    a.Zd(this.T);
    return a;
  };
  k.Qd = function () {
    return this.fa;
  };
  k.Pb = function (a) {
    this.J = a;
  };
  k.Cn = function () {
    return this.J;
  };
  k.ed = function (a) {
    this.N = a;
  };
  k.wj = function () {
    return this.N;
  };
  k.Ua = function () {
    this.Eb = !0;
  };
  k.Zd = function (a) {
    this.T = a;
  };
  k.ub = function () {
    return this.T;
  };
  var fb = function (a, b, c) {
    var d;
    d = Error.call(this, a.message);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.On = a;
    this.un = c === void 0 ? !1 : c;
    this.debugInfo = [];
    this.D = b;
  };
  xa(fb, Error);
  var gb = function (a) {
    return a instanceof fb ? a : new fb(a, void 0, !0);
  };
  var jb = [];
  function kb(a) {
    return jb[a] === void 0 ? !1 : jb[a];
  }
  var lb = bb();
  function mb(a, b) {
    for (
      var c, d = m(b), e = d.next();
      !e.done && !((c = nb(a, e.value)), c instanceof Ua);
      e = d.next()
    );
    return c;
  }
  function nb(a, b) {
    try {
      if (kb(17)) {
        var c = b[0],
          d = b.slice(1),
          e = String(c),
          f = lb.has(e) ? lb.get(e) : a.get(e);
        if (!f || typeof f.invoke !== "function")
          throw gb(Error("Attempting to execute non-function " + b[0] + "."));
        return f.apply(a, d);
      }
      var g = m(b),
        h = g.next().value,
        l = za(g),
        n = a.get(String(h));
      if (!n || typeof n.invoke !== "function")
        throw gb(Error("Attempting to execute non-function " + b[0] + "."));
      return n.invoke.apply(n, [a].concat(Aa(l)));
    } catch (q) {
      var p = a.Cn();
      p && p(q, b.context ? { id: b[0], line: b.context.line } : null);
      throw q;
    }
  }
  var ob = function () {
    this.J = new Ya();
    this.D = kb(17) ? new db(this.J) : new Za(this.J);
  };
  k = ob.prototype;
  k.Qd = function () {
    return this.J;
  };
  k.Pb = function (a) {
    this.D.Pb(a);
  };
  k.ed = function (a) {
    this.D.ed(a);
  };
  k.execute = function (a) {
    return this.Vj([a].concat(Aa(Qa.apply(1, arguments))));
  };
  k.Vj = function () {
    for (
      var a, b = m(Qa.apply(0, arguments)), c = b.next();
      !c.done;
      c = b.next()
    )
      a = nb(this.D, c.value);
    return a;
  };
  k.Sp = function (a) {
    var b = Qa.apply(1, arguments),
      c = this.D.sb();
    c.Zd(a);
    for (var d, e = m(b), f = e.next(); !f.done; f = e.next())
      d = nb(c, f.value);
    return d;
  };
  k.Ua = function () {
    this.D.Ua();
  };
  var pb = function () {
    this.Ja = !1;
    this.ia = new Wa();
  };
  k = pb.prototype;
  k.get = function (a) {
    return this.ia.get(a);
  };
  k.set = function (a, b) {
    this.Ja || this.ia.set(a, b);
  };
  k.has = function (a) {
    return this.ia.has(a);
  };
  k.remove = function (a) {
    this.Ja || this.ia.remove(a);
  };
  k.za = function () {
    return this.ia.za();
  };
  k.Bc = function () {
    return this.ia.Bc();
  };
  k.fc = function () {
    return this.ia.fc();
  };
  k.Ua = function () {
    this.Ja = !0;
  };
  k.Eb = function () {
    return this.Ja;
  };
  function qb() {
    for (var a = rb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
    return b;
  }
  function sb() {
    var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    a += a.toLowerCase() + "0123456789-_";
    return a + ".";
  }
  var rb, tb;
  function vb(a) {
    rb = rb || sb();
    tb = tb || qb();
    for (var b = [], c = 0; c < a.length; c += 3) {
      var d = c + 1 < a.length,
        e = c + 2 < a.length,
        f = a.charCodeAt(c),
        g = d ? a.charCodeAt(c + 1) : 0,
        h = e ? a.charCodeAt(c + 2) : 0,
        l = f >> 2,
        n = ((f & 3) << 4) | (g >> 4),
        p = ((g & 15) << 2) | (h >> 6),
        q = h & 63;
      e || ((q = 64), d || (p = 64));
      b.push(rb[l], rb[n], rb[p], rb[q]);
    }
    return b.join("");
  }
  function wb(a) {
    function b(l) {
      for (; d < a.length; ) {
        var n = a.charAt(d++),
          p = tb[n];
        if (p != null) return p;
        if (!/^[\s\xa0]*$/.test(n))
          throw Error("Unknown base64 encoding at char: " + n);
      }
      return l;
    }
    rb = rb || sb();
    tb = tb || qb();
    for (var c = "", d = 0; ; ) {
      var e = b(-1),
        f = b(0),
        g = b(64),
        h = b(64);
      if (h === 64 && e === -1) return c;
      c += String.fromCharCode((e << 2) | (f >> 4));
      g !== 64 &&
        ((c += String.fromCharCode(((f << 4) & 240) | (g >> 2))),
        h !== 64 && (c += String.fromCharCode(((g << 6) & 192) | h)));
    }
  }
  var xb = {};
  function yb(a, b) {
    var c = xb[a];
    c || (c = xb[a] = []);
    c[b] = !0;
  }
  function zb() {
    delete xb.GA4_EVENT;
  }
  function Ab() {
    var a = Bb.slice();
    xb.GTAG_EVENT_FEATURE_CHANNEL = a;
  }
  function Cb(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++)
      (d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), (c = 0)),
        a[d] && (c |= 1 << (d % 8)));
    c > 0 && b.push(String.fromCharCode(c));
    return vb(b.join("")).replace(/\.+$/, "");
  }
  function Db() {}
  function Eb(a) {
    return typeof a === "function";
  }
  function Fb(a) {
    return typeof a === "string";
  }
  function Gb(a) {
    return typeof a === "number" && !isNaN(a);
  }
  function Hb(a) {
    return Array.isArray(a) ? a : [a];
  }
  function Ib(a, b) {
    if (a && Array.isArray(a))
      for (var c = 0; c < a.length; c++) if (a[c] && b(a[c])) return a[c];
  }
  function Jb(a, b) {
    if (!Gb(a) || !Gb(b) || a > b) ((a = 0), (b = 2147483647));
    return Math.floor(Math.random() * (b - a + 1) + a);
  }
  function Kb(a, b) {
    for (var c = new Lb(), d = 0; d < a.length; d++) c.set(a[d], !0);
    for (var e = 0; e < b.length; e++) if (c.get(b[e])) return !0;
    return !1;
  }
  function Mb(a, b) {
    for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c]);
  }
  function Nb(a) {
    return (
      !!a &&
      (Object.prototype.toString.call(a) === "[object Arguments]" ||
        Object.prototype.hasOwnProperty.call(a, "callee"))
    );
  }
  function Ob(a) {
    return Math.round(Number(a)) || 0;
  }
  function Pb(a) {
    return "false" === String(a).toLowerCase() ? !1 : !!a;
  }
  function Qb(a) {
    var b = [];
    if (Array.isArray(a))
      for (var c = 0; c < a.length; c++) b.push(String(a[c]));
    return b;
  }
  function Rb(a) {
    return a ? a.replace(/^\s+|\s+$/g, "") : "";
  }
  function Sb() {
    return new Date(Date.now());
  }
  function Tb() {
    return Sb().getTime();
  }
  var Lb = function () {
    this.prefix = "gtm.";
    this.values = {};
  };
  Lb.prototype.set = function (a, b) {
    this.values[this.prefix + a] = b;
  };
  Lb.prototype.get = function (a) {
    return this.values[this.prefix + a];
  };
  Lb.prototype.contains = function (a) {
    return this.get(a) !== void 0;
  };
  function Ub(a, b, c) {
    return a && a.hasOwnProperty(b) ? a[b] : c;
  }
  function Vb(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = void 0;
        try {
          c();
        } catch (d) {}
      }
    };
  }
  function Wb(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
  }
  function Xb(a, b) {
    for (var c = [], d = 0; d < a.length; d++)
      (c.push(a[d]), c.push.apply(c, b[a[d]] || []));
    return c;
  }
  function Yb(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b;
  }
  function ac(a, b) {
    return (
      a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    );
  }
  function bc(a, b, c) {
    c = c || [];
    for (var d = a, e = 0; e < b.length - 1; e++) {
      if (!d.hasOwnProperty(b[e])) return;
      d = d[b[e]];
      if (c.indexOf(d) >= 0) return;
    }
    return d;
  }
  function cc(a, b) {
    for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++)
      d = d[e[f]] = {};
    d[e[e.length - 1]] = b;
    return c;
  }
  var dc = /^\w{1,9}$/;
  function ec(a, b) {
    a = a || {};
    b = b || ",";
    var c = [];
    Mb(a, function (d, e) {
      dc.test(d) && e && c.push(d);
    });
    return c.join(b);
  }
  function fc(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      d < 128
        ? b.push(d)
        : d < 2048
          ? b.push(192 | (d >> 6), 128 | (d & 63))
          : d < 55296 || d >= 57344
            ? b.push(224 | (d >> 12), 128 | ((d >> 6) & 63), 128 | (d & 63))
            : ((d = 65536 + (((d & 1023) << 10) | (a.charCodeAt(++c) & 1023))),
              b.push(
                240 | (d >> 18),
                128 | ((d >> 12) & 63),
                128 | ((d >> 6) & 63),
                128 | (d & 63),
              ));
    }
    return new Uint8Array(b);
  }
  function hc(a, b) {
    function c() {
      e && ++d === b && (e(), (e = null), (c.done = !0));
    }
    var d = 0,
      e = a;
    c.done = !1;
    return c;
  }
  function ic(a) {
    if (!a) return a;
    var b = a;
    try {
      b = decodeURIComponent(a);
    } catch (d) {}
    var c = b.split(",");
    return c.length === 2 && c[0] === c[1] ? c[0] : a;
  }
  function jc(a, b, c) {
    function d(n) {
      var p = n.split("=")[0];
      if (a.indexOf(p) < 0) return n;
      if (c !== void 0) return p + "=" + c;
    }
    function e(n) {
      return n
        .split("&")
        .map(d)
        .filter(function (p) {
          return p !== void 0;
        })
        .join("&");
    }
    var f = b.href.split(/[?#]/)[0],
      g = b.search,
      h = b.hash;
    g[0] === "?" && (g = g.substring(1));
    h[0] === "#" && (h = h.substring(1));
    g = e(g);
    h = e(h);
    g !== "" && (g = "?" + g);
    h !== "" && (h = "#" + h);
    var l = "" + f + g + h;
    l[l.length - 1] === "/" && (l = l.substring(0, l.length - 1));
    return l;
  }
  function kc(a) {
    for (var b = 0; b < 3; ++b)
      try {
        var c = decodeURIComponent(a).replace(/\+/g, " ");
        if (c === a) break;
        a = c;
      } catch (d) {
        return "";
      }
    return a;
  }
  function lc() {
    var a = w,
      b;
    a: {
      var c = a.crypto || a.msCrypto;
      if (c && c.getRandomValues)
        try {
          var d = new Uint8Array(25);
          c.getRandomValues(d);
          b = btoa(String.fromCharCode.apply(String, Aa(d)))
            .replace(/\+/g, "-")
            .replace(/\//g, "_")
            .replace(/=+$/, "");
          break a;
        } catch (e) {}
      b = void 0;
    }
    return b;
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var mc = globalThis.trustedTypes,
    nc;
  function oc() {
    var a = null;
    if (!mc) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = mc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function pc() {
    nc === void 0 && (nc = oc());
    return nc;
  }
  var qc = function (a) {
    this.D = a;
  };
  qc.prototype.toString = function () {
    return this.D + "";
  };
  function rc(a) {
    var b = a,
      c = pc(),
      d = c ? c.createScriptURL(b) : b;
    return new qc(d);
  }
  function sc(a) {
    if (a instanceof qc) return a.D;
    throw Error("");
  }
  var tc = Ca([""]),
    uc = Ba(["\x00"], ["\\0"]),
    vc = Ba(["\n"], ["\\n"]),
    wc = Ba(["\x00"], ["\\u0000"]);
  function xc(a) {
    return a.toString().indexOf("`") === -1;
  }
  xc(function (a) {
    return a(tc);
  }) ||
    xc(function (a) {
      return a(uc);
    }) ||
    xc(function (a) {
      return a(vc);
    }) ||
    xc(function (a) {
      return a(wc);
    });
  var yc = function (a) {
    this.D = a;
  };
  yc.prototype.toString = function () {
    return this.D;
  };
  var zc = function (a) {
    this.Er = a;
  };
  function Ac(a) {
    return new zc(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var Bc = [
    Ac("data"),
    Ac("http"),
    Ac("https"),
    Ac("mailto"),
    Ac("ftp"),
    new zc(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function Cc(a) {
    var b;
    b = b === void 0 ? Bc : b;
    if (a instanceof yc) return a;
    for (var c = 0; c < b.length; ++c) {
      var d = b[c];
      if (d instanceof zc && d.Er(a)) return new yc(a);
    }
  }
  var Dc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Ec(a) {
    var b;
    if (a instanceof yc)
      if (a instanceof yc) b = a.D;
      else throw Error("");
    else b = Dc.test(a) ? a : void 0;
    return b;
  }
  function Fc(a, b) {
    var c = Ec(b);
    c !== void 0 && (a.action = c);
  }
  function Gc(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var Hc = function (a) {
    this.D = a;
  };
  Hc.prototype.toString = function () {
    return this.D + "";
  };
  var Jc = function () {
    this.D = Ic;
  };
  Jc.prototype.toString = function () {
    return this.D + "";
  };
  var Lc = function () {
    this.D = Kc[0].toLowerCase();
  };
  Lc.prototype.toString = function () {
    return this.D;
  };
  function Mc(a, b) {
    var c = [new Lc()];
    if (c.length === 0) throw Error("");
    var d = c.map(function (f) {
        var g;
        if (f instanceof Lc) g = f.D;
        else throw Error("");
        return g;
      }),
      e = b.toLowerCase();
    if (
      d.every(function (f) {
        return e.indexOf(f) !== 0;
      })
    )
      throw Error(
        'Attribute "' + b + '" does not match any of the allowed prefixes.',
      );
    a.setAttribute(b, "true");
  }
  var Nc = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  function Oc(a, b) {
    return new SharedWorker(sc(a), b);
  }
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Pc(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var w = window,
    Qc = window.history,
    A = document,
    Rc = navigator;
  function Sc() {
    var a;
    try {
      a = Rc.serviceWorker;
    } catch (b) {
      return;
    }
    return a;
  }
  var Tc = A.currentScript,
    Uc = Tc && Tc.src;
  function Vc(a, b) {
    var c = w,
      d = c[a];
    c[a] = d === void 0 ? b : d;
    return c[a];
  }
  function Wc(a) {
    return (Rc.userAgent || "").indexOf(a) !== -1;
  }
  function Xc() {
    return Wc("Firefox") || Wc("FxiOS");
  }
  function Yc() {
    return (Wc("GSA") || Wc("GoogleApp")) && (Wc("iPhone") || Wc("iPad"));
  }
  function Zc() {
    return Wc("Edg/") || Wc("EdgA/") || Wc("EdgiOS/");
  }
  var $c = { async: 1, nonce: 1, onerror: 1, onload: 1, src: 1, type: 1 },
    ad = { height: 1, onload: 1, src: 1, style: 1, width: 1 };
  function bd(a, b, c) {
    b &&
      Mb(b, function (d, e) {
        d = d.toLowerCase();
        c.hasOwnProperty(d) || a.setAttribute(d, e);
      });
  }
  function cd(a, b, c, d, e) {
    var f = A.createElement("script");
    bd(f, d, $c);
    f.type = "text/javascript";
    f.async = d && d.async === !1 ? !1 : !0;
    var g;
    g = rc(Pc(a));
    f.src = sc(g);
    var h,
      l = f.ownerDocument;
    l = l === void 0 ? document : l;
    var n,
      p,
      q =
        (p = (n = l).querySelector) == null
          ? void 0
          : p.call(n, "script[nonce]");
    (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") &&
      f.setAttribute("nonce", h);
    b && (f.onload = b);
    c && (f.onerror = c);
    if (e) e.appendChild(f);
    else {
      var r = A.getElementsByTagName("script")[0] || A.body || A.head;
      r.parentNode.insertBefore(f, r);
    }
    return f;
  }
  function dd() {
    if (Uc) {
      var a = Uc.toLowerCase();
      if (a.indexOf("https://") === 0) return 2;
      if (a.indexOf("http://") === 0) return 3;
    }
    return 1;
  }
  function ed(a, b, c, d, e, f) {
    f = f === void 0 ? !0 : f;
    var g = e,
      h = !1;
    g || ((g = A.createElement("iframe")), (h = !0));
    bd(g, c, ad);
    d &&
      Mb(d, function (n, p) {
        g.dataset[n] = p;
      });
    f &&
      ((g.height = "0"),
      (g.width = "0"),
      (g.style.display = "none"),
      (g.style.visibility = "hidden"));
    a !== void 0 && (g.src = a);
    if (h) {
      var l = (A.body && A.body.lastChild) || A.body || A.head;
      l.parentNode.insertBefore(g, l);
    }
    b && (g.onload = b);
    return g;
  }
  function fd(a, b, c, d) {
    return gd(a, b, c, d);
  }
  function hd(a, b, c, d) {
    a.addEventListener && a.addEventListener(b, c, !!d);
  }
  function id(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1);
  }
  function jd(a) {
    w.setTimeout(a, 0);
  }
  function kd(a, b) {
    return a && b && a.attributes && a.attributes[b]
      ? a.attributes[b].value
      : null;
  }
  function ld(a) {
    var b = a.innerText || a.textContent || "";
    b &&
      b !== " " &&
      ((b = b.replace(/^[\s\xa0]+/g, "")), (b = b.replace(/[\s\xa0]+$/g, "")));
    b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
    return b;
  }
  function md(a) {
    var b = A.createElement("div"),
      c = b,
      d,
      e = Pc("A<div>" + a + "</div>"),
      f = pc(),
      g = f ? f.createHTML(e) : e;
    d = new Hc(g);
    if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
      throw Error("");
    var h;
    if (d instanceof Hc) h = d.D;
    else throw Error("");
    c.innerHTML = h;
    b = b.lastChild;
    for (var l = []; b && b.firstChild; ) l.push(b.removeChild(b.firstChild));
    return l;
  }
  function nd(a, b, c) {
    c = c || 100;
    for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
    for (var f = a, g = 0; f && g <= c; g++) {
      if (d[String(f.tagName).toLowerCase()]) return f;
      f = f.parentElement;
    }
    return null;
  }
  function od(a, b, c) {
    var d;
    try {
      d = Rc.sendBeacon && Rc.sendBeacon(a);
    } catch (e) {
      yb("TAGGING", 15);
    }
    d ? b == null || b() : gd(a, b, c);
  }
  function pd(a, b) {
    try {
      if (Rc.sendBeacon !== void 0) return Rc.sendBeacon(a, b);
    } catch (c) {
      yb("TAGGING", 15);
    }
    return !1;
  }
  var qd = Object.freeze({
    cache: "no-store",
    credentials: "include",
    keepalive: !0,
    method: "POST",
    mode: "no-cors",
    redirect: "follow",
  });
  function rd(a, b, c, d, e) {
    if (sd()) {
      var f = oa(Object, "assign").call(Object, {}, qd);
      b && (f.body = b);
      c &&
        (c.attributionReporting &&
          (f.attributionReporting = c.attributionReporting),
        c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics),
        c.credentials && (f.credentials = c.credentials),
        c.keepalive !== void 0 && (f.keepalive = c.keepalive),
        c.method && (f.method = c.method),
        c.mode && (f.mode = c.mode));
      try {
        var g = w.fetch(a, f);
        if (g)
          return (
            g
              .then(function (l) {
                l && (l.ok || l.status === 0)
                  ? d == null || d()
                  : e == null || e();
              })
              .catch(function () {
                e == null || e();
              }),
            !0
          );
      } catch (l) {}
    }
    if (
      (c == null ? 0 : c.Ue) ||
      ((c == null ? 0 : c.credentials) && c.credentials !== "include")
    )
      return (e == null || e(), !1);
    if (b) {
      var h = pd(a, b);
      h ? d == null || d() : e == null || e();
      return h;
    }
    td(a, d, e);
    return !0;
  }
  function sd() {
    return typeof w.fetch === "function";
  }
  function ud(a, b) {
    var c = a[b];
    c && typeof c.animVal === "string" && (c = c.animVal);
    return c;
  }
  function vd() {
    var a = w.performance;
    if (a && Eb(a.now)) return a.now();
  }
  function wd() {
    var a,
      b = w.performance;
    if (b && b.getEntriesByType)
      try {
        var c = b.getEntriesByType("navigation");
        c && c.length > 0 && (a = c[0].type);
      } catch (d) {
        return "e";
      }
    if (!a) return "u";
    switch (a) {
      case "navigate":
        return "n";
      case "back_forward":
        return "h";
      case "reload":
        return "r";
      case "prerender":
        return "p";
      default:
        return "x";
    }
  }
  function xd() {
    return w.performance || void 0;
  }
  function yd() {
    var a = w.webPixelsManager;
    return a ? a.createShopifyExtend !== void 0 : !1;
  }
  var gd = function (a, b, c, d) {
      var e = new Image(1, 1);
      bd(e, d, {});
      e.onload = function () {
        e.onload = null;
        b && b();
      };
      e.onerror = function () {
        e.onerror = null;
        c && c();
      };
      e.src = a;
      return e;
    },
    td = od;
  function zd(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function Ad(a, b) {
    return this.evaluate(a) === this.evaluate(b);
  }
  function Bd(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Cd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    return String(c).indexOf(String(d)) > -1;
  }
  function Dd(a, b) {
    var c = String(this.evaluate(a)),
      d = String(this.evaluate(b));
    return c.substring(0, d.length) === d;
  }
  function Ed(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    switch (c) {
      case "pageLocation":
        var e = w.location.href;
        d instanceof pb &&
          d.get("stripProtocol") &&
          (e = e.replace(/^https?:\/\//, ""));
        return e;
    }
  } /*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
  var Fd = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    Gd = function (a) {
      if (a == null) return String(a);
      var b = Fd.exec(Object.prototype.toString.call(Object(a)));
      return b ? b[1].toLowerCase() : "object";
    },
    Hd = function (a, b) {
      return Object.prototype.hasOwnProperty.call(Object(a), b);
    },
    Id = function (a) {
      if (!a || Gd(a) != "object" || a.nodeType || a == a.window) return !1;
      try {
        if (
          a.constructor &&
          !Hd(a, "constructor") &&
          !Hd(a.constructor.prototype, "isPrototypeOf")
        )
          return !1;
      } catch (c) {
        return !1;
      }
      for (var b in a);
      return b === void 0 || Hd(a, b);
    },
    Jd = function (a, b) {
      var c = b || (Gd(a) == "array" ? [] : {}),
        d;
      for (d in a)
        if (Hd(a, d)) {
          var e = a[d];
          Gd(e) == "array"
            ? (Gd(c[d]) != "array" && (c[d] = []), (c[d] = Jd(e, c[d])))
            : Id(e)
              ? (Id(c[d]) || (c[d] = {}), (c[d] = Jd(e, c[d])))
              : (c[d] = e);
        }
      return c;
    };
  function Kd(a) {
    return (
      (typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0) ||
      (typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a))
    );
  }
  var Ld = function (a) {
    a = a === void 0 ? [] : a;
    this.ia = new Wa();
    this.values = [];
    this.Ja = !1;
    for (var b in a)
      a.hasOwnProperty(b) &&
        (Kd(b)
          ? (this.values[Number(b)] = a[Number(b)])
          : this.ia.set(b, a[b]));
  };
  k = Ld.prototype;
  k.toString = function (a) {
    if (a && a.indexOf(this) >= 0) return "";
    for (var b = [], c = 0; c < this.values.length; c++) {
      var d = this.values[c];
      d === null || d === void 0
        ? b.push("")
        : d instanceof Ld
          ? ((a = a || []), a.push(this), b.push(d.toString(a)), a.pop())
          : b.push(String(d));
    }
    return b.join(",");
  };
  k.set = function (a, b) {
    if (!this.Ja)
      if (a === "length") {
        if (!Kd(b))
          throw gb(
            Error("RangeError: Length property must be a valid integer."),
          );
        this.values.length = Number(b);
      } else Kd(a) ? (this.values[Number(a)] = b) : this.ia.set(a, b);
  };
  k.get = function (a) {
    return a === "length"
      ? this.length()
      : Kd(a)
        ? this.values[Number(a)]
        : this.ia.get(a);
  };
  k.length = function () {
    return this.values.length;
  };
  k.za = function () {
    for (var a = this.ia.za(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(String(b));
    return a;
  };
  k.Bc = function () {
    for (var a = this.ia.Bc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(this.values[b]);
    return a;
  };
  k.fc = function () {
    for (var a = this.ia.fc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
    return a;
  };
  k.remove = function (a) {
    Kd(a) ? delete this.values[Number(a)] : this.Ja || this.ia.remove(a);
  };
  k.pop = function () {
    return this.values.pop();
  };
  k.push = function () {
    return this.values.push.apply(this.values, Aa(Qa.apply(0, arguments)));
  };
  k.shift = function () {
    return this.values.shift();
  };
  k.splice = function (a, b) {
    var c = Qa.apply(2, arguments);
    return b === void 0 && c.length === 0
      ? new Ld(this.values.splice(a))
      : new Ld(
          this.values.splice.apply(this.values, [a, b || 0].concat(Aa(c))),
        );
  };
  k.unshift = function () {
    return this.values.unshift.apply(this.values, Aa(Qa.apply(0, arguments)));
  };
  k.has = function (a) {
    return (Kd(a) && this.values.hasOwnProperty(a)) || this.ia.has(a);
  };
  k.Ua = function () {
    this.Ja = !0;
    Object.freeze(this.values);
  };
  k.Eb = function () {
    return this.Ja;
  };
  function Md(a) {
    for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
    return b;
  }
  var Nd = function (a, b) {
    this.functionName = a;
    this.Pd = b;
    this.ia = new Wa();
    this.Ja = !1;
  };
  k = Nd.prototype;
  k.toString = function () {
    return this.functionName;
  };
  k.getName = function () {
    return this.functionName;
  };
  k.getKeys = function () {
    return new Ld(this.za());
  };
  k.invoke = function (a) {
    return this.Pd.call.apply(
      this.Pd,
      [new Od(this, a)].concat(Aa(Qa.apply(1, arguments))),
    );
  };
  k.apply = function (a, b) {
    return this.Pd.apply(new Od(this, a), b);
  };
  k.Ob = function (a) {
    var b = Qa.apply(1, arguments);
    try {
      return this.invoke.apply(this, [a].concat(Aa(b)));
    } catch (c) {}
  };
  k.get = function (a) {
    return this.ia.get(a);
  };
  k.set = function (a, b) {
    this.Ja || this.ia.set(a, b);
  };
  k.has = function (a) {
    return this.ia.has(a);
  };
  k.remove = function (a) {
    this.Ja || this.ia.remove(a);
  };
  k.za = function () {
    return this.ia.za();
  };
  k.Bc = function () {
    return this.ia.Bc();
  };
  k.fc = function () {
    return this.ia.fc();
  };
  k.Ua = function () {
    this.Ja = !0;
  };
  k.Eb = function () {
    return this.Ja;
  };
  var Pd = function (a, b) {
    Nd.call(this, a, b);
  };
  xa(Pd, Nd);
  var Qd = function (a, b) {
    Nd.call(this, a, b);
  };
  xa(Qd, Nd);
  var Od = function (a, b) {
    this.Pd = a;
    this.M = b;
  };
  Od.prototype.evaluate = function (a) {
    var b = this.M;
    return Array.isArray(a) ? nb(b, a) : a;
  };
  Od.prototype.getName = function () {
    return this.Pd.getName();
  };
  Od.prototype.Qd = function () {
    return this.M.Qd();
  };
  var Rd = function () {
    this.map = new Map();
  };
  Rd.prototype.set = function (a, b) {
    this.map.set(a, b);
  };
  Rd.prototype.get = function (a) {
    return this.map.get(a);
  };
  var Sd = function () {
    this.keys = [];
    this.values = [];
  };
  Sd.prototype.set = function (a, b) {
    this.keys.push(a);
    this.values.push(b);
  };
  Sd.prototype.get = function (a) {
    var b = this.keys.indexOf(a);
    if (b > -1) return this.values[b];
  };
  function Td() {
    try {
      return Map ? new Rd() : new Sd();
    } catch (a) {
      return new Sd();
    }
  }
  var Ud = function (a) {
    if (a instanceof Ud) return a;
    var b;
    a: if (a == void 0 || Array.isArray(a) || Id(a)) b = !0;
    else {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "function":
          b = !0;
          break a;
      }
      b = !1;
    }
    if (b) throw Error("Type of given value has an equivalent Pixie type.");
    this.value = a;
  };
  Ud.prototype.getValue = function () {
    return this.value;
  };
  Ud.prototype.toString = function () {
    return String(this.value);
  };
  var Wd = function (a) {
    this.promise = a;
    this.Ja = !1;
    this.ia = new Wa();
    this.ia.set("then", Vd(this));
    this.ia.set("catch", Vd(this, !0));
    this.ia.set("finally", Vd(this, !1, !0));
  };
  k = Wd.prototype;
  k.get = function (a) {
    return this.ia.get(a);
  };
  k.set = function (a, b) {
    this.Ja || this.ia.set(a, b);
  };
  k.has = function (a) {
    return this.ia.has(a);
  };
  k.remove = function (a) {
    this.Ja || this.ia.remove(a);
  };
  k.za = function () {
    return this.ia.za();
  };
  k.Bc = function () {
    return this.ia.Bc();
  };
  k.fc = function () {
    return this.ia.fc();
  };
  var Vd = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    return new Pd("", function (d, e) {
      b && ((e = d), (d = void 0));
      c && (e = d);
      d instanceof Pd || (d = void 0);
      e instanceof Pd || (e = void 0);
      var f = this.M.sb(),
        g = function (l) {
          return function (n) {
            try {
              return c ? (l.invoke(f), a.promise) : l.invoke(f, n);
            } catch (p) {
              return Promise.reject(p instanceof Error ? new Ud(p) : String(p));
            }
          };
        },
        h = a.promise.then(d && g(d), e && g(e));
      return new Wd(h);
    });
  };
  Wd.prototype.Ua = function () {
    this.Ja = !0;
  };
  Wd.prototype.Eb = function () {
    return this.Ja;
  };
  function B(a, b, c) {
    var d = Td(),
      e = function (g, h) {
        for (var l = g.za(), n = 0; n < l.length; n++) h[l[n]] = f(g.get(l[n]));
      },
      f = function (g) {
        if (g === null || g === void 0) return g;
        var h = d.get(g);
        if (h) return h;
        if (g instanceof Ld) {
          var l = [];
          d.set(g, l);
          for (var n = g.za(), p = 0; p < n.length; p++)
            l[n[p]] = f(g.get(n[p]));
          return l;
        }
        if (g instanceof Wd)
          return g.promise.then(
            function (u) {
              return B(u, b, 1);
            },
            function (u) {
              return Promise.reject(B(u, b, 1));
            },
          );
        if (g instanceof pb) {
          var q = {};
          d.set(g, q);
          e(g, q);
          return q;
        }
        if (g instanceof Pd) {
          var r = function () {
            for (var u = [], v = 0; v < arguments.length; v++)
              u[v] = Xd(arguments[v], b, c);
            var x = new Za(b ? b.Qd() : new Ya());
            b && x.Zd(b.ub());
            return f(
              kb(17) ? g.apply(x, u) : g.invoke.apply(g, [x].concat(Aa(u))),
            );
          };
          d.set(g, r);
          e(g, r);
          return r;
        }
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          case 3:
            t = !1;
            break;
          default:
        }
        if (g instanceof Ud && t) return g.getValue();
        switch (typeof g) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return g;
          case "object":
            if (g === null) return null;
        }
      };
    return f(a);
  }
  function Xd(a, b, c) {
    var d = Td(),
      e = function (g, h) {
        for (var l in g) g.hasOwnProperty(l) && h.set(l, f(g[l]));
      },
      f = function (g) {
        var h = d.get(g);
        if (h) return h;
        if (Array.isArray(g) || Nb(g)) {
          var l = new Ld();
          d.set(g, l);
          for (var n in g) g.hasOwnProperty(n) && l.set(n, f(g[n]));
          return l;
        }
        if (Id(g)) {
          var p = new pb();
          d.set(g, p);
          e(g, p);
          return p;
        }
        if (typeof g === "function") {
          var q = new Pd("", function () {
            for (
              var u = Qa.apply(0, arguments), v = [], x = 0;
              x < u.length;
              x++
            )
              v[x] = B(this.evaluate(u[x]), b, c);
            return f(this.M.wj()(g, g, v));
          });
          d.set(g, q);
          e(g, q);
          return q;
        }
        var r = typeof g;
        if (g === null || r === "string" || r === "number" || r === "boolean")
          return g;
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          default:
        }
        if (g !== void 0 && t) return new Ud(g);
      };
    return f(a);
  }
  var Yd = {
    supportedMethods:
      "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(
        " ",
      ),
    concat: function (a) {
      for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
      for (var d = 1; d < arguments.length; d++)
        if (arguments[d] instanceof Ld)
          for (var e = arguments[d], f = 0; f < e.length(); f++)
            b.push(e.get(f));
        else b.push(arguments[d]);
      return new Ld(b);
    },
    every: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
      return !0;
    },
    filter: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
      return new Ld(d);
    },
    forEach: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        this.has(d) && b.invoke(a, this.get(d), d, this);
    },
    hasOwnProperty: function (a, b) {
      return this.has(b);
    },
    indexOf: function (a, b, c) {
      var d = this.length(),
        e = c === void 0 ? 0 : Number(c);
      e < 0 && (e = Math.max(d + e, 0));
      for (var f = e; f < d; f++)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    join: function (a, b) {
      for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
      return c.join(b);
    },
    lastIndexOf: function (a, b, c) {
      var d = this.length(),
        e = d - 1;
      c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
      for (var f = e; f >= 0; f--)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    map: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
      return new Ld(d);
    },
    pop: function () {
      return this.pop();
    },
    push: function (a) {
      return this.push.apply(this, Aa(Qa.apply(1, arguments)));
    },
    reduce: function (a, b, c) {
      var d = this.length(),
        e,
        f = 0;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw gb(Error("TypeError: Reduce on List with no elements."));
        for (var g = 0; g < d; g++)
          if (this.has(g)) {
            e = this.get(g);
            f = g + 1;
            break;
          }
        if (g === d)
          throw gb(Error("TypeError: Reduce on List with no elements."));
      }
      for (var h = f; h < d; h++)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reduceRight: function (a, b, c) {
      var d = this.length(),
        e,
        f = d - 1;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw gb(Error("TypeError: ReduceRight on List with no elements."));
        for (var g = 1; g <= d; g++)
          if (this.has(d - g)) {
            e = this.get(d - g);
            f = d - (g + 1);
            break;
          }
        if (g > d)
          throw gb(Error("TypeError: ReduceRight on List with no elements."));
      }
      for (var h = f; h >= 0; h--)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reverse: function () {
      for (var a = Md(this), b = a.length - 1, c = 0; b >= 0; b--, c++)
        a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
      return this;
    },
    shift: function () {
      return this.shift();
    },
    slice: function (a, b, c) {
      var d = this.length();
      b === void 0 && (b = 0);
      b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
      c = c === void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
      c = Math.max(b, c);
      for (var e = [], f = b; f < c; f++) e.push(this.get(f));
      return new Ld(e);
    },
    some: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
      return !1;
    },
    sort: function (a, b) {
      var c = Md(this);
      b === void 0
        ? c.sort()
        : c.sort(function (e, f) {
            return Number(b.invoke(a, e, f));
          });
      for (var d = 0; d < c.length; d++)
        c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
      return this;
    },
    splice: function (a, b, c) {
      return this.splice.apply(this, [b, c].concat(Aa(Qa.apply(3, arguments))));
    },
    toString: function () {
      return this.toString();
    },
    unshift: function (a) {
      return this.unshift.apply(this, Aa(Qa.apply(1, arguments)));
    },
  };
  var Zd = {
      charAt: 1,
      concat: 1,
      indexOf: 1,
      lastIndexOf: 1,
      match: 1,
      replace: 1,
      search: 1,
      slice: 1,
      split: 1,
      substring: 1,
      toLowerCase: 1,
      toLocaleLowerCase: 1,
      toString: 1,
      toUpperCase: 1,
      toLocaleUpperCase: 1,
      trim: 1,
    },
    $d = new Ua("break"),
    ae = new Ua("continue");
  function be(a, b) {
    return this.evaluate(a) + this.evaluate(b);
  }
  function ce(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function de(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!(f instanceof Ld))
      throw Error("Error: Non-List argument given to Apply instruction.");
    if (d === null || d === void 0)
      throw gb(Error("TypeError: Can't read property " + e + " of " + d + "."));
    var g = typeof d === "number";
    if (typeof d === "boolean" || g) {
      if (e === "toString") {
        if (g && f.length()) {
          var h = B(f.get(0));
          try {
            return d.toString(h);
          } catch (u) {}
        }
        return d.toString();
      }
      throw gb(Error("TypeError: " + d + "." + e + " is not a function."));
    }
    if (typeof d === "string") {
      if (Zd.hasOwnProperty(e)) {
        var l = B(f, void 0, 1);
        return Xd(d[e].apply(d, l), this.M);
      }
      throw gb(Error("TypeError: " + e + " is not a function"));
    }
    if (d instanceof Ld) {
      if (d.has(e)) {
        var n = d.get(String(e));
        if (n instanceof Pd) {
          var p = Md(f);
          return kb(17)
            ? n.apply(this.M, p)
            : n.invoke.apply(n, [this.M].concat(Aa(p)));
        }
        throw gb(Error("TypeError: " + e + " is not a function"));
      }
      if (Yd.supportedMethods.indexOf(e) >= 0) {
        var q = Md(f);
        return Yd[e].call.apply(Yd[e], [d, this.M].concat(Aa(q)));
      }
    }
    if (d instanceof Pd || d instanceof pb || d instanceof Wd) {
      if (d.has(e)) {
        var r = d.get(e);
        if (r instanceof Pd) {
          var t = Md(f);
          return kb(17)
            ? r.apply(this.M, t)
            : r.invoke.apply(r, [this.M].concat(Aa(t)));
        }
        throw gb(Error("TypeError: " + e + " is not a function"));
      }
      if (e === "toString") return d instanceof Pd ? d.getName() : d.toString();
      if (e === "hasOwnProperty") return d.has(f.get(0));
    }
    if (d instanceof Ud && e === "toString") return d.toString();
    throw gb(Error("TypeError: Object has no '" + e + "' property."));
  }
  function ee(a, b) {
    a = this.evaluate(a);
    if (typeof a !== "string")
      throw Error("Invalid key name given for assignment.");
    var c = this.M;
    if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
    var d = this.evaluate(b);
    c.set(a, d);
    return d;
  }
  function fe() {
    var a = Qa.apply(0, arguments),
      b = this.M.sb(),
      c = mb(b, a);
    if (c instanceof Ua) return c;
  }
  function ge() {
    return $d;
  }
  function he(a) {
    for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
      var d = this.evaluate(b[c]);
      if (d instanceof Ua) return d;
    }
  }
  function ie() {
    for (var a = this.M, b = 0; b < arguments.length - 1; b += 2) {
      var c = arguments[b];
      if (typeof c === "string") {
        var d = this.evaluate(arguments[b + 1]);
        a.Kh(c, d);
      }
    }
  }
  function je() {
    return ae;
  }
  function le(a, b) {
    return new Ua(a, this.evaluate(b));
  }
  function me(a, b) {
    var c = Qa.apply(2, arguments),
      d;
    d = new Ld();
    for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
    var g = [51, a, d].concat(Aa(c));
    this.M.add(a, this.evaluate(g));
  }
  function ne(a, b) {
    return this.evaluate(a) / this.evaluate(b);
  }
  function oe(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b),
      e = c instanceof Ud,
      f = d instanceof Ud;
    return e || f ? (e && f ? c.getValue() === d.getValue() : !1) : c == d;
  }
  function pe() {
    for (var a, b = 0; b < arguments.length; b++)
      a = this.evaluate(arguments[b]);
    return a;
  }
  function qe(a, b, c, d) {
    for (var e = 0; e < b(); e++) {
      var f = a(c(e)),
        g = mb(f, d);
      if (g instanceof Ua) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
    }
  }
  function re(a, b, c) {
    if (typeof b === "string")
      return qe(
        a,
        function () {
          return b.length;
        },
        function (f) {
          return f;
        },
        c,
      );
    if (
      b instanceof pb ||
      b instanceof Wd ||
      b instanceof Ld ||
      b instanceof Pd
    ) {
      var d = b.za(),
        e = d.length;
      return qe(
        a,
        function () {
          return e;
        },
        function (f) {
          return d[f];
        },
        c,
      );
    }
  }
  function se(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return re(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f,
    );
  }
  function te(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return re(
      function (h) {
        var l = g.sb();
        l.Kh(d, h);
        return l;
      },
      e,
      f,
    );
  }
  function ue(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return re(
      function (h) {
        var l = g.sb();
        l.add(d, h);
        return l;
      },
      e,
      f,
    );
  }
  function ve(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return we(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f,
    );
  }
  function xe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return we(
      function (h) {
        var l = g.sb();
        l.Kh(d, h);
        return l;
      },
      e,
      f,
    );
  }
  function ye(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.M;
    return we(
      function (h) {
        var l = g.sb();
        l.add(d, h);
        return l;
      },
      e,
      f,
    );
  }
  function we(a, b, c) {
    if (typeof b === "string")
      return qe(
        a,
        function () {
          return b.length;
        },
        function (d) {
          return b[d];
        },
        c,
      );
    if (b instanceof Ld)
      return qe(
        a,
        function () {
          return b.length();
        },
        function (d) {
          return b.get(d);
        },
        c,
      );
    throw gb(Error("The value is not iterable."));
  }
  function ze(a, b, c, d) {
    function e(q, r) {
      for (var t = 0; t < f.length(); t++) {
        var u = f.get(t);
        r.add(u, q.get(u));
      }
    }
    var f = this.evaluate(a);
    if (!(f instanceof Ld))
      throw Error("TypeError: Non-List argument given to ForLet instruction.");
    var g = this.M,
      h = this.evaluate(d),
      l = g.sb();
    for (e(g, l); nb(l, b); ) {
      var n = mb(l, h);
      if (n instanceof Ua) {
        if (n.type === "break") break;
        if (n.type === "return") return n;
      }
      var p = g.sb();
      e(l, p);
      nb(p, c);
      l = p;
    }
  }
  function Ae(a, b) {
    var c = Qa.apply(2, arguments),
      d = this.M,
      e = this.evaluate(b);
    if (!(e instanceof Ld))
      throw Error("Error: non-List value given for Fn argument names.");
    return new Pd(
      a,
      (function () {
        return function () {
          var f = Qa.apply(0, arguments),
            g = d.sb();
          g.ub() === void 0 && g.Zd(this.M.ub());
          for (var h = [], l = 0; l < f.length; l++) {
            var n = this.evaluate(f[l]);
            h[l] = n;
          }
          for (var p = e.get("length"), q = 0; q < p; q++)
            q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
          g.add("arguments", new Ld(h));
          var r = mb(g, c);
          if (r instanceof Ua) return r.type === "return" ? r.data : r;
        };
      })(),
    );
  }
  function Be(a) {
    var b = this.evaluate(a),
      c = this.M;
    if (Ce && !c.has(b)) throw new ReferenceError(b + " is not defined.");
    return c.get(b);
  }
  function De(a, b) {
    var c,
      d = this.evaluate(a),
      e = this.evaluate(b);
    if (d === void 0 || d === null)
      throw gb(
        Error(
          "TypeError: Cannot read properties of " +
            d +
            " (reading '" +
            e +
            "')",
        ),
      );
    if (
      d instanceof pb ||
      d instanceof Wd ||
      d instanceof Ld ||
      d instanceof Pd
    )
      c = d.get(e);
    else if (typeof d === "string")
      e === "length" ? (c = d.length) : Kd(e) && (c = d[e]);
    else if (d instanceof Ud) return;
    return c;
  }
  function Ee(a, b) {
    return this.evaluate(a) > this.evaluate(b);
  }
  function Fe(a, b) {
    return this.evaluate(a) >= this.evaluate(b);
  }
  function Ge(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    c instanceof Ud && (c = c.getValue());
    d instanceof Ud && (d = d.getValue());
    return c === d;
  }
  function He(a, b) {
    return !Ge.call(this, a, b);
  }
  function Ie(a, b, c) {
    var d = [];
    this.evaluate(a) ? (d = this.evaluate(b)) : c && (d = this.evaluate(c));
    var e = mb(this.M, d);
    if (e instanceof Ua) return e;
  }
  var Ce = !1;
  function Je(a, b) {
    return this.evaluate(a) < this.evaluate(b);
  }
  function Ke(a, b) {
    return this.evaluate(a) <= this.evaluate(b);
  }
  function Le() {
    for (var a = new Ld(), b = 0; b < arguments.length; b++) {
      var c = this.evaluate(arguments[b]);
      a.push(c);
    }
    return a;
  }
  function Me() {
    for (var a = new pb(), b = 0; b < arguments.length - 1; b += 2) {
      var c = String(this.evaluate(arguments[b])),
        d = this.evaluate(arguments[b + 1]);
      a.set(c, d);
    }
    return a;
  }
  function Ne(a, b) {
    return this.evaluate(a) % this.evaluate(b);
  }
  function Oe(a, b) {
    return this.evaluate(a) * this.evaluate(b);
  }
  function Pe(a) {
    return -this.evaluate(a);
  }
  function Qe(a) {
    return !this.evaluate(a);
  }
  function Re(a, b) {
    return !oe.call(this, a, b);
  }
  function Se() {
    return null;
  }
  function Te(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Ve(a, b) {
    var c = this.evaluate(a);
    this.evaluate(b);
    return c;
  }
  function We(a) {
    return this.evaluate(a);
  }
  function Xe() {
    return Qa.apply(0, arguments);
  }
  function Ye(a) {
    return new Ua("return", this.evaluate(a));
  }
  function Ze(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (d === null || d === void 0)
      throw gb(Error("TypeError: Can't set property " + e + " of " + d + "."));
    (d instanceof Pd || d instanceof Ld || d instanceof pb) &&
      d.set(String(e), f);
    return f;
  }
  function $e(a, b) {
    return this.evaluate(a) - this.evaluate(b);
  }
  function af(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!Array.isArray(e) || !Array.isArray(f))
      throw Error("Error: Malformed switch instruction.");
    for (var g, h = !1, l = 0; l < e.length; l++)
      if (h || d === this.evaluate(e[l]))
        if (((g = this.evaluate(f[l])), g instanceof Ua)) {
          var n = g.type;
          if (n === "break") return;
          if (n === "return" || n === "continue") return g;
        } else h = !0;
    if (
      f.length === e.length + 1 &&
      ((g = this.evaluate(f[f.length - 1])),
      g instanceof Ua && (g.type === "return" || g.type === "continue"))
    )
      return g;
  }
  function bf(a, b, c) {
    return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c);
  }
  function cf(a) {
    var b = this.evaluate(a);
    return b instanceof Pd ? "function" : typeof b;
  }
  function df() {
    for (var a = this.M, b = 0; b < arguments.length; b++) {
      var c = arguments[b];
      typeof c !== "string" || a.add(c, void 0);
    }
  }
  function ef(a, b, c, d) {
    var e = this.evaluate(d);
    if (this.evaluate(c)) {
      var f = mb(this.M, e);
      if (f instanceof Ua) {
        if (f.type === "break") return;
        if (f.type === "return") return f;
      }
    }
    for (; this.evaluate(a); ) {
      var g = mb(this.M, e);
      if (g instanceof Ua) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
      this.evaluate(b);
    }
  }
  function ff(a) {
    return ~Number(this.evaluate(a));
  }
  function gf(a, b) {
    return Number(this.evaluate(a)) << Number(this.evaluate(b));
  }
  function hf(a, b) {
    return Number(this.evaluate(a)) >> Number(this.evaluate(b));
  }
  function jf(a, b) {
    return Number(this.evaluate(a)) >>> Number(this.evaluate(b));
  }
  function kf(a, b) {
    return Number(this.evaluate(a)) & Number(this.evaluate(b));
  }
  function lf(a, b) {
    return Number(this.evaluate(a)) ^ Number(this.evaluate(b));
  }
  function mf(a, b) {
    return Number(this.evaluate(a)) | Number(this.evaluate(b));
  }
  function nf() {}
  function of(a, b, c) {
    try {
      var d = this.evaluate(b);
      if (d instanceof Ua) return d;
    } catch (h) {
      if (!(h instanceof fb && h.un)) throw h;
      var e = this.M.sb();
      a !== "" && (h instanceof fb && (h = h.On), e.add(a, new Ud(h)));
      var f = this.evaluate(c),
        g = mb(e, f);
      if (g instanceof Ua) return g;
    }
  }
  function pf(a, b) {
    var c, d;
    try {
      d = this.evaluate(a);
    } catch (f) {
      if (!(f instanceof fb && f.un)) throw f;
      c = f;
    }
    var e = this.evaluate(b);
    if (e instanceof Ua) return e;
    if (c) throw c;
    if (d instanceof Ua) return d;
  }
  var rf = function () {
    this.D = new ob();
    qf(this);
  };
  rf.prototype.execute = function (a) {
    return this.D.Vj(a);
  };
  var qf = function (a) {
    var b = function (c, d) {
      var e = new Qd(String(c), d);
      e.Ua();
      var f = String(c);
      a.D.D.set(f, e);
      lb.set(f, e);
    };
    b("map", Me);
    b("and", zd);
    b("contains", Cd);
    b("equals", Ad);
    b("or", Bd);
    b("startsWith", Dd);
    b("variable", Ed);
  };
  rf.prototype.Pb = function (a) {
    this.D.Pb(a);
  };
  var tf = function () {
    this.J = !1;
    this.D = new ob();
    sf(this);
    this.J = !0;
  };
  tf.prototype.execute = function (a) {
    return uf(this.D.Vj(a));
  };
  var vf = function (a, b, c) {
    return uf(a.D.Sp(b, c));
  };
  tf.prototype.Ua = function () {
    this.D.Ua();
  };
  var sf = function (a) {
    var b = function (c, d) {
      var e = String(c),
        f = new Qd(e, d);
      f.Ua();
      a.D.D.set(e, f);
      lb.set(e, f);
    };
    b(0, be);
    b(1, ce);
    b(2, de);
    b(3, ee);
    b(56, kf);
    b(57, gf);
    b(58, ff);
    b(59, mf);
    b(60, hf);
    b(61, jf);
    b(62, lf);
    b(53, fe);
    b(4, ge);
    b(5, he);
    b(68, of);
    b(52, ie);
    b(6, je);
    b(49, le);
    b(7, Le);
    b(8, Me);
    b(9, he);
    b(50, me);
    b(10, ne);
    b(12, oe);
    b(13, pe);
    b(67, pf);
    b(51, Ae);
    b(47, se);
    b(54, te);
    b(55, ue);
    b(63, ze);
    b(64, ve);
    b(65, xe);
    b(66, ye);
    b(15, Be);
    b(16, De);
    b(17, De);
    b(18, Ee);
    b(19, Fe);
    b(20, Ge);
    b(21, He);
    b(22, Ie);
    b(23, Je);
    b(24, Ke);
    b(25, Ne);
    b(26, Oe);
    b(27, Pe);
    b(28, Qe);
    b(29, Re);
    b(45, Se);
    b(30, Te);
    b(32, Ve);
    b(33, Ve);
    b(34, We);
    b(35, We);
    b(46, Xe);
    b(36, Ye);
    b(43, Ze);
    b(37, $e);
    b(38, af);
    b(39, bf);
    b(40, cf);
    b(44, nf);
    b(41, df);
    b(42, ef);
  };
  tf.prototype.Qd = function () {
    return this.D.Qd();
  };
  tf.prototype.Pb = function (a) {
    this.D.Pb(a);
  };
  tf.prototype.ed = function (a) {
    this.D.ed(a);
  };
  function uf(a) {
    if (
      a instanceof Ua ||
      a instanceof Pd ||
      a instanceof Ld ||
      a instanceof pb ||
      a instanceof Wd ||
      a instanceof Ud ||
      a === null ||
      a === void 0 ||
      typeof a === "string" ||
      typeof a === "number" ||
      typeof a === "boolean"
    )
      return a;
  }
  var wf = function (a) {
    this.message = a;
  };
  function xf(a) {
    a.du = !0;
    return a;
  }
  var yf = xf(function (a) {
    return typeof a === "string";
  });
  function zf(a) {
    var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
      a
    ];
    return b === void 0
      ? new wf(
          "Value " + a + " can not be encoded in web-safe base64 dictionary.",
        )
      : b;
  }
  function Af(a) {
    switch (a) {
      case 1:
        return "1";
      case 2:
      case 4:
        return "0";
      default:
        return "-";
    }
  }
  var Bf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;
  function Cf(a, b) {
    for (var c = "", d = !0; a > 7; ) {
      var e = a & 31;
      a >>= 5;
      d ? (d = !1) : (e |= 32);
      c = "" + zf(e) + c;
    }
    a <<= 2;
    d || (a |= 32);
    return (c = "" + zf(a | b) + c);
  }
  function Df(a, b) {
    var c;
    var d = a.Zh,
      e = a.Kj;
    d === void 0
      ? (c = "")
      : (e || (e = 0), (c = "" + Cf(1, 1) + zf((d << 2) | e)));
    var f = a.xq,
      g = "4" + c + (f ? "" + Cf(2, 1) + zf(f) : ""),
      h,
      l = a.Zn;
    h = l && Bf.test(l) ? "" + Cf(3, 2) + l : "";
    var n,
      p = a.Vn;
    n = p ? "" + Cf(4, 1) + zf(p) : "";
    var q;
    var r = a.ctid;
    if (r && b) {
      var t = Cf(5, 3),
        u = r.split("-"),
        v = u[0].toUpperCase();
      if (v !== "GTM" && v !== "OPT") q = "";
      else {
        var x = u[1];
        q = "" + t + zf(1 + x.length) + (a.Fr || 0) + x;
      }
    } else q = "";
    var y = a.rs,
      z = a.canonicalId,
      C = a.Ra,
      E = a.iu,
      G =
        g +
        h +
        n +
        q +
        (y ? "" + Cf(6, 1) + zf(y) : "") +
        (z ? "" + Cf(7, 3) + zf(z.length) + z : "") +
        (C ? "" + Cf(8, 3) + zf(C.length) + C : "") +
        (E ? "" + Cf(9, 3) + zf(E.length) + E : ""),
      K;
    var P = a.Dq;
    P = P === void 0 ? {} : P;
    for (
      var fa = [], ca = m(Object.keys(P)), Q = ca.next();
      !Q.done;
      Q = ca.next()
    ) {
      var S = Q.value;
      fa[Number(S)] = P[S];
    }
    if (fa.length) {
      var ma = Cf(10, 3),
        ka;
      if (fa.length === 0) ka = zf(0);
      else {
        for (var V = [], U = 0, ea = !1, pa = 0; pa < fa.length; pa++) {
          ea = !0;
          var qa = pa % 6;
          fa[pa] && (U |= 1 << qa);
          qa === 5 && (V.push(zf(U)), (U = 0), (ea = !1));
        }
        ea && V.push(zf(U));
        ka = V.join("");
      }
      var Fa = ka;
      K = "" + ma + zf(Fa.length) + Fa;
    } else K = "";
    var Va = a.Mr,
      ib = a.Zr,
      ub = a.us;
    return (
      G +
      K +
      (Va ? "" + Cf(11, 3) + zf(Va.length) + Va : "") +
      (ib ? "" + Cf(13, 3) + zf(ib.length) + ib : "") +
      (ub ? "" + Cf(14, 1) + zf(ub) : "")
    );
  }
  function Ef(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    return b;
  }
  function Ff(a, b) {
    for (var c = wb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++)
      d[e] = c.charCodeAt(e);
    if (d.length !== 32) throw Error("Key is not 32 bytes.");
    return Gf(a, d);
  }
  function Gf(a, b) {
    if (a === "") return "";
    var c = fc(a),
      d = b.slice(-2),
      e = [].concat(Aa(d), Aa(c)).map(function (g, h) {
        return g ^ b[h % b.length];
      }),
      f = new Uint8Array([].concat(Aa(e), Aa(d)));
    return vb(String.fromCharCode.apply(String, Aa(f))).replace(/\.+$/, "");
  }
  var Hf = (function () {
    function a(b) {
      return {
        toString: function () {
          return b;
        },
      };
    }
    return {
      uo: a("consent"),
      yk: a("convert_case_to"),
      zk: a("convert_false_to"),
      Ak: a("convert_null_to"),
      Bk: a("convert_true_to"),
      Ck: a("convert_undefined_to"),
      Ns: a("debug_mode_metadata"),
      Ya: a("function"),
      Ki: a("instance_name"),
      Wp: a("live_only"),
      Xp: a("malware_disabled"),
      METADATA: a("metadata"),
      aq: a("original_activity_id"),
      Jt: a("original_vendor_template_id"),
      It: a("once_on_load"),
      Zp: a("once_per_event"),
      Jm: a("once_per_load"),
      Lt: a("priority_override"),
      Ot: a("respected_consent_types"),
      Sm: a("setup_tags"),
      Jh: a("tag_id"),
      hn: a("teardown_tags"),
    };
  })();
  var dg;
  var eg = [],
    fg = [],
    gg = [],
    hg = [],
    ig = [],
    jg,
    kg,
    lg;
  function mg(a) {
    lg = lg || a;
  }
  function ng() {
    for (
      var a = data.resource || {}, b = a.macros || [], c = 0;
      c < b.length;
      c++
    )
      eg.push(b[c]);
    for (var d = a.tags || [], e = 0; e < d.length; e++) hg.push(d[e]);
    for (var f = a.predicates || [], g = 0; g < f.length; g++) gg.push(f[g]);
    for (var h = a.rules || [], l = 0; l < h.length; l++) {
      for (var n = h[l], p = {}, q = 0; q < n.length; q++) {
        var r = n[q][0];
        p[r] = Array.prototype.slice.call(n[q], 1);
        (r !== "if" && r !== "unless") || og(p[r]);
      }
      fg.push(p);
    }
  }
  function og(a) {}
  var pg;
  function qg(a, b) {
    var c = {};
    c[Hf.Ya] = "__" + a;
    for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
    return c;
  }
  function rg(a, b, c) {
    try {
      return kg(sg(a, b, c));
    } catch (d) {
      JSON.stringify(a);
    }
    return 2;
  }
  var sg = function (a, b, c) {
      c = c || [];
      var d = {},
        e;
      for (e in a) a.hasOwnProperty(e) && (d[e] = tg(a[e], b, c));
      return d;
    },
    tg = function (a, b, c) {
      if (Array.isArray(a)) {
        var d;
        switch (a[0]) {
          case "function_id":
            return a[1];
          case "list":
            d = [];
            for (var e = 1; e < a.length; e++) d.push(tg(a[e], b, c));
            return d;
          case "macro":
            var f = a[1];
            if (c[f]) return;
            var g = eg[f];
            if (!g || b.isBlocked(g)) return;
            c[f] = !0;
            var h = String(g[Hf.Ki]);
            try {
              var l = sg(g, b, c);
              l.vtp_gtmEventId = b.id;
              b.priorityId && (l.vtp_gtmPriorityId = b.priorityId);
              d = ug(l, { event: b, index: f, type: 2, name: h });
              pg && (d = pg.Eq(d, l));
            } catch (z) {
              (b.logMacroError && b.logMacroError(z, Number(f), h), (d = !1));
            }
            c[f] = !1;
            return d;
          case "map":
            d = {};
            for (var n = 1; n < a.length; n += 2)
              d[tg(a[n], b, c)] = tg(a[n + 1], b, c);
            return d;
          case "template":
            d = [];
            for (var p = !1, q = 1; q < a.length; q++) {
              var r = tg(a[q], b, c);
              lg && (p = p || lg.Br(r));
              d.push(r);
            }
            return lg && p ? lg.Jq(d) : d.join("");
          case "escape":
            d = tg(a[1], b, c);
            if (lg && Array.isArray(a[1]) && a[1][0] === "macro" && lg.Cr(a))
              return lg.Rr(d);
            d = String(d);
            for (var t = 2; t < a.length; t++) Of[a[t]] && (d = Of[a[t]](d));
            return d;
          case "tag":
            var u = a[1];
            if (!hg[u])
              throw Error("Unable to resolve tag reference " + u + ".");
            return { zn: a[2], index: u };
          case "zb":
            var v = { arg0: a[2], arg1: a[3], ignore_case: a[5] };
            v[Hf.Ya] = a[1];
            var x = rg(v, b, c),
              y = !!a[4];
            return y || x !== 2 ? y !== (x === 1) : null;
          default:
            throw Error(
              "Attempting to expand unknown Value type: " + a[0] + ".",
            );
        }
      }
      return a;
    },
    ug = function (a, b) {
      var c = a[Hf.Ya],
        d = b && b.event;
      if (!c) throw Error("Error: No function name given for function call.");
      var e = jg[c],
        f = {},
        g;
      for (g in a)
        a.hasOwnProperty(g) &&
          Yb(g, "vtp_") &&
          (f[e !== void 0 ? g : g.substring(4)] = a[g]);
      e &&
        d &&
        d.cachedModelValues &&
        (f.vtp_gtmCachedValues = d.cachedModelValues);
      if (b) {
        if (b.name == null) {
          var h;
          a: {
            var l = b.type,
              n = b.index;
            if (n == null) h = "";
            else {
              var p;
              switch (l) {
                case 2:
                  p = eg[n];
                  break;
                case 1:
                  p = hg[n];
                  break;
                default:
                  h = "";
                  break a;
              }
              var q = p && p[Hf.Ki];
              h = q ? String(q) : "";
            }
          }
          b.name = h;
        }
        e && ((f.vtp_gtmEntityIndex = b.index), (f.vtp_gtmEntityName = b.name));
      }
      return e !== void 0 ? e(f) : dg(c, f, b);
    };
  function vg(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? !!data.blob[a]
      : b;
  }
  function D(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? String(data.blob[a])
      : b;
  }
  function wg(a) {
    var b, c;
    return (
      (b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)
    )
      ? Number(data.blob[a])
      : 0;
  }
  function xg(a) {
    var b;
    b = b === void 0 ? [] : b;
    var c,
      d,
      e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
    return Array.isArray(e) ? e : b;
  }
  function yg(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c = zg(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b;
  }
  function Ag(a, b) {
    var c = zg(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b;
  }
  function zg(a) {
    var b, c;
    return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a];
  }
  var Bg = function (a, b, c) {
    var d;
    d = Error.call(this, c);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.permissionId = a;
    this.parameters = b;
    this.name = "PermissionError";
  };
  xa(Bg, Error);
  Bg.prototype.getMessage = function () {
    return this.message;
  };
  function Cg(a, b) {
    if (Array.isArray(a)) {
      Object.defineProperty(a, "context", { value: { line: b[0] } });
      for (var c = 1; c < a.length; c++) Cg(a[c], b[c]);
    }
  }
  function Dg() {
    return function (a, b) {
      var c;
      var d = Eg;
      a instanceof fb ? ((a.D = d), (c = a)) : (c = new fb(a, d));
      var e = c;
      b && e.debugInfo.push(b);
      throw e;
    };
  }
  function Eg(a) {
    if (!a.length) return a;
    a.push({ id: "main", line: 0 });
    for (var b = a.length - 1; b > 0; b--) Gb(a[b].id) && a.splice(b++, 1);
    for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
    a.splice(0, 1);
    return a;
  }
  function Fg(a) {
    function b(r) {
      for (var t = 0; t < r.length; t++) d[r[t]] = !0;
    }
    for (var c = [], d = [], e = Gg(a), f = 0; f < fg.length; f++) {
      var g = fg[f],
        h = Hg(g, e);
      if (h) {
        for (var l = g.add || [], n = 0; n < l.length; n++) c[l[n]] = !0;
        b(g.block || []);
      } else h === null && b(g.block || []);
    }
    for (var p = [], q = 0; q < hg.length; q++) c[q] && !d[q] && (p[q] = !0);
    return p;
  }
  function Hg(a, b) {
    for (var c = a["if"] || [], d = 0; d < c.length; d++) {
      var e = b(c[d]);
      if (e === 0) return !1;
      if (e === 2) return null;
    }
    for (var f = a.unless || [], g = 0; g < f.length; g++) {
      var h = b(f[g]);
      if (h === 2) return null;
      if (h === 1) return !1;
    }
    return !0;
  }
  function Gg(a) {
    var b = [];
    return function (c) {
      b[c] === void 0 && (b[c] = rg(gg[c], a));
      return b[c];
    };
  }
  function Ig(a, b) {
    b[Hf.yk] &&
      typeof a === "string" &&
      (a = b[Hf.yk] === 1 ? a.toLowerCase() : a.toUpperCase());
    b.hasOwnProperty(Hf.Ak) && a === null && (a = b[Hf.Ak]);
    b.hasOwnProperty(Hf.Ck) && a === void 0 && (a = b[Hf.Ck]);
    b.hasOwnProperty(Hf.Bk) && a === !0 && (a = b[Hf.Bk]);
    b.hasOwnProperty(Hf.zk) && a === !1 && (a = b[Hf.zk]);
    return a;
  }
  var Jg = function () {
      this.D = {};
    },
    Kg = function (a, b, c) {
      var d;
      (d = a.D)[b] != null || (d[b] = []);
      a.D[b].push(function () {
        return c.apply(null, Aa(Qa.apply(0, arguments)));
      });
    };
  function Lg(a, b, c, d) {
    if (a)
      for (var e = 0; e < a.length; e++) {
        var f = void 0,
          g = "A policy function denied the permission request";
        try {
          ((f = a[e](b, c, d)), (g += "."));
        } catch (h) {
          g =
            typeof h === "string"
              ? g + (": " + h)
              : h instanceof Error
                ? g + (": " + h.message)
                : g + ".";
        }
        if (!f) throw new Bg(c, d, g);
      }
  }
  function Mg(a, b, c) {
    return function (d) {
      if (d) {
        var e = a.D[d],
          f = a.D.all;
        if (e || f) {
          var g = c.apply(void 0, [d].concat(Aa(Qa.apply(1, arguments))));
          Lg(e, b, d, g);
          Lg(f, b, d, g);
        }
      }
    };
  }
  var Pg = function (a, b) {
      var c = this;
      this.J = {};
      this.D = new Jg();
      var d = {},
        e = {},
        f = Mg(this.D, a, function (g) {
          return g && d[g]
            ? d[g].apply(void 0, [g].concat(Aa(Qa.apply(1, arguments))))
            : {};
        });
      Mb(b, function (g, h) {
        function l(p) {
          var q = Qa.apply(1, arguments);
          if (!n[p])
            throw Ng(
              p,
              {},
              "The requested additional permission " +
                p +
                " is not configured.",
            );
          f.apply(null, [p].concat(Aa(q)));
        }
        var n = {};
        Mb(h, function (p, q) {
          var r = Og(p, q);
          n[p] = r.assert;
          d[p] || (d[p] = r.W);
          r.sn && !e[p] && (e[p] = r.sn);
        });
        c.J[g] = function (p, q) {
          var r = n[p];
          if (!r)
            throw Ng(
              p,
              {},
              "The requested permission " + p + " is not configured.",
            );
          var t = Array.prototype.slice.call(arguments, 0);
          r.apply(void 0, t);
          f.apply(void 0, t);
          var u = e[p];
          u && u.apply(null, [l].concat(Aa(t.slice(1))));
        };
      });
    },
    Rg = function (a) {
      return Qg.J[a] || function () {};
    };
  function Og(a, b) {
    var c = qg(a, b);
    c.vtp_permissionName = a;
    c.vtp_createPermissionError = Ng;
    try {
      return ug(c);
    } catch (d) {
      return {
        assert: function (e) {
          throw new Bg(e, {}, "Permission " + e + " is unknown.");
        },
        W: function () {
          throw new Bg(a, {}, "Permission " + a + " is unknown.");
        },
      };
    }
  }
  function Ng(a, b, c) {
    return new Bg(a, b, c);
  }
  var Sg = D(5),
    Tg = D(20),
    Ug = D(1),
    Vg = !1;
  var Wg = {};
  Wg.io = vg(29);
  Wg.Pq = vg(28);
  var F = {
    P: {
      yo: 1,
      Bo: 2,
      jn: 3,
      Mm: 4,
      Jk: 5,
      Kk: 6,
      Np: 7,
      Co: 8,
      Mp: 9,
      xo: 10,
      wo: 11,
      Ym: 12,
      Tm: 13,
      rk: 14,
      mo: 15,
      oo: 16,
      Hm: 17,
      Lk: 18,
      Em: 19,
      zo: 20,
      Yp: 21,
      ro: 22,
      no: 23,
      po: 24,
      Hk: 25,
      pk: 26,
      jq: 27,
      im: 28,
      tm: 29,
      sm: 30,
      rm: 31,
      lm: 32,
      jm: 33,
      km: 34,
      fm: 35,
      dm: 36,
      gm: 37,
      hm: 38,
      Lp: 39,
    },
  };
  F.P[F.P.yo] = "CREATE_EVENT_SOURCE";
  F.P[F.P.Bo] = "EDIT_EVENT";
  F.P[F.P.jn] = "TRAFFIC_TYPE";
  F.P[F.P.Mm] = "REFERRAL_EXCLUSION";
  F.P[F.P.Jk] = "ECOMMERCE_FROM_GTM_TAG";
  F.P[F.P.Kk] = "ECOMMERCE_FROM_GTM_UA_SCHEMA";
  F.P[F.P.Np] = "GA_SEND";
  F.P[F.P.Co] = "EM_FORM";
  F.P[F.P.Mp] = "GA_GAM_LINK";
  F.P[F.P.xo] = "CREATE_EVENT_AUTO_PAGE_PATH";
  F.P[F.P.wo] = "CREATED_EVENT";
  F.P[F.P.Ym] = "SIDELOADED";
  F.P[F.P.Tm] = "SGTM_LEGACY_CONFIGURATION";
  F.P[F.P.rk] = "CCD_EM_EVENT";
  F.P[F.P.mo] = "AUTO_REDACT_EMAIL";
  F.P[F.P.oo] = "AUTO_REDACT_QUERY_PARAM";
  F.P[F.P.Hm] = "MULTIPLE_PAGEVIEW_FROM_CONFIG";
  F.P[F.P.Lk] = "EM_EVENT_SENT_BEFORE_CONFIG";
  F.P[F.P.Em] = "LOADED_VIA_CST_OR_SIDELOADING";
  F.P[F.P.zo] = "DECODED_PARAM_MATCH";
  F.P[F.P.Yp] = "NON_DECODED_PARAM_MATCH";
  F.P[F.P.ro] = "CCD_EVENT_SGTM";
  F.P[F.P.no] = "AUTO_REDACT_EMAIL_SGTM";
  F.P[F.P.po] = "AUTO_REDACT_QUERY_PARAM_SGTM";
  F.P[F.P.Hk] = "DAILY_LIMIT_REACHED";
  F.P[F.P.pk] = "BURST_LIMIT_REACHED";
  F.P[F.P.jq] = "SHARED_USER_ID_SET_AFTER_REQUEST";
  F.P[F.P.im] = "GA4_MULTIPLE_SESSION_COOKIES";
  F.P[F.P.tm] = "INVALID_GA4_SESSION_COUNT";
  F.P[F.P.sm] = "INVALID_GA4_LAST_EVENT_TIMESTAMP";
  F.P[F.P.rm] = "INVALID_GA4_JOIN_TIMER";
  F.P[F.P.lm] = "GA4_STALE_SESSION_COOKIE_SELECTED";
  F.P[F.P.jm] = "GA4_SESSION_COOKIE_GS1_READ";
  F.P[F.P.km] = "GA4_SESSION_COOKIE_GS2_READ";
  F.P[F.P.fm] = "GA4_DL_PARAM_RECOVERY_AVAILABLE";
  F.P[F.P.dm] = "GA4_DL_PARAM_RECOVERY_APPLIED";
  F.P[F.P.gm] = "GA4_GOOGLE_SIGNALS_ALLOWED";
  F.P[F.P.hm] = "GA4_GOOGLE_SIGNALS_ENABLED";
  F.P[F.P.Lp] = "GA4_FALLBACK_REQUEST";
  var bh = {},
    ch =
      ((bh.uaa = !0),
      (bh.uab = !0),
      (bh.uafvl = !0),
      (bh.uamb = !0),
      (bh.uam = !0),
      (bh.uap = !0),
      (bh.uapv = !0),
      (bh.uaw = !0),
      bh);
  var kh = function (a, b) {
      for (var c = 0; c < b.length; c++) {
        var d = a,
          e = b[c];
        if (!ih.exec(e)) throw Error("Invalid key wildcard");
        var f = e.indexOf(".*"),
          g = f !== -1 && f === e.length - 2,
          h = g ? e.slice(0, e.length - 2) : e,
          l;
        a: if (d.length === 0) l = !1;
        else {
          for (var n = d.split("."), p = 0; p < n.length; p++)
            if (!jh.exec(n[p])) {
              l = !1;
              break a;
            }
          l = !0;
        }
        if (
          !l || h.length > d.length || (!g && d.length !== e.length)
            ? 0
            : g
              ? Yb(d, h) && (d === h || d.charAt(h.length) === ".")
              : d === h
        )
          return !0;
      }
      return !1;
    },
    jh = /^[a-z$_][\w-$]*$/i,
    ih = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
  var lh = [
    "matches",
    "webkitMatchesSelector",
    "mozMatchesSelector",
    "msMatchesSelector",
    "oMatchesSelector",
  ];
  function mh(a, b) {
    var c = String(a),
      d = String(b),
      e = c.length - d.length;
    return e >= 0 && c.indexOf(d, e) === e;
  }
  function nh(a, b) {
    return String(a).split(",").indexOf(String(b)) >= 0;
  }
  var oh = new Lb();
  function ph(a, b, c) {
    var d = c ? "i" : void 0;
    try {
      var e = String(b) + String(d),
        f = oh.get(e);
      f || ((f = new RegExp(b, d)), oh.set(e, f));
      return f.test(a);
    } catch (g) {
      return !1;
    }
  }
  function qh(a, b) {
    return String(a).indexOf(String(b)) >= 0;
  }
  function rh(a, b) {
    return String(a) === String(b);
  }
  function sh(a, b) {
    return Number(a) >= Number(b);
  }
  function th(a, b) {
    return Number(a) <= Number(b);
  }
  function uh(a, b) {
    return Number(a) > Number(b);
  }
  function vh(a, b) {
    return Number(a) < Number(b);
  }
  function wh(a, b) {
    return Yb(String(a), String(b));
  }
  var Dh =
      /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
    Eh = { Fn: "function", PixieMap: "Object", List: "Array" };
  function Fh(a, b) {
    for (var c = ["input:!*"], d = 0; d < c.length; d++) {
      var e = Dh.exec(c[d]);
      if (!e) throw Error("Internal Error in " + a);
      var f = e[1],
        g = e[2] === "!",
        h = e[3],
        l = b[d];
      if (l == null) {
        if (g)
          throw Error(
            "Error in " + a + ". Required argument " + f + " not supplied.",
          );
      } else if (h !== "*") {
        var n = typeof l;
        l instanceof Pd
          ? (n = "Fn")
          : l instanceof Ld
            ? (n = "List")
            : l instanceof pb
              ? (n = "PixieMap")
              : l instanceof Wd
                ? (n = "PixiePromise")
                : l instanceof Ud && (n = "OpaqueValue");
        if (n !== h)
          throw Error(
            "Error in " +
              a +
              ". Argument " +
              f +
              " has type " +
              ((Eh[n] || n) + ", which does not match required type ") +
              ((Eh[h] || h) + "."),
          );
      }
    }
  }
  function H(a, b, c) {
    for (var d = [], e = m(c), f = e.next(); !f.done; f = e.next()) {
      var g = f.value;
      g instanceof Pd
        ? d.push("function")
        : g instanceof Ld
          ? d.push("Array")
          : g instanceof pb
            ? d.push("Object")
            : g instanceof Wd
              ? d.push("Promise")
              : g instanceof Ud
                ? d.push("OpaqueValue")
                : d.push(typeof g);
    }
    return Error(
      "Argument error in " +
        a +
        ". Expected argument types [" +
        (b.join(",") + "], but received [") +
        (d.join(",") + "]."),
    );
  }
  function Gh(a) {
    return a instanceof pb;
  }
  function Hh(a) {
    return Gh(a) || a === null || Ih(a);
  }
  function Jh(a) {
    return a instanceof Pd;
  }
  function Kh(a) {
    return Jh(a) || a === null || Ih(a);
  }
  function Lh(a) {
    return a instanceof Ld;
  }
  function Mh(a) {
    return a instanceof Ud;
  }
  function Nh(a) {
    return typeof a === "string";
  }
  function Oh(a) {
    return Nh(a) || a === null || Ih(a);
  }
  function Ph(a) {
    return typeof a === "boolean";
  }
  function Qh(a) {
    return Ph(a) || Ih(a);
  }
  function Rh(a) {
    return Ph(a) || a === null || Ih(a);
  }
  function Sh(a) {
    return typeof a === "number";
  }
  function Ih(a) {
    return a === void 0;
  }
  function Th(a) {
    return "" + a;
  }
  function Uh(a, b) {
    var c = [];
    return c;
  }
  function Vh(a, b) {
    var c = new Pd(a, function () {
      for (
        var d = Array.prototype.slice.call(arguments, 0), e = 0;
        e < d.length;
        e++
      )
        d[e] = this.evaluate(d[e]);
      try {
        return b.apply(this, d);
      } catch (g) {
        throw gb(g);
      }
    });
    c.Ua();
    return c;
  }
  function Wh(a, b) {
    var c = new pb(),
      d;
    for (d in b)
      if (b.hasOwnProperty(d)) {
        var e = b[d];
        Eb(e)
          ? c.set(d, Vh(a + "_" + d, e))
          : Id(e)
            ? c.set(d, Wh(a + "_" + d, e))
            : (Gb(e) || Fb(e) || typeof e === "boolean") && c.set(d, e);
      }
    c.Ua();
    return c;
  }
  function Xh(a, b) {
    if (!Nh(a)) throw H(this.getName(), ["string"], arguments);
    if (!Oh(b)) throw H(this.getName(), ["string", "undefined"], arguments);
    var c = {},
      d = new pb();
    return (d = Wh("AssertApiSubject", c));
  }
  function Yh(a, b) {
    if (!Oh(b)) throw H(this.getName(), ["string", "undefined"], arguments);
    if (a instanceof Wd)
      throw Error(
        "Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.",
      );
    var c = {},
      d = new pb();
    return (d = Wh("AssertThatSubject", c));
  }
  function Zh(a) {
    return function () {
      for (
        var b = Qa.apply(0, arguments), c = [], d = this.M, e = 0;
        e < b.length;
        ++e
      )
        c.push(B(b[e], d));
      return Xd(a.apply(null, c));
    };
  }
  function $h() {
    for (var a = Math, b = ai, c = {}, d = 0; d < b.length; d++) {
      var e = b[d];
      a.hasOwnProperty(e) && (c[e] = Zh(a[e].bind(a)));
    }
    return c;
  }
  function bi(a) {
    return a != null && Yb(a, "__cvt_");
  }
  function ci(a) {
    var b;
    return b;
  }
  function di(a) {
    var b;
    if (!Nh(a)) throw H(this.getName(), ["string"], arguments);
    try {
      b = decodeURIComponent(a);
    } catch (c) {}
    return b;
  }
  function ei(a) {
    try {
      return encodeURI(a);
    } catch (b) {}
  }
  function fi(a) {
    try {
      return encodeURIComponent(String(a));
    } catch (b) {}
  }
  function ki(a) {
    if (!Oh(a)) throw H(this.getName(), ["string|undefined"], arguments);
  }
  function li(a) {
    var b = 1,
      c,
      d,
      e;
    if (a)
      for (b = 0, d = a.length - 1; d >= 0; d--)
        ((e = a.charCodeAt(d)),
          (b = ((b << 6) & 268435455) + e + (e << 14)),
          (c = b & 266338304),
          (b = c !== 0 ? b ^ (c >> 21) : b));
    return b;
  }
  function mi(a) {
    var b = B(a);
    return li(b ? "" + b : "");
  }
  function ni(a, b) {
    if (!Sh(a) || !Sh(b))
      throw H(this.getName(), ["number", "number"], arguments);
    return Jb(a, b);
  }
  function oi() {
    return new Date().getTime();
  }
  function pi(a) {
    if (a === null) return "null";
    if (a instanceof Ld) return "array";
    if (a instanceof Pd) return "function";
    if (a instanceof Ud) {
      var b = a.getValue();
      if (
        (b == null ? void 0 : b.constructor) === void 0 ||
        b.constructor.name === void 0
      ) {
        var c = String(b);
        return c.substring(8, c.length - 1);
      }
      return String(b.constructor.name);
    }
    return typeof a;
  }
  function qi(a) {
    function b(c) {
      return function (d) {
        try {
          return c(d);
        } catch (e) {
          (Vg || Wg.io) && a.call(this, e.message);
        }
      };
    }
    return {
      parse: b(function (c) {
        return Xd(JSON.parse(c));
      }),
      stringify: b(function (c) {
        return JSON.stringify(B(c));
      }),
      publicName: "JSON",
    };
  }
  function ri(a) {
    return Ob(B(a, this.M));
  }
  function si(a) {
    return Number(B(a, this.M));
  }
  function ti(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a.toString();
  }
  function ui(a, b, c) {
    var d = null,
      e = !1;
    if (!Lh(a) || !Nh(b) || !Nh(c))
      throw H(this.getName(), ["Array", "string", "string"], arguments);
    d = new pb();
    for (var f = 0; f < a.length(); f++) {
      var g = a.get(f);
      g instanceof pb &&
        g.has(b) &&
        g.has(c) &&
        (d.set(g.get(b), g.get(c)), (e = !0));
    }
    return e ? d : null;
  }
  var ai = "floor ceil round max min abs pow sqrt".split(" ");
  function vi() {
    var a = {};
    return {
      Yq: function (b) {
        return a.hasOwnProperty(b) ? a[b] : void 0;
      },
      co: function (b, c) {
        a[b] = c;
      },
      reset: function () {
        a = {};
      },
    };
  }
  function wi(a, b) {
    return function () {
      return Pd.prototype.invoke.apply(
        a,
        [b].concat(Aa(Qa.apply(0, arguments))),
      );
    };
  }
  function xi(a, b) {
    if (!Nh(a)) throw H(this.getName(), ["string", "any"], arguments);
  }
  function yi(a, b) {
    if (!Nh(a) || !Gh(b))
      throw H(this.getName(), ["string", "PixieMap"], arguments);
  }
  var zi = {};
  var Ai = function (a) {
    var b = new pb();
    if (a instanceof Ld)
      for (var c = a.za(), d = 0; d < c.length; d++) {
        var e = c[d];
        a.has(e) && b.set(e, a.get(e));
      }
    else if (a instanceof Pd)
      for (var f = a.za(), g = 0; g < f.length; g++) {
        var h = f[g];
        b.set(h, a.get(h));
      }
    else for (var l = 0; l < a.length; l++) b.set(l, a[l]);
    return b;
  };
  zi.keys = function (a) {
    Fh(this.getName(), arguments);
    if (a instanceof Ld || a instanceof Pd || typeof a === "string") a = Ai(a);
    if (a instanceof pb || a instanceof Wd) return new Ld(a.za());
    return new Ld();
  };
  zi.values = function (a) {
    Fh(this.getName(), arguments);
    if (a instanceof Ld || a instanceof Pd || typeof a === "string") a = Ai(a);
    if (a instanceof pb || a instanceof Wd) return new Ld(a.Bc());
    return new Ld();
  };
  zi.entries = function (a) {
    Fh(this.getName(), arguments);
    if (a instanceof Ld || a instanceof Pd || typeof a === "string") a = Ai(a);
    if (a instanceof pb || a instanceof Wd)
      return new Ld(
        a.fc().map(function (b) {
          return new Ld(b);
        }),
      );
    return new Ld();
  };
  zi.freeze = function (a) {
    (a instanceof pb ||
      a instanceof Wd ||
      a instanceof Ld ||
      a instanceof Pd) &&
      a.Ua();
    return a;
  };
  zi.delete = function (a, b) {
    if (a instanceof pb && !a.Eb()) return (a.remove(b), !0);
    return !1;
  };
  function I(a, b) {
    var c = Qa.apply(2, arguments),
      d = a.M.ub();
    if (!d) throw Error("Missing program state.");
    if (d.Xr) {
      try {
        d.tn.apply(null, [b].concat(Aa(c)));
      } catch (e) {
        throw (yb("TAGGING", 21), e);
      }
      return;
    }
    d.tn.apply(null, [b].concat(Aa(c)));
  }
  var Bi = function () {
    this.J = {};
    this.D = {};
    this.N = !0;
  };
  Bi.prototype.get = function (a, b) {
    var c = this.contains(a) ? this.J[a] : void 0;
    return c;
  };
  Bi.prototype.contains = function (a) {
    return this.J.hasOwnProperty(a);
  };
  Bi.prototype.add = function (a, b, c) {
    if (this.contains(a))
      throw Error(
        "Attempting to add a function which already exists: " + a + ".",
      );
    if (this.D.hasOwnProperty(a))
      throw Error(
        "Attempting to add an API with an existing private API name: " +
          a +
          ".",
      );
    this.J[a] = c ? void 0 : Eb(b) ? Vh(a, b) : Wh(a, b);
  };
  function Ci(a, b) {
    var c = void 0;
    return c;
  }
  function Di() {
    var a = {};
    return a;
  }
  var J = {
    m: {
      Ka: "ad_personalization",
      X: "ad_storage",
      Z: "ad_user_data",
      la: "analytics_storage",
      mc: "region",
      ka: "consent_updated",
      Sg: "wait_for_update",
      Eo: "app_remove",
      Fo: "app_store_refund",
      Go: "app_store_subscription_cancel",
      Ho: "app_store_subscription_convert",
      Io: "app_store_subscription_renew",
      Jo: "consent_update",
      Ko: "conversion",
      Nk: "add_payment_info",
      Ok: "add_shipping_info",
      ie: "add_to_cart",
      je: "remove_from_cart",
      Pk: "view_cart",
      jd: "begin_checkout",
      Rs: "generate_lead",
      ke: "select_item",
      nc: "view_item_list",
      Gc: "select_promotion",
      oc: "view_promotion",
      Fb: "purchase",
      me: "refund",
      qc: "view_item",
      Qk: "add_to_wishlist",
      Lo: "exception",
      Mo: "first_open",
      No: "first_visit",
      na: "gtag.config",
      Gb: "gtag.get",
      Oo: "in_app_purchase",
      rc: "page_view",
      Po: "screen_view",
      Qo: "session_start",
      Ro: "source_update",
      So: "timing_complete",
      To: "track_social",
      cf: "user_engagement",
      Uo: "user_id_update",
      df: "gclid_link_decoration_source",
      ef: "gclid_storage_source",
      sc: "gclgb",
      yb: "gclid",
      Rk: "gclid_len",
      ne: "gclgs",
      oe: "gcllp",
      pe: "gclst",
      La: "ads_data_redaction",
      ff: "gad_source",
      hf: "gad_source_src",
      kd: "gclid_url",
      Sk: "gclsrc",
      jf: "gbraid",
      qe: "wbraid",
      Rb: "allow_ad_personalization_signals",
      kf: "allow_custom_scripts",
      lf: "allow_direct_google_requests",
      Yg: "allow_display_features",
      ii: "allow_enhanced_conversions",
      uc: "allow_google_signals",
      ji: "allow_interest_groups",
      Vo: "app_id",
      Wo: "app_installer_id",
      Xo: "app_name",
      Yo: "app_version",
      ld: "auid",
      Ss: "auto_detection_enabled",
      Tk: "auto_event",
      Uk: "aw_remarketing",
      Zg: "aw_remarketing_only",
      nf: "discount",
      pf: "aw_feed_country",
      qf: "aw_feed_language",
      wa: "items",
      rf: "aw_merchant_id",
      ki: "aw_basket_type",
      tf: "campaign_content",
      uf: "campaign_id",
      vf: "campaign_medium",
      wf: "campaign_name",
      xf: "campaign",
      yf: "campaign_source",
      zf: "campaign_term",
      Sb: "client_id",
      Vk: "rnd",
      li: "consent_update_type",
      Zo: "content_group",
      ap: "content_type",
      Hb: "conversion_cookie_prefix",
      mi: "conversion_id",
      zb: "conversion_linker",
      ah: "conversion_linker_disabled",
      md: "conversion_api",
      bh: "cookie_deprecation",
      Ib: "cookie_domain",
      Ab: "cookie_expires",
      Tb: "cookie_flags",
      nd: "cookie_name",
      vc: "cookie_path",
      eb: "cookie_prefix",
      od: "cookie_update",
      Hc: "country",
      nb: "currency",
      eh: "customer_buyer_stage",
      te: "customer_lifetime_value",
      fh: "customer_loyalty",
      gh: "customer_ltv_bucket",
      ue: "custom_map",
      hh: "gcldc",
      pd: "dclid",
      Wk: "debug_mode",
      Ha: "developer_id",
      bp: "disable_merchant_reported_purchases",
      Ic: "dc_custom_params",
      Xk: "dc_natural_search",
      cp: "dynamic_event_settings",
      Yk: "affiliation",
      ih: "checkout_option",
      ni: "checkout_step",
      Zk: "coupon",
      Af: "item_list_name",
      oi: "list_name",
      ep: "promotions",
      rd: "shipping",
      al: "tax",
      jh: "engagement_time_msec",
      kh: "enhanced_client_id",
      fp: "enhanced_conversions",
      Ts: "enhanced_conversions_automatic_settings",
      ve: "estimated_delivery_date",
      Bf: "event_callback",
      hp: "event_category",
      Jc: "event_developer_id_string",
      jp: "event_label",
      Kc: "event",
      ri: "event_settings",
      mh: "event_timeout",
      kp: "description",
      lp: "fatal",
      mp: "experiments",
      si: "firebase_id",
      Cf: "first_party_collection",
      Df: "_x_20",
      Ub: "_x_19",
      np: "flight_error_code",
      op: "flight_error_message",
      bl: "fl_activity_category",
      fl: "fl_activity_group",
      ui: "fl_advertiser_id",
      il: "fl_ar_dedupe",
      Ef: "match_id",
      jl: "fl_random_number",
      kl: "tran",
      ml: "u",
      nh: "gac_gclid",
      we: "gac_wbraid",
      nl: "gac_wbraid_multiple_conversions",
      pp: "ga_restrict_domain",
      ol: "ga_temp_client_id",
      qp: "ga_temp_ecid",
      xe: "gdpr_applies",
      pl: "geo_granularity",
      Ff: "value_callback",
      Gf: "value_key",
      Bb: "google_analysis_params",
      ye: "_google_ng",
      Hf: "google_signals",
      rp: "google_tld",
      oh: "gpp_sid",
      ph: "gpp_string",
      qh: "groups",
      ql: "gsa_experiment_id",
      If: "gtag_event_feature_usage",
      rl: "gtm_up",
      ud: "iframe_state",
      Jf: "ignore_referrer",
      sl: "internal_traffic_results",
      tl: "_is_fpm",
      Mc: "is_legacy_converted",
      Nc: "is_legacy_loaded",
      wi: "is_passthrough",
      ze: "_lps",
      ob: "language",
      rh: "legacy_developer_id_string",
      fb: "linker",
      Kf: "accept_incoming",
      Oc: "decorate_forms",
      xa: "domains",
      vd: "url_position",
      wc: "merchant_feed_label",
      xc: "merchant_feed_language",
      yc: "merchant_id",
      vl: "method",
      tp: "name",
      wl: "navigation_type",
      Ae: "new_customer",
      xi: "non_interaction",
      up: "optimize_id",
      xl: "page_hostname",
      Lf: "page_path",
      Xa: "page_referrer",
      Jb: "page_title",
      vp: "passengers",
      yl: "phone_conversion_callback",
      wp: "phone_conversion_country_code",
      zl: "phone_conversion_css_class",
      xp: "phone_conversion_ids",
      Al: "phone_conversion_number",
      Bl: "phone_conversion_options",
      yp: "_platinum_request_status",
      zp: "_protected_audience_enabled",
      Pc: "quantity",
      sh: "redact_device_info",
      Cl: "referral_exclusion_definition",
      Us: "_request_start_time",
      Vb: "restricted_data_processing",
      Ap: "retoken",
      Bp: "sample_rate",
      yi: "screen_name",
      Qc: "screen_resolution",
      Dl: "_script_source",
      Cp: "search_term",
      wd: "send_page_view",
      xd: "send_to",
      yd: "server_container_url",
      Dp: "session_attributes_encoded",
      th: "session_duration",
      uh: "session_engaged",
      zi: "session_engaged_time",
      pb: "session_id",
      wh: "session_number",
      Mf: "_shared_user_id",
      zd: "delivery_postal_code",
      Vs: "_tag_firing_delay",
      Ws: "_tag_firing_time",
      Xs: "temporary_client_id",
      El: "testonly",
      Ep: "_timezone",
      Ai: "topmost_url",
      xh: "tracking_id",
      Bi: "traffic_type",
      Da: "transaction_id",
      Fl: "transaction_id_source",
      Rc: "transport_url",
      Fp: "trip_type",
      Bd: "update",
      Kb: "url_passthrough",
      Gl: "uptgs",
      Nf: "_user_agent_architecture",
      Of: "_user_agent_bitness",
      Pf: "_user_agent_full_version_list",
      Qf: "_user_agent_mobile",
      Rf: "_user_agent_model",
      Sf: "_user_agent_platform",
      Tf: "_user_agent_platform_version",
      Uf: "_user_agent_wow64",
      Lb: "user_data",
      Hl: "user_data_auto_latency",
      Il: "user_data_auto_meta",
      Jl: "user_data_auto_multi",
      Kl: "user_data_auto_selectors",
      Ll: "user_data_auto_status",
      Cd: "user_data_mode",
      Ml: "user_data_settings",
      Oa: "user_id",
      zc: "user_properties",
      Nl: "_user_region",
      Vf: "us_privacy_string",
      Ea: "value",
      Ol: "wbraid_multiple_conversions",
      Sc: "_fpm_parameters",
      Ji: "_host_name",
      vm: "_in_page_command",
      Mi: "_ip_override",
      zm: "_is_passthrough_cid",
      Fh: "_measurement_type",
      Jd: "non_personalized_ads",
      Yi: "_sst_parameters",
      iq: "sgtm_geo_user_country",
      se: "conversion_label",
      ya: "page_location",
      sd: "_extracted_data",
      Lc: "global_developer_id_string",
      Be: "tc_privacy_string",
    },
  };
  var Ei = {},
    Fi =
      ((Ei[J.m.ka] = "gcu"),
      (Ei[J.m.sc] = "gclgb"),
      (Ei[J.m.yb] = "gclaw"),
      (Ei[J.m.Rk] = "gclid_len"),
      (Ei[J.m.ne] = "gclgs"),
      (Ei[J.m.oe] = "gcllp"),
      (Ei[J.m.pe] = "gclst"),
      (Ei[J.m.ld] = "auid"),
      (Ei[J.m.Tk] = "ae"),
      (Ei[J.m.nf] = "dscnt"),
      (Ei[J.m.pf] = "fcntr"),
      (Ei[J.m.qf] = "flng"),
      (Ei[J.m.rf] = "mid"),
      (Ei[J.m.ki] = "bttype"),
      (Ei[J.m.Sb] = "gacid"),
      (Ei[J.m.se] = "label"),
      (Ei[J.m.md] = "capi"),
      (Ei[J.m.bh] = "pscdl"),
      (Ei[J.m.nb] = "currency_code"),
      (Ei[J.m.eh] = "clobs"),
      (Ei[J.m.te] = "vdltv"),
      (Ei[J.m.fh] = "clolo"),
      (Ei[J.m.gh] = "clolb"),
      (Ei[J.m.Wk] = "_dbg"),
      (Ei[J.m.ve] = "oedeld"),
      (Ei[J.m.Jc] = "edid"),
      (Ei[J.m.nh] = "gac"),
      (Ei[J.m.we] = "gacgb"),
      (Ei[J.m.nl] = "gacmcov"),
      (Ei[J.m.xe] = "gdpr"),
      (Ei[J.m.Lc] = "gdid"),
      (Ei[J.m.ye] = "_ng"),
      (Ei[J.m.oh] = "gpp_sid"),
      (Ei[J.m.ph] = "gpp"),
      (Ei[J.m.ql] = "gsaexp"),
      (Ei[J.m.If] = "_tu"),
      (Ei[J.m.ud] = "frm"),
      (Ei[J.m.wi] = "gtm_up"),
      (Ei[J.m.ze] = "lps"),
      (Ei[J.m.rh] = "did"),
      (Ei[J.m.wc] = "fcntr"),
      (Ei[J.m.xc] = "flng"),
      (Ei[J.m.yc] = "mid"),
      (Ei[J.m.Ae] = void 0),
      (Ei[J.m.Jb] = "tiba"),
      (Ei[J.m.Vb] = "rdp"),
      (Ei[J.m.pb] = "ecsid"),
      (Ei[J.m.Mf] = "ga_uid"),
      (Ei[J.m.zd] = "delopc"),
      (Ei[J.m.Be] = "gdpr_consent"),
      (Ei[J.m.Da] = "oid"),
      (Ei[J.m.Fl] = "oidsrc"),
      (Ei[J.m.Gl] = "uptgs"),
      (Ei[J.m.Nf] = "uaa"),
      (Ei[J.m.Of] = "uab"),
      (Ei[J.m.Pf] = "uafvl"),
      (Ei[J.m.Qf] = "uamb"),
      (Ei[J.m.Rf] = "uam"),
      (Ei[J.m.Sf] = "uap"),
      (Ei[J.m.Tf] = "uapv"),
      (Ei[J.m.Uf] = "uaw"),
      (Ei[J.m.Hl] = "ec_lat"),
      (Ei[J.m.Il] = "ec_meta"),
      (Ei[J.m.Jl] = "ec_m"),
      (Ei[J.m.Kl] = "ec_sel"),
      (Ei[J.m.Ll] = "ec_s"),
      (Ei[J.m.Cd] = "ec_mode"),
      (Ei[J.m.Oa] = "userId"),
      (Ei[J.m.Vf] = "us_privacy"),
      (Ei[J.m.Ea] = "value"),
      (Ei[J.m.Ol] = "mcov"),
      (Ei[J.m.Ji] = "hn"),
      (Ei[J.m.vm] = "gtm_ee"),
      (Ei[J.m.Mi] = "uip"),
      (Ei[J.m.Fh] = "mt"),
      (Ei[J.m.Jd] = "npa"),
      (Ei[J.m.iq] = "sg_uc"),
      (Ei[J.m.mi] = null),
      (Ei[J.m.Qc] = null),
      (Ei[J.m.ob] = null),
      (Ei[J.m.wa] = null),
      (Ei[J.m.ya] = null),
      (Ei[J.m.Xa] = null),
      (Ei[J.m.Ai] = null),
      (Ei[J.m.Sc] = null),
      (Ei[J.m.df] = null),
      (Ei[J.m.ef] = null),
      (Ei[J.m.Bb] = null),
      (Ei[J.m.sd] = null),
      Ei);
  function Gi(a, b) {
    if (a) {
      var c = a.split("x");
      c.length === 2 && (Hi(b, "u_w", c[0]), Hi(b, "u_h", c[1]));
    }
  }
  function Ii(a) {
    var b = Mi;
    b = b === void 0 ? Ni : b;
    return Oi(Pi(a, b));
  }
  function Oi(a) {
    return (a || [])
      .filter(function (b) {
        return !!b;
      })
      .map(function (b) {
        return (
          "(" +
          [
            Qi(b.value),
            Qi(b.quantity),
            Qi(b.item_id),
            Qi(b.start_date),
            Qi(b.end_date),
          ].join("*") +
          ")"
        );
      })
      .join("");
  }
  function Pi(a, b) {
    return (a || [])
      .filter(function (c) {
        return !!c;
      })
      .map(function (c) {
        return {
          item_id: b(c),
          quantity: c.quantity,
          value: c.price,
          start_date: c.start_date,
          end_date: c.end_date,
        };
      });
  }
  function Ni(a) {
    return [a.item_id, a.id, a.item_name].find(function (b) {
      return b != null;
    });
  }
  function Ri(a) {
    if (a && a.length)
      return a
        .map(function (b) {
          return b && b.estimated_delivery_date
            ? b.estimated_delivery_date
            : "";
        })
        .join(",");
  }
  function Hi(a, b, c) {
    c === void 0 || c === null || (c === "" && !ch[b]) || (a[b] = c);
  }
  function Qi(a) {
    return typeof a !== "number" && typeof a !== "string" ? "" : a.toString();
  }
  function Si(a) {
    switch (a) {
      case 0:
        break;
      case 9:
        return "e4";
      case 6:
        return "e5";
      case 14:
        return "e6";
      default:
        return "e7";
    }
  }
  function Ti() {
    this.blockSize = -1;
  }
  function Ui(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.N = Sa.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.T = this.J = 0;
    this.D = [];
    this.fa = a;
    this.V = b;
    this.ma = Sa.Int32Array ? new Int32Array(64) : Array(64);
    Vi === void 0 && (Sa.Int32Array ? (Vi = new Int32Array(Wi)) : (Vi = Wi));
    this.reset();
  }
  Ta(Ui, Ti);
  for (var Xi = [], Yi = 0; Yi < 63; Yi++) Xi[Yi] = 0;
  var Zi = [].concat(128, Xi);
  Ui.prototype.reset = function () {
    this.T = this.J = 0;
    var a;
    if (Sa.Int32Array) a = new Int32Array(this.V);
    else {
      var b = this.V,
        c = b.length;
      if (c > 0) {
        for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
        a = d;
      } else a = [];
    }
    this.D = a;
  };
  var $i = function (a) {
    for (var b = a.N, c = a.ma, d = 0, e = 0; e < b.length; )
      ((c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4));
    for (var f = 16; f < 64; f++) {
      var g = c[f - 15] | 0,
        h = c[f - 2] | 0;
      c[f] =
        ((((c[f - 16] | 0) +
          (((g >>> 7) | (g << 25)) ^ ((g >>> 18) | (g << 14)) ^ (g >>> 3))) |
          0) +
          (((c[f - 7] | 0) +
            (((h >>> 17) | (h << 15)) ^
              ((h >>> 19) | (h << 13)) ^
              (h >>> 10))) |
            0)) |
        0;
    }
    for (
      var l = a.D[0] | 0,
        n = a.D[1] | 0,
        p = a.D[2] | 0,
        q = a.D[3] | 0,
        r = a.D[4] | 0,
        t = a.D[5] | 0,
        u = a.D[6] | 0,
        v = a.D[7] | 0,
        x = 0;
      x < 64;
      x++
    ) {
      var y =
          ((((l >>> 2) | (l << 30)) ^
            ((l >>> 13) | (l << 19)) ^
            ((l >>> 22) | (l << 10))) +
            ((l & n) ^ (l & p) ^ (n & p))) |
          0,
        z =
          (((v +
            (((r >>> 6) | (r << 26)) ^
              ((r >>> 11) | (r << 21)) ^
              ((r >>> 25) | (r << 7)))) |
            0) +
            ((((((r & t) ^ (~r & u)) + (Vi[x] | 0)) | 0) + (c[x] | 0)) | 0)) |
          0;
      v = u;
      u = t;
      t = r;
      r = (q + z) | 0;
      q = p;
      p = n;
      n = l;
      l = (z + y) | 0;
    }
    a.D[0] = (a.D[0] + l) | 0;
    a.D[1] = (a.D[1] + n) | 0;
    a.D[2] = (a.D[2] + p) | 0;
    a.D[3] = (a.D[3] + q) | 0;
    a.D[4] = (a.D[4] + r) | 0;
    a.D[5] = (a.D[5] + t) | 0;
    a.D[6] = (a.D[6] + u) | 0;
    a.D[7] = (a.D[7] + v) | 0;
  };
  Ui.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.J;
    if (typeof a === "string")
      for (; c < b; )
        ((this.N[d++] = a.charCodeAt(c++)),
          d == this.blockSize && ($i(this), (d = 0)));
    else {
      var e,
        f = typeof a;
      e = f != "object" ? f : a ? (Array.isArray(a) ? "array" : f) : "null";
      if (e == "array" || (e == "object" && typeof a.length == "number"))
        for (; c < b; ) {
          var g = a[c++];
          if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0)))
            throw Error("message must be a byte array");
          this.N[d++] = g;
          d == this.blockSize && ($i(this), (d = 0));
        }
      else throw Error("message must be string or array");
    }
    this.J = d;
    this.T += b;
  };
  Ui.prototype.digest = function () {
    var a = [],
      b = this.T * 8;
    this.J < 56
      ? this.update(Zi, 56 - this.J)
      : this.update(Zi, this.blockSize - (this.J - 56));
    for (var c = 63; c >= 56; c--) ((this.N[c] = b & 255), (b /= 256));
    $i(this);
    for (var d = 0, e = 0; e < this.fa; e++)
      for (var f = 24; f >= 0; f -= 8) a[d++] = (this.D[e] >> f) & 255;
    return a;
  };
  var Wi = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    Vi;
  function aj() {
    Ui.call(this, 8, bj);
  }
  Ta(aj, Ui);
  var bj = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var cj = /^[0-9A-Fa-f]{64}$/;
  function dj(a) {
    try {
      return new TextEncoder().encode(a);
    } catch (b) {
      return fc(a);
    }
  }
  function ej(a) {
    var b = w;
    if (a === "" || a === "e0") return Promise.resolve(a);
    var c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
      if (cj.test(a)) return Promise.resolve(a);
      try {
        var d = dj(a);
        return b.crypto.subtle
          .digest("SHA-256", d)
          .then(function (e) {
            return fj(e, b);
          })
          .catch(function () {
            return "e2";
          });
      } catch (e) {
        return Promise.resolve("e2");
      }
    } else return Promise.resolve("e1");
  }
  function gj(a) {
    try {
      var b = new aj();
      b.update(dj(a));
      return b.digest();
    } catch (c) {
      return "e2";
    }
  }
  function hj(a) {
    var b = w;
    if (a === "" || a === "e0" || cj.test(a)) return a;
    var c = gj(a);
    if (c === "e2") return "e2";
    try {
      return fj(c, b);
    } catch (d) {
      return "e2";
    }
  }
  function fj(a, b) {
    var c = Array.from(new Uint8Array(a))
      .map(function (d) {
        return String.fromCharCode(d);
      })
      .join("");
    return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  var ij = {},
    jj = function () {
      for (var a = !1, b = !1, c = 0; a === b; )
        if (((a = Jb(0, 1) === 0), (b = Jb(0, 1) === 0), c++, c > 30)) return;
      return a;
    },
    lj = { es: kj };
  function kj(a, b, c) {
    var d = ij[b];
    if (
      !(
        (c === void 0 ? Jb(0, 9999) : c % 1e4) <
        d.probability * (d.controlId2 ? 4 : 2) * 1e4
      )
    )
      return a;
    a: {
      var e = d.studyId,
        f = d.experimentId,
        g = d.controlId,
        h = d.controlId2;
      if (!((a.exp || {})[f] || (a.exp || {})[g] || (h && (a.exp || {})[h]))) {
        var l = c !== void 0 ? c % 2 === 0 : jj();
        if (l !== void 0) {
          var n = l ? 0 : 1;
          if (h) {
            var p = c !== void 0 ? (c >> 1) % 2 === 0 : jj();
            if (p === void 0) break a;
            n |= (p ? 0 : 1) << 1;
          }
          n === 0
            ? mj(a, f, e)
            : n === 1
              ? mj(a, g, e)
              : n === 2 && mj(a, h, e);
        }
      }
    }
    return a;
  }
  function nj(a, b) {
    return ij[b]
      ? !!ij[b].active ||
          ij[b].probability > 0.5 ||
          !!(a.exp || {})[ij[b].experimentId]
      : !1;
  }
  function oj(a, b) {
    for (
      var c = a.exp || {}, d = m(Object.keys(c).map(Number)), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value;
      if (c[f] === b) return f;
    }
  }
  function mj(a, b, c) {
    var d = a.exp || {};
    d[b] = c;
    a.exp = d;
  }
  var L = {
    O: {
      qk: "call_conversion",
      ee: "ccm_conversion",
      tk: "common_aw",
      Ba: "conversion",
      Fi: "floodlight",
      Wf: "ga_conversion",
      Ed: "gcp_remarketing",
      Dm: "landing_page",
      Ia: "page_view",
      Ke: "fpm_test_hit",
      Le: "shw_test_hit",
      Yb: "remarketing",
      Mb: "user_data_lead",
      Db: "user_data_web",
    },
  };
  var pj = function () {
      this.D = new Set();
      this.J = new Set();
    },
    rj = function (a) {
      var b = qj.D;
      a = a === void 0 ? [] : a;
      var c = []
        .concat(Aa(b.D))
        .concat([].concat(Aa(b.J)))
        .concat(a);
      c.sort(function (d, e) {
        return d - e;
      });
      return c;
    },
    sj = function () {
      var a = [].concat(Aa(qj.D.D));
      a.sort(function (b, c) {
        return b - c;
      });
      return a;
    },
    tj = function () {
      var a = qj.D,
        b = D(44);
      a.D = new Set();
      if (b !== "")
        for (var c = m(b.split("~")), d = c.next(); !d.done; d = c.next()) {
          var e = Number(d.value);
          isNaN(e) || a.D.add(e);
        }
    };
  var uj = {},
    vj = {
      __cl: 1,
      __ecl: 1,
      __ehl: 1,
      __evl: 1,
      __fal: 1,
      __fil: 1,
      __fsl: 1,
      __hl: 1,
      __jel: 1,
      __lcl: 1,
      __sdl: 1,
      __tl: 1,
      __ytl: 1,
    },
    wj = { __paused: 1, __tg: 1 },
    xj;
  for (xj in vj) vj.hasOwnProperty(xj) && (wj[xj] = 1);
  var yj = vg(45),
    zj,
    Aj = !1;
  zj = Aj;
  var Bj = null,
    Cj = {},
    Dj = "";
  uj.Zi = Dj;
  var qj = new (function () {
    this.D = new pj();
    this.J = !1;
  })();
  var Ej = /:[0-9]+$/,
    Fj = /^\d+\.fls\.doubleclick\.net$/;
  function Gj(a, b, c, d) {
    var e = Hj(a, !!d, b),
      f,
      g;
    return c
      ? (g = e[b]) != null
        ? g
        : []
      : (f = e[b]) == null
        ? void 0
        : f[0];
  }
  function Hj(a, b, c) {
    for (var d = {}, e = m(a.split("&")), f = e.next(); !f.done; f = e.next()) {
      var g = m(f.value.split("=")),
        h = g.next().value,
        l = za(g),
        n = decodeURIComponent(h.replace(/\+/g, " "));
      if (c === void 0 || n === c) {
        var p = l.join("=");
        d[n] || (d[n] = []);
        d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")));
      }
    }
    return d;
  }
  function Ij(a) {
    try {
      return decodeURIComponent(a);
    } catch (b) {}
  }
  function Jj(a, b, c, d, e) {
    b && (b = String(b).toLowerCase());
    if (b === "protocol" || b === "port")
      a.protocol = Kj(a.protocol) || Kj(w.location.protocol);
    b === "port"
      ? (a.port = String(
          Number(a.hostname ? a.port : w.location.port) ||
            (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : ""),
        ))
      : b === "host" &&
        (a.hostname = (a.hostname || w.location.hostname)
          .replace(Ej, "")
          .toLowerCase());
    return Lj(a, b, c, d, e);
  }
  function Lj(a, b, c, d, e) {
    var f,
      g = Kj(a.protocol);
    b && (b = String(b).toLowerCase());
    switch (b) {
      case "url_no_fragment":
        f = Mj(a);
        break;
      case "protocol":
        f = g;
        break;
      case "host":
        f = a.hostname.replace(Ej, "").toLowerCase();
        if (c) {
          var h = /^www\d*\./.exec(f);
          h && h[0] && (f = f.substring(h[0].length));
        }
        break;
      case "port":
        f = String(
          Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : ""),
        );
        break;
      case "path":
        a.pathname || a.hostname || yb("TAGGING", 1);
        f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
        var l = f.split("/");
        (d || []).indexOf(l[l.length - 1]) >= 0 && (l[l.length - 1] = "");
        f = l.join("/");
        break;
      case "query":
        f = a.search.replace("?", "");
        e && (f = Gj(f, e, !1));
        break;
      case "extension":
        var n = a.pathname.split(".");
        f = n.length > 1 ? n[n.length - 1] : "";
        f = f.split("/")[0];
        break;
      case "fragment":
        f = a.hash.replace("#", "");
        break;
      default:
        f = a && a.href;
    }
    return f;
  }
  function Kj(a) {
    return a ? a.replace(":", "").toLowerCase() : "";
  }
  function Mj(a) {
    var b = "";
    if (a && a.href) {
      var c = a.href.indexOf("#");
      b = c < 0 ? a.href : a.href.substring(0, c);
    }
    return b;
  }
  var Nj = {},
    Oj = 0;
  function Pj(a) {
    var b = Nj[a];
    if (!b) {
      var c = A.createElement("a");
      a && (c.href = a);
      var d = c.pathname;
      d[0] !== "/" && (a || yb("TAGGING", 1), (d = "/" + d));
      var e = c.hostname.replace(Ej, "");
      b = {
        href: c.href,
        protocol: c.protocol,
        host: c.host,
        hostname: e,
        pathname: d,
        search: c.search,
        hash: c.hash,
        port: c.port,
      };
      Oj < 5 && ((Nj[a] = b), Oj++);
    }
    return b;
  }
  function Qj(a, b, c) {
    var d = Pj(a);
    return jc(b, d, c);
  }
  function Rj(a) {
    var b = Pj(w.location.href),
      c = Jj(b, "host", !1);
    if (c && c.match(Fj)) {
      var d = Jj(b, "path");
      if (d) {
        var e = d.split(a + "=");
        if (e.length > 1) return e[1].split(";")[0].split("?")[0];
      }
    }
  }
  var Sj = {
      "https://www.google.com": "/g",
      "https://www.googleadservices.com": "/as",
      "https://pagead2.googlesyndication.com": "/gs",
    },
    Tj = [
      "/as/d/ccm/conversion",
      "/g/d/ccm/conversion",
      "/gs/ccm/conversion",
      "/d/ccm/form-data",
    ];
  function Uj() {
    return vg(47) ? wg(54) !== 1 : !1;
  }
  function Vj() {
    var a = D(18),
      b = a.length;
    return a[b - 1] === "/" ? a.substring(0, b - 1) : a;
  }
  function Wj(a, b) {
    if (a) {
      var c = "" + a;
      c.indexOf("http://") !== 0 &&
        c.indexOf("https://") !== 0 &&
        (c = "https://" + c);
      c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
      return Pj("" + c + b).href;
    }
  }
  function Xj(a, b) {
    if (Yj()) return Wj(a, b);
  }
  function Yj() {
    return Uj() || vg(50);
  }
  function Zj() {
    return !!uj.Zi && uj.Zi.split("@@").join("") !== "SGTM_TOKEN";
  }
  function ak(a) {
    for (var b = m([J.m.yd, J.m.Rc]), c = b.next(); !c.done; c = b.next()) {
      var d = M(a, c.value);
      if (d) return d;
    }
  }
  function bk(a, b, c) {
    c = c === void 0 ? "" : c;
    if (!Uj()) return a;
    var d = b ? Sj[a] || "" : "";
    d === "/gs" && (c = "");
    return "" + Vj() + d + c;
  }
  function ck(a) {
    if (!Uj()) return "";
    for (var b = m(Tj), c = b.next(); !c.done; c = b.next()) {
      var d = c.value;
      if (Yb(a, "" + Vj() + d)) return "&_uip=" + encodeURIComponent("::");
    }
    return "";
  }
  var dk = /gtag[.\/]js/,
    ek = /gtm[.\/]js/,
    fk = !1;
  function gk(a) {
    if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
      var b;
      a: {
        var c,
          d = (c = a.scriptElement) == null ? void 0 : c.src;
        if (d) {
          for (
            var e = vg(47),
              f = Pj(d),
              g = e ? f.pathname : "" + f.hostname + f.pathname,
              h = A.scripts,
              l = "",
              n = 0;
            n < h.length;
            ++n
          ) {
            var p = h[n];
            if (
              !(
                p.innerHTML.length === 0 ||
                (!e &&
                  p.innerHTML.indexOf(
                    a.scriptContainerId || "SHOULD_NOT_BE_SET",
                  ) < 0) ||
                p.innerHTML.indexOf(g) < 0
              )
            ) {
              if (p.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                b = String(n);
                break a;
              }
              l = String(n);
            }
          }
          if (l) {
            b = l;
            break a;
          }
        }
        b = void 0;
      }
      var q = b;
      if (q) return ((fk = !0), q);
    }
    var r = [].slice.call(A.scripts);
    return a.scriptElement ? String(r.indexOf(a.scriptElement)) : "-1";
  }
  function hk(a) {
    if (fk) return "1";
    var b,
      c = (b = a.scriptElement) == null ? void 0 : b.src;
    if (c) {
      if (dk.test(c)) return "3";
      if (ek.test(c)) return "2";
    }
    return "0";
  }
  var ik = [];
  function jk(a) {
    switch (a) {
      case 1:
        return 0;
      case 421:
        return 20;
      case 235:
        return 18;
      case 38:
        return 13;
      case 287:
        return 11;
      case 288:
        return 12;
      case 285:
        return 9;
      case 286:
        return 10;
      case 219:
        return 7;
      case 220:
        return 8;
      case 53:
        return 1;
      case 54:
        return 2;
      case 52:
        return 5;
      case 203:
        return 17;
      case 75:
        return 3;
      case 103:
        return 14;
      case 197:
        return 15;
      case 109:
        return 19;
      case 116:
        return 4;
    }
  }
  function kk(a) {
    ik[a] = !0;
    var b = jk(a);
    b !== void 0 && (jb[b] = !0);
  }
  kk(87);
  kk(132);
  kk(20);
  kk(72);
  kk(113);
  kk(116);
  kk(24);
  Ag(6, 6e4);
  Ag(7, 1);
  Ag(35, 50);
  kk(37);
  kk(123);
  kk(158);
  kk(71);
  kk(38);
  kk(103);
  kk(101);
  kk(435);
  kk(21);
  kk(141);
  kk(185);
  kk(197);
  kk(200);
  kk(206);
  kk(218);
  kk(232);
  kk(252);

  function N(a) {
    return !!ik[a];
  }
  function O(a) {
    yb("GTM", a);
  }
  function lk(a) {
    var b = mk().destinationArray[a],
      c = mk().destination[a];
    return b && b.length > 0 ? b[0] : c;
  }
  function nk(a, b) {
    var c = mk();
    c.pending || (c.pending = []);
    Ib(c.pending, function (d) {
      return (
        d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
      );
    }) || c.pending.push({ target: a, onLoad: b });
  }
  function ok() {
    var a = w.google_tags_first_party;
    Array.isArray(a) || (a = []);
    for (var b = {}, c = m(a), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return Object.freeze(b);
  }
  var pk = function () {
    this.container = {};
    this.destination = {};
    this.destinationArray = {};
    this.canonical = {};
    this.pending = [];
    this.injectedFirstPartyContainers = {};
    this.injectedFirstPartyContainers = ok();
  };
  function mk() {
    var a = Vc("google_tag_data", {}),
      b = a.tidr;
    (b && typeof b === "object") || ((b = new pk()), (a.tidr = b));
    var c = b;
    c.container || (c.container = {});
    c.destination || (c.destination = {});
    c.destinationArray || (c.destinationArray = {});
    c.canonical || (c.canonical = {});
    c.pending || (c.pending = []);
    c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = ok());
    return c;
  }
  function qk() {
    return (
      vg(7) &&
      rk().some(function (a) {
        return a === D(5);
      })
    );
  }
  function sk() {
    if (N(461)) return rk();
    var a;
    return (a = xg(55)) != null ? a : [];
  }
  function tk() {
    return D(6) || "_" + D(5);
  }
  function uk() {
    var a = D(10);
    return a ? a.split("|") : [D(5)];
  }
  function rk() {
    var a = xg(59);
    return Array.isArray(a)
      ? a
          .filter(function (b) {
            return typeof b === "string";
          })
          .filter(function (b) {
            return b.indexOf("GTM-") !== 0;
          })
      : [];
  }
  function vk() {
    var a = wk(xk()),
      b = a && a.parent;
    if (b) return wk(b);
  }
  function yk() {
    var a = wk(xk());
    if (a) {
      for (; a.parent; ) {
        var b = wk(a.parent);
        if (!b) break;
        a = b;
      }
      return a;
    }
  }
  function wk(a) {
    var b = mk();
    return a.isDestination ? lk(a.ctid) : b.container[a.ctid];
  }
  function zk() {
    var a = mk();
    if (a.pending) {
      for (
        var b, c = [], d = !1, e = uk(), f = rk(), g = {}, h = 0;
        h < a.pending.length;
        g = { Hg: void 0 }, h++
      )
        ((g.Hg = a.pending[h]),
          Ib(
            g.Hg.target.isDestination ? f : e,
            (function (l) {
              return function (n) {
                return n === l.Hg.target.ctid;
              };
            })(g),
          )
            ? d || ((b = g.Hg.onLoad), (d = !0))
            : c.push(g.Hg));
      a.pending = c;
      if (b)
        try {
          b(tk());
        } catch (l) {}
    }
  }
  function Ak() {
    for (
      var a = D(5),
        b = uk(),
        c = rk(),
        d = sk(),
        e = function (q, r) {
          var t = {
            canonicalContainerId: D(6),
            scriptContainerId: a,
            state: 2,
            containers: b.slice(),
            destinations: c.slice(),
          };
          Tc && (t.scriptElement = Tc);
          Uc && (t.scriptSource = Uc);
          vk() === void 0 &&
            ((t.htmlLoadOrder = gk(t)), (t.loadScriptType = hk(t)));
          var u, v;
          switch (r) {
            case 0:
              u = function (z) {
                f.container[q] = z;
              };
              v = f.container[q];
              break;
            case 1:
              u = function (z) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].unshift(z);
              };
              var x,
                y =
                  ((x = f.destinationArray[q]) == null ? void 0 : x[0]) ||
                  f.destination[q];
              !y || (y.state !== 0 && y.state !== 1) || (v = y);
              break;
            case 2:
              ((u = function (z) {
                f.destinationArray[q] = f.destinationArray[q] || [];
                f.destinationArray[q].push(z);
              }),
                (v = void 0));
          }
          u &&
            (v
              ? (v.state === 0 && O(93),
                oa(Object, "assign").call(Object, v, t))
              : u(t));
        },
        f = mk(),
        g = m(b),
        h = g.next();
      !h.done;
      h = g.next()
    )
      e(h.value, 0);
    for (var l = m(c), n = l.next(); !n.done; n = l.next()) {
      var p = n.value;
      d.includes(p) ? e(p, 1) : e(p, 2);
    }
    f.canonical[tk()] = {};
    zk();
  }
  function Bk() {
    var a = tk();
    return !!mk().canonical[a];
  }
  function Ck(a) {
    return !!mk().container[a];
  }
  function Dk() {
    var a = xk(),
      b = wk(a);
    return b && b.context;
  }
  function Ek(a) {
    var b = lk(a);
    return b ? b.state !== 0 : !1;
  }
  function xk() {
    return { ctid: D(5), isDestination: vg(7) };
  }
  function Fk(a, b, c) {
    var d = xk(),
      e = mk().container[a];
    (e && e.state !== 3) ||
      ((mk().container[a] = { state: 1, context: b, parent: d }),
      nk({ ctid: a, isDestination: !1 }, c));
  }
  function Gk() {
    var a = mk().container,
      b;
    for (b in a) if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
    return !1;
  }
  function Hk() {
    var a = {};
    Mb(mk().destination, function (b, c) {
      (c == null ? void 0 : c.state) === 0 && (a[b] = c);
    });
    Mb(mk().destinationArray, function (b, c) {
      var d = c[0];
      (d == null ? void 0 : d.state) === 0 && (a[b] = d);
    });
    return a;
  }
  function Ik(a) {
    return !!(
      a &&
      a.parent &&
      a.context &&
      a.context.source === 1 &&
      a.parent.ctid.indexOf("GTM-") !== 0
    );
  }
  function Jk() {
    for (var a = mk(), b = m(uk()), c = b.next(); !c.done; c = b.next())
      if (a.injectedFirstPartyContainers[c.value]) return !0;
    return !1;
  }
  var Kk = {},
    Lk =
      ((Kk.tdp = 1),
      (Kk.exp = 1),
      (Kk.pid = 1),
      (Kk.dl = 1),
      (Kk.seq = 1),
      (Kk.t = 1),
      (Kk.v = 1),
      Kk),
    Mk = {};
  function Nk() {
    return Object.keys(Mk).filter(function (a) {
      return Mk[a];
    });
  }
  var Ok = {};
  function Pk(a, b, c) {
    Ok[a] = b;
    (c === void 0 || c) && Qk(a);
  }
  function Qk(a, b) {
    (Mk[a] !== void 0 && (b === void 0 || !b)) ||
      (Yb(D(5), "GTM-") && a === "mcc") ||
      (Mk[a] = !0);
  }
  function Rk(a) {
    a.forEach(function (b) {
      Lk[b] || (Mk[b] = !1);
    });
  }
  function Sk(a) {
    a = a === void 0 ? [] : a;
    return rj(a).join("~");
  }
  function Tk() {
    return { total: 0, lb: 0, Ve: {} };
  }
  function Uk(a, b, c, d) {
    var e = Object.keys(a.We)
      .sort(function (f, g) {
        return Number(f) - Number(g);
      })
      .map(function (f) {
        return [f, b(a.We[f])];
      })
      .filter(function (f) {
        return f[1] !== void 0;
      })
      .map(function (f) {
        return f.join(c);
      })
      .join(d);
    return e ? e : void 0;
  }
  function Vk(a, b) {
    var c, d, e;
    c = c === void 0 ? "_" : c;
    d = d === void 0 ? ";" : d;
    e = e === void 0 ? "~" : e;
    for (
      var f = [], g = m(Object.keys(a.Ve).sort()), h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        n = Uk(a.Ve[l], b, c, d);
      if (n) {
        var p = void 0;
        f.push("" + ((p = l) != null ? p : "") + d + n);
      }
    }
    return f.length ? f.join(e) : void 0;
  }
  function Wk(a) {
    a.lb = 0;
    for (var b = m(Object.keys(a.Ve)), c = b.next(); !c.done; c = b.next()) {
      var d = a.Ve[c.value];
      d.lb = 0;
      for (var e = m(Object.keys(d.We)), f = e.next(); !f.done; f = e.next())
        d.We[f.value].lb = 0;
    }
  }
  function Xk(a, b, c) {
    var d;
    d = d === void 0 ? 1 : d;
    a.total += d;
    a.lb += d;
    var e,
      f = b === void 0 ? "" : b;
    e = a.Ve[f] || (a.Ve[f] = { total: 0, lb: 0, We: {} });
    e.total += d;
    e.lb += d;
    var g,
      h = String(c);
    g = e.We[h] || (e.We[h] = { total: 0, lb: 0 });
    g.total += d;
    g.lb += d;
  }
  var Yk = Tk();
  function Zk(a) {
    var b = String(a[Hf.Ya] || "").replace(/_/g, "");
    return Yb(b, "cvt") ? "cvt" : b;
  }
  var $k =
    w.location.search.indexOf("?gtm_latency=") >= 0 ||
    w.location.search.indexOf("&gtm_latency=") >= 0;
  var al = Math.random(),
    bl,
    cl = wg(27);
  bl = $k || al < cl;
  var el,
    fl = wg(42);
  el = $k || al >= 1 - fl;
  var gl = {},
    hl = ((gl[1] = {}), (gl[2] = {}), (gl[3] = {}), (gl[4] = {}), gl);
  function il(a, b, c) {
    if (el) {
      var d = jl(b, c);
      if (d) {
        var e = hl[b][d];
        e || (e = hl[b][d] = []);
        e.push(oa(Object, "assign").call(Object, {}, a));
        Xk(Yk, a.destinationId, a.endpoint);
        a.endpoint !== 56 && a.endpoint !== 61 && Qk("mde", !0);
      }
    }
  }
  function kl(a, b) {
    var c = jl(a, b);
    if (c) {
      var d = hl[a][c];
      d &&
        (hl[a][c] = d.filter(function (e) {
          return !e.Wn;
        }));
    }
  }
  function ll(a) {
    switch (a) {
      case "script-src":
      case "script-src-elem":
        return 1;
      case "frame-src":
        return 4;
      case "connect-src":
        return 2;
      case "img-src":
        return 3;
    }
  }
  function jl(a, b) {
    var c = b;
    if (b[0] === "/") {
      var d;
      c = ((d = w.location) == null ? void 0 : d.origin) + b;
    }
    try {
      var e = new URL(c);
      return a === 4 ? e.origin : e.origin + e.pathname;
    } catch (f) {}
  }
  function ml(a, b, c) {
    var d,
      e = a.GooglebQhCsO;
    e || ((e = {}), (a.GooglebQhCsO = e));
    d = e;
    if (d[b]) return !1;
    d[b] = [];
    d[b][0] = c;
    return !0;
  }
  var nl, ol;
  a: {
    for (var pl = ["CLOSURE_FLAGS"], ql = Sa, rl = 0; rl < pl.length; rl++)
      if (((ql = ql[pl[rl]]), ql == null)) {
        ol = null;
        break a;
      }
    ol = ql;
  }
  var sl = ol && ol[610401301];
  nl = sl != null ? sl : !1;
  function tl() {
    var a = Sa.navigator;
    if (a) {
      var b = a.userAgent;
      if (b) return b;
    }
    return "";
  }
  var ul,
    vl = Sa.navigator;
  ul = vl ? vl.userAgentData || null : null;
  function wl(a) {
    if (!nl || !ul) return !1;
    for (var b = 0; b < ul.brands.length; b++) {
      var c = ul.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function xl(a) {
    return tl().indexOf(a) != -1;
  }
  function yl() {
    return nl ? !!ul && ul.brands.length > 0 : !1;
  }
  function zl() {
    return yl() ? !1 : xl("Opera");
  }
  function Al() {
    return xl("Firefox") || xl("FxiOS");
  }
  function Bl() {
    return yl()
      ? wl("Chromium")
      : ((xl("Chrome") || xl("CriOS")) && !(yl() ? 0 : xl("Edge"))) ||
          xl("Silk");
  }
  function Cl() {
    return nl ? !!ul && !!ul.platform : !1;
  }
  function Dl() {
    return xl("iPhone") && !xl("iPod") && !xl("iPad");
  }
  function El() {
    Dl() || xl("iPad") || xl("iPod");
  }
  var Fl = function (a) {
    Fl[" "](a);
    return a;
  };
  Fl[" "] = function () {};
  zl();
  yl() || xl("Trident") || xl("MSIE");
  xl("Edge");
  !xl("Gecko") ||
    (tl().toLowerCase().indexOf("webkit") != -1 && !xl("Edge")) ||
    xl("Trident") ||
    xl("MSIE") ||
    xl("Edge");
  tl().toLowerCase().indexOf("webkit") != -1 && !xl("Edge") && xl("Mobile");
  Cl() || xl("Macintosh");
  Cl() || xl("Windows");
  (Cl() ? ul.platform === "Linux" : xl("Linux")) || Cl() || xl("CrOS");
  Cl() || xl("Android");
  Dl();
  xl("iPad");
  xl("iPod");
  El();
  tl().toLowerCase().indexOf("kaios");
  Al();
  Dl() || xl("iPod");
  xl("iPad");
  !xl("Android") || Bl() || Al() || zl() || xl("Silk");
  Bl();
  !xl("Safari") ||
    Bl() ||
    (yl() ? 0 : xl("Coast")) ||
    zl() ||
    (yl() ? 0 : xl("Edge")) ||
    (yl() ? wl("Microsoft Edge") : xl("Edg/")) ||
    (yl() ? wl("Opera") : xl("OPR")) ||
    Al() ||
    xl("Silk") ||
    xl("Android") ||
    El();
  var Gl = {},
    Hl = null;
  function Il(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e > 255 && ((b[c++] = e & 255), (e >>= 8));
      b[c++] = e;
    }
    var f = 4;
    f === void 0 && (f = 0);
    if (!Hl) {
      Hl = {};
      for (
        var g =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              "",
            ),
          h = ["+/=", "+/", "-_=", "-_.", "-_"],
          l = 0;
        l < 5;
        l++
      ) {
        var n = g.concat(h[l].split(""));
        Gl[l] = n;
        for (var p = 0; p < n.length; p++) {
          var q = n[p];
          Hl[q] === void 0 && (Hl[q] = p);
        }
      }
    }
    for (
      var r = Gl[f],
        t = Array(Math.floor(b.length / 3)),
        u = r[64] || "",
        v = 0,
        x = 0;
      v < b.length - 2;
      v += 3
    ) {
      var y = b[v],
        z = b[v + 1],
        C = b[v + 2],
        E = r[y >> 2],
        G = r[((y & 3) << 4) | (z >> 4)],
        K = r[((z & 15) << 2) | (C >> 6)],
        P = r[C & 63];
      t[x++] = "" + E + G + K + P;
    }
    var fa = 0,
      ca = u;
    switch (b.length - v) {
      case 2:
        ((fa = b[v + 1]), (ca = r[(fa & 15) << 2] || u));
      case 1:
        var Q = b[v];
        t[x] = "" + r[Q >> 2] + r[((Q & 3) << 4) | (fa >> 4)] + ca + u;
    }
    return t.join("");
  }
  var Jl = function (a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  };
  var Kl = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$",
  );
  function Ll(a, b, c, d) {
    for (var e = b, f = c.length; (e = a.indexOf(c, e)) >= 0 && e < d; ) {
      var g = a.charCodeAt(e - 1);
      if (g == 38 || g == 63) {
        var h = a.charCodeAt(e + f);
        if (!h || h == 61 || h == 38 || h == 35) return e;
      }
      e += f + 1;
    }
    return -1;
  }
  var Ml = /#|$/;
  function Nl(a, b) {
    var c = a.search(Ml),
      d = Ll(a, 0, b, c);
    if (d < 0) return null;
    var e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return Jl(a.slice(d, e !== -1 ? e : 0));
  }
  var Ol = /[?&]($|#)/;
  function Pl(a, b, c) {
    for (var d, e = a.search(Ml), f = 0, g, h = []; (g = Ll(a, f, b, e)) >= 0; )
      (h.push(a.substring(f, g)),
        (f = Math.min(a.indexOf("&", g) + 1 || e, e)));
    h.push(a.slice(f));
    d = h.join("").replace(Ol, "$1");
    var l,
      n = c != null ? "=" + encodeURIComponent(String(c)) : "";
    var p = b + n;
    if (p) {
      var q,
        r = d.indexOf("#");
      r < 0 && (r = d.length);
      var t = d.indexOf("?"),
        u;
      t < 0 || t > r ? ((t = r), (u = "")) : (u = d.substring(t + 1, r));
      q = [d.slice(0, t), u, d.slice(r)];
      var v = q[1];
      q[1] = p ? (v ? v + "&" + p : p) : v;
      l = q[0] + (q[1] ? "?" + q[1] : "") + q[2];
    } else l = d;
    return l;
  }
  function Ql(a, b, c, d, e, f, g, h) {
    var l = Nl(c, "fmt");
    if (d) {
      var n = Nl(c, "random"),
        p = Nl(c, "label") || "";
      if (!n) return;
      var q = Il(Jl(p) + ":" + Jl(n));
      if (!ml(a, q, d)) return;
    }
    l && Number(l) !== 4 && (c = Pl(c, "rfmt", l));
    var r = Pl(c, "fmt", 4),
      t = b.getElementsByTagName("script")[0].parentElement;
    g == null || Rl(g);
    cd(
      r,
      function () {
        g == null || Sl(g);
        h == null || Tl(h, c);
        a.google_noFurtherRedirects &&
          d &&
          ((a.google_noFurtherRedirects = null), d());
      },
      function () {
        g == null || Sl(g);
        h == null || Tl(h, c);
        e == null || e();
      },
      f,
      t || void 0,
    );
    return r;
  }
  function Ul(a) {
    var b = Qa.apply(1, arguments);
    il(a, 2, b[0]);
    od.apply(null, Aa(b));
  }
  function Vl(a) {
    var b = Qa.apply(1, arguments);
    il(a, 2, b[0]);
    return pd.apply(null, Aa(b));
  }
  function Wl(a) {
    var b = Qa.apply(1, arguments);
    il(a, 3, b[0]);
    fd.apply(null, Aa(b));
  }
  function Xl(a) {
    var b = Qa.apply(1, arguments);
    il(a, 2, b[0]);
    return rd.apply(null, Aa(b));
  }
  function Yl(a) {
    var b = Qa.apply(1, arguments);
    il(a, 1, b[0]);
    cd.apply(null, Aa(b));
  }
  function Zl(a) {
    var b = Qa.apply(1, arguments);
    b[0] && il(a, 4, b[0]);
    ed.apply(null, Aa(b));
  }
  function $l(a) {
    var b = Ql.apply(null, Aa(Qa.apply(1, arguments)));
    b && il(a, 1, b);
    return b;
  }
  var am = { Na: { Ee: 0, Je: 1, Si: 2 } };
  am.Na[am.Na.Ee] = "FULL_TRANSMISSION";
  am.Na[am.Na.Je] = "LIMITED_TRANSMISSION";
  am.Na[am.Na.Si] = "NO_TRANSMISSION";
  var bm = { ba: { Tc: 0, Wa: 1, gd: 2, Ac: 3 } };
  bm.ba[bm.ba.Tc] = "NO_QUEUE";
  bm.ba[bm.ba.Wa] = "ADS";
  bm.ba[bm.ba.gd] = "ANALYTICS";
  bm.ba[bm.ba.Ac] = "MONITORING";
  function cm() {
    var a = Vc("google_tag_data", {});
    return (a.ics = a.ics || new dm());
  }
  var dm = function () {
    this.entries = {};
    this.waitPeriodTimedOut =
      this.wasSetLate =
      this.accessedAny =
      this.accessedDefault =
      this.usedImplicit =
      this.usedUpdate =
      this.usedDefault =
      this.usedDeclare =
      this.active =
        !1;
    this.D = [];
  };
  dm.prototype.default = function (a, b, c, d, e, f, g) {
    this.usedDefault ||
      this.usedDeclare ||
      (!this.accessedDefault && !this.accessedAny) ||
      (this.wasSetLate = !0);
    this.usedDefault = this.active = !0;
    yb("TAGGING", 19);
    b == null ? yb("TAGGING", 18) : em(this, a, b === "granted", c, d, e, f, g);
  };
  dm.prototype.waitForUpdate = function (a, b, c) {
    for (var d = 0; d < a.length; d++)
      em(this, a[d], void 0, void 0, "", "", b, c);
  };
  var em = function (a, b, c, d, e, f, g, h) {
    var l = a.entries,
      n = l[b] || {},
      p = n.region,
      q = d && Fb(d) ? d.toUpperCase() : void 0;
    e = e.toUpperCase();
    f = f.toUpperCase();
    if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
      var r = !!(g && g > 0 && n.update === void 0),
        t = {
          region: q,
          declare_region: n.declare_region,
          implicit: n.implicit,
          default: c !== void 0 ? c : n.default,
          declare: n.declare,
          update: n.update,
          quiet: r,
        };
      if (e !== "" || n.default !== !1) l[b] = t;
      r &&
        w.setTimeout(function () {
          l[b] === t &&
            t.quiet &&
            (yb("TAGGING", 2),
            (a.waitPeriodTimedOut = !0),
            a.clearTimeout(b, void 0, h),
            a.notifyListeners());
        }, g);
    }
  };
  k = dm.prototype;
  k.clearTimeout = function (a, b, c) {
    var d = [a],
      e = c.delegatedConsentTypes,
      f;
    for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
    var g = this.entries[a] || {},
      h = this.getConsentState(a, c);
    if (g.quiet) {
      g.quiet = !1;
      for (var l = m(d), n = l.next(); !n.done; n = l.next()) fm(this, n.value);
    } else if (b !== void 0 && h !== b)
      for (var p = m(d), q = p.next(); !q.done; q = p.next()) fm(this, q.value);
  };
  k.update = function (a, b, c) {
    this.usedDefault ||
      this.usedDeclare ||
      this.usedUpdate ||
      !this.accessedAny ||
      (this.wasSetLate = !0);
    this.usedUpdate = this.active = !0;
    if (b != null) {
      var d = this.getConsentState(a, c),
        e = this.entries;
      (e[a] = e[a] || {}).update = b === "granted";
      this.clearTimeout(a, d, c);
    }
  };
  k.declare = function (a, b, c, d, e) {
    this.usedDeclare = this.active = !0;
    var f = this.entries,
      g = f[a] || {},
      h = g.declare_region,
      l = c && Fb(c) ? c.toUpperCase() : void 0;
    d = d.toUpperCase();
    e = e.toUpperCase();
    if (d === "" || l === e || (l === d ? h !== e : !l && !h)) {
      var n = {
        region: g.region,
        declare_region: l,
        declare: b === "granted",
        implicit: g.implicit,
        default: g.default,
        update: g.update,
        quiet: g.quiet,
      };
      if (d !== "" || g.declare !== !1) f[a] = n;
    }
  };
  k.implicit = function (a, b) {
    this.usedImplicit = !0;
    var c = this.entries,
      d = (c[a] = c[a] || {});
    d.implicit !== !1 && (d.implicit = b === "granted");
  };
  k.getConsentState = function (a, b) {
    var c = this.entries,
      d = c[a] || {},
      e = d.update;
    if (e !== void 0) return e ? 1 : 2;
    if (b.usedContainerScopedDefaults) {
      var f = b.containerScopedDefaults[a];
      if (f === 3) return 1;
      if (f === 2) return 2;
    } else if (((e = d.default), e !== void 0)) return e ? 1 : 2;
    if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
      var g = b.delegatedConsentTypes[a],
        h = c[g] || {};
      e = h.update;
      if (e !== void 0) return e ? 1 : 2;
      if (b.usedContainerScopedDefaults) {
        var l = b.containerScopedDefaults[g];
        if (l === 3) return 1;
        if (l === 2) return 2;
      } else if (((e = h.default), e !== void 0)) return e ? 1 : 2;
    }
    e = d.declare;
    if (e !== void 0) return e ? 1 : 2;
    e = d.implicit;
    return e !== void 0 ? (e ? 3 : 4) : 0;
  };
  k.addListener = function (a, b) {
    this.D.push({ consentTypes: a, Pd: b });
  };
  var fm = function (a, b) {
    for (var c = 0; c < a.D.length; ++c) {
      var d = a.D[c];
      Array.isArray(d.consentTypes) &&
        d.consentTypes.indexOf(b) !== -1 &&
        (d.Rn = !0);
    }
  };
  dm.prototype.notifyListeners = function (a, b) {
    for (var c = 0; c < this.D.length; ++c) {
      var d = this.D[c];
      if (d.Rn) {
        d.Rn = !1;
        try {
          d.Pd({ consentEventId: a, consentPriorityId: b });
        } catch (e) {}
      }
    }
  };
  var gm = !1,
    hm = !1,
    im = {},
    jm = {
      delegatedConsentTypes: {},
      corePlatformServices: {},
      usedCorePlatformServices: !1,
      selectedAllCorePlatformServices: !1,
      containerScopedDefaults:
        ((im.ad_storage = 1),
        (im.analytics_storage = 1),
        (im.ad_user_data = 1),
        (im.ad_personalization = 1),
        im),
      usedContainerScopedDefaults: !1,
    };
  function km(a) {
    var b = cm();
    b.accessedAny = !0;
    return (Fb(a) ? [a] : a).every(function (c) {
      switch (b.getConsentState(c, jm)) {
        case 1:
        case 3:
          return !0;
        case 2:
        case 4:
          return !1;
        default:
          return !0;
      }
    });
  }
  function lm(a) {
    var b = cm();
    b.accessedAny = !0;
    return b.getConsentState(a, jm);
  }
  function mm(a) {
    var b = cm();
    b.accessedAny = !0;
    return !(b.entries[a] || {}).quiet;
  }
  function nm() {
    if (!kb(6)) return !1;
    var a = cm();
    a.accessedAny = !0;
    if (a.active) return !0;
    if (!jm.usedContainerScopedDefaults) return !1;
    for (
      var b = m(Object.keys(jm.containerScopedDefaults)), c = b.next();
      !c.done;
      c = b.next()
    )
      if (jm.containerScopedDefaults[c.value] !== 1) return !0;
    return !1;
  }
  function om(a, b) {
    cm().addListener(a, b);
  }
  function pm(a, b) {
    cm().notifyListeners(a, b);
  }
  function qm(a, b) {
    function c() {
      for (var e = 0; e < b.length; e++) if (!mm(b[e])) return !0;
      return !1;
    }
    if (c()) {
      var d = !1;
      om(b, function (e) {
        d || c() || ((d = !0), a(e));
      });
    } else a({});
  }
  function rm(a, b) {
    function c() {
      for (var h = [], l = 0; l < e.length; l++) {
        var n = e[l];
        km(n) && !f[n] && h.push(n);
      }
      return h;
    }
    function d(h) {
      for (var l = 0; l < h.length; l++) f[h[l]] = !0;
    }
    var e = Fb(b) ? [b] : b,
      f = {},
      g = c();
    g.length !== e.length &&
      (d(g),
      om(e, function (h) {
        function l(q) {
          q.length !== 0 && (d(q), (h.consentTypes = q), a(h));
        }
        var n = c();
        if (n.length !== 0) {
          var p = Object.keys(f).length;
          n.length + p >= e.length
            ? l(n)
            : w.setTimeout(function () {
                l(c());
              }, 500);
        }
      }));
  }
  var sm = {},
    tm =
      ((sm[bm.ba.Tc] = am.Na.Ee),
      (sm[bm.ba.Wa] = am.Na.Ee),
      (sm[bm.ba.gd] = am.Na.Ee),
      (sm[bm.ba.Ac] = am.Na.Ee),
      sm),
    um = function (a, b) {
      this.D = a;
      this.consentTypes = b;
    };
  um.prototype.isConsentGranted = function () {
    switch (this.D) {
      case 0:
        return this.consentTypes.every(function (a) {
          return km(a);
        });
      case 1:
        return this.consentTypes.some(function (a) {
          return km(a);
        });
      default:
        Gc(this.D, "consentsRequired had an unknown type");
    }
  };
  var vm = {},
    wm =
      ((vm[bm.ba.Tc] = new um(0, [])),
      (vm[bm.ba.Wa] = new um(0, ["ad_storage"])),
      (vm[bm.ba.gd] = new um(0, ["analytics_storage"])),
      (vm[bm.ba.Ac] = new um(1, ["ad_storage", "analytics_storage"])),
      vm);
  var ym = function (a) {
    var b = this;
    this.type = a;
    this.D = [];
    om(wm[a].consentTypes, function () {
      xm(b) || b.flush();
    });
  };
  ym.prototype.flush = function () {
    for (var a = m(this.D), b = a.next(); !b.done; b = a.next()) {
      var c = b.value;
      c();
    }
    this.D = [];
  };
  var xm = function (a) {
      return tm[a.type] === am.Na.Si && !wm[a.type].isConsentGranted();
    },
    zm = function (a, b) {
      xm(a) ? a.D.push(b) : b();
    },
    Am = new Map();
  function Bm(a) {
    Am.has(a) || Am.set(a, new ym(a));
    return Am.get(a);
  }
  var Cm = {
    aa: {
      Fs: "aw_user_data_cache",
      gi: "cookie_deprecation_label",
      Xg: "diagnostics_page_id",
      Qs: "em_registry",
      Ci: "eab",
      et: "fl_user_data_cache",
      ft: "ga4_user_data_cache",
      Qp: "idc_pv_claim",
      Ge: "ip_geo_data_cache",
      Li: "ip_geo_fetch_in_progress",
      Im: "nb_data",
      cq: "page_experiment_ids",
      Km: "pld",
      Me: "pt_data",
      Lm: "pt_listener_set",
      Rm: "service_worker_endpoint",
      Um: "shared_user_id",
      Vm: "shared_user_id_requested",
      Hh: "shared_user_id_source",
      Wm: "awh",
    },
  };
  var Dm = (function (a) {
    return xf(function (b) {
      for (var c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  })(Cm.aa);
  function Em(a, b) {
    b = b === void 0 ? !1 : b;
    if (Dm(a)) {
      var c,
        d,
        e =
          (d = (c = Vc("google_tag_data", {})).xcd) != null ? d : (c.xcd = {});
      if (e[a]) return e[a];
      if (b) {
        var f = void 0,
          g = 1,
          h = {},
          l = {
            set: function (n) {
              f = n;
              l.notify();
            },
            get: function () {
              return f;
            },
            subscribe: function (n) {
              h[String(g)] = n;
              return g++;
            },
            unsubscribe: function (n) {
              var p = String(n);
              return h.hasOwnProperty(p) ? (delete h[p], !0) : !1;
            },
            notify: function () {
              for (
                var n = m(Object.keys(h)), p = n.next();
                !p.done;
                p = n.next()
              ) {
                var q = p.value;
                try {
                  h[q](a, f);
                } catch (r) {}
              }
            },
          };
        return (e[a] = l);
      }
    }
  }
  function Fm(a, b) {
    var c = Em(a, !0);
    c && c.set(b);
  }
  function Gm(a) {
    var b;
    return (b = Em(a)) == null ? void 0 : b.get();
  }
  function Hm(a, b) {
    var c = Em(a);
    if (!c) {
      c = Em(a, !0);
      if (!c) return;
      c.set(b);
    }
    return c.get();
  }
  function Im(a, b) {
    if (typeof b === "function") {
      var c;
      return (c = Em(a, !0)) == null ? void 0 : c.subscribe(b);
    }
  }
  function Jm(a, b) {
    var c = Em(a);
    return c ? c.unsubscribe(b) : !1;
  }
  var Km = ["fin", "fs", "mcc", "wft"],
    Lm = !1;
  function Mm(a) {
    a = a === void 0 ? !1 : a;
    var b = Nk().filter(function (c) {
      return Ok[c] !== void 0 && (a || !Km.includes(c));
    });
    Rk(b);
    return (
      b
        .map(function (c) {
          var d = Ok[c];
          typeof d === "function" && (d = d());
          return d ? "&" + c + "=" + d : "";
        })
        .join("") + "&z=0"
    );
  }
  function Nm(a) {
    var b = "https://" + D(21),
      c = "/td?id=" + D(5);
    return "" + bk(b) + c + a;
  }
  function Om(a) {
    a = a === void 0 ? !1 : a;
    if (qj.J && el && D(5)) {
      var b = Bm(bm.ba.Ac);
      if (xm(b)) Lm || ((Lm = !0), zm(b, Om));
      else {
        a && Pk("fin", "1");
        var c = Mm(a),
          d = Nm(c),
          e = { destinationId: D(5), endpoint: 61 };
        a
          ? Xl(e, d, void 0, { Ue: !0 }, void 0, function () {
              Wl(e, d + "&img=1");
            })
          : Wl(e, d);
        Lm = !1;
        Pm(c);
      }
    }
  }
  function Pm(a) {
    if (
      N(426) &&
      Uc &&
      (Yb(Uc, "https://www.googletagmanager.com/") || vg(47)) &&
      !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)
    ) {
      var b;
      a: {
        try {
          if (Uc) {
            b = new URL(Uc);
            break a;
          }
        } catch (c) {}
        b = void 0;
      }
      b && cd("" + Uc + (Uc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a);
    }
  }
  function Qm() {
    Nk().some(function (a) {
      return !Lk[a];
    }) && Om(!0);
  }
  var Rm;
  function Sm() {
    if (Gm(Cm.aa.Xg) === void 0) {
      var a = function () {
        Fm(Cm.aa.Xg, Jb());
        Rm = 0;
      };
      a();
      w.setInterval(a, 864e5);
    } else
      Im(Cm.aa.Xg, function () {
        Rm = 0;
      });
    Rm = 0;
  }
  function Tm() {
    Sm();
    Pk("v", "3");
    Pk("t", "t");
    Pk("pid", function () {
      return String(Gm(Cm.aa.Xg));
    });
    Pk("seq", function () {
      return String(++Rm);
    });
    Pk("exp", Sk());
    hd(w, "pagehide", Qm);
  }
  var Um = [
      "ad_storage",
      "analytics_storage",
      "ad_user_data",
      "ad_personalization",
    ],
    Vm = [
      J.m.yd,
      J.m.Rc,
      J.m.Cf,
      J.m.Sb,
      J.m.pb,
      J.m.Oa,
      J.m.fb,
      J.m.eb,
      J.m.Ib,
      J.m.vc,
    ],
    Wm = !1,
    Xm = !1,
    Ym = {},
    Zm = {};
  function $m() {
    !Xm &&
      Wm &&
      (Um.some(function (a) {
        return jm.containerScopedDefaults[a] !== 1;
      }) ||
        an("mbc"));
    Xm = !0;
  }
  function an(a) {
    el && (Pk(a, "1"), Om());
  }
  function bn(a, b) {
    if (!Ym[b] && ((Ym[b] = !0), Zm[b]))
      for (var c = m(Vm), d = c.next(); !d.done; d = c.next())
        if (M(a, d.value)) {
          an("erc");
          break;
        }
  }
  function cn(a) {
    yb("HEALTH", a);
  }
  var dn = {},
    en = !1;
  function fn() {
    function a() {
      c !== void 0 && Jm(Cm.aa.Ge, c);
      try {
        var e = Gm(Cm.aa.Ge);
        dn = JSON.parse(e);
      } catch (f) {
        (O(123), cn(2), (dn = {}));
      }
      en = !0;
      b();
    }
    var b = gn,
      c = void 0,
      d = Gm(Cm.aa.Ge);
    d ? a(d) : ((c = Im(Cm.aa.Ge, a)), hn());
  }
  function hn() {
    function a(b) {
      Fm(Cm.aa.Ge, b || "{}");
      Fm(Cm.aa.Li, !1);
    }
    if (!Gm(Cm.aa.Li)) {
      Fm(Cm.aa.Li, !0);
      try {
        w.fetch("https://www.google.com/ccm/geo", {
          method: "GET",
          cache: "no-store",
          mode: "cors",
          credentials: "omit",
        }).then(
          function (b) {
            b.ok
              ? b.text().then(
                  function (c) {
                    a(c);
                  },
                  function () {
                    a();
                  },
                )
              : a();
          },
          function () {
            a();
          },
        );
      } catch (b) {
        a();
      }
    }
  }
  function jn() {
    var a = D(22);
    try {
      return JSON.parse(wb(a));
    } catch (b) {
      return (O(123), cn(2), {});
    }
  }
  function kn() {
    return dn["0"] || "";
  }
  function ln() {
    return dn["1"] || "";
  }
  function mn() {
    var a = !1;
    return a;
  }
  function nn() {
    return dn["6"] !== !1;
  }
  function on() {
    var a = "";
    return a;
  }
  function pn() {
    var a = "";
    return a;
  }
  var qn = {},
    rn = Object.freeze(
      ((qn[J.m.Rb] = 1),
      (qn[J.m.Yg] = 1),
      (qn[J.m.ii] = 1),
      (qn[J.m.uc] = 1),
      (qn[J.m.wa] = 1),
      (qn[J.m.Ib] = 1),
      (qn[J.m.Ab] = 1),
      (qn[J.m.Tb] = 1),
      (qn[J.m.nd] = 1),
      (qn[J.m.vc] = 1),
      (qn[J.m.eb] = 1),
      (qn[J.m.od] = 1),
      (qn[J.m.ue] = 1),
      (qn[J.m.Ha] = 1),
      (qn[J.m.cp] = 1),
      (qn[J.m.Bf] = 1),
      (qn[J.m.ri] = 1),
      (qn[J.m.mh] = 1),
      (qn[J.m.sd] = 1),
      (qn[J.m.Cf] = 1),
      (qn[J.m.pp] = 1),
      (qn[J.m.Bb] = 1),
      (qn[J.m.Hf] = 1),
      (qn[J.m.rp] = 1),
      (qn[J.m.qh] = 1),
      (qn[J.m.sl] = 1),
      (qn[J.m.Mc] = 1),
      (qn[J.m.Nc] = 1),
      (qn[J.m.fb] = 1),
      (qn[J.m.Cl] = 1),
      (qn[J.m.Vb] = 1),
      (qn[J.m.wd] = 1),
      (qn[J.m.xd] = 1),
      (qn[J.m.yd] = 1),
      (qn[J.m.th] = 1),
      (qn[J.m.zi] = 1),
      (qn[J.m.zd] = 1),
      (qn[J.m.Rc] = 1),
      (qn[J.m.Bd] = 1),
      (qn[J.m.Ml] = 1),
      (qn[J.m.zc] = 1),
      (qn[J.m.Sc] = 1),
      (qn[J.m.Yi] = 1),
      qn),
    );
  Object.freeze([
    J.m.ya,
    J.m.Xa,
    J.m.Jb,
    J.m.ob,
    J.m.yi,
    J.m.Oa,
    J.m.si,
    J.m.Zo,
  ]);
  var sn = {},
    tn = Object.freeze(
      ((sn[J.m.Eo] = 1),
      (sn[J.m.Fo] = 1),
      (sn[J.m.Go] = 1),
      (sn[J.m.Ho] = 1),
      (sn[J.m.Io] = 1),
      (sn[J.m.Mo] = 1),
      (sn[J.m.No] = 1),
      (sn[J.m.Oo] = 1),
      (sn[J.m.Qo] = 1),
      (sn[J.m.cf] = 1),
      sn),
    ),
    un = {},
    vn = Object.freeze(
      ((un[J.m.Nk] = 1),
      (un[J.m.Ok] = 1),
      (un[J.m.ie] = 1),
      (un[J.m.je] = 1),
      (un[J.m.Pk] = 1),
      (un[J.m.jd] = 1),
      (un[J.m.ke] = 1),
      (un[J.m.nc] = 1),
      (un[J.m.Gc] = 1),
      (un[J.m.oc] = 1),
      (un[J.m.Fb] = 1),
      (un[J.m.me] = 1),
      (un[J.m.qc] = 1),
      (un[J.m.Qk] = 1),
      un),
    ),
    wn = Object.freeze([
      J.m.Rb,
      J.m.lf,
      J.m.uc,
      J.m.od,
      J.m.Cf,
      J.m.Jf,
      J.m.wd,
      J.m.Bd,
    ]),
    xn = Object.freeze([].concat(Aa(wn))),
    yn = Object.freeze([J.m.Ab, J.m.mh, J.m.th, J.m.zi, J.m.jh]),
    zn = Object.freeze([].concat(Aa(yn))),
    An = {},
    Bn =
      ((An[J.m.X] = "1"),
      (An[J.m.la] = "2"),
      (An[J.m.Z] = "3"),
      (An[J.m.Ka] = "4"),
      An),
    Cn = {},
    Dn = Object.freeze(
      ((Cn.search = "s"),
      (Cn.youtube = "y"),
      (Cn.playstore = "p"),
      (Cn.shopping = "h"),
      (Cn.ads = "a"),
      (Cn.maps = "m"),
      Cn),
    );
  function En(a) {
    return typeof a !== "object" || a === null ? {} : a;
  }
  function Fn(a) {
    return a === void 0 || a === null
      ? ""
      : typeof a === "object"
        ? a.toString()
        : String(a);
  }
  function Gn(a) {
    if (a !== void 0 && a !== null) return Fn(a);
  }
  function Hn(a) {
    return a && a.indexOf("pending:") === 0 ? In(a.substr(8)) : !1;
  }
  function In(a) {
    if (a == null || a.length === 0) return !1;
    var b = Number(a),
      c = Tb();
    return b < c + 3e5 && b > c - 9e5;
  }
  var Jn = !1,
    Kn = !1,
    Ln = !1,
    Mn = 0,
    Nn = !1,
    On = [];
  function Pn(a) {
    if (Mn === 0) Nn && On && (On.length >= 100 && On.shift(), On.push(a));
    else if (Qn()) {
      var b = D(41),
        c = Vc(b, []);
      c.length >= 50 && c.shift();
      c.push(a);
    }
  }
  function Rn() {
    Sn();
    id(A, "TAProdDebugSignal", Rn);
  }
  function Sn() {
    if (!Kn) {
      Kn = !0;
      Tn();
      var a = On;
      On = void 0;
      a == null ||
        a.forEach(function (b) {
          Pn(b);
        });
    }
  }
  function Tn() {
    var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
    In(a)
      ? (Mn = 1)
      : !Hn(a) || Jn || Ln
        ? (Mn = 2)
        : ((Ln = !0),
          hd(A, "TAProdDebugSignal", Rn, !1),
          w.setTimeout(function () {
            Sn();
            Jn = !0;
          }, 200));
  }
  function Qn() {
    if (!Nn) return !1;
    switch (Mn) {
      case 1:
      case 0:
        return !0;
      case 2:
        return !1;
      default:
        return !1;
    }
  }
  var Un = !1;
  function Vn(a, b) {
    var c = uk(),
      d = rk();
    D(26);
    var e = vg(47) ? 0 : vg(50) ? 1 : 3,
      f = Vj();
    if (Qn()) {
      var g = Wn("INIT");
      g.containerLoadSource = a != null ? a : 0;
      b && (g.parentTargetReference = b);
      g.aliases = c;
      g.destinations = d;
      e !== void 0 && (g.gtg = { source: e, mPath: f != null ? f : "" });
      Pn(g);
    }
  }
  function Xn(a) {
    var b, c, d, e;
    b = a.targetId;
    c = a.request;
    d = a.jb;
    e = a.isBatched;
    var f;
    if ((f = Qn())) {
      var g;
      a: switch (c.endpoint) {
        case 68:
        case 19:
        case 47:
          g = !0;
          break a;
        default:
          g = !1;
      }
      f = !g;
    }
    if (f) {
      var h = Wn("GTAG_HIT", { eventId: d.eventId, priorityId: d.priorityId });
      h.target = b;
      h.url = c.url;
      c.postBody && (h.postBody = c.postBody);
      h.parameterEncoding = c.parameterEncoding;
      h.endpoint = c.endpoint;
      e !== void 0 && (h.isBatched = e);
      Pn(h);
    }
  }
  function Yn(a) {
    Qn() && Xn(a());
  }
  function Wn(a, b) {
    b = b === void 0 ? {} : b;
    b.groupId = Zn;
    var c,
      d = b,
      e = $n,
      f = { publicId: ao };
    d.eventId != null && (f.eventId = d.eventId);
    d.priorityId != null && (f.priorityId = d.priorityId);
    d.eventName && (f.eventName = d.eventName);
    d.groupId && (f.groupId = d.groupId);
    d.tagName && (f.tagName = d.tagName);
    c = { containerProduct: "GTM", key: f, version: e, messageType: a };
    c.containerProduct = Un ? "OGT" : "GTM";
    c.key.targetRef = bo;
    return c;
  }
  var ao = "",
    $n = "",
    bo = { ctid: "", isDestination: !1 },
    Zn;
  function co(a) {
    var b = D(5),
      c = qk(),
      d = D(6),
      e = D(1);
    D(23);
    Mn = 0;
    Nn = !0;
    Tn();
    Zn = a;
    ao = b;
    $n = e;
    Un = yj;
    bo = { ctid: b, isDestination: c, canonicalId: d };
  }
  var eo = [J.m.X, J.m.la, J.m.Z, J.m.Ka],
    fo,
    go;
  function ho(a) {
    var b = a[J.m.mc];
    b || (b = [""]);
    for (var c = { vg: 0 }; c.vg < b.length; c = { vg: c.vg }, ++c.vg)
      Mb(
        a,
        (function (d) {
          return function (e, f) {
            if (e !== J.m.mc) {
              var g = Fn(f),
                h = b[d.vg],
                l = kn(),
                n = ln();
              hm = !0;
              gm && yb("TAGGING", 20);
              cm().declare(e, g, h, l, n);
            }
          };
        })(c),
      );
  }
  function io(a) {
    $m();
    !go && fo && an("crc");
    go = !0;
    var b = a[J.m.Sg];
    b && O(41);
    var c = a[J.m.mc];
    c ? O(40) : (c = [""]);
    for (var d = { wg: 0 }; d.wg < c.length; d = { wg: d.wg }, ++d.wg)
      Mb(
        a,
        (function (e) {
          return function (f, g) {
            if (f !== J.m.mc && f !== J.m.Sg) {
              var h = Gn(g),
                l = c[e.wg],
                n = Number(b),
                p = kn(),
                q = ln();
              n = n === void 0 ? 0 : n;
              gm = !0;
              hm && yb("TAGGING", 20);
              cm().default(f, h, l, p, q, n, jm);
            }
          };
        })(d),
      );
  }
  function jo(a) {
    jm.usedContainerScopedDefaults = !0;
    var b = a[J.m.mc];
    if (b) {
      var c = Array.isArray(b) ? b : [b];
      if (!c.includes(ln()) && !c.includes(kn())) return;
    }
    Mb(a, function (d, e) {
      switch (d) {
        case "ad_storage":
        case "analytics_storage":
        case "ad_user_data":
        case "ad_personalization":
          break;
        default:
          return;
      }
      jm.usedContainerScopedDefaults = !0;
      jm.containerScopedDefaults[d] = e === "granted" ? 3 : 2;
    });
  }
  function ko(a, b) {
    $m();
    fo = !0;
    Mb(a, function (c, d) {
      var e = Fn(d);
      gm = !0;
      hm && yb("TAGGING", 20);
      cm().update(c, e, jm);
    });
    pm(b.eventId, b.priorityId);
  }
  function lo(a) {
    a.hasOwnProperty("all") &&
      ((jm.selectedAllCorePlatformServices = !0),
      Mb(Dn, function (b) {
        jm.corePlatformServices[b] = a.all === "granted";
        jm.usedCorePlatformServices = !0;
      }));
    Mb(a, function (b, c) {
      b !== "all" &&
        ((jm.corePlatformServices[b] = c === "granted"),
        (jm.usedCorePlatformServices = !0));
    });
  }
  function mo(a) {
    Array.isArray(a) || (a = [a]);
    return a.every(function (b) {
      return km(b);
    });
  }
  function no() {
    var a = oo;
    Array.isArray(a) || (a = [a]);
    return a.some(function (b) {
      return km(b);
    });
  }
  function po(a, b) {
    om(a, b);
  }
  function qo(a, b) {
    rm(a, b);
  }
  function ro(a, b) {
    qm(a, b);
  }
  function so() {
    var a = [J.m.X, J.m.Ka, J.m.Z];
    cm().waitForUpdate(a, 500, jm);
  }
  function to(a) {
    for (var b = m(a), c = b.next(); !c.done; c = b.next()) {
      var d = c.value;
      cm().clearTimeout(d, void 0, jm);
    }
    pm();
  }
  function uo() {
    if (!zj)
      for (var a = nn() ? vo(yg(5)) : vo(yg(4)), b = 0; b < eo.length; b++) {
        var c = eo[b],
          d = c,
          e = a[c] ? "granted" : "denied";
        cm().implicit(d, e);
      }
  }
  function vo(a) {
    for (var b = {}, c = m(a.split("|")), d = c.next(); !d.done; d = c.next())
      b[d.value] = !0;
    return b;
  }
  var wo = (w.google_tag_manager = w.google_tag_manager || {});
  function xo(a, b) {
    return (wo[a] = wo[a] || b());
  }
  function yo() {
    var a = D(5),
      b = zo;
    wo[a] = wo[a] || b;
  }
  function Ao() {
    var a = D(19);
    return (wo[a] = wo[a] || {});
  }
  function Bo() {
    var a = D(19);
    return wo[a];
  }
  function Co() {
    var a = wo.sequence || 1;
    wo.sequence = a + 1;
    return a;
  }
  w.google_tag_data = w.google_tag_data || {};
  var Do = !1,
    Eo = [];
  function Fo() {
    if (!Do) {
      Do = !0;
      for (var a = Eo.length - 1; a >= 0; a--) Eo[a]();
      Eo = [];
    }
  }
  var Go = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
    Ho = /\s/;
  function Io(a, b) {
    if (Fb(a)) {
      a = Rb(a);
      var c = a.indexOf("-");
      if (!(c < 0)) {
        var d = a.substring(0, c);
        if (Go.test(d)) {
          var e = a.substring(c + 1),
            f;
          if (b) {
            var g = function (n) {
              var p = n.indexOf("/");
              return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)];
            };
            f = g(e);
            if (d === "DC" && f.length === 2) {
              var h = g(f[1]);
              h.length === 2 && ((f[1] = h[0]), f.push(h[1]));
            }
          } else {
            f = e.split("/");
            for (var l = 0; l < f.length; l++)
              if (!f[l] || (Ho.test(f[l]) && (d !== "AW" || l !== 1))) return;
          }
          return { id: a, prefix: d, destinationId: d + "-" + f[0], ids: f };
        }
      }
    }
  }
  function Jo(a, b) {
    for (var c = {}, d = 0; d < a.length; ++d) {
      var e = Io(a[d], b);
      e && (c[e.id] = e);
    }
    var f = [],
      g;
    for (g in c)
      if (c.hasOwnProperty(g)) {
        var h = c[g];
        h.prefix === "AW" && h.ids[Ko[1]] && f.push(h.destinationId);
      }
    for (var l = 0; l < f.length; ++l) delete c[f[l]];
    for (var n = [], p = m(Object.keys(c)), q = p.next(); !q.done; q = p.next())
      n.push(c[q.value]);
    return n;
  }
  var Lo = {},
    Ko =
      ((Lo[0] = 0),
      (Lo[1] = 1),
      (Lo[2] = 2),
      (Lo[3] = 0),
      (Lo[4] = 1),
      (Lo[5] = 0),
      (Lo[6] = 0),
      (Lo[7] = 0),
      Lo);
  var Mo = Ag(34, 500),
    No = {},
    Oo = {},
    Po = { initialized: 11, complete: 12, interactive: 13 },
    Qo = {},
    Ro = Object.freeze(((Qo[J.m.wd] = !0), Qo)),
    So = void 0;
  function To(a, b) {
    if (b.length && el) {
      var c;
      (c = No)[a] != null || (c[a] = []);
      Oo[a] != null || (Oo[a] = []);
      var d = b.filter(function (e) {
        return !Oo[a].includes(e);
      });
      No[a].push.apply(No[a], Aa(d));
      Oo[a].push.apply(Oo[a], Aa(d));
      !So &&
        d.length > 0 &&
        (Qk("tdc", !0),
        (So = w.setTimeout(function () {
          Om();
          No = {};
          So = void 0;
        }, Mo)));
    }
  }
  function Uo(a, b) {
    var c = {},
      d;
    for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
    for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
    return c;
  }
  function Vo(a, b, c, d) {
    c = c === void 0 ? {} : c;
    d = d === void 0 ? "" : d;
    if (a === b) return [];
    var e = function (r, t) {
        var u;
        Gd(t) === "object" ? (u = t[r]) : Gd(t) === "array" && (u = t[r]);
        return u === void 0 ? Ro[r] : u;
      },
      f = Uo(a, b),
      g;
    for (g in f)
      if (f.hasOwnProperty(g)) {
        var h = (d ? d + "." : "") + g,
          l = e(g, a),
          n = e(g, b),
          p = Gd(l) === "object" || Gd(l) === "array",
          q = Gd(n) === "object" || Gd(n) === "array";
        if (p && q) Vo(l, n, c, h);
        else if (p || q || l !== n) c[h] = !0;
      }
    return Object.keys(c);
  }
  function Wo() {
    Pk(
      "tdc",
      function () {
        So && (w.clearTimeout(So), (So = void 0));
        var a = [],
          b;
        for (b in No) No.hasOwnProperty(b) && a.push(b + "*" + No[b].join("."));
        return a.length ? a.join("!") : void 0;
      },
      !1,
    );
  }
  var Xo = {
    U: {
      mk: 1,
      Xi: 2,
      ik: 3,
      Fk: 4,
      jk: 5,
      hd: 6,
      Ek: 7,
      Vp: 8,
      Pm: 9,
      kk: 10,
      lk: 11,
      Ah: 12,
      am: 13,
      Xl: 14,
      Zl: 15,
      Wl: 16,
      Yl: 17,
      Vl: 18,
      lo: 19,
      Hp: 20,
      Ip: 21,
      Ri: 22,
    },
  };
  Xo.U[Xo.U.mk] = "ALLOW_INTEREST_GROUPS";
  Xo.U[Xo.U.Xi] = "SERVER_CONTAINER_URL";
  Xo.U[Xo.U.ik] = "ADS_DATA_REDACTION";
  Xo.U[Xo.U.Fk] = "CUSTOMER_LIFETIME_VALUE";
  Xo.U[Xo.U.jk] = "ALLOW_CUSTOM_SCRIPTS";
  Xo.U[Xo.U.hd] = "ANY_COOKIE_PARAMS";
  Xo.U[Xo.U.Ek] = "COOKIE_EXPIRES";
  Xo.U[Xo.U.Vp] = "LEGACY_ENHANCED_CONVERSION_JS_VARIABLE";
  Xo.U[Xo.U.Pm] = "RESTRICTED_DATA_PROCESSING";
  Xo.U[Xo.U.kk] = "ALLOW_DISPLAY_FEATURES";
  Xo.U[Xo.U.lk] = "ALLOW_GOOGLE_SIGNALS";
  Xo.U[Xo.U.Ah] = "GENERATED_TRANSACTION_ID";
  Xo.U[Xo.U.am] = "FLOODLIGHT_COUNTING_METHOD_UNKNOWN";
  Xo.U[Xo.U.Xl] = "FLOODLIGHT_COUNTING_METHOD_STANDARD";
  Xo.U[Xo.U.Zl] = "FLOODLIGHT_COUNTING_METHOD_UNIQUE";
  Xo.U[Xo.U.Wl] = "FLOODLIGHT_COUNTING_METHOD_PER_SESSION";
  Xo.U[Xo.U.Yl] = "FLOODLIGHT_COUNTING_METHOD_TRANSACTIONS";
  Xo.U[Xo.U.Vl] = "FLOODLIGHT_COUNTING_METHOD_ITEMS_SOLD";
  Xo.U[Xo.U.lo] = "ADS_OGT_V1_USAGE";
  Xo.U[Xo.U.Hp] = "FORM_INTERACTION_PERMISSION_DENIED";
  Xo.U[Xo.U.Ip] = "FORM_SUBMIT_PERMISSION_DENIED";
  Xo.U[Xo.U.Ri] = "MICROTASK_NOT_SUPPORTED";
  var Yo = {},
    Zo =
      ((Yo[J.m.ji] = Xo.U.mk),
      (Yo[J.m.yd] = Xo.U.Xi),
      (Yo[J.m.Rc] = Xo.U.Xi),
      (Yo[J.m.La] = Xo.U.ik),
      (Yo[J.m.te] = Xo.U.Fk),
      (Yo[J.m.kf] = Xo.U.jk),
      (Yo[J.m.od] = Xo.U.hd),
      (Yo[J.m.eb] = Xo.U.hd),
      (Yo[J.m.Ib] = Xo.U.hd),
      (Yo[J.m.nd] = Xo.U.hd),
      (Yo[J.m.vc] = Xo.U.hd),
      (Yo[J.m.Tb] = Xo.U.hd),
      (Yo[J.m.Ab] = Xo.U.Ek),
      (Yo[J.m.Vb] = Xo.U.Pm),
      (Yo[J.m.Yg] = Xo.U.kk),
      (Yo[J.m.uc] = Xo.U.lk),
      Yo),
    $o = {},
    ap =
      (($o.unknown = Xo.U.am),
      ($o.standard = Xo.U.Xl),
      ($o.unique = Xo.U.Zl),
      ($o.per_session = Xo.U.Wl),
      ($o.transactions = Xo.U.Yl),
      ($o.items_sold = Xo.U.Vl),
      $o);
  var Bb = [];
  function bp(a, b) {
    b = b === void 0 ? !1 : b;
    yb("GTAG_EVENT_FEATURE_CHANNEL", a);
    b && (Bb[a] = !0);
  }
  function cp(a, b) {
    b = b === void 0 ? !1 : b;
    for (
      var c = Object.keys(a), d = m(Object.keys(Zo)), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value;
      c.includes(f) && bp(Zo[f], b);
    }
  }
  function dp(a, b) {
    return arguments.length === 1 ? ep("set", a) : ep("set", a, b);
  }
  function fp(a, b) {
    return arguments.length === 1 ? ep("config", a) : ep("config", a, b);
  }
  function gp(a, b, c) {
    c = c || {};
    c[J.m.xd] = a;
    return ep("event", b, c);
  }
  function ep() {
    return arguments;
  }
  var hp = function (a, b, c, d, e, f, g, h, l, n, p) {
      this.eventId = a;
      this.priorityId = b;
      this.D = c;
      this.V = d;
      this.J = e;
      this.T = f;
      this.N = g;
      this.eventMetadata = h;
      this.onSuccess = l;
      this.onFailure = n;
      this.isGtmEvent = p;
    },
    ip = function (a, b) {
      var c = [];
      switch (b) {
        case 3:
          c.push(a.D);
          c.push(a.V);
          c.push(a.J);
          c.push(a.T);
          c.push(a.N);
          break;
        case 2:
          c.push(a.D);
          break;
        case 1:
          c.push(a.V);
          c.push(a.J);
          c.push(a.T);
          c.push(a.N);
          break;
        case 4:
          (c.push(a.D), c.push(a.V), c.push(a.J), c.push(a.T));
      }
      return c;
    },
    M = function (a, b, c, d) {
      for (
        var e = m(ip(a, d === void 0 ? 3 : d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        if (g[b] !== void 0) return g[b];
      }
      return c;
    },
    tp = function (a) {
      for (
        var b = {}, c = ip(a, 4), d = m(c), e = d.next();
        !e.done;
        e = d.next()
      )
        for (
          var f = Object.keys(e.value), g = m(f), h = g.next();
          !h.done;
          h = g.next()
        )
          b[h.value] = 1;
      return Object.keys(b);
    };
  hp.prototype.getMergedValues = function (a, b, c) {
    function d(n) {
      Id(n) &&
        Mb(n, function (p, q) {
          f = !0;
          e[p] = q;
        });
    }
    b = b === void 0 ? 3 : b;
    var e = {},
      f = !1;
    c && d(c);
    var g = ip(this, b);
    g.reverse();
    for (var h = m(g), l = h.next(); !l.done; l = h.next()) d(l.value[a]);
    return f ? e : void 0;
  };
  var up = function (a) {
      for (
        var b = [J.m.xf, J.m.tf, J.m.uf, J.m.vf, J.m.wf, J.m.yf, J.m.zf],
          c = ip(a, 3),
          d = m(c),
          e = d.next();
        !e.done;
        e = d.next()
      ) {
        for (
          var f = e.value, g = {}, h = !1, l = m(b), n = l.next();
          !n.done;
          n = l.next()
        ) {
          var p = n.value;
          f[p] !== void 0 && ((g[p] = f[p]), (h = !0));
        }
        var q = h ? g : void 0;
        if (q) return q;
      }
      return {};
    },
    vp = function (a, b) {
      this.eventId = a;
      this.priorityId = b;
      this.J = {};
      this.V = {};
      this.D = {};
      this.N = {};
      this.fa = {};
      this.T = {};
      this.eventMetadata = {};
      this.isGtmEvent = !1;
      this.onSuccess = function () {};
      this.onFailure = function () {};
    },
    wp = function (a, b) {
      a.J = b;
      return a;
    },
    xp = function (a, b) {
      a.V = b;
      return a;
    },
    yp = function (a, b) {
      a.D = b;
      return a;
    },
    zp = function (a, b) {
      a.N = b;
      return a;
    },
    Ap = function (a, b) {
      a.fa = b;
      return a;
    },
    Bp = function (a, b) {
      a.T = b;
      return a;
    },
    Cp = function (a, b) {
      a.eventMetadata = b || {};
      return a;
    },
    Dp = function (a, b) {
      a.onSuccess = b;
      return a;
    },
    Ep = function (a, b) {
      a.onFailure = b;
      return a;
    },
    Fp = function (a, b) {
      a.isGtmEvent = b;
      return a;
    },
    Gp = function (a) {
      return new hp(
        a.eventId,
        a.priorityId,
        a.J,
        a.V,
        a.D,
        a.N,
        a.T,
        a.eventMetadata,
        a.onSuccess,
        a.onFailure,
        a.isGtmEvent,
      );
    };
  var R = {
    C: {
      bi: "accept_by_default",
      fk: "add_tag_timing",
      de: "ads_event_page_view",
      Pg: "ads_hit_param_overrides",
      fd: "allow_ad_personalization",
      Gs: "auto_event",
      nk: "batch_on_navigation",
      sk: "client_id_source",
      Qg: "consent_event_id",
      Rg: "consent_priority_id",
      Is: "consent_state",
      ka: "consent_updated",
      fe: "conversion_linker_enabled",
      Ca: "cookie_options",
      Ug: "create_dc_join",
      Vg: "create_fpm_geo_join",
      Wg: "create_fpm_signals_join",
      he: "create_google_join",
      Ik: "dc_random",
      Fc: "em_event",
      Ps: "endpoint_for_debug",
      Mk: "enhanced_client_id_source",
      Do: "enhanced_match_result",
      Pl: "euid_logged_in_state",
      Ce: "euid_mode_enabled",
      Cb: "event_start_timestamp_ms",
      Tl: "event_usage",
      Ei: "extra_tag_experiment_ids",
      bt: "add_parameter",
      Gi: "attribution_reporting_experiment",
      Hi: "counting_method",
      zh: "send_as_iframe",
      ct: "parameter_order",
      De: "parsed_target",
      Kp: "ga4_collection_subdomain",
      Ii: "ga4_request_flags",
      om: "gbraid_cookie_marked",
      qb: "handle_internally",
      da: "hit_type",
      Wb: "hit_type_override",
      Fe: "ignore_hit_success_failure",
      Et: "is_config_command",
      Bh: "is_consent_update",
      Xf: "is_conversion",
      wm: "is_ecommerce",
      xm: "is_ec_cm_split",
      Fd: "is_external_event",
      Ni: "is_fallback_aw_conversion_ping_allowed",
      Yf: "is_first_visit",
      ym: "is_first_visit_conversion",
      Ch: "is_fl_fallback_conversion_flow_allowed",
      Gd: "is_fpm_encryption",
      Oi: "is_fpm_split",
      hb: "is_gcp_conversion",
      Zf: "is_google_signals_allowed",
      Dh: "is_google_signals_enabled",
      Hd: "is_merchant_center",
      Eh: "is_new_to_site",
      He: "is_personalization",
      Am: "is_server_side_destination",
      Ie: "is_session_start",
      Bm: "is_session_start_conversion",
      Ft: "is_sgtm_ga_ads_conversion_study_control_group",
      Gt: "is_sgtm_prehit",
      Cm: "is_sgtm_service_worker",
      Pi: "is_split_conversion",
      Rp: "is_syn",
      cg: "is_test_event",
      dg: "join_id",
      Qi: "join_elapsed",
      eg: "join_timer_sec",
      Fm: "local_storage_aw_conversion_counters",
      Ne: "tunnel_updated",
      Kt: "prehit_for_retry",
      Mt: "promises",
      Nt: "record_aw_latency",
      Vc: "redact_ads_data",
      Oe: "redact_click_ids",
      Om: "remarketing_only",
      Vi: "send_ccm_parallel_ping",
      Pt: "send_ccm_parallel_test_ping",
      hg: "send_to_destinations",
      Wi: "send_to_targets",
      Qm: "send_user_data_hit",
      Ih: "shw_rnd",
      Ta: "source_canonical_id",
      Fa: "speculative",
      Zm: "speculative_in_message",
      dn: "suppress_script_load",
      fn: "syn_or_mod",
      fj: "transient_ecsid",
      ig: "transmission_type",
      Pa: "user_data",
      St: "user_data_from_automatic",
      Tt: "user_data_from_automatic_getter",
      kn: "user_data_from_code",
      mq: "user_data_from_manual",
      Ut: "user_data_mode",
      kg: "user_id_updated",
    },
  };
  function Hp(a, b) {
    Mb(a, function (c) {
      var d;
      if ((d = c.charAt(0) === "_")) {
        var e;
        a: switch (c) {
          case J.m.Ub:
          case J.m.Df:
            e = !0;
            break a;
          default:
            e = !1;
        }
        d = !e;
      }
      d && (b && b(c), delete a[c]);
    });
  }
  var Ip = new Lb(),
    Jp = {},
    Kp = {},
    Np = {
      name: D(19),
      set: function (a, b) {
        Jd(cc(a, b), Jp);
        Lp();
      },
      get: function (a) {
        return Mp(a, 2);
      },
      reset: function () {
        Ip = new Lb();
        Jp = {};
        Lp();
      },
    };
  function Mp(a, b) {
    return b != 2 ? Ip.get(a) : Op(a);
  }
  function Op(a, b) {
    var c = a.split(".");
    b = b || [];
    for (var d = Jp, e = 0; e < c.length; e++) {
      if (d === null) return !1;
      if (d === void 0) break;
      d = d[c[e]];
      if (b.indexOf(d) !== -1) return;
    }
    return d;
  }
  function Pp(a, b) {
    Kp.hasOwnProperty(a) || (Ip.set(a, b), Jd(cc(a, b), Jp), Lp());
  }
  function Qp() {
    for (
      var a = [
          "gtm.allowlist",
          "gtm.blocklist",
          "gtm.whitelist",
          "gtm.blacklist",
          "tagTypeBlacklist",
        ],
        b = 0;
      b < a.length;
      b++
    ) {
      var c = a[b],
        d = Mp(c, 1);
      if (Array.isArray(d) || Id(d)) d = Jd(d, null);
      Kp[c] = d;
    }
  }
  function Lp(a) {
    Mb(Kp, function (b, c) {
      Ip.set(b, c);
      Jd(cc(b), Jp);
      Jd(cc(b, c), Jp);
      a && delete Kp[b];
    });
  }
  function Rp(a, b) {
    var c,
      d = (b === void 0 ? 2 : b) !== 1 ? Op(a) : Ip.get(a);
    Gd(d) === "array" || Gd(d) === "object" ? (c = Jd(d, null)) : (c = d);
    return c;
  }
  var Sp = { UA: 1, AW: 2, DC: 3, G: 4, GF: 5, GT: 12, GTM: 14, HA: 6, MC: 7 };
  function Tp(a) {
    a = a === void 0 ? {} : a;
    var b = D(5).split("-")[0].toUpperCase(),
      c,
      d = {
        ctid: D(5),
        Vn: wg(15),
        Zn: D(14),
        Fr: vg(7) ? 2 : 1,
        rs: a.bo,
        canonicalId: D(6),
        Zr: (c = yk()) == null ? void 0 : c.canonicalContainerId,
        us: a.be === void 0 ? void 0 : a.be ? 10 : 12,
      };
    d.canonicalId !== a.Ra && (d.Ra = a.Ra);
    var e = vk();
    d.Mr = e ? e.canonicalContainerId : void 0;
    yj ? ((d.Zh = Sp[b]), d.Zh || (d.Zh = 0)) : (d.Zh = zj ? 13 : 10);
    vg(47) ? ((d.Kj = 0), (d.xq = 2)) : vg(50) ? (d.Kj = 1) : (d.Kj = 3);
    var f = a,
      g = { 6: !1 };
    wg(54) === 2 ? (g[7] = !0) : wg(54) === 1 && (g[2] = !0);
    if (Uc) {
      var h = Jj(Pj(Uc), "host");
      h && (g[8] = h.match(/^(www\.)?googletagmanager\.com$/) === null);
    }
    if (N(417)) {
      var l;
      g[9] = (l = f.kc) != null ? l : !1;
    }
    if (N(420)) {
      var n = Dk(),
        p;
      g[10] =
        (p = n == null ? void 0 : n.fromContainerExecution) != null ? p : !1;
    }
    d.Dq = g;
    return Df(d, a.Lh);
  }
  var Up = { ko: Ag(3, 0) },
    Vp = [],
    Wp = !1;
  function Xp(a) {
    Vp.push(a);
  }
  var Yp = void 0,
    Zp = {},
    $p = void 0,
    aq = new (function () {
      var a = 5;
      Up.ko > 0 && (a = Up.ko);
      this.J = a;
      this.D = 0;
      this.N = [];
    })(),
    bq = 1e3;
  function cq(a, b) {
    var c = Yp;
    if (c === void 0)
      if (b) c = Co();
      else return "";
    for (
      var d = [bk("https://" + D(21)), "/a", "?id=" + D(5)],
        e = m(Vp),
        f = e.next();
      !f.done;
      f = e.next()
    )
      for (
        var g = f.value, h = g({ eventId: c, Ng: !!a }), l = m(h), n = l.next();
        !n.done;
        n = l.next()
      ) {
        var p = m(n.value),
          q = p.next().value,
          r = p.next().value;
        d.push("&" + q + "=" + r);
      }
    d.push("&z=0");
    return d.join("");
  }
  function dq() {
    if (
      qj.J &&
      ($p && (w.clearTimeout($p), ($p = void 0)), Yp !== void 0 && eq)
    ) {
      var a = Bm(bm.ba.Ac);
      if (xm(a)) Wp || ((Wp = !0), zm(a, dq));
      else {
        var b;
        if (!(b = Zp[Yp])) {
          var c = aq;
          b = c.D < c.J ? !1 : Tb() - c.N[c.D % c.J] < 1e3;
        }
        if (b || bq-- <= 0) (O(1), (Zp[Yp] = !0));
        else {
          var d = aq,
            e = d.D++ % d.J;
          d.N[e] = Tb();
          var f = cq(!0);
          Wl({ destinationId: D(5), endpoint: 56, eventId: Yp }, f);
          Wp = eq = !1;
        }
      }
    }
  }
  function fq() {
    if (bl && qj.J) {
      var a = cq(!0, !0);
      Wl({ destinationId: D(5), endpoint: 56, eventId: Yp }, a);
    }
  }
  var eq = !1;
  function gq(a) {
    Zp[a] ||
      (a !== Yp && (dq(), (Yp = a)),
      (eq = !0),
      $p || ($p = w.setTimeout(dq, 500)),
      cq().length >= 2022 && dq());
  }
  var hq = Jb();
  function iq() {
    hq = Jb();
  }
  function jq() {
    var a = [
        ["v", "3"],
        ["t", "t"],
        ["pid", String(hq)],
      ],
      b = Tp();
    b && a.push(["gtm", b]);
    return a;
  }
  var kq = {};
  function lq(a, b, c) {
    bl && a !== void 0 && ((kq[a] = kq[a] || []), kq[a].push(c + b), gq(a));
  }
  function mq(a) {
    var b = a.eventId,
      c = a.Ng,
      d = [],
      e = kq[b] || [];
    e.length && d.push(["epr", e.join(".")]);
    c && delete kq[b];
    return d;
  }
  var nq = !1;
  function oq(a, b, c, d) {
    var e = Io(c, d.isGtmEvent);
    e && (nq && (d.deferrable = !0), pq.push("event", [b, a], e, d));
  }
  function qq(a, b, c, d) {
    var e = Io(c, d.isGtmEvent);
    e && pq.push("get", [a, b], e, d);
  }
  function rq(a) {
    var b = Io(a, !0),
      c;
    b ? (c = sq(pq, b).T) : (c = {});
    return c;
  }
  var tq = function () {
      this.D = {};
      this.T = {};
      this.V = {};
      this.fa = null;
      this.N = {};
      this.J = !1;
      this.status = 1;
    },
    uq = function (a, b, c, d) {
      this.J = Tb();
      this.D = b;
      this.args = c;
      this.messageContext = d;
      this.type = a;
    };
  function vq(a, b) {
    var c = {};
    Mb(a, function (d, e) {
      Jd(cc(d, e), c);
    });
    N(411) && Hp(c, b);
    return c;
  }
  var wq = function () {
      this.destinations = {};
      this.D = {};
      this.commands = [];
    },
    sq = function (a, b) {
      return (a.destinations[b.destinationId] =
        a.destinations[b.destinationId] || new tq());
    },
    xq = function (a, b, c, d) {
      if (d.D) {
        var e = sq(a, d.D),
          f = e.fa;
        if (f) {
          var g = Jd(c, null),
            h = Jd(e.D[d.D.destinationId], null),
            l = Jd(e.N, null),
            n = Jd(e.T, null),
            p = Jd(a.D, null),
            q = {};
          if (bl)
            try {
              q = Jd(Jp, null);
            } catch (x) {
              O(72);
            }
          var r = d.D.prefix,
            t = function (x) {
              lq(d.messageContext.eventId, r, x);
            },
            u = Gp(
              Fp(
                Ep(
                  Dp(
                    Cp(
                      Ap(
                        zp(
                          Bp(
                            yp(
                              xp(
                                wp(
                                  new vp(
                                    d.messageContext.eventId,
                                    d.messageContext.priorityId,
                                  ),
                                  g,
                                ),
                                h,
                              ),
                              l,
                            ),
                            n,
                          ),
                          p,
                        ),
                        q,
                      ),
                      d.messageContext.eventMetadata,
                    ),
                    function () {
                      if (t) {
                        var x = t;
                        t = void 0;
                        x("2");
                        if (d.messageContext.onSuccess)
                          d.messageContext.onSuccess();
                      }
                    },
                  ),
                  function () {
                    if (t) {
                      var x = t;
                      t = void 0;
                      x("3");
                      if (d.messageContext.onFailure)
                        d.messageContext.onFailure();
                    }
                  },
                ),
                !!d.messageContext.isGtmEvent,
              ),
            ),
            v = function () {
              try {
                lq(d.messageContext.eventId, r, "1");
                var x = d.D.id;
                if (el && b === J.m.na) {
                  var y,
                    z = (y = Io(x)) == null ? void 0 : y.ids;
                  if (!(z && z.length > 1)) {
                    var C,
                      E = Vc("google_tag_data", {});
                    E.td || (E.td = {});
                    C = E.td;
                    var G = Jd(u.T);
                    Jd(u.D, G);
                    var K = [],
                      P;
                    for (P in C)
                      C.hasOwnProperty(P) && Vo(C[P], G).length && K.push(P);
                    K.length &&
                      (To(x, K), yb("TAGGING", Po[A.readyState] || 14));
                    C[x] = G;
                  }
                }
                f(d.D.id, b, d.J, u);
              } catch (fa) {
                lq(d.messageContext.eventId, r, "4");
              }
            };
          b === "gtag.get" ? v() : zm(e.ma, v);
        }
      }
    },
    yq = function (a, b) {
      if (b.type !== "require")
        if (b.D)
          for (var c = sq(a, b.D).V[b.type] || [], d = 0; d < c.length; d++)
            c[d]();
        else
          for (var e in a.destinations)
            if (a.destinations.hasOwnProperty(e)) {
              var f = a.destinations[e];
              if (f && f.V)
                for (var g = f.V[b.type] || [], h = 0; h < g.length; h++)
                  g[h]();
            }
    };
  wq.prototype.register = function (a, b, c, d) {
    var e = sq(this, a);
    e.status !== 3 &&
      ((e.fa = b),
      (e.status = 3),
      (e.ma = Bm(c)),
      zq(this, a, d || {}),
      this.flush());
  };
  wq.prototype.push = function (a, b, c, d) {
    c !== void 0 &&
      (sq(this, c).status === 1 &&
        ((sq(this, c).status = 2), this.push("require", [{}], c, {})),
      sq(this, c).J && (d.deferrable = !1),
      d.eventMetadata || (d.eventMetadata = {}),
      d.eventMetadata[R.C.hg] || (d.eventMetadata[R.C.hg] = [c.destinationId]),
      d.eventMetadata[R.C.Wi] || (d.eventMetadata[R.C.Wi] = [c.id]));
    this.commands.push(new uq(a, c, b, d));
    d.deferrable || this.flush();
  };
  wq.prototype.flush = function (a) {
    for (
      var b = this, c = [], d = !1, e = {};
      this.commands.length;
      e = { xn: void 0 }
    ) {
      var f = this.commands[0],
        g = f.D;
      if (f.messageContext.deferrable)
        (!g || sq(this, g).J
          ? ((f.messageContext.deferrable = !1), this.commands.push(f))
          : c.push(f),
          this.commands.shift());
      else {
        switch (f.type) {
          case "require":
            if (sq(this, g).status !== 3 && !a) {
              this.commands.push.apply(this.commands, c);
              return;
            }
            break;
          case "set":
            var h = f.args[0];
            N(411) && Hp(h);
            Mb(h, function (C, E) {
              Jd(cc(C, E), b.D);
            });
            cp(h, !0);
            break;
          case "config":
            var l = sq(this, g),
              n = vq(f.args[0], function () {}),
              p = !!n[J.m.Bd];
            delete n[J.m.Bd];
            var q = g.destinationId === g.id;
            cp(n, !0);
            p || (q ? (l.N = {}) : (l.D[g.id] = {}));
            (l.J && p) || xq(this, J.m.na, n, f);
            l.J = !0;
            q ? Jd(n, l.N) : (Jd(n, l.D[g.id]), O(70));
            d = !0;
            break;
          case "event":
            e.xn = f.args[1];
            var r = vq(
              f.args[0],
              (function () {
                return function () {};
              })(e),
            );
            cp(r);
            xq(this, e.xn, r, f);
            break;
          case "get":
            var t = {},
              u = ((t[J.m.Gf] = f.args[0]), (t[J.m.Ff] = f.args[1]), t);
            xq(this, J.m.Gb, u, f);
            break;
          case "container_config":
            var v = sq(this, g),
              x = vq(f.args[0], function () {});
            cp(x, !0);
            v.J = !0;
            Jd(x, v.N);
            d = !0;
            break;
          case "destination_config":
            var y = sq(this, g),
              z = vq(f.args[0], function () {});
            cp(z, !0);
            y.D[g.id] || (y.D[g.id] = {});
            y.J = !0;
            Jd(z, y.D[g.id]);
            d = !0;
            break;
          case "reset_container_config":
            sq(this, g).N = {};
            break;
          case "reset_target_config":
            sq(this, g).D[g.id] = {};
        }
        this.commands.shift();
        yq(this, f);
      }
    }
    this.commands.push.apply(this.commands, c);
    d && this.flush();
  };
  var zq = function (a, b, c) {
      var d = Jd(c, null);
      Jd(sq(a, b).T, d);
      sq(a, b).T = d;
    },
    pq = new wq();
  function Aq(a) {
    var b = a.location.href;
    if (a === a.top) return { url: b, Dr: !0 };
    var c = !1,
      d = a.document;
    d && d.referrer && ((b = d.referrer), a.parent === a.top && (c = !0));
    var e = a.location.ancestorOrigins;
    if (e) {
      var f = e[e.length - 1],
        g;
      f &&
        ((g = b) == null ? void 0 : g.indexOf(f)) === -1 &&
        ((c = !1), (b = f));
    }
    return { url: b, Dr: c };
  }
  function Bq(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Fl(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function Cq() {
    for (var a = w, b = a; a && a != a.parent; )
      ((a = a.parent), Bq(a) && (b = a));
    return b;
  }
  var Dq = function (a, b) {
      var c = function () {};
      c.prototype = a.prototype;
      var d = new c();
      a.apply(d, Array.prototype.slice.call(arguments, 1));
      return d;
    },
    Eq = function (a) {
      var b = a;
      return function () {
        if (b) {
          var c = b;
          b = null;
          c();
        }
      };
    };
  function Fq(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Gq(a) {
    var b = Qa.apply(1, arguments);
    if (b.length === 0) return rc(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return rc(c);
  }
  var Hq = function (a, b) {
      for (var c = a, d = 0; d < 50; ++d) {
        var e;
        try {
          e = !(!c.frames || !c.frames[b]);
        } catch (h) {
          e = !1;
        }
        if (e) return c;
        var f;
        a: {
          try {
            var g = c.parent;
            if (g && g != c) {
              f = g;
              break a;
            }
          } catch (h) {}
          f = null;
        }
        if (!(c = f)) break;
      }
      return null;
    },
    Iq = function (a) {
      var b = w;
      if (b.top == b) return 0;
      if (a === void 0 ? 0 : a) {
        var c = b.location.ancestorOrigins;
        if (c) return c[c.length - 1] == b.location.origin ? 1 : 2;
      }
      return Bq(b.top) ? 1 : 2;
    },
    Jq = function (a, b) {
      b = b === void 0 ? document : b;
      return b.createElement(String(a).toLowerCase());
    };
  function Kq(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function Lq(a, b, c) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, !1), !0)
      : !1;
  }
  function Mq(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function Nq(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = Jq("IMG", a.document);
    if (c) {
      var f = function () {
        if (c) {
          var g = a.google_image_requests,
            h = Nc(g, e);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        Mq(e, "load", f);
        Mq(e, "error", f);
      };
      Lq(e, "load", f);
      Lq(e, "error", f);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function Oq(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    Fq(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    Pq(c, b);
  }
  function Pq(a, b) {
    var c = window,
      d;
    b = b === void 0 ? !1 : b;
    d = d === void 0 ? !1 : d;
    if (c.fetch) {
      var e = {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors",
      };
      d &&
        ((e.mode = "cors"),
        "setAttributionReporting" in XMLHttpRequest.prototype
          ? (e.attributionReporting = {
              eventSourceEligible: "true",
              triggerEligible: "false",
            })
          : (e.headers = { "Attribution-Reporting-Eligible": "event-source" }));
      c.fetch(a, e);
    } else Nq(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d);
  }
  var Qq = function () {
    this.fa = this.fa;
    this.T = this.T;
  };
  Qq.prototype.fa = !1;
  Qq.prototype.dispose = function () {
    this.fa || ((this.fa = !0), this.N());
  };
  Qq.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  Qq.prototype.addOnDisposeCallback = function (a, b) {
    this.fa
      ? b !== void 0
        ? a.call(b)
        : a()
      : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a));
  };
  Qq.prototype.N = function () {
    if (this.T) for (; this.T.length; ) this.T.shift()();
  };
  function Rq(a) {
    a.addtlConsent !== void 0 &&
      typeof a.addtlConsent !== "string" &&
      (a.addtlConsent = void 0);
    a.gdprApplies !== void 0 &&
      typeof a.gdprApplies !== "boolean" &&
      (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && typeof a.tcString !== "string") ||
      (a.listenerId !== void 0 && typeof a.listenerId !== "number")
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
        ? 0
        : 3;
  }
  var Sq = function (a, b) {
    b = b === void 0 ? {} : b;
    Qq.call(this);
    this.D = null;
    this.ma = {};
    this.Sa = 0;
    this.V = null;
    this.J = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.nj = (d = b.nj) != null ? d : !1;
  };
  xa(Sq, Qq);
  Sq.prototype.N = function () {
    this.ma = {};
    this.V && (Mq(this.J, "message", this.V), delete this.V);
    delete this.ma;
    delete this.J;
    delete this.D;
    Qq.prototype.N.call(this);
  };
  var Uq = function (a) {
    return typeof a.J.__tcfapi === "function" || Tq(a) != null;
  };
  Sq.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.nj },
      d = Eq(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = Rq(c)),
          (c.internalBlockOnErrors = b.nj),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      Vq(this, "addEventListener", f);
    } catch (g) {
      ((c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d());
    }
  };
  Sq.prototype.removeEventListener = function (a) {
    a && a.listenerId && Vq(this, "removeEventListener", null, a.listenerId);
  };
  var Xq = function (a, b, c) {
      var d;
      d = d === void 0 ? "755" : d;
      var e;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var f = a.publisher.restrictions[b];
          if (f !== void 0) {
            e = f[d === void 0 ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      var g = e;
      if (g === 0) return !1;
      var h = c;
      c === 2
        ? ((h = 0), g === 2 && (h = 1))
        : c === 3 && ((h = 1), g === 1 && (h = 0));
      var l;
      if (h === 0)
        if (a.purpose && a.vendor) {
          var n = Wq(a.vendor.consents, d === void 0 ? "755" : d);
          l =
            n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH"
              ? !0
              : n && Wq(a.purpose.consents, b);
        } else l = !0;
      else
        l =
          h === 1
            ? a.purpose && a.vendor
              ? Wq(a.purpose.legitimateInterests, b) &&
                Wq(a.vendor.legitimateInterests, d === void 0 ? "755" : d)
              : !0
            : !0;
      return l;
    },
    Wq = function (a, b) {
      return !(!a || !a[b]);
    },
    Vq = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.J;
      if (typeof e.__tcfapi === "function") {
        var f = e.__tcfapi;
        f(b, 2, c, d);
      } else if (Tq(a)) {
        Yq(a);
        var g = ++a.Sa;
        a.ma[g] = c;
        if (a.D) {
          var h = {};
          a.D.postMessage(
            ((h.__tcfapiCall = {
              command: b,
              version: 2,
              callId: g,
              parameter: d,
            }),
            h),
            "*",
          );
        }
      } else c({}, !1);
    },
    Tq = function (a) {
      if (a.D) return a.D;
      a.D = Hq(a.J, "__tcfapiLocator");
      return a.D;
    },
    Yq = function (a) {
      if (!a.V) {
        var b = function (c) {
          try {
            var d;
            d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data)
              .__tcfapiReturn;
            a.ma[d.callId](d.returnValue, d.success);
          } catch (e) {}
        };
        a.V = b;
        Lq(a.J, "message", b);
      }
    },
    Zq = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = Rq(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Oq({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus !== "loaded" ||
            (a.eventStatus !== "tcloaded" &&
              a.eventStatus !== "useractioncomplete")
          ? !1
          : !0;
    };
  var $q = { 1: 0, 3: 0, 4: 0, 7: 3, 9: 3, 10: 3 };
  Ag(32, 500);
  function ar() {
    return xo("tcf", function () {
      return {};
    });
  }
  var br = function () {
    return new Sq(w, { timeoutMs: -1 });
  };
  function cr() {
    var a = ar(),
      b = br();
    Uq(b) && !dr() && !er() && O(124);
    if (!a.active && Uq(b)) {
      dr() &&
        ((a.active = !0),
        (a.purposes = {}),
        (a.cmpId = 0),
        (a.tcfPolicyVersion = 0),
        (cm().active = !0),
        (a.tcString = "tcunavailable"));
      so();
      try {
        b.addEventListener(function (c) {
          if (c.internalErrorState !== 0)
            (fr(a), to([J.m.X, J.m.Ka, J.m.Z]), (cm().active = !0));
          else if (
            ((a.gdprApplies = c.gdprApplies),
            (a.cmpId = c.cmpId),
            (a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode),
            er() && (a.active = !0),
            !gr(c) || dr() || er())
          ) {
            a.tcfPolicyVersion = c.tcfPolicyVersion;
            var d;
            if (c.gdprApplies === !1) {
              var e = {},
                f;
              for (f in $q) $q.hasOwnProperty(f) && (e[f] = !0);
              d = e;
              b.removeEventListener(c);
            } else if (gr(c)) {
              var g = {},
                h;
              for (h in $q)
                if ($q.hasOwnProperty(h))
                  if (h === "1") {
                    var l,
                      n = c,
                      p = { Xq: !0 };
                    p = p === void 0 ? {} : p;
                    l = Zq(n)
                      ? n.gdprApplies === !1
                        ? !0
                        : n.tcString === "tcunavailable"
                          ? !p.idpcApplies
                          : (p.idpcApplies ||
                                n.gdprApplies !== void 0 ||
                                p.Xq) &&
                              (p.idpcApplies ||
                                (typeof n.tcString === "string" &&
                                  n.tcString.length))
                            ? Xq(n, "1", 0)
                            : !0
                      : !1;
                    g["1"] = l;
                  } else g[h] = Xq(c, h, $q[h]);
              d = g;
            }
            if (d) {
              a.tcString = c.tcString || "tcempty";
              a.purposes = d;
              var q = {},
                r = ((q[J.m.X] = a.purposes["1"] ? "granted" : "denied"), q);
              a.gdprApplies !== !0
                ? (to([J.m.X, J.m.Ka, J.m.Z]), (cm().active = !0))
                : ((r[J.m.Ka] =
                    a.purposes["3"] && a.purposes["4"] ? "granted" : "denied"),
                  typeof a.tcfPolicyVersion === "number" &&
                  a.tcfPolicyVersion >= 4
                    ? (r[J.m.Z] =
                        a.purposes["1"] && a.purposes["7"]
                          ? "granted"
                          : "denied")
                    : to([J.m.Z]),
                  ko(
                    r,
                    { eventId: 0 },
                    {
                      gdprApplies: a ? a.gdprApplies : void 0,
                      tcString: hr() || "",
                    },
                  ));
            }
          } else to([J.m.X, J.m.Ka, J.m.Z]);
        });
      } catch (c) {
        (fr(a), to([J.m.X, J.m.Ka, J.m.Z]), (cm().active = !0));
      }
    }
  }
  function fr(a) {
    a.type = "e";
    a.tcString = "tcunavailable";
  }
  function gr(a) {
    return (
      a.eventStatus === "tcloaded" ||
      a.eventStatus === "useractioncomplete" ||
      a.eventStatus === "cmpuishown"
    );
  }
  function dr() {
    return w.gtag_enable_tcf_support === !0;
  }
  function er() {
    return ar().enableAdvertiserConsentMode === !0;
  }
  function hr() {
    var a = ar();
    if (a.active) return a.tcString;
  }
  function ir() {
    var a = ar();
    if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0";
  }
  function jr(a) {
    if (!$q.hasOwnProperty(String(a))) return !0;
    var b = ar();
    return b.active && b.purposes ? !!b.purposes[String(a)] : !0;
  }
  var kr = [J.m.X, J.m.la, J.m.Z, J.m.Ka],
    lr = {},
    mr = ((lr[J.m.X] = 1), (lr[J.m.la] = 2), lr);
  function nr(a) {
    if (a === void 0) return 0;
    switch (M(a, J.m.Rb)) {
      case void 0:
        return 1;
      case !1:
        return 3;
      default:
        return 2;
    }
  }
  function or() {
    return (
      (N(183) ? yg(16).split("~") : yg(17).split("~")).indexOf(ln()) !== -1 &&
      Rc.globalPrivacyControl === !0
    );
  }
  function pr(a) {
    if (or()) return !1;
    var b = nr(a);
    if (b === 3) return !1;
    switch (lm(J.m.Ka)) {
      case 1:
      case 3:
        return !0;
      case 2:
        return !1;
      case 4:
        return b === 2;
      case 0:
        return !0;
      default:
        return !1;
    }
  }
  function qr() {
    return nm() || !km(J.m.X) || !km(J.m.la);
  }
  function rr() {
    var a = {},
      b;
    for (b in mr) mr.hasOwnProperty(b) && (a[mr[b]] = lm(b));
    return "G1" + Af(a[1] || 0) + Af(a[2] || 0);
  }
  var sr = {},
    tr =
      ((sr[J.m.X] = 0),
      (sr[J.m.la] = 1),
      (sr[J.m.Z] = 2),
      (sr[J.m.Ka] = 3),
      sr);
  function ur(a) {
    switch (a) {
      case void 0:
        return 1;
      case !0:
        return 3;
      case !1:
        return 2;
      default:
        return 0;
    }
  }
  function vr(a) {
    for (var b = "1", c = 0; c < kr.length; c++) {
      var d = b,
        e,
        f = kr[c],
        g = jm.delegatedConsentTypes[f];
      e = g === void 0 ? 0 : tr.hasOwnProperty(g) ? 12 | tr[g] : 8;
      var h = cm();
      h.accessedAny = !0;
      var l = h.entries[f] || {};
      e = (e << 2) | ur(l.implicit);
      b =
        d +
        ("" +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            e
          ] +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            (ur(l.declare) << 4) | (ur(l.default) << 2) | ur(l.update)
          ]);
    }
    var n = b,
      p = (or() ? 1 : 0) << 3,
      q = (nm() ? 1 : 0) << 2,
      r = nr(a);
    b =
      n +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        p | q | r
      ];
    return (b +=
      "" +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (jm.containerScopedDefaults.ad_storage << 4) |
          (jm.containerScopedDefaults.analytics_storage << 2) |
          jm.containerScopedDefaults.ad_user_data
      ] +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        ((jm.usedContainerScopedDefaults ? 1 : 0) << 2) |
          jm.containerScopedDefaults.ad_personalization
      ]);
  }
  function wr() {
    if (!km(J.m.Z)) return "-";
    if (N(170)) return "a";
    for (
      var a = Object.keys(Dn), b = {}, c = m(a), d = c.next();
      !d.done;
      d = c.next()
    ) {
      var e = d.value;
      b[e] = jm.corePlatformServices[e] !== !1;
    }
    for (var f = "", g = m(a), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      b[l] && (f += Dn[l]);
    }
    (jm.usedCorePlatformServices ? jm.selectedAllCorePlatformServices : 1) &&
      (f += "o");
    return f || "-";
  }
  function xr() {
    return nn() || ((dr() || er()) && ir() === "1") ? "1" : "0";
  }
  function yr() {
    return (nn() ? !0 : !(!dr() && !er()) && ir() === "1") || !km(J.m.Z);
  }
  function zr() {
    var a = "0",
      b = "0",
      c;
    var d = ar();
    c = d.active ? d.cmpId : void 0;
    typeof c === "number" &&
      c >= 0 &&
      c <= 4095 &&
      ((a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (c >> 6) & 63
      ]),
      (b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        c & 63
      ]));
    var e = "0",
      f;
    var g = ar();
    f = g.active ? g.tcfPolicyVersion : void 0;
    typeof f === "number" &&
      f >= 0 &&
      f <= 63 &&
      (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        f
      ]);
    var h = 0;
    nn() && (h |= 1);
    ir() === "1" && (h |= 2);
    dr() && (h |= 4);
    var l;
    var n = ar();
    l =
      n.enableAdvertiserConsentMode !== void 0
        ? n.enableAdvertiserConsentMode
          ? "1"
          : "0"
        : void 0;
    l === "1" && (h |= 8);
    cm().waitPeriodTimedOut && (h |= 16);
    return (
      "1" +
      a +
      b +
      e +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]
    );
  }
  function Ar() {
    return ln() === "US-CO";
  }
  function Br(a, b, c, d) {
    var e,
      f = Number(a.bd != null ? a.bd : void 0);
    f !== 0 && (e = new Date((b || Tb()) + 1e3 * (f || 7776e3)));
    return {
      path: a.path,
      domain: a.domain,
      flags: a.flags,
      encode: !!c,
      expires: e,
      Ec: d,
    };
  }
  var Cr = ["ad_storage", "ad_user_data"];
  function Dr(a, b) {
    if (!a) return (yb("TAGGING", 32), 10);
    if (b === null || b === void 0 || b === "") return (yb("TAGGING", 33), 11);
    var c = Er(!1);
    if (c.error !== 0) return (yb("TAGGING", 34), c.error);
    if (!c.value) return (yb("TAGGING", 35), 2);
    c.value[a] = b;
    var d = Fr(c);
    d !== 0 && yb("TAGGING", 36);
    return d;
  }
  function Gr(a) {
    if (!a) return (yb("TAGGING", 27), { error: 10 });
    var b = Er();
    if (b.error !== 0) return (yb("TAGGING", 29), b);
    if (!b.value) return (yb("TAGGING", 30), { error: 2 });
    if (!(a in b.value))
      return (yb("TAGGING", 31), { value: void 0, error: 15 });
    var c = b.value[a];
    return c === null || c === void 0 || c === ""
      ? (yb("TAGGING", 28), { value: void 0, error: 11 })
      : { value: c, error: 0 };
  }
  function Er(a) {
    a = a === void 0 ? !0 : a;
    if (!km(Cr)) return (yb("TAGGING", 43), { error: 3 });
    try {
      if (!w.localStorage) return (yb("TAGGING", 44), { error: 1 });
    } catch (f) {
      return (yb("TAGGING", 45), { error: 14 });
    }
    var b = { schema: "gcl", version: 1 },
      c = void 0;
    try {
      c = w.localStorage.getItem("_gcl_ls");
    } catch (f) {
      return (yb("TAGGING", 46), { error: 13 });
    }
    try {
      if (c) {
        var d = JSON.parse(c);
        if (d && typeof d === "object") b = d;
        else return (yb("TAGGING", 47), { error: 12 });
      }
    } catch (f) {
      return (yb("TAGGING", 48), { error: 8 });
    }
    if (b.schema !== "gcl") return (yb("TAGGING", 49), { error: 4 });
    if (b.version !== 1) return (yb("TAGGING", 50), { error: 5 });
    try {
      var e = Hr(b);
      a && e && Fr({ value: b, error: 0 });
    } catch (f) {
      return (yb("TAGGING", 48), { error: 8 });
    }
    return { value: b, error: 0 };
  }
  function Hr(a) {
    if (!a || typeof a !== "object") return !1;
    if ("expires" in a && "value" in a) {
      var b;
      typeof a.expires === "number"
        ? (b = a.expires)
        : (b = typeof a.expires === "string" ? Number(a.expires) : NaN);
      if (isNaN(b) || !(Date.now() <= b))
        return ((a.value = null), (a.error = 9), yb("TAGGING", 54), !0);
    } else {
      for (
        var c = !1, d = m(Object.keys(a)), e = d.next();
        !e.done;
        e = d.next()
      )
        c = Hr(a[e.value]) || c;
      return c;
    }
    return !1;
  }
  function Fr(a) {
    if (a.error) return a.error;
    if (!a.value) return (yb("TAGGING", 42), 2);
    var b = a.value,
      c;
    try {
      c = JSON.stringify(b);
    } catch (d) {
      return (yb("TAGGING", 52), 6);
    }
    try {
      w.localStorage.setItem("_gcl_ls", c);
    } catch (d) {
      return (yb("TAGGING", 53), 7);
    }
    return 0;
  }
  var Ir = { Eg: "value", ib: "conversionCount", Fg: 1 },
    Jr = { Th: 7, Yh: 8, Eg: "timeouts", ib: "timeouts", Fg: 0 },
    Kr = { Th: 11, Yh: 12, Eg: "eopCount", ib: "endOfPageCount", Fg: 0 },
    Lr = { Th: 9, Yh: 10, Eg: "errors", ib: "errors", Fg: 0 },
    Mr = [Ir, Jr, Lr, Kr];
  function Nr(a) {
    var b;
    b = b === void 0 ? 1 : b;
    if (!Or(a)) return {};
    var c = Pr(Mr),
      d = c[a.ib];
    if (d === void 0 || d === -1) return c;
    var e = {},
      f = oa(Object, "assign").call(Object, {}, c, ((e[a.ib] = d + b), e));
    return Qr(f) ? f : c;
  }
  function Pr(a) {
    var b;
    a: {
      var c = Gr("gcl_ctr");
      if (c.error === 0 && c.value && typeof c.value === "object") {
        var d = c.value;
        try {
          b = "value" in d && typeof d.value === "object" ? d.value : void 0;
          break a;
        } catch (p) {}
      }
      b = void 0;
    }
    for (var e = b, f = {}, g = m(a), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      if (e && Or(l)) {
        var n = e[l.Eg];
        n === void 0 || Number.isNaN(n)
          ? (f[l.ib] = -1)
          : (f[l.ib] = Number(n));
      } else f[l.ib] = -1;
    }
    return f;
  }
  function Qr(a, b) {
    b = b || {};
    for (
      var c = Tb(), d = Br(b, c, !0), e = {}, f = m(Mr), g = f.next();
      !g.done;
      g = f.next()
    ) {
      var h = g.value,
        l = a[h.ib];
      l !== void 0 && l !== -1 && (e[h.Eg] = l);
    }
    e.creationTimeMs = c;
    return Dr("gcl_ctr", { value: e, expires: Number(d.expires) }) === 0
      ? !0
      : !1;
  }
  function Or(a) {
    return km(["ad_storage", "ad_user_data"]) ? !a.Yh || kb(a.Yh) : !1;
  }
  function Rr(a) {
    return km(["ad_storage", "ad_user_data"]) ? !a.Th || kb(a.Th) : !1;
  }
  var Sr = {
    R: {
      gq: 0,
      hk: 1,
      Tg: 2,
      wk: 3,
      ei: 4,
      uk: 5,
      vk: 6,
      xk: 7,
      fi: 8,
      Rl: 9,
      Ql: 10,
      Di: 11,
      Sl: 12,
      yh: 13,
      bm: 14,
      fg: 15,
      bq: 16,
      Pe: 17,
      bj: 18,
      cj: 19,
      dj: 20,
      gn: 21,
      ej: 22,
      hi: 23,
      Gk: 24,
    },
  };
  Sr.R[Sr.R.gq] = "RESERVED_ZERO";
  Sr.R[Sr.R.hk] = "ADS_CONVERSION_HIT";
  Sr.R[Sr.R.Tg] = "CONTAINER_EXECUTE_START";
  Sr.R[Sr.R.wk] = "CONTAINER_SETUP_END";
  Sr.R[Sr.R.ei] = "CONTAINER_SETUP_START";
  Sr.R[Sr.R.uk] = "CONTAINER_BLOCKING_END";
  Sr.R[Sr.R.vk] = "CONTAINER_EXECUTE_END";
  Sr.R[Sr.R.xk] = "CONTAINER_YIELD_END";
  Sr.R[Sr.R.fi] = "CONTAINER_YIELD_START";
  Sr.R[Sr.R.Rl] = "EVENT_EXECUTE_END";
  Sr.R[Sr.R.Ql] = "EVENT_EVALUATION_END";
  Sr.R[Sr.R.Di] = "EVENT_EVALUATION_START";
  Sr.R[Sr.R.Sl] = "EVENT_SETUP_END";
  Sr.R[Sr.R.yh] = "EVENT_SETUP_START";
  Sr.R[Sr.R.bm] = "GA4_CONVERSION_HIT";
  Sr.R[Sr.R.fg] = "PAGE_LOAD";
  Sr.R[Sr.R.bq] = "PAGEVIEW";
  Sr.R[Sr.R.Pe] = "SNIPPET_LOAD";
  Sr.R[Sr.R.bj] = "TAG_CALLBACK_ERROR";
  Sr.R[Sr.R.cj] = "TAG_CALLBACK_FAILURE";
  Sr.R[Sr.R.dj] = "TAG_CALLBACK_SUCCESS";
  Sr.R[Sr.R.gn] = "TAG_EXECUTE_END";
  Sr.R[Sr.R.ej] = "TAG_EXECUTE_START";
  Sr.R[Sr.R.hi] = "CUSTOM_PERFORMANCE_START";
  Sr.R[Sr.R.Gk] = "CUSTOM_PERFORMANCE_END";
  var Tr = [],
    Ur = {},
    Vr = {};
  function Wr(a) {
    if (kb(19) && Tr.includes(a)) {
      var b;
      (b = xd()) == null || b.mark(a + "-" + Sr.R.hi + "-" + (Vr[a] || 0));
    }
  }
  function Xr(a) {
    if (kb(19) && Tr.includes(a)) {
      var b = a + "-" + Sr.R.Gk + "-" + (Vr[a] || 0),
        c = { start: a + "-" + Sr.R.hi + "-" + (Vr[a] || 0), end: b },
        d;
      (d = xd()) == null || d.mark(b);
      var e,
        f,
        g =
          (f = (e = xd()) == null ? void 0 : e.measure(b, c)) == null
            ? void 0
            : f.duration;
      g !== void 0 && ((Vr[a] = (Vr[a] || 0) + 1), (Ur[a] = g + (Ur[a] || 0)));
    }
  }
  var Yr = ["3", "4"];
  function Zr(a) {
    return a.origin !== "null";
  }
  function $r(a, b, c, d) {
    try {
      Wr("3");
      var e;
      return (e = as(
        function (f) {
          return f === a;
        },
        b,
        c,
        d,
      )[a]) != null
        ? e
        : [];
    } finally {
      Xr("3");
    }
  }
  function as(a, b, c, d) {
    var e;
    if (bs(d)) {
      for (
        var f = {}, g = String(b || cs()).split(";"), h = 0;
        h < g.length;
        h++
      ) {
        var l = g[h].split("="),
          n = l[0].trim();
        if (n && a(n)) {
          var p = l.slice(1).join("=").trim();
          p && c && (p = decodeURIComponent(p));
          var q = void 0,
            r = void 0;
          ((q = f)[(r = n)] || (q[r] = [])).push(p);
        }
      }
      e = f;
    } else e = {};
    return e;
  }
  function ds(a, b, c, d, e) {
    if (bs(e)) {
      var f = es(a, d, e);
      if (f.length === 1) return f[0];
      if (f.length !== 0) {
        f = fs(
          f,
          function (g) {
            return g.Nq;
          },
          b,
        );
        if (f.length === 1) return f[0];
        f = fs(
          f,
          function (g) {
            return g.Or;
          },
          c,
        );
        return f[0];
      }
    }
  }
  function gs(a, b, c, d) {
    var e = cs(),
      f = window;
    Zr(f) && (f.document.cookie = a);
    var g = cs();
    return e !== g || (c !== void 0 && $r(b, g, !1, d).indexOf(c) >= 0);
  }
  function hs(a, b, c, d) {
    function e(x, y, z) {
      if (z == null) return (delete h[y], x);
      h[y] = z;
      return x + "; " + y + "=" + z;
    }
    function f(x, y) {
      if (y == null) return x;
      h[y] = !0;
      return x + "; " + y;
    }
    if (!bs(c.Ec)) return 2;
    var g;
    b == null
      ? (g = a + "=deleted; expires=" + new Date(0).toUTCString())
      : (c.encode && (b = encodeURIComponent(b)),
        (b = is(b)),
        (g = a + "=" + b));
    var h = {};
    g = e(g, "path", c.path);
    var l;
    c.expires instanceof Date
      ? (l = c.expires.toUTCString())
      : c.expires != null && (l = "" + c.expires);
    g = e(g, "expires", l);
    g = e(g, "max-age", c.Jr);
    g = e(g, "samesite", c.ds);
    c.secure && (g = f(g, "secure"));
    var n = c.domain;
    if (n && n.toLowerCase() === "auto") {
      for (var p = js(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
        var u = p[t] !== "none" ? p[t] : void 0,
          v = e(g, "domain", u);
        v = f(v, c.flags);
        try {
          d && d(a, h);
        } catch (x) {
          q = x;
          continue;
        }
        r = !0;
        if (!ks(u, c.path) && gs(v, a, b, c.Ec)) return 0;
      }
      if (q && !r) throw q;
      return 1;
    }
    n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
    g = f(g, c.flags);
    d && d(a, h);
    return ks(n, c.path) ? 1 : gs(g, a, b, c.Ec) ? 0 : 1;
  }
  function ls(a, b, c) {
    c.path == null && (c.path = "/");
    c.domain || (c.domain = "auto");
    Wr("2");
    var d = hs(a, b, c);
    Xr("2");
    return d;
  }
  function fs(a, b, c) {
    for (var d = [], e = [], f, g = 0; g < a.length; g++) {
      var h = a[g],
        l = b(h);
      l === c
        ? d.push(h)
        : f === void 0 || l < f
          ? ((e = [h]), (f = l))
          : l === f && e.push(h);
    }
    return d.length > 0 ? d : e;
  }
  function es(a, b, c) {
    for (var d = [], e = $r(a, void 0, void 0, c), f = 0; f < e.length; f++) {
      var g = e[f].split("."),
        h = g.shift();
      if (!b || !h || b.indexOf(h) !== -1) {
        var l = g.shift();
        if (l) {
          var n = l.split("-");
          d.push({
            Fq: e[f],
            Gq: g.join("."),
            Nq: Number(n[0]) || 1,
            Or: Number(n[1]) || 1,
          });
        }
      }
    }
    return d;
  }
  function is(a) {
    a && a.length > 1200 && (a = a.substring(0, 1200));
    return a;
  }
  var ms = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    ns = /(^|\.)doubleclick\.net$/i;
  function ks(a, b) {
    return (
      a !== void 0 &&
      (ns.test(window.document.location.hostname) || (b === "/" && ms.test(a)))
    );
  }
  function os(a) {
    if (!a) return 1;
    var b = a;
    kb(5) && a === "none" && (b = window.document.location.hostname);
    b = b.indexOf(".") === 0 ? b.substring(1) : b;
    return b.split(".").length;
  }
  function ps(a) {
    if (!a || a === "/") return 1;
    a[0] !== "/" && (a = "/" + a);
    a[a.length - 1] !== "/" && (a += "/");
    return a.split("/").length - 1;
  }
  function qs(a, b) {
    var c = "" + os(a),
      d = ps(b);
    d > 1 && (c += "-" + d);
    return c;
  }
  var cs = function () {
      return Zr(window) ? window.document.cookie : "";
    },
    bs = function (a) {
      return a && kb(6)
        ? (Array.isArray(a) ? a : [a]).every(function (b) {
            return mm(b) && km(b);
          })
        : !0;
    },
    js = function () {
      var a = [],
        b = window.document.location.hostname.split(".");
      if (b.length === 4) {
        var c = b[b.length - 1];
        if (Number(c).toString() === c) return ["none"];
      }
      for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
      var e = window.document.location.hostname;
      ns.test(e) || ms.test(e) || a.push("none");
      return a;
    };
  function rs(a) {
    var b = Math.round(Math.random() * 2147483647);
    return a ? String(b ^ (li(a) & 2147483647)) : String(b);
  }
  function ss(a) {
    return [rs(a), Math.round(Tb() / 1e3)].join(".");
  }
  function ts(a, b, c, d, e) {
    var f = os(b),
      g;
    return (g = ds(a, f, ps(c), d, e)) == null ? void 0 : g.Gq;
  }
  var us;
  function vs() {
    function a(g) {
      c(g.target || g.srcElement || {});
    }
    function b(g) {
      d(g.target || g.srcElement || {});
    }
    var c = ws,
      d = xs,
      e = ys();
    if (!e.init) {
      hd(A, "mousedown", a);
      hd(A, "keyup", a);
      hd(A, "submit", b);
      var f = HTMLFormElement.prototype.submit;
      HTMLFormElement.prototype.submit = function () {
        d(this);
        f.call(this);
      };
      e.init = !0;
    }
  }
  function zs(a, b, c, d, e) {
    var f = {
      callback: a,
      domains: b,
      fragment: c === 2,
      placement: c,
      forms: d,
      sameHost: e,
    };
    ys().decorators.push(f);
  }
  function As(a, b, c) {
    for (var d = ys().decorators, e = {}, f = 0; f < d.length; ++f) {
      var g = d[f],
        h;
      if ((h = !c || g.forms))
        a: {
          var l = g.domains,
            n = a,
            p = !!g.sameHost;
          if (l && (p || n !== A.location.hostname))
            for (var q = 0; q < l.length; q++)
              if (l[q] instanceof RegExp) {
                if (l[q].test(n)) {
                  h = !0;
                  break a;
                }
              } else if (n.indexOf(l[q]) >= 0 || (p && l[q].indexOf(n) >= 0)) {
                h = !0;
                break a;
              }
          h = !1;
        }
      if (h) {
        var r = g.placement;
        r === void 0 && (r = g.fragment ? 2 : 1);
        r === b && Wb(e, g.callback());
      }
    }
    return e;
  }
  function ys() {
    var a = Vc("google_tag_data", {}),
      b = a.gl;
    (b && b.decorators) || ((b = { decorators: [] }), (a.gl = b));
    return b;
  }
  var Bs = /(.*?)\*(.*?)\*(.*)/,
    Cs = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
    Ds = /^(?:www\.|m\.|amp\.)+/,
    Es = /([^?#]+)(\?[^#]*)?(#.*)?/;
  function Fs(a) {
    var b = Es.exec(a);
    if (b) return { Qj: b[1], query: b[2], fragment: b[3] };
  }
  function Gs(a) {
    return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)");
  }
  function Hs(a, b) {
    var c = [
        Rc.userAgent,
        new Date().getTimezoneOffset(),
        Rc.userLanguage || Rc.language,
        Math.floor(Tb() / 60 / 1e3) - (b === void 0 ? 0 : b),
        a,
      ].join("*"),
      d;
    if (!(d = us)) {
      for (var e = Array(256), f = 0; f < 256; f++) {
        for (var g = f, h = 0; h < 8; h++)
          g = g & 1 ? (g >>> 1) ^ 3988292384 : g >>> 1;
        e[f] = g;
      }
      d = e;
    }
    us = d;
    for (var l = 4294967295, n = 0; n < c.length; n++)
      l = (l >>> 8) ^ us[(l ^ c.charCodeAt(n)) & 255];
    return ((l ^ -1) >>> 0).toString(36);
  }
  function Is(a) {
    return function (b) {
      var c = Pj(w.location.href),
        d = c.search.replace("?", ""),
        e = Gj(d, "_gl", !1, !0) || "";
      b.query = Js(e) || {};
      var f = Jj(c, "fragment"),
        g;
      var h = -1;
      if (Yb(f, "_gl=")) h = 4;
      else {
        var l = f.indexOf("&_gl=");
        l > 0 && (h = l + 3 + 2);
      }
      if (h < 0) g = void 0;
      else {
        var n = f.indexOf("&", h);
        g = n < 0 ? f.substring(h) : f.substring(h, n);
      }
      b.fragment = Js(g || "") || {};
      a && Ks(c, d, f);
    };
  }
  function Ls(a, b) {
    var c = Gs(a).exec(b),
      d = b;
    if (c) {
      var e = c[2],
        f = c[4];
      d = c[1];
      f && (d = d + e + f);
    }
    return d;
  }
  function Ks(a, b, c) {
    function d(g, h) {
      var l = Ls("_gl", g);
      l.length && (l = h + l);
      return l;
    }
    if (Qc && Qc.replaceState) {
      var e = Gs("_gl");
      if (e.test(b) || e.test(c)) {
        var f = Jj(a, "path");
        b = d(b, "?");
        c = d(c, "#");
        Qc.replaceState({}, "", "" + f + b + c);
      }
    }
  }
  function Ms(a, b) {
    var c = Is(!!b),
      d = ys();
    d.data || ((d.data = { query: {}, fragment: {} }), c(d.data));
    var e = {},
      f = d.data;
    f && (Wb(e, f.query), a && Wb(e, f.fragment));
    return e;
  }
  var Js = function (a) {
    try {
      var b = Ns(a, 3);
      if (b !== void 0) {
        for (
          var c = {}, d = b ? b.split("*") : [], e = 0;
          e + 1 < d.length;
          e += 2
        ) {
          var f = d[e],
            g = wb(d[e + 1]);
          c[f] = g;
        }
        yb("TAGGING", 6);
        return c;
      }
    } catch (h) {
      yb("TAGGING", 8);
    }
  };
  function Ns(a, b) {
    if (a) {
      var c;
      a: {
        for (var d = a, e = 0; e < 3; ++e) {
          var f = Bs.exec(d);
          if (f) {
            c = f;
            break a;
          }
          d = Ij(d) || "";
        }
        c = void 0;
      }
      var g = c;
      if (g && g[1] === "1") {
        var h = g[3],
          l;
        a: {
          for (var n = g[2], p = 0; p < b; ++p)
            if (n === Hs(h, p)) {
              l = !0;
              break a;
            }
          l = !1;
        }
        if (l) return h;
        yb("TAGGING", 7);
      }
    }
  }
  function Os(a, b, c, d, e) {
    function f(p) {
      p = Ls(a, p);
      var q = p.charAt(p.length - 1);
      p && q !== "&" && (p += "&");
      return p + n;
    }
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var g = Fs(c);
    if (!g) return "";
    var h = g.query || "",
      l = g.fragment || "",
      n = a + "=" + b;
    d
      ? (l.substring(1).length !== 0 && e) || (l = "#" + f(l.substring(1)))
      : (h = "?" + f(h.substring(1)));
    return "" + g.Qj + h + l;
  }
  function Ps(a, b) {
    function c(n, p, q) {
      var r;
      a: {
        for (var t in n)
          if (n.hasOwnProperty(t)) {
            r = !0;
            break a;
          }
        r = !1;
      }
      if (r) {
        var u,
          v = [],
          x;
        for (x in n)
          if (n.hasOwnProperty(x)) {
            var y = n[x];
            y !== void 0 &&
              y === y &&
              y !== null &&
              y.toString() !== "[object Object]" &&
              (v.push(x), v.push(vb(String(y))));
          }
        var z = v.join("*");
        u = ["1", Hs(z), z].join("*");
        d
          ? (kb(3) || kb(1) || !p) && Qs("_gl", u, a, p, q)
          : Rs("_gl", u, a, p, q);
      }
    }
    var d = (a.tagName || "").toUpperCase() === "FORM",
      e = As(b, 1, d),
      f = As(b, 2, d),
      g = As(b, 4, d),
      h = As(b, 3, d);
    c(e, !1, !1);
    c(f, !0, !1);
    kb(1) && c(g, !0, !0);
    for (var l in h) h.hasOwnProperty(l) && Ss(l, h[l], a);
  }
  function Ss(a, b, c) {
    c.tagName.toLowerCase() === "a"
      ? Rs(a, b, c)
      : c.tagName.toLowerCase() === "form" && Qs(a, b, c);
  }
  function Rs(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var f;
    if ((f = c.href)) {
      var g;
      if (!(g = !kb(4) || d)) {
        var h = w.location.href,
          l = Fs(c.href),
          n = Fs(h);
        g = !(l && n && l.Qj === n.Qj && l.query === n.query && l.fragment);
      }
      f = g;
    }
    if (f) {
      var p = Os(a, b, c.href, d, e);
      Dc.test(p) && (c.href = p);
    }
  }
  function Qs(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    if (c) {
      var f = c.getAttribute("action") || "";
      if (f) {
        var g = (c.method || "").toLowerCase();
        if (g !== "get" || d) {
          if (g === "get" || g === "post") {
            var h = Os(a, b, f, d, e);
            Dc.test(h) && (c.action = h);
          }
        } else {
          for (var l = c.childNodes || [], n = !1, p = 0; p < l.length; p++) {
            var q = l[p];
            if (q.name === a) {
              q.setAttribute("value", b);
              n = !0;
              break;
            }
          }
          if (!n) {
            var r = A.createElement("input");
            r.setAttribute("type", "hidden");
            r.setAttribute("name", a);
            r.setAttribute("value", b);
            c.appendChild(r);
          }
        }
      }
    }
  }
  function ws(a) {
    try {
      var b;
      a: {
        for (var c = a, d = 100; c && d > 0; ) {
          if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
            b = c;
            break a;
          }
          c = c.parentNode;
          d--;
        }
        b = null;
      }
      var e = b;
      if (e) {
        var f = e.protocol;
        (f !== "http:" && f !== "https:") || Ps(e, e.hostname);
      }
    } catch (g) {}
  }
  function xs(a) {
    try {
      var b = a.getAttribute("action");
      if (b) {
        var c = Jj(Pj(b), "host");
        Ps(a, c);
      }
    } catch (d) {}
  }
  function Ts(a, b, c, d) {
    vs();
    var e = c === "fragment" ? 2 : 1;
    d = !!d;
    zs(a, b, e, d, !1);
    e === 2 && yb("TAGGING", 23);
    d && yb("TAGGING", 24);
  }
  function Us(a, b) {
    vs();
    zs(a, [Lj(w.location, "host", !0)], b, !0, !0);
  }
  function Vs() {
    var a = A.location.hostname,
      b = Cs.exec(A.referrer);
    if (!b) return !1;
    var c = b[2],
      d = b[1],
      e = "";
    if (c) {
      var f = c.split("/"),
        g = f[1];
      e = g === "s" ? Ij(f[2]) || "" : Ij(g) || "";
    } else if (d) {
      if (d.indexOf("xn--") === 0) return !1;
      e = d.replace(/-/g, ".").replace(/\.\./g, "-");
    }
    var h = a.replace(Ds, ""),
      l = e.replace(Ds, "");
    return h === l || ac(h, "." + l);
  }
  function Ws(a, b) {
    return a === !1 ? !1 : a || b || Vs();
  }
  var Xs = ["1"],
    Ys = {},
    Zs = {};
  function $s(a, b) {
    b = b === void 0 ? !0 : b;
    var c = at(a.prefix);
    if (Ys[c]) bt(a);
    else if (ct(c, a.path, a.domain)) {
      var d = Zs[at(a.prefix)] || { id: void 0, Vh: void 0 };
      b && dt(a, d.id, d.Vh);
      bt(a);
    } else {
      var e = Rj("auiddc");
      if (e) (yb("TAGGING", 17), (Ys[c] = e));
      else if (b) {
        var f = at(a.prefix),
          g = ss();
        et(f, g, a);
        ct(c, a.path, a.domain);
        bt(a, !0);
      }
    }
  }
  function bt(a, b) {
    if ((b === void 0 ? 0 : b) && Or(Ir)) {
      var c = Er(!1);
      c.error !== 0
        ? yb("TAGGING", 38)
        : c.value
          ? "gcl_ctr" in c.value
            ? (delete c.value.gcl_ctr, Fr(c) !== 0 && yb("TAGGING", 41))
            : yb("TAGGING", 40)
          : yb("TAGGING", 39);
    }
    if (Rr(Ir) && Pr([Ir])[Ir.ib] === -1) {
      for (
        var d = {}, e = ((d[Ir.ib] = 0), d), f = m(Mr), g = f.next();
        !g.done;
        g = f.next()
      ) {
        var h = g.value;
        h !== Ir && Rr(h) && (e[h.ib] = 0);
      }
      Qr(e, a);
    }
  }
  function dt(a, b, c) {
    var d = at(a.prefix),
      e = Ys[d];
    if (e) {
      var f = e.split(".");
      if (f.length === 2) {
        var g = Number(f[1]) || 0;
        if (g) {
          var h = e;
          b && (h = e + "." + b + "." + (c ? c : Math.floor(Tb() / 1e3)));
          et(d, h, a, g * 1e3);
        }
      }
    }
  }
  function et(a, b, c, d) {
    var e;
    e = ["1", qs(c.domain, c.path), b].join(".");
    var f = Br(c, d);
    f.Ec = ft();
    ls(a, e, f);
  }
  function ct(a, b, c) {
    var d = ts(a, b, c, Xs, ft());
    if (!d) return !1;
    gt(a, d);
    return !0;
  }
  function gt(a, b) {
    var c = b.split(".");
    c.length === 5
      ? ((Ys[a] = c.slice(0, 2).join(".")),
        (Zs[a] = { id: c.slice(2, 4).join("."), Vh: Number(c[4]) || 0 }))
      : c.length === 3
        ? (Zs[a] = { id: c.slice(0, 2).join("."), Vh: Number(c[2]) || 0 })
        : (Ys[a] = b);
  }
  function at(a) {
    return (a || "_gcl") + "_au";
  }
  function ht(a) {
    function b() {
      km(c) && a();
    }
    var c = ft();
    qm(function () {
      b();
      km(c) || rm(b, c);
    }, c);
  }
  function it(a) {
    var b = Ms(!0),
      c = at(a.prefix);
    ht(function () {
      var d = b[c];
      if (d) {
        gt(c, d);
        var e = Number(Ys[c].split(".")[1]) * 1e3;
        if (e) {
          yb("TAGGING", 16);
          var f = Br(a, e);
          f.Ec = ft();
          var g = ["1", qs(a.domain, a.path), d].join(".");
          ls(c, g, f);
        }
      }
    });
  }
  function jt(a, b, c, d, e) {
    e = e || {};
    var f = function () {
      var g = {},
        h = ts(a, e.path, e.domain, Xs, ft());
      h && (g[a] = h);
      return g;
    };
    ht(function () {
      Ts(f, b, c, d);
    });
  }
  function ft() {
    return ["ad_storage", "ad_user_data"];
  }
  function kt(a) {
    for (
      var b = [],
        c = A.cookie.split(";"),
        d = new RegExp(
          "^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$",
        ),
        e = 0;
      e < c.length;
      e++
    ) {
      var f = c[e].match(d);
      f &&
        b.push({
          ce: f[1],
          value: f[2],
          timestamp: Number(f[2].split(".")[1]) || 0,
        });
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return b;
  }
  function lt(a, b) {
    var c = kt(a),
      d = {};
    if (!c || !c.length) return d;
    for (var e = 0; e < c.length; e++) {
      var f = c[e].value.split(".");
      if (
        !(f[0] !== "1" || (b && f.length < 3) || (!b && f.length !== 3)) &&
        Number(f[1])
      ) {
        d[c[e].ce] || (d[c[e].ce] = []);
        var g = { version: f[0], timestamp: Number(f[1]) * 1e3, gclid: f[2] };
        b && f.length > 3 && (g.labels = f.slice(3));
        d[c[e].ce].push(g);
      }
    }
    return d;
  }
  var mt = {},
    nt =
      ((mt.k = { ja: /^[\w-]+$/ }),
      (mt.b = { ja: /^[\w-]+$/, Tj: !0 }),
      (mt.i = { ja: /^[1-9]\d*$/ }),
      (mt.h = { ja: /^\d+$/ }),
      (mt.t = { ja: /^[1-9]\d*$/ }),
      (mt.d = { ja: /^[A-Za-z0-9_-]+$/ }),
      (mt.j = { ja: /^\d+$/ }),
      (mt.u = { ja: /^[1-9]\d*$/ }),
      (mt.l = { ja: /^[01]$/ }),
      (mt.o = { ja: /^[1-9]\d*$/ }),
      (mt.g = { ja: /^[01]$/ }),
      (mt.s = { ja: /^.+$/ }),
      mt);
  var ot = {},
    st =
      ((ot[5] = { ai: { 2: pt }, Jj: "2", Mh: ["k", "i", "b", "u"] }),
      (ot[4] = { ai: { 2: pt, GCL: qt }, Jj: "2", Mh: ["k", "i", "b"] }),
      (ot[2] = {
        ai: { GS2: pt, GS1: rt },
        Jj: "GS2",
        Mh: "sogtjlhd".split(""),
      }),
      ot);
  function tt(a, b, c) {
    var d = st[b];
    if (d) {
      var e = a.split(".")[0];
      c == null || c(e);
      if (e) {
        var f = d.ai[e];
        if (f) return f(a, b);
      }
    }
  }
  function pt(a, b) {
    var c = a.split(".");
    if (c.length === 3) {
      var d = c[2];
      if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1)
        try {
          d = decodeURIComponent(d);
        } catch (t) {}
      var e = {},
        f = st[b];
      if (f) {
        for (
          var g = f.Mh, h = m(d.split("$")), l = h.next();
          !l.done;
          l = h.next()
        ) {
          var n = l.value,
            p = n[0];
          if (g.indexOf(p) !== -1)
            try {
              var q = decodeURIComponent(n.substring(1)),
                r = nt[p];
              r && (r.Tj ? ((e[p] = e[p] || []), e[p].push(q)) : (e[p] = q));
            } catch (t) {}
        }
        return e;
      }
    }
  }
  function ut(a, b, c) {
    var d = st[b];
    if (d) return [d.Jj, c || "1", vt(a, b)].join(".");
  }
  function vt(a, b) {
    var c = st[b];
    if (c) {
      for (var d = [], e = m(c.Mh), f = e.next(); !f.done; f = e.next()) {
        var g = f.value,
          h = nt[g];
        if (h) {
          var l = a[g];
          if (l !== void 0)
            if (h.Tj && Array.isArray(l))
              for (var n = m(l), p = n.next(); !p.done; p = n.next())
                d.push(encodeURIComponent("" + g + p.value));
            else d.push(encodeURIComponent("" + g + l));
        }
      }
      return d.join("$");
    }
  }
  function qt(a) {
    var b = a.split(".");
    b.shift();
    var c = b.shift(),
      d = b.shift(),
      e = {};
    return ((e.k = d), (e.i = c), (e.b = b), e);
  }
  function rt(a) {
    var b = a.split(".").slice(2);
    if (!(b.length < 5 || b.length > 7)) {
      var c = {};
      return (
        (c.s = b[0]),
        (c.o = b[1]),
        (c.g = b[2]),
        (c.t = b[3]),
        (c.j = b[4]),
        (c.l = b[5]),
        (c.h = b[6]),
        c
      );
    }
  }
  var wt = new Map([
    [5, "ad_storage"],
    [4, ["ad_storage", "ad_user_data"]],
    [2, "analytics_storage"],
  ]);
  function xt(a, b, c) {
    if (st[b]) {
      for (
        var d = [],
          e = $r(a, void 0, void 0, wt.get(b)),
          f = m(e),
          g = f.next();
        !g.done;
        g = f.next()
      ) {
        var h = tt(g.value, b, c);
        h && d.push(zt(h));
      }
      return d;
    }
  }
  function At(a) {
    var b = Bt;
    if (st[2]) {
      for (
        var c = {},
          d = as(a, void 0, void 0, wt.get(2)),
          e = Object.keys(d).sort(),
          f = m(e),
          g = f.next();
        !g.done;
        g = f.next()
      )
        for (
          var h = g.value, l = m(d[h]), n = l.next();
          !n.done;
          n = l.next()
        ) {
          var p = tt(n.value, 2, b);
          p && (c[h] || (c[h] = []), c[h].push(zt(p)));
        }
      return c;
    }
  }
  function Ct(a, b, c, d, e) {
    d = d || {};
    var f = qs(d.domain, d.path),
      g = ut(b, c, f);
    if (!g) return 1;
    var h = Br(d, e, void 0, wt.get(c));
    return ls(a, g, h);
  }
  function Dt(a, b) {
    var c = b.ja;
    return typeof c === "function" ? c(a) : c.test(a);
  }
  function zt(a) {
    for (
      var b = m(Object.keys(a)), c = b.next(), d = {};
      !c.done;
      d = { og: void 0 }, c = b.next()
    ) {
      var e = c.value,
        f = a[e];
      d.og = nt[e];
      d.og
        ? d.og.Tj
          ? (a[e] = Array.isArray(f)
              ? f.filter(
                  (function (g) {
                    return function (h) {
                      return Dt(h, g.og);
                    };
                  })(d),
                )
              : void 0)
          : (typeof f === "string" && Dt(f, d.og)) || (a[e] = void 0)
        : (a[e] = void 0);
    }
    return a;
  }
  var Et = function (a) {
    this.value = 0;
    this.value = a === void 0 ? 0 : a;
  };
  Et.prototype.set = function (a) {
    return (this.value |= 1 << a);
  };
  var Ft = function (a, b) {
    b <= 0 || (a.value |= 1 << (b - 1));
  };
  Et.prototype.get = function () {
    return this.value;
  };
  Et.prototype.clear = function (a) {
    this.value &= ~(1 << a);
  };
  Et.prototype.clearAll = function () {
    this.value = 0;
  };
  Et.prototype.equals = function (a) {
    return this.value === a.value;
  };
  function Gt(a) {
    if (a)
      try {
        return new Uint8Array(
          atob(a.replace(/-/g, "+").replace(/_/g, "/"))
            .split("")
            .map(function (b) {
              return b.charCodeAt(0);
            }),
        );
      } catch (b) {}
  }
  function Ht(a, b) {
    var c = 0,
      d = 0,
      e,
      f = b;
    do {
      if (f >= a.length) return;
      e = a[f++];
      c |= (e & 127) << d;
      d += 7;
    } while (e & 128);
    return [c, f];
  }
  function It() {
    var a = String,
      b = w.location.hostname,
      c = w.location.pathname,
      d = (b = kc(b));
    d.split(".").length > 2 &&
      (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
    b = d;
    c = kc(c);
    var e = c.split(";")[0];
    e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
    return a(li(("" + b + e).toLowerCase()));
  }
  var Jt = {},
    Kt =
      ((Jt.gclid = !0),
      (Jt.dclid = !0),
      (Jt.gbraid = !0),
      (Jt.wbraid = !0),
      Jt),
    Lt = /^\w+$/,
    Mt = /^[\w-]+$/,
    Nt = {},
    Ot =
      ((Nt.aw = "_aw"),
      (Nt.dc = "_dc"),
      (Nt.gf = "_gf"),
      (Nt.gp = "_gp"),
      (Nt.gs = "_gs"),
      (Nt.ha = "_ha"),
      (Nt.ag = "_ag"),
      (Nt.gb = "_gb"),
      Nt),
    Pt = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
    Qt = /^www\.googleadservices\.com$/;
  function Rt() {
    return ["ad_storage", "ad_user_data"];
  }
  function St(a) {
    return !kb(6) || km(a);
  }
  function Tt(a, b) {
    function c() {
      var d = St(b);
      d && a();
      return d;
    }
    qm(function () {
      c() || rm(c, b);
    }, b);
  }
  function Ut(a) {
    return Vt(a).map(function (b) {
      return b.gclid;
    });
  }
  function Wt(a) {
    return Xt(a)
      .filter(function (b) {
        return b.gclid;
      })
      .map(function (b) {
        return b.gclid;
      });
  }
  function Xt(a) {
    var b = Yt(a.prefix),
      c = Zt("gb", b),
      d = Zt("ag", b);
    if (!d || !c) return [];
    var e = function (h) {
        return function (l) {
          l.type = h;
          return l;
        };
      },
      f = Vt(c).map(e("gb")),
      g = $t(d).map(e("ag"));
    return f.concat(g).sort(function (h, l) {
      return l.timestamp - h.timestamp;
    });
  }
  function au(a, b, c, d, e) {
    var f = Ib(a, function (g) {
      return g.gclid === b;
    });
    f
      ? (f.timestamp < c && ((f.timestamp = c), (f.Zc = e)),
        (f.labels = bu(f.labels || [], d || [])))
      : a.push({ version: "2", gclid: b, timestamp: c, labels: d, Zc: e });
  }
  function $t(a) {
    for (
      var b = xt(a, 5) || [], c = [], d = m(b), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = e.value,
        g = f,
        h = cu(f);
      h && au(c, g.k, h, g.b || [], f.u);
    }
    return c.sort(function (l, n) {
      return n.timestamp - l.timestamp;
    });
  }
  function Vt(a) {
    for (
      var b = [], c = $r(a, A.cookie, void 0, Rt()), d = m(c), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = du(e.value);
      f != null && ((f.Zc = void 0), (f.Aa = new Et()), (f.ab = [1]), eu(b, f));
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return fu(b);
  }
  function gu(a, b) {
    for (var c = [], d = m(a), e = d.next(); !e.done; e = d.next()) {
      var f = e.value;
      c.includes(f) || c.push(f);
    }
    for (var g = m(b), h = g.next(); !h.done; h = g.next()) {
      var l = h.value;
      c.includes(l) || c.push(l);
    }
    return c;
  }
  function eu(a, b, c) {
    c = c === void 0 ? !1 : c;
    for (var d, e, f = m(a), g = f.next(); !g.done; g = f.next()) {
      var h = g.value;
      if (h.gclid === b.gclid) {
        d = h;
        break;
      }
      h.Aa && b.Aa && h.Aa.equals(b.Aa) && (e = h);
    }
    if (d) {
      var l,
        n,
        p = (l = d.Aa) != null ? l : new Et(),
        q = (n = b.Aa) != null ? n : new Et();
      p.value |= q.value;
      d.Aa = p;
      d.timestamp < b.timestamp && ((d.timestamp = b.timestamp), (d.Zc = b.Zc));
      d.labels = gu(d.labels || [], b.labels || []);
      d.ab = gu(d.ab || [], b.ab || []);
    } else c && e ? oa(Object, "assign").call(Object, e, b) : a.push(b);
  }
  function hu(a) {
    if (!a) return new Et();
    var b = new Et();
    if (a === 1) return (Ft(b, 2), Ft(b, 3), b);
    Ft(b, a);
    return b;
  }
  function iu() {
    var a = Gr("gclid");
    if (!a || a.error || !a.value || typeof a.value !== "object") return null;
    var b = a.value;
    try {
      if (!("value" in b && b.value) || typeof b.value !== "object")
        return null;
      var c = b.value,
        d = c.value;
      if (!d || !d.match(Mt)) return null;
      var e = c.linkDecorationSource,
        f = c.linkDecorationSources,
        g = new Et();
      typeof e === "number"
        ? (g = hu(e))
        : typeof f === "number" && (g.value = f);
      return {
        version: "",
        gclid: d,
        timestamp: Number(c.creationTimeMs) || 0,
        labels: [],
        Aa: g,
        ab: [2],
      };
    } catch (h) {
      return null;
    }
  }
  function ju() {
    var a = Gr("gcl_aw");
    if (a.error !== 0) return null;
    try {
      return a.value.reduce(function (b, c) {
        if (!c.value || typeof c.value !== "object") return b;
        var d = c.value,
          e = d.value;
        if (!e || !e.match(Mt)) return b;
        var f = new Et(),
          g = d.linkDecorationSources;
        typeof g === "number" && (f.value = g);
        b.push({
          version: "",
          gclid: e,
          timestamp: Number(d.creationTimeMs) || 0,
          expires: Number(c.expires) || 0,
          labels: [],
          Aa: f,
          ab: [2],
        });
        return b;
      }, []);
    } catch (b) {
      return null;
    }
  }
  function ku(a) {
    for (
      var b = [], c = $r(a, A.cookie, void 0, Rt()), d = m(c), e = d.next();
      !e.done;
      e = d.next()
    ) {
      var f = du(e.value);
      f != null && ((f.Zc = void 0), (f.Aa = new Et()), (f.ab = [1]), eu(b, f));
    }
    var g = iu();
    g && ((g.Zc = void 0), (g.ab = g.ab || [2]), eu(b, g));
    if (kb(14)) {
      var h = ju();
      if (h)
        for (var l = m(h), n = l.next(); !n.done; n = l.next()) {
          var p = n.value;
          p.Zc = void 0;
          p.ab = p.ab || [2];
          eu(b, p);
        }
    }
    b.sort(function (q, r) {
      return r.timestamp - q.timestamp;
    });
    return fu(b);
  }
  function bu(a, b) {
    if (!a.length) return b;
    if (!b.length) return a;
    var c = {};
    return a.concat(b).filter(function (d) {
      return c.hasOwnProperty(d) ? !1 : (c[d] = !0);
    });
  }
  function Yt(a) {
    return a && typeof a === "string" && a.match(Lt) ? a : "_gcl";
  }
  function lu(a, b) {
    if (a) {
      var c = { value: a, Aa: new Et() };
      Ft(c.Aa, b);
      return c;
    }
  }
  function mu(a, b, c) {
    var d = Pj(a),
      e = Jj(d, "query", !1, void 0, "gclsrc"),
      f = lu(Jj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
    if (b && (!f || !e)) {
      var g = d.hash.replace("#", "");
      f || (f = lu(Gj(g, "gclid", !1), 3));
      e || (e = Gj(g, "gclsrc", !1));
    }
    return f &&
      (e === void 0 || e === "aw" || e === "aw.ds" || (kb(18) && e === "aw.dv"))
      ? [f]
      : [];
  }
  function nu(a, b) {
    var c = Pj(a),
      d = Jj(c, "query", !1, void 0, "gclid"),
      e = Jj(c, "query", !1, void 0, "gclsrc"),
      f = Jj(c, "query", !1, void 0, "wbraid");
    f = ic(f);
    var g = Jj(c, "query", !1, void 0, "gbraid"),
      h = Jj(c, "query", !1, void 0, "gad_source"),
      l = Jj(c, "query", !1, void 0, "dclid");
    if (b && !(d && e && f && g)) {
      var n = c.hash.replace("#", "");
      d = d || Gj(n, "gclid", !1);
      e = e || Gj(n, "gclsrc", !1);
      f = f || Gj(n, "wbraid", !1);
      g = g || Gj(n, "gbraid", !1);
      h = h || Gj(n, "gad_source", !1);
    }
    return ou(d, e, l, f, g, h);
  }
  function pu() {
    return nu(w.location.href, !0);
  }
  function ou(a, b, c, d, e, f) {
    var g = {},
      h = function (l, n) {
        g[n] || (g[n] = []);
        g[n].push(l);
      };
    g.gclid = a;
    g.gclsrc = b;
    g.dclid = c;
    if (a !== void 0 && a.match(Mt))
      switch (b) {
        case void 0:
          h(a, "aw");
          break;
        case "aw.ds":
          h(a, "aw");
          h(a, "dc");
          break;
        case "aw.dv":
          kb(18) && (h(a, "aw"), h(a, "dc"));
          break;
        case "ds":
          h(a, "dc");
          break;
        case "3p.ds":
          h(a, "dc");
          break;
        case "gf":
          h(a, "gf");
          break;
        case "ha":
          h(a, "ha");
      }
    c && h(c, "dc");
    d !== void 0 && Mt.test(d) && ((g.wbraid = d), h(d, "gb"));
    e !== void 0 && Mt.test(e) && ((g.gbraid = e), h(e, "ag"));
    f !== void 0 && Mt.test(f) && ((g.gad_source = f), h(f, "gs"));
    return g;
  }
  function qu(a) {
    for (
      var b = pu(), c = !0, d = m(Object.keys(b)), e = d.next();
      !e.done;
      e = d.next()
    )
      if (b[e.value] !== void 0) {
        c = !1;
        break;
      }
    c && ((b = nu(w.document.referrer, !1)), (b.gad_source = void 0));
    ru(b, !1, a);
  }
  function su(a) {
    qu(a);
    var b = mu(w.location.href, !0, !1);
    b.length || (b = mu(w.document.referrer, !1, !0));
    a = a || {};
    tu(a);
    if (b.length) {
      var c = b[0],
        d = Tb(),
        e = Br(a, d, !0),
        f = Rt(),
        g = function () {
          St(f) &&
            e.expires !== void 0 &&
            Dr("gclid", {
              value: {
                value: c.value,
                creationTimeMs: d,
                linkDecorationSources: c.Aa.get(),
              },
              expires: Number(e.expires),
            });
        };
      qm(function () {
        g();
        St(f) || rm(g, f);
      }, f);
    }
  }
  function tu(a) {
    var b;
    if ((b = kb(15))) {
      var c = uu();
      b = Pt.test(c) || Qt.test(c) || vu();
    }
    if (b) {
      var d;
      a: {
        for (
          var e = Pj(w.location.href),
            f = Hj(Jj(e, "query")),
            g = m(Object.keys(f)),
            h = g.next();
          !h.done;
          h = g.next()
        ) {
          var l = h.value;
          if (!Kt[l]) {
            var n = f[l][0] || "",
              p;
            if (!n || n.length < 50 || n.length > 200) p = !1;
            else {
              var q = Gt(n),
                r;
              if (q)
                c: {
                  var t = q;
                  if (t && t.length !== 0) {
                    var u = 0;
                    try {
                      for (var v = 10; u < t.length && !(v-- <= 0); ) {
                        var x = Ht(t, u);
                        if (x === void 0) break;
                        var y = m(x),
                          z = y.next().value,
                          C = y.next().value,
                          E = z,
                          G = C,
                          K = E & 7;
                        if (E >> 3 === 16382) {
                          if (K !== 0) break;
                          var P = Ht(t, G);
                          if (P === void 0) break;
                          r = m(P).next().value === 1;
                          break c;
                        }
                        var fa;
                        d: {
                          var ca = void 0,
                            Q = t,
                            S = G;
                          switch (K) {
                            case 0:
                              fa = (ca = Ht(Q, S)) == null ? void 0 : ca[1];
                              break d;
                            case 1:
                              fa = S + 8;
                              break d;
                            case 2:
                              var ma = Ht(Q, S);
                              if (ma === void 0) break;
                              var ka = m(ma),
                                V = ka.next().value;
                              fa = ka.next().value + V;
                              break d;
                            case 5:
                              fa = S + 4;
                              break d;
                          }
                          fa = void 0;
                        }
                        if (fa === void 0 || fa > t.length || fa <= u) break;
                        u = fa;
                      }
                    } catch (ea) {}
                  }
                  r = !1;
                }
              else r = !1;
              p = r;
            }
            if (p) {
              d = n;
              break a;
            }
          }
        }
        d = void 0;
      }
      var U = d;
      U && wu(U, 7, a);
    }
  }
  function wu(a, b, c) {
    c = c || {};
    var d = Tb(),
      e = Br(c, d, !0),
      f = Rt(),
      g = function () {
        if (St(f) && e.expires !== void 0) {
          var h = ju() || [];
          eu(
            h,
            {
              version: "",
              gclid: a,
              timestamp: d,
              expires: Number(e.expires),
              Aa: hu(b),
            },
            !0,
          );
          Dr(
            "gcl_aw",
            h.map(function (l) {
              return {
                value: {
                  value: l.gclid,
                  creationTimeMs: l.timestamp,
                  linkDecorationSources: l.Aa ? l.Aa.get() : 0,
                },
                expires: Number(l.expires),
              };
            }),
          );
        }
      };
    qm(function () {
      St(f) ? g() : rm(g, f);
    }, f);
  }
  function ru(a, b, c, d, e) {
    c = c || {};
    e = e || [];
    var f = Yt(c.prefix),
      g = d || Tb(),
      h = Math.round(g / 1e3),
      l = Rt(),
      n = !1,
      p = !1,
      q = kb(20),
      r = function () {
        if (St(l)) {
          var t = Br(c, g, !0);
          t.Ec = l;
          for (
            var u = function (ca, Q) {
                var S = Zt(ca, f);
                S && (ls(S, Q, t), ca !== "gb" && (n = !0));
              },
              v = function (ca) {
                var Q = ["GCL", h, ca];
                e.length > 0 && Q.push(e.join("."));
                return Q.join(".");
              },
              x = m(["aw", "dc", "gf", "ha", "gp"]),
              y = x.next();
            !y.done;
            y = x.next()
          ) {
            var z = y.value;
            a[z] && u(z, v(a[z][0]));
          }
          if ((!n || q) && a.gb) {
            var C = a.gb[0],
              E = Zt("gb", f);
            (!b &&
              Vt(E).some(function (ca) {
                return ca.gclid === C && ca.labels && ca.labels.length > 0;
              })) ||
              u("gb", v(C));
          }
        }
        if (!p && a.gbraid && St("ad_storage") && ((p = !0), !n || q)) {
          var G = a.gbraid,
            K = Zt("ag", f);
          if (
            b ||
            !$t(K).some(function (ca) {
              return ca.gclid === G && ca.labels && ca.labels.length > 0;
            })
          ) {
            var P = {},
              fa = ((P.k = G), (P.i = "" + h), (P.b = e), P);
            Ct(K, fa, 5, c, g);
          }
        }
        xu(a, f, g, c);
      };
    qm(function () {
      r();
      St(l) || rm(r, l);
    }, l);
  }
  function xu(a, b, c, d) {
    if (a.gad_source !== void 0 && St("ad_storage")) {
      var e = wd();
      if (e !== "r" && e !== "h") {
        var f = a.gad_source,
          g = Zt("gs", b);
        if (g) {
          var h = Math.floor((Tb() - (vd() || 0)) / 1e3),
            l,
            n = It(),
            p = {};
          l = ((p.k = f), (p.i = "" + h), (p.u = n), p);
          Ct(g, l, 5, d, c);
        }
      }
    }
  }
  function yu(a, b) {
    var c = Ms(!0);
    Tt(function () {
      for (var d = Yt(b.prefix), e = 0; e < a.length; ++e) {
        var f = a[e];
        if (Ot[f] !== void 0) {
          var g = Zt(f, d),
            h = c[g];
          if (h) {
            var l = Math.min(zu(h), Tb()),
              n;
            b: {
              for (
                var p = l, q = $r(g, A.cookie, void 0, Rt()), r = 0;
                r < q.length;
                ++r
              )
                if (zu(q[r]) > p) {
                  n = !0;
                  break b;
                }
              n = !1;
            }
            if (!n) {
              var t = Br(b, l, !0);
              t.Ec = Rt();
              ls(g, h, t);
            }
          }
        }
      }
      ru(ou(c.gclid, c.gclsrc), !1, b);
    }, Rt());
  }
  function Au(a) {
    var b = ["ag"],
      c = Ms(!0),
      d = Yt(a.prefix);
    Tt(
      function () {
        for (var e = 0; e < b.length; ++e) {
          var f = Zt(b[e], d);
          if (f) {
            var g = c[f];
            if (g) {
              var h = tt(g, 5);
              if (h) {
                var l = cu(h);
                l || (l = Tb());
                var n;
                a: {
                  for (var p = l, q = xt(f, 5), r = 0; r < q.length; ++r)
                    if (cu(q[r]) > p) {
                      n = !0;
                      break a;
                    }
                  n = !1;
                }
                if (n) break;
                h.i = "" + Math.round(l / 1e3);
                Ct(f, h, 5, a, l);
              }
            }
          }
        }
      },
      ["ad_storage"],
    );
  }
  function Zt(a, b) {
    var c = Ot[a];
    if (c !== void 0) return b + c;
  }
  function zu(a) {
    return Bu(a.split(".")).length !== 0
      ? (Number(a.split(".")[1]) || 0) * 1e3
      : 0;
  }
  function cu(a) {
    return a ? (Number(a.i) || 0) * 1e3 : 0;
  }
  function du(a) {
    var b = Bu(a.split("."));
    return b.length === 0
      ? null
      : {
          version: b[0],
          gclid: b[2],
          timestamp: (Number(b[1]) || 0) * 1e3,
          labels: b.slice(3),
        };
  }
  function Bu(a) {
    return a.length < 3 ||
      (a[0] !== "GCL" && a[0] !== "1") ||
      !/^\d+$/.test(a[1]) ||
      !Mt.test(a[2])
      ? []
      : a;
  }
  function Cu(a, b, c, d, e) {
    if (Array.isArray(b) && Zr(w)) {
      var f = Yt(e),
        g = function () {
          for (var h = {}, l = 0; l < a.length; ++l) {
            var n = Zt(a[l], f);
            if (n) {
              var p = $r(n, A.cookie, void 0, Rt());
              p.length && (h[n] = p.sort()[p.length - 1]);
            }
          }
          return h;
        };
      Tt(function () {
        Ts(g, b, c, d);
      }, Rt());
    }
  }
  function Du(a, b, c, d) {
    if (Array.isArray(a) && Zr(w)) {
      var e = ["ag"],
        f = Yt(d),
        g = function () {
          for (var h = {}, l = 0; l < e.length; ++l) {
            var n = Zt(e[l], f);
            if (!n) return {};
            var p = xt(n, 5);
            if (p.length) {
              var q = p.sort(function (r, t) {
                return cu(t) - cu(r);
              })[0];
              h[n] = ut(q, 5);
            }
          }
          return h;
        };
      Tt(
        function () {
          Ts(g, a, b, c);
        },
        ["ad_storage"],
      );
    }
  }
  function fu(a) {
    return a.filter(function (b) {
      return Mt.test(b.gclid);
    });
  }
  function Eu(a, b) {
    if (Zr(w)) {
      for (var c = Yt(b.prefix), d = {}, e = 0; e < a.length; e++)
        Ot[a[e]] && (d[a[e]] = Ot[a[e]]);
      Tt(function () {
        Mb(d, function (f, g) {
          var h = $r(c + g, A.cookie, void 0, Rt());
          h.sort(function (t, u) {
            return zu(u) - zu(t);
          });
          if (h.length) {
            var l = h[0],
              n = zu(l),
              p = Bu(l.split(".")).length !== 0 ? l.split(".").slice(3) : [],
              q = {},
              r;
            r = Bu(l.split(".")).length !== 0 ? l.split(".")[2] : void 0;
            q[f] = [r];
            ru(q, !0, b, n, p);
          }
        });
      }, Rt());
    }
  }
  function Fu(a) {
    var b = ["ag"],
      c = ["gbraid"];
    Tt(
      function () {
        for (var d = Yt(a.prefix), e = 0; e < b.length; ++e) {
          var f = Zt(b[e], d);
          if (!f) break;
          var g = xt(f, 5);
          if (g.length) {
            var h = g.sort(function (q, r) {
                return cu(r) - cu(q);
              })[0],
              l = cu(h),
              n = h.b,
              p = {};
            p[c[e]] = h.k;
            ru(p, !0, a, l, n);
          }
        }
      },
      ["ad_storage"],
    );
  }
  function Gu(a, b) {
    for (var c = 0; c < b.length; ++c) if (a[b[c]]) return !0;
    return !1;
  }
  function Hu(a) {
    function b(h, l, n) {
      n && (h[l] = n);
    }
    if (nm()) {
      var c = pu(),
        d;
      a.includes("gad_source") &&
        (d = c.gad_source !== void 0 ? c.gad_source : Ms(!1)._gs);
      if (Gu(c, a) || d) {
        var e = {};
        b(e, "gclid", c.gclid);
        b(e, "dclid", c.dclid);
        b(e, "gclsrc", c.gclsrc);
        b(e, "wbraid", c.wbraid);
        b(e, "gbraid", c.gbraid);
        Us(function () {
          return e;
        }, 3);
        var f = {},
          g = ((f._up = "1"), f);
        b(g, "_gs", d);
        Us(function () {
          return g;
        }, 1);
      }
    }
  }
  function vu() {
    var a = Pj(w.location.href);
    return Jj(a, "query", !1, void 0, "gad_source");
  }
  function Iu(a) {
    if (!kb(1)) return null;
    var b = Ms(!0).gad_source;
    if (b != null) return ((w.location.hash = ""), b);
    if (kb(2)) {
      b = vu();
      if (b != null) return b;
      var c = pu();
      if (Gu(c, a)) return "0";
    }
    return null;
  }
  function Ju(a) {
    var b = Iu(a);
    b != null &&
      Us(function () {
        var c = {};
        return ((c.gad_source = b), c);
      }, 4);
  }
  function Ku(a, b, c) {
    var d = [];
    if (b.length === 0) return d;
    for (var e = {}, f = 0; f < b.length; f++) {
      var g = b[f],
        h = g.type ? g.type : "gcl";
      (g.labels || []).indexOf(c) === -1
        ? (a.push(0), e[h] || d.push(g))
        : a.push(1);
      e[h] = !0;
    }
    return d;
  }
  function Lu(a, b, c, d) {
    var e = [];
    c = c || {};
    if (!St(Rt())) return e;
    var f = Vt(a),
      g = Ku(e, f, b);
    if (g.length && !d)
      for (var h = m(g), l = h.next(); !l.done; l = h.next()) {
        var n = l.value,
          p = n.timestamp,
          q = [n.version, Math.round(p / 1e3), n.gclid]
            .concat(n.labels || [], [b])
            .join("."),
          r = Br(c, p, !0);
        r.Ec = Rt();
        ls(a, q, r);
      }
    return e;
  }
  function Mu(a, b) {
    var c = [];
    b = b || {};
    var d = Xt(b),
      e = Ku(c, d, a);
    if (e.length)
      for (var f = m(e), g = f.next(); !g.done; g = f.next()) {
        var h = g.value,
          l = Yt(b.prefix),
          n = Zt(h.type, l);
        if (!n) break;
        var p = h,
          q = p.version,
          r = p.gclid,
          t = p.labels,
          u = p.timestamp,
          v = Math.round(u / 1e3);
        if (h.type === "ag") {
          var x = {},
            y = ((x.k = r), (x.i = "" + v), (x.b = (t || []).concat([a])), x);
          Ct(n, y, 5, b, u);
        } else if (h.type === "gb") {
          var z = [q, v, r].concat(t || [], [a]).join("."),
            C = Br(b, u, !0);
          C.Ec = Rt();
          ls(n, z, C);
        }
      }
    return c;
  }
  function Nu(a, b) {
    var c = Yt(b),
      d = Zt(a, c);
    if (!d) return 0;
    var e;
    e = a === "ag" ? $t(d) : Vt(d);
    for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
    return f;
  }
  function Ou(a) {
    for (var b = 0, c = m(Object.keys(a)), d = c.next(); !d.done; d = c.next())
      for (var e = a[d.value], f = 0; f < e.length; f++)
        b = Math.max(b, Number(e[f].timestamp));
    return b;
  }
  function Pu(a) {
    var b = Math.max(Nu("aw", a), Ou(St(Rt()) ? lt() : {})),
      c = Math.max(Nu("gb", a), Ou(St(Rt()) ? lt("_gac_gb", !0) : {}));
    c = Math.max(c, Nu("ag", a));
    return c > b;
  }
  function uu() {
    return A.referrer ? Jj(Pj(A.referrer), "host") : "";
  }
  function av(a) {
    var b = window,
      c = b.webkit;
    delete b.webkit;
    a(b.webkit);
    b.webkit = c;
  }
  function bv(a) {
    var b = { action: "gcl_setup" };
    if ("CWVWebViewMessage" in a.messageHandlers)
      return (
        a.messageHandlers.CWVWebViewMessage.postMessage({
          command: "awb",
          payload: b,
        }),
        !0
      );
    var c = a.messageHandlers.awb;
    return c ? (c.postMessage(b), !0) : !1;
  }
  function cv() {
    return ["ad_storage", "ad_user_data"];
  }
  function dv(a) {
    if (
      N(38) &&
      !Gm(Cm.aa.Im) &&
      "webkit" in window &&
      window.webkit.messageHandlers
    ) {
      var b = function () {
        try {
          av(function (c) {
            c &&
              ("CWVWebViewMessage" in c.messageHandlers ||
                "awb" in c.messageHandlers) &&
              (Fm(Cm.aa.Im, function (d) {
                d.gclid && wu(d.gclid, 5, a);
              }),
              bv(c) || O(178));
          });
        } catch (c) {
          O(177);
        }
      };
      qm(function () {
        St(cv()) ? b() : rm(b, cv());
      }, cv());
    }
  }
  var ev = [
    "https://www.google.com",
    "https://www.youtube.com",
    "https://m.youtube.com",
  ];
  function fv(a) {
    return a.data.action !== "gcl_transfer"
      ? (O(173), !0)
      : a.data.gadSource
        ? a.data.gclid
          ? !1
          : (O(181), !0)
        : (O(180), !0);
  }
  function gv(a, b) {
    if (N(a)) {
      if (Gm(Cm.aa.Me)) return (O(176), Cm.aa.Me);
      if (Gm(Cm.aa.Lm)) return (O(170), Cm.aa.Me);
      var c = Cq();
      if (!c) O(171);
      else if (c.opener) {
        var d = function (g) {
          if (!ev.includes(g.origin)) O(172);
          else if (!fv(g)) {
            var h = { gadSource: g.data.gadSource };
            N(229) && (h.gclid = g.data.gclid);
            Fm(Cm.aa.Me, h);
            a === 200 && g.data.gclid && wu(String(g.data.gclid), 6, b);
            var l;
            (l = g.stopImmediatePropagation) == null || l.call(g);
            Mq(c, "message", d);
          }
        };
        if (Lq(c, "message", d)) {
          Fm(Cm.aa.Lm, !0);
          for (var e = m(ev), f = e.next(); !f.done; f = e.next())
            c.opener.postMessage({ action: "gcl_setup" }, f.value);
          O(174);
          return Cm.aa.Me;
        }
        O(175);
      }
    }
  }
  var qv = RegExp(
      "^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$",
    ),
    rv = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
    sv = /^\d+\.fls\.doubleclick\.net$/,
    tv = /;gac=([^;?]+)/,
    uv = /;gacgb=([^;?]+)/;
  function vv(a, b) {
    if (sv.test(A.location.host)) {
      var c = A.location.href.match(b);
      return c && c.length === 2 && c[1].match(qv) ? Ij(c[1]) || "" : "";
    }
    for (
      var d = [], e = m(Object.keys(a)), f = e.next();
      !f.done;
      f = e.next()
    ) {
      for (var g = f.value, h = [], l = a[g], n = 0; n < l.length; n++)
        h.push(l[n].gclid);
      d.push(g + ":" + h.join(","));
    }
    return d.length > 0 ? d.join(";") : "";
  }
  function wv(a, b, c) {
    for (
      var d = St(Rt()) ? lt("_gac_gb", !0) : {},
        e = [],
        f = !1,
        g = m(Object.keys(d)),
        h = g.next();
      !h.done;
      h = g.next()
    ) {
      var l = h.value,
        n = Lu("_gac_gb_" + l, a, b, c);
      f =
        f ||
        (n.length !== 0 &&
          n.some(function (p) {
            return p === 1;
          }));
      e.push(l + ":" + n.join(","));
    }
    return { Vq: f ? e.join(";") : "", Uq: vv(d, uv) };
  }
  function xv(a) {
    var b = A.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
    return b && b.length === 2 && b[1].match(rv) ? b[1] : void 0;
  }
  function yv(a) {
    var b = {},
      c,
      d,
      e;
    sv.test(A.location.host) &&
      ((c = xv("gclgs")), (d = xv("gclst")), (e = xv("gcllp")));
    if (c && d && e) ((b.tg = c), (b.Ph = d), (b.Oh = e));
    else {
      var f = Tb(),
        g = $t((a || "_gcl") + "_gs"),
        h = g.map(function (p) {
          return p.gclid;
        }),
        l = g.map(function (p) {
          return f - p.timestamp;
        }),
        n = g.map(function (p) {
          return p.Zc;
        });
      h.length > 0 &&
        l.length > 0 &&
        n.length > 0 &&
        ((b.tg = h.join(".")), (b.Ph = l.join(".")), (b.Oh = n.join(".")));
    }
    return b;
  }
  function zv(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (sv.test(A.location.host)) {
      var e = xv(c);
      if (e) {
        if (d) {
          var f = new Et();
          Ft(f, 2);
          Ft(f, 3);
          return e.split(".").map(function (h) {
            return { gclid: h, Aa: f, ab: [1] };
          });
        }
        return e.split(".").map(function (h) {
          return { gclid: h, Aa: new Et(), ab: [1] };
        });
      }
    } else {
      if (b === "gclid") {
        var g = (a || "_gcl") + "_aw";
        return d ? ku(g) : Vt(g);
      }
      if (b === "wbraid") return Vt((a || "_gcl") + "_gb");
      if (b === "braids") return Xt({ prefix: a });
    }
    return [];
  }
  function Av(a) {
    return sv.test(A.location.host) ? !(xv("gclaw") || xv("gac")) : Pu(a);
  }
  function Bv(a, b, c) {
    var d;
    d = c ? Mu(a, b) : Lu(((b && b.prefix) || "_gcl") + "_gb", a, b);
    return d.length === 0 ||
      d.every(function (e) {
        return e === 0;
      })
      ? ""
      : d.join(".");
  }
  function Hv() {
    var a = [],
      b = Number("") || 0,
      c = Number("") || 0;
    c || (c = b / 100);
    var d = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 21,
      studyId: 21,
      experimentId: 105102050,
      controlId: 105102051,
      controlId2: 105102052,
      probability: c,
      active: d,
      oa: 0,
    });
    var e = Number("") || 0,
      f = Number("") || 0;
    f || (f = e / 100);
    var g = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 265,
      studyId: 265,
      experimentId: 115691063,
      controlId: 115691064,
      controlId2: 115691065,
      probability: f,
      active: g,
      oa: 0,
    });
    var h = Number("") || 0,
      l = Number("") || 0;
    l || (l = h / 100);
    var n = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 228,
      studyId: 228,
      experimentId: 105177154,
      controlId: 105177155,
      controlId2: 105255245,
      probability: l,
      active: n,
      oa: 0,
    });
    var p = Number("") || 0,
      q = Number("") || 0;
    q || (q = p / 100);
    var r = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 287,
      studyId: 287,
      experimentId: 116133312,
      controlId: 116133313,
      controlId2: 116133314,
      probability: q,
      active: r,
      oa: 0,
    });
    var t = Number("") || 0,
      u = Number("") || 0;
    u || (u = t / 100);
    var v = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 288,
      studyId: 288,
      experimentId: 116133315,
      controlId: 116133316,
      controlId2: 116133317,
      probability: u,
      active: v,
      oa: 0,
    });
    var x = Number("") || 0,
      y = Number("") || 0;
    y || (y = x / 100);
    var z = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 285,
      studyId: 285,
      experimentId: 115495938,
      controlId: 115495939,
      controlId2: 115495940,
      probability: y,
      active: z,
      oa: 0,
    });
    var C = Number("") || 0,
      E = Number("") || 0;
    E || (E = C / 100);
    var G = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 286,
      studyId: 286,
      experimentId: 115495941,
      controlId: 115495942,
      controlId2: 115495943,
      probability: E,
      active: G,
      oa: 0,
    });
    var K = Number("") || 0,
      P = Number("") || 0;
    P || (P = K / 100);
    var fa = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 219,
      studyId: 219,
      experimentId: 104948811,
      controlId: 104948812,
      controlId2: 0,
      probability: P,
      active: fa,
      oa: 0,
    });
    var ca = Number("") || 0,
      Q = Number("") || 0;
    Q || (Q = ca / 100);
    var S = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 220,
      studyId: 220,
      experimentId: 104948813,
      controlId: 104948814,
      controlId2: 0,
      probability: Q,
      active: S,
      oa: 0,
    });
    var ma = Number("") || 0,
      ka = Number("") || 0;
    ka || (ka = ma / 100);
    var V = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 255,
      studyId: 255,
      experimentId: 105391252,
      controlId: 105391253,
      controlId2: 105446120,
      probability: ka,
      active: V,
      oa: 0,
    });
    var U = Number("") || 0,
      ea = Number("") || 0;
    ea || (ea = U / 100);
    var pa = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 235,
      studyId: 235,
      experimentId: 105357150,
      controlId: 105357151,
      controlId2: 0,
      probability: ea,
      active: pa,
      oa: 1,
    });
    var qa = Number("") || 0,
      Fa = Number("0") || 0;
    Fa || (Fa = qa / 100);
    var Va = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 170,
      studyId: 170,
      experimentId: 116024733,
      controlId: 116024734,
      controlId2: 116024735,
      probability: Fa,
      active: Va,
      oa: 0,
    });
    var ib = Number("") || 0,
      ub = Number("") || 0;
    ub || (ub = ib / 100);
    var hb = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 203,
      studyId: 203,
      experimentId: 115480710,
      controlId: 115480709,
      controlId2: 115489982,
      probability: ub,
      active: hb,
      oa: 0,
    });
    var Zb = Number("") || 0,
      $b = Number("") || 0;
    $b || ($b = Zb / 100);
    var ke = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 178,
      studyId: 178,
      experimentId: 115958700,
      controlId: 115958701,
      controlId2: 115958702,
      probability: $b,
      active: ke,
      oa: 0,
    });
    var Ji = Number("") || 0,
      Ue = Number("") || 0;
    Ue || (Ue = Ji / 100);
    var Pf = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 197,
      studyId: 197,
      experimentId: 105113532,
      controlId: 105113531,
      controlId2: 0,
      probability: Ue,
      active: Pf,
      oa: 0,
    });
    var jp = Number("") || 0,
      Ki = Number("0.2") || 0;
    Ki || (Ki = jp / 100);
    var dl = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 243,
      studyId: 243,
      experimentId: 115616985,
      controlId: 115616986,
      controlId2: 0,
      probability: Ki,
      active: dl,
      oa: 0,
    });
    var kp = Number("") || 0,
      Li = Number("") || 0;
    Li || (Li = kp / 100);
    var nK = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 277,
      studyId: 277,
      experimentId: 116130039,
      controlId: 116130040,
      controlId2: 0,
      probability: Li,
      active: nK,
      oa: 0,
    });
    var oK = Number("") || 0,
      lp = Number("0") || 0;
    lp || (lp = oK / 100);
    var pK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 254,
      studyId: 254,
      experimentId: 115583767,
      controlId: 115583768,
      controlId2: 115583769,
      probability: lp,
      active: pK,
      oa: 0,
    });
    var qK = Number("") || 0,
      mp = Number("") || 0;
    mp || (mp = qK / 100);
    var rK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 253,
      studyId: 253,
      experimentId: 115583770,
      controlId: 115583771,
      controlId2: 115583772,
      probability: mp,
      active: rK,
      oa: 0,
    });
    var sK = Number("") || 0,
      np = Number("") || 0;
    np || (np = sK / 100);
    var tK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 266,
      studyId: 266,
      experimentId: 115718529,
      controlId: 115718530,
      controlId2: 115718531,
      probability: np,
      active: tK,
      oa: 0,
    });
    var uK = Number("") || 0,
      op = Number("") || 0;
    op || (op = uK / 100);
    var vK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 267,
      studyId: 267,
      experimentId: 115718526,
      controlId: 115718527,
      controlId2: 115718528,
      probability: op,
      active: vK,
      oa: 0,
    });
    var wK = Number("") || 0,
      pp = Number("") || 0;
    pp || (pp = wK / 100);
    var xK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 249,
      studyId: 249,
      experimentId: 105440521,
      controlId: 105440522,
      controlId2: 0,
      focused: !0,
      probability: pp,
      active: xK,
      oa: 0,
    });
    var yK = Number("") || 0,
      qp = Number("0.5") || 0;
    qp || (qp = yK / 100);
    var zK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 195,
      studyId: 195,
      experimentId: 104527906,
      controlId: 104527907,
      controlId2: 104898015,
      probability: qp,
      active: zK,
      oa: 1,
    });
    var AK = Number("") || 0,
      rp = Number("0.5") || 0;
    rp || (rp = AK / 100);
    var BK = (function () {
      var la = !1;
      return la;
    })();
    a.push({
      qa: 196,
      studyId: 196,
      experimentId: 104528500,
      controlId: 104528501,
      controlId2: 104898016,
      probability: rp,
      active: BK,
      oa: 0,
    });
    var CK = Number("") || 0,
      sp = Number("") || 0;
    sp || (sp = CK / 100);
    var DK = (function () {
      var la = !1;
      la = !0;
      return la;
    })();
    a.push({
      qa: 229,
      studyId: 229,
      experimentId: 105359938,
      controlId: 105359937,
      controlId2: 105359936,
      probability: sp,
      active: DK,
      oa: 0,
    });
    return a;
  }
  var Iv = {};
  function Jv(a) {
    var b = a,
      c = (a = Kv[b.studyId]
        ? oa(Object, "assign").call(Object, {}, b, { active: !0 })
        : b);
    (c.controlId2 && c.probability <= 0.25) ||
      (c = oa(Object, "assign").call(Object, {}, c, { controlId2: 0 }));
    ij[c.studyId] = c;
    a.focused && (Iv[a.studyId] = !0);
    if (a.oa === 1) {
      var d = a.studyId;
      Lv(Mv(), d);
      Nv(d) && kk(d);
    } else if (a.oa === 0) {
      var e = a.studyId;
      Lv(Ov, e);
      Nv(e) && kk(e);
    }
  }
  function Lv(a, b, c) {
    if (ij[b]) {
      var d = ij[b],
        e = d.experimentId,
        f = d.probability;
      if (!(a.studies || {})[b]) {
        var g = a.studies || {};
        g[b] = !0;
        a.studies = g;
        if (!ij[b].active)
          if (ij[b].probability > 0.5) mj(a, e, b);
          else if (!(f <= 0 || f > 1)) {
            var h = void 0;
            if (c) {
              var l = gj(c + "~" + b);
              if (l === "e2") h = -1;
              else {
                for (
                  var n = new Uint8Array(l),
                    p = BigInt(0),
                    q = m(n),
                    r = q.next();
                  !r.done;
                  r = q.next()
                )
                  p = (p << BigInt(8)) | BigInt(r.value);
                h = Number(p % BigInt(Number.MAX_SAFE_INTEGER));
              }
            }
            lj.es(a, b, h);
          }
      }
    }
    if (!Iv[b]) {
      var t = oj(a, b);
      t && qj.D.J.add(t);
    }
  }
  function Mv() {
    return Hm(Cm.aa.cq, {});
  }
  var Ov = {};
  function Pv(a, b) {
    var c = Nv(a);
    if (Iv[a]) {
      var d;
      if ((d = oj(Mv(), a) || oj(Ov, a))) {
        var e = T(b, R.C.Ei) || [];
        e.includes(d) || e.push(d);
        W(b, R.C.Ei, e);
      }
    }
    return c;
  }
  function Nv(a) {
    return nj(Mv(), a) || nj(Ov, a);
  }
  function Qv(a) {
    var b = T(a, R.C.Ei) || [];
    return Sk(b);
  }
  var Kv = {};
  function Rv(a) {
    var b = {
        studyId: a[1],
        active: !!a[2],
        probability: a[3] || 0,
        experimentId: a[4] || 0,
        controlId: a[5] || 0,
        controlId2: a[6] || 0,
      },
      c = 0;
    switch (a[7]) {
      case 2:
        c = 1;
        break;
      case 3:
        c = 2;
        break;
      case 1:
      case 4:
      case 5:
      case 0:
        c = 0;
    }
    var d;
    a: switch (b.studyId) {
      case 451:
      case 249:
        d = !0;
        break a;
      default:
        d = !1;
    }
    return oa(Object, "assign").call(Object, {}, b, { oa: c, focused: d });
  }
  function Sv() {
    var a = !1;
    if (a) {
      var b,
        c,
        d =
          ((b = w) == null
            ? void 0
            : (c = b.location) == null
              ? void 0
              : c.hash) || "";
      if (
        d[0] === "#" &&
        d[1] === "_" &&
        d[2] === "t" &&
        d[3] === "e" &&
        d[4] === "="
      ) {
        var e = d.substring(5);
        if (e)
          for (var f = m(e.split("~")), g = f.next(); !g.done; g = f.next()) {
            var h = Number(g.value);
            h && ((Kv[h] = !0), kk(h));
          }
      }
    }
    for (var l = m(Hv()), n = l.next(); !n.done; n = l.next()) Jv(n.value);
    for (
      var p = Rv, q = [], r = m(zg(56) || []), t = r.next();
      !t.done;
      t = r.next()
    ) {
      var u = p(t.value);
      (u.active || (u.experimentId && u.controlId)) && q.push(u);
    }
    for (var v = m(q), x = v.next(); !x.done; x = v.next()) Jv(x.value);
  }
  function Tv(a, b) {
    b &&
      Mb(b, function (c, d) {
        typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d));
      });
  }
  function Uv(a, b) {
    var c = kv(a, J.m.Bb);
    if (c && typeof c === "object")
      for (var d = m(Object.keys(c)), e = d.next(); !e.done; e = d.next()) {
        var f = e.value,
          g = c[f];
        g !== void 0 && (g === null && (g = ""), (b["gap." + f] = String(g)));
      }
  }
  var cw = function (a) {
      this.D = 1;
      this.D > 0 || (this.D = 1);
      this.onSuccess = a.F.onSuccess;
    },
    dw = function (a, b) {
      return hc(
        function () {
          a.D--;
          if (Eb(a.onSuccess) && a.D === 0) a.onSuccess();
        },
        b > 0 ? b : 1,
      );
    };
  var ew = 0,
    fw = void 0;
  function gw(a, b) {
    N(462) &&
      el &&
      b === "gtm.formSubmit" &&
      ((ew = a), a !== 5 ? Qk("fs") : ((Mk.fs = !1), (Mk.ftnw = !1)));
  }
  function hw() {
    N(462) &&
      (Pk(
        "fs",
        function () {
          return ew > 0 && ew < 5 ? String(ew) : void 0;
        },
        !1,
      ),
      Pk(
        "ftnw",
        function () {
          return ew > 0 && ew < 5 && fw !== void 0 ? fw : void 0;
        },
        !1,
      ),
      Pk("wft", function () {}, !1));
  }
  function kw(a, b) {
    var c = !!Uj();
    switch (a) {
      case 45:
        return "https://www.google.com/ccm/collect";
      case 46:
        return c
          ? Vj() + "/gs/ccm/collect"
          : "https://pagead2.googlesyndication.com/ccm/collect";
      case 51:
        return "https://www.google.com/travel/flights/click/conversion";
      case 9:
        return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
      case 68:
        return "https://www.google.com/rmkt/collect";
      case 17:
        return c && !on() ? "" + Vj() + "/ag/g/c" : iw();
      case 16:
        return c && !on() ? "" + Vj() + "/ga/g/c" : jw();
      case 67:
        var d;
        d = d === void 0 ? "g/collect" : d;
        return on() ? "" : "https://www.google.com/" + d;
      case 55:
        return on()
          ? jw("measurement/conversion")
          : c
            ? Vj() + "/gs/measurement/conversion"
            : "https://pagead2.googlesyndication.com/measurement/conversion";
      case 54:
        return on()
          ? iw("measurement/conversion")
          : c
            ? Vj() + "/g/measurement/conversion"
            : "https://www.google.com/measurement/conversion";
      case 1:
        return "https://ad.doubleclick.net/activity;";
      case 2:
        return (
          (c ? Vj() : "https://ade.googlesyndication.com") +
          "/ddm/activity" +
          (N(467) ? ";" : "/")
        );
      case 33:
        return "https://ad.doubleclick.net/activity;register_conversion=1;";
      case 11:
        return c
          ? Vj() + "/d/pagead/form-data"
          : N(141)
            ? "https://www.google.com/pagead/form-data"
            : "https://google.com/pagead/form-data";
      case 3:
        return "https://" + b.sq + ".fls.doubleclick.net/activityi;";
      case 5:
        return "https://www.googleadservices.com/pagead/conversion";
      case 6:
        return c
          ? Vj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      case 66:
        return "https://www.google.com/pagead/uconversion";
      case 8:
        return "https://www.google.com/pagead/1p-conversion";
      case 63:
        return "https://www.googleadservices.com/pagead/conversion";
      case 64:
        return c
          ? Vj() + "/gs/pagead/conversion"
          : "https://pagead2.googlesyndication.com/pagead/conversion";
      case 65:
        return "https://www.google.com/pagead/1p-conversion";
      case 22:
        return c
          ? Vj() + "/as/d/ccm/conversion"
          : "https://www.googleadservices.com/ccm/conversion";
      case 60:
        return c
          ? Vj() + "/gs/ccm/conversion"
          : "https://pagead2.googlesyndication.com/ccm/conversion";
      case 23:
        return c
          ? Vj() + "/g/d/ccm/conversion"
          : "https://www.google.com/ccm/conversion";
      case 21:
        return c
          ? Vj() + "/d/ccm/form-data"
          : N(141)
            ? "https://www.google.com/ccm/form-data"
            : "https://google.com/ccm/form-data";
      case 7:
      case 52:
      case 53:
      case 39:
      case 38:
      case 40:
      case 37:
      case 49:
      case 48:
      case 14:
      case 24:
      case 19:
      case 27:
      case 30:
      case 36:
      case 62:
      case 26:
      case 29:
      case 32:
      case 35:
      case 57:
      case 58:
      case 50:
      case 12:
      case 13:
      case 20:
      case 18:
      case 59:
      case 47:
      case 15:
      case 0:
      case 61:
      case 56:
      case 25:
      case 28:
      case 31:
      case 34:
        throw Error("Unsupported endpoint");
      default:
        Gc(a, "Unknown endpoint");
    }
  }
  var nw =
      "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(
        " ",
      ),
    ow =
      "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(
        " ",
      );
  function pw(a, b) {
    if (!b._tag_metadata) {
      for (var c = {}, d = 0, e = 0; e < a.length; e++)
        d += qw(a[e], b, c) ? 1 : 0;
      d > 0 && (b._tag_metadata = c);
    }
  }
  function qw(a, b, c) {
    var d = b[a];
    if (d === void 0 || d === null) return !1;
    c[a] = Array.isArray(d)
      ? d.map(function () {
          return { mode: "c" };
        })
      : { mode: "c" };
    return !0;
  }
  function rw(a) {
    if (N(178) && a) {
      pw(nw, a);
      for (var b = Hb(a.address), c = 0; c < b.length; c++) {
        var d = b[c];
        d && pw(ow, d);
      }
      var e = a.home_address;
      e && pw(ow, e);
    }
  }
  function sw(a, b, c) {
    function d(f, g) {
      g = String(g).substring(0, 100);
      e.push("" + f + encodeURIComponent(g));
    }
    if (!c) return "";
    var e = [];
    d("i", String(a));
    d("f", b);
    c.mode && d("m", c.mode);
    c.isPreHashed && d("p", "1");
    c.rawLength && d("r", String(c.rawLength));
    c.normalizedLength && d("n", String(c.normalizedLength));
    c.location && d("l", c.location);
    c.selector && d("s", c.selector);
    return e.join(".");
  }
  function $w(a, b, c, d) {
    if (Qn()) {
      var e = b.F;
      Xn({
        targetId: d || [b.target.destinationId],
        request: { url: a, parameterEncoding: 2, endpoint: c },
        jb: { eventId: e.eventId, priorityId: e.priorityId },
        oj: { eventId: T(b, R.C.Qg), priorityId: T(b, R.C.Rg) },
      });
    }
  }
  var nx = {};
  nx.R = Sr.R;
  var ox = {
      Ht: "L",
      hq: "S",
      Vt: "Y",
      Hs: "B",
      Zs: "E",
      Dt: "I",
      Rt: "TC",
      ht: "HTC",
    },
    px = { hq: "S", Ys: "V", Os: "E", Qt: "tag" },
    qx = {},
    rx = ((qx[nx.R.cj] = "6"), (qx[nx.R.dj] = "5"), (qx[nx.R.bj] = "7"), qx);
  function sx() {
    function a(c, d) {
      var e = Cb(xb[d] || []);
      e && b.push([c, e]);
    }
    var b = [];
    a("u", "GTM");
    a("ut", "TAGGING");
    a("h", "HEALTH");
    return b;
  }
  var tx = !1;
  function Mx(a) {}
  function Nx(a) {}
  function Ox() {}
  function Px(a) {}
  function Qx(a) {}
  function Rx(a) {}
  function Sx() {}
  function Tx(a, b) {}
  function Ux(a, b, c) {}
  function Vx() {}
  var Wx = Object.freeze({
    cache: "no-store",
    credentials: "include",
    method: "GET",
    keepalive: !0,
    redirect: "follow",
  });
  function Xx(a, b, c, d, e, f, g, h) {
    var l = oa(Object, "assign").call(Object, {}, Wx);
    b && ((l.body = b), (l.method = "POST"));
    oa(Object, "assign").call(Object, l, d);
    g == null || Rl(g);
    w.fetch(a, l)
      .then(function (n) {
        g == null || Sl(g);
        h == null || Tl(h, a);
        if (!n.ok) f == null || f();
        else if (n.body) {
          var p = n.body.getReader(),
            q = new TextDecoder();
          return new Promise(function (r) {
            function t() {
              p.read()
                .then(function (u) {
                  var v;
                  v = u.done;
                  var x = q.decode(u.value, { stream: !v });
                  Yx(c, x);
                  v ? (e == null || e(), r()) : t();
                })
                .catch(function () {
                  r();
                });
            }
            t();
          });
        }
      })
      .catch(function () {
        g == null || Sl(g);
        h == null || Tl(h, a);
        f && f();
      });
  }
  var Zx = function (a) {
      this.N = a;
      this.D = "";
    },
    $x = function (a, b) {
      a.J = b;
      return a;
    },
    Yx = function (a, b) {
      b = a.D + b;
      for (var c = b.indexOf("\n\n"); c !== -1; ) {
        var d = a,
          e;
        a: {
          var f = m(b.substring(0, c).split("\n")),
            g = f.next().value,
            h = f.next().value;
          if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0)
            try {
              e = JSON.parse(h.substring(h.indexOf(":") + 1));
              break a;
            } catch (l) {}
          e = void 0;
        }
        ay(d, e);
        b = b.substring(c + 2);
        c = b.indexOf("\n\n");
      }
      a.D = b;
    },
    by = function (a, b) {
      return function () {
        if (b.fallback_url && b.fallback_url_method) {
          var c = {};
          ay(
            a,
            ((c[b.fallback_url_method] = [b.fallback_url]),
            (c.options = {}),
            c),
          );
        }
      };
    },
    ay = function (a, b) {
      b &&
        (cy(b.send_pixel, b.options, a.N),
        cy(b.create_iframe, b.options, a.T),
        cy(b.fetch, b.options, a.J));
    };
  function dy(a) {
    var b = a.search;
    return (
      a.protocol +
      "//" +
      a.hostname +
      a.pathname +
      (b ? b + "&richsstsse" : "?richsstsse")
    );
  }
  function cy(a, b, c) {
    if (a && c) {
      var d = a || [];
      if (Array.isArray(d))
        for (
          var e = Id(b) ? b : {}, f = m(d), g = f.next();
          !g.done;
          g = f.next()
        )
          c(g.value, e);
    }
  }
  var Qg;
  function ey() {
    var a = data.permissions || {};
    Qg = new Pg(D(5), a);
  }
  function fy(a, b) {
    var c;
    (c = Qg) == null || Kg(c.D, a, b);
  }
  var gy = Ag(57, 5),
    hy = Ag(58, 50),
    iy = Jb();
  var ky = function (a, b) {
      a &&
        (jy("sid", a.targetId, b),
        jy("cc", a.clientCount, b),
        jy("tl", a.totalLifeMs, b),
        jy("hc", a.heartbeatCount, b),
        jy("cl", a.clientLifeMs, b));
    },
    jy = function (a, b, c) {
      b != null && c.push(a + "=" + b);
    },
    ly = function () {
      var a = A.referrer;
      if (a) {
        var b;
        return Jj(Pj(a), "host") ===
          ((b = w.location) == null ? void 0 : b.host)
          ? 1
          : 2;
      }
      return 0;
    },
    my = "https://" + D(21) + "/a?",
    oy = function () {
      this.V = ny;
      this.N = 0;
    };
  oy.prototype.J = function (a, b, c, d) {
    var e = ly(),
      f,
      g = [];
    f =
      w === w.top && e !== 0 && b
        ? (b == null ? void 0 : b.clientCount) > 1
          ? e === 2
            ? 1
            : 2
          : e === 2
            ? 0
            : 3
        : 4;
    a && jy("si", a.Bg, g);
    jy("m", 0, g);
    jy("iss", f, g);
    jy("if", c, g);
    ky(b, g);
    d && jy("fm", encodeURIComponent(d.substring(0, hy)), g);
    this.T(g);
  };
  oy.prototype.D = function (a, b, c, d, e) {
    var f = [];
    jy("m", 1, f);
    jy("s", a, f);
    jy("po", ly(), f);
    b && (jy("st", b.state, f), jy("si", b.Bg, f), jy("sm", b.Jg, f));
    ky(c, f);
    jy("c", d, f);
    e && jy("fm", encodeURIComponent(e.substring(0, hy)), f);
    this.T(f);
  };
  oy.prototype.T = function (a) {
    a = a === void 0 ? [] : a;
    !bl ||
      this.N >= gy ||
      (jy("pid", iy, a),
      jy("bc", ++this.N, a),
      a.unshift("ctid=" + D(5) + "&t=s"),
      this.V("" + my + a.join("&")));
  };
  function py(a) {
    return (a.performance && a.performance.now()) || Date.now();
  }
  var ry = function (a, b) {
    var c = w,
      d = qy,
      e;
    var f = function (g, h, l) {
      l =
        l === void 0
          ? {
              Ln: function () {},
              Nn: function () {},
              Kn: function () {},
              onFailure: function () {},
            }
          : l;
      this.jj = g;
      this.D = h;
      this.N = l;
      this.fa = this.ma = this.heartbeatCount = this.ij = 0;
      this.Uc = !1;
      this.J = {};
      this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
      this.state = 0;
      this.Bg = py(this.D);
      this.Jg = py(this.D);
      this.V = 10;
    };
    f.prototype.init = function () {
      this.T(1);
      this.Sa();
    };
    f.prototype.getState = function () {
      return {
        state: this.state,
        Bg: Math.round(py(this.D) - this.Bg),
        Jg: Math.round(py(this.D) - this.Jg),
      };
    };
    f.prototype.T = function (g) {
      this.state !== g && ((this.state = g), (this.Jg = py(this.D)));
    };
    f.prototype.Md = function () {
      return String(this.ij++);
    };
    f.prototype.Sa = function () {
      var g = this;
      this.heartbeatCount++;
      this.mg(
        {
          type: 0,
          clientId: this.id,
          requestId: this.Md(),
          maxDelay: this.Ld(),
        },
        function (h) {
          if (h.type === 0) {
            var l;
            if (((l = h.failure) == null ? void 0 : l.failureType) != null)
              if (
                (h.stats && (g.stats = h.stats),
                g.fa++,
                h.isDead || g.fa > d.Gm)
              ) {
                var n = h.isDead && h.failure.failureType;
                g.V = n || 10;
                g.T(4);
                g.gj();
                var p, q;
                (q = (p = g.N).Kn) == null ||
                  q.call(p, { failureType: n || 10, data: h.failure.data });
              } else (g.T(3), g.jg());
            else {
              if (g.heartbeatCount > h.stats.heartbeatCount + d.Gm) {
                g.heartbeatCount = h.stats.heartbeatCount;
                var r, t;
                (t = (r = g.N).onFailure) == null ||
                  t.call(r, { failureType: 13 });
              }
              g.stats = h.stats;
              var u = g.state;
              g.T(2);
              if (u !== 2)
                if (g.Uc) {
                  var v, x;
                  (x = (v = g.N).Nn) == null || x.call(v);
                } else {
                  g.Uc = !0;
                  var y, z;
                  (z = (y = g.N).Ln) == null || z.call(y);
                }
              g.fa = 0;
              g.kj();
              g.jg();
            }
          }
        },
      );
    };
    f.prototype.Ld = function () {
      return this.state === 2 ? d.Pp : d.lq;
    };
    f.prototype.jg = function () {
      var g = this;
      this.D.setTimeout(
        function () {
          g.Sa();
        },
        Math.max(0, this.Ld() - (py(this.D) - this.ma)),
      );
    };
    f.prototype.qq = function (g, h, l) {
      var n = this;
      this.mg(
        { type: 1, clientId: this.id, requestId: this.Md(), command: g },
        function (p) {
          if (p.type === 1)
            if (p.result) h(p.result);
            else {
              var q,
                r,
                t,
                u = {
                  failureType:
                    (t = (q = p.failure) == null ? void 0 : q.failureType) !=
                    null
                      ? t
                      : 12,
                  data: (r = p.failure) == null ? void 0 : r.data,
                },
                v,
                x;
              (x = (v = n.N).onFailure) == null || x.call(v, u);
              l(u);
            }
        },
      );
    };
    f.prototype.mg = function (g, h) {
      var l = this;
      if (this.state === 4) ((g.failure = { failureType: this.V }), h(g));
      else {
        var n = this.state !== 2 && g.type !== 0,
          p = g.requestId,
          q,
          r = this.D.setTimeout(
            function () {
              var u = l.J[p];
              u && (cn(6), l.Xb(u, 7));
            },
            (q = g.maxDelay) != null ? q : d.Ao,
          ),
          t = { request: g, Yn: h, Sn: n, Hr: r };
        this.J[p] = t;
        n || this.sendRequest(t);
      }
    };
    f.prototype.sendRequest = function (g) {
      this.ma = py(this.D);
      g.Sn = !1;
      this.jj(g.request);
    };
    f.prototype.kj = function () {
      for (
        var g = m(Object.keys(this.J)), h = g.next();
        !h.done;
        h = g.next()
      ) {
        var l = this.J[h.value];
        l.Sn && this.sendRequest(l);
      }
    };
    f.prototype.gj = function () {
      for (var g = m(Object.keys(this.J)), h = g.next(); !h.done; h = g.next())
        this.Xb(this.J[h.value], this.V);
    };
    f.prototype.Xb = function (g, h) {
      this.rb(g);
      var l = g.request;
      l.failure = { failureType: h };
      g.Yn(l);
    };
    f.prototype.rb = function (g) {
      delete this.J[g.request.requestId];
      this.D.clearTimeout(g.Hr);
    };
    f.prototype.kr = function (g) {
      this.ma = py(this.D);
      var h = this.J[g.requestId];
      if (h) (this.rb(h), h.Yn(g));
      else {
        var l, n;
        (n = (l = this.N).onFailure) == null || n.call(l, { failureType: 14 });
      }
    };
    e = new f(a, c, b);
    return e;
  };
  var sy;
  var ty = function () {
      sy || (sy = new oy());
      return sy;
    },
    ny = function (a) {
      zm(Bm(bm.ba.Ac), function () {
        gd(a);
      });
    },
    uy = function (a) {
      var b = a.substring(0, a.indexOf("/_/service_worker"));
      return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "");
    },
    vy = function (a) {
      var b = a,
        c,
        d = yg(11);
      d = yg(10);
      c = d;
      b
        ? (b.charAt(b.length - 1) !== "/" && (b += "/"), (a = b + c))
        : (a =
            "https://www.googletagmanager.com/static/service_worker/" +
            c +
            "/");
      var e;
      try {
        e = new URL(a);
      } catch (f) {
        return null;
      }
      return e.protocol !== "https:" ? null : e;
    },
    wy = function (a) {
      var b = w.location.origin;
      if (!b) return null;
      (N(432) ? Uj() : Uj() && !a) && (a = "" + b + Vj() + "/_/service_worker");
      return vy(a);
    },
    xy = function (a) {
      var b = Gm(Cm.aa.Rm);
      return b && b[a];
    },
    qy = { lq: Ag(53, 500), Pp: Ag(54, 5e3), Gm: Ag(8, 20), Ao: Ag(55, 5e3) },
    yy = function (a) {
      var b = this;
      this.J = ty();
      this.V = this.T = !1;
      this.fa = null;
      this.initTime = Math.round(Tb());
      this.D = 15;
      this.N = this.Iq(a);
      w.setTimeout(function () {
        b.initialize();
      }, 1e3);
      jd(function () {
        b.yr(a);
      });
    };
  k = yy.prototype;
  k.delegate = function (a, b, c) {
    this.getState() !== 2
      ? (this.J.D(
          this.D,
          {
            state: this.getState(),
            Bg: this.initTime,
            Jg: Math.round(Tb()) - this.initTime,
          },
          void 0,
          a.commandType,
        ),
        c({ failureType: this.D }))
      : this.N.qq(a, b, c);
  };
  k.getState = function () {
    return this.N.getState().state;
  };
  k.yr = function (a) {
    var b = w.location.origin,
      c = this,
      d = ed();
    try {
      var e = d.contentDocument.createElement("iframe"),
        f = a.pathname,
        g = f[f.length - 1] === "/" ? a.toString() : a.toString() + "/",
        h = a.origin !== "https://www.googletagmanager.com" ? uy(f) : "",
        l;
      N(133) && (l = { sandbox: "allow-same-origin allow-scripts" });
      ed(
        g + "sw_iframe.html?origin=" + encodeURIComponent(b) + h,
        void 0,
        l,
        void 0,
        e,
      );
      var n = function () {
        d.contentDocument.body.appendChild(e);
        e.addEventListener("load", function () {
          c.fa = e.contentWindow;
          d.contentWindow.addEventListener("message", function (p) {
            p.origin === a.origin && c.N.kr(p.data);
          });
          c.initialize();
        });
      };
      d.contentDocument.readyState === "complete"
        ? n()
        : d.contentWindow.addEventListener("load", function () {
            n();
          });
    } catch (p) {
      (d.parentElement.removeChild(d),
        (this.D = 11),
        this.J.J(void 0, void 0, this.D, p.toString()));
    }
  };
  k.Iq = function (a) {
    var b = this,
      c = ry(
        function (d) {
          var e;
          (e = b.fa) == null || e.postMessage(d, a.origin);
        },
        {
          Ln: function () {
            b.T = !0;
            b.J.J(c.getState(), c.stats);
          },
          Nn: function () {},
          Kn: function (d) {
            b.T
              ? ((b.D = (d == null ? void 0 : d.failureType) || 10),
                b.J.D(
                  b.D,
                  c.getState(),
                  c.stats,
                  void 0,
                  d == null ? void 0 : d.data,
                ))
              : ((b.D = (d == null ? void 0 : d.failureType) || 4),
                b.J.J(c.getState(), c.stats, b.D, d == null ? void 0 : d.data));
          },
          onFailure: function (d) {
            b.D = d.failureType;
            b.J.D(b.D, c.getState(), c.stats, d.command, d.data);
          },
        },
      );
    return c;
  };
  k.initialize = function () {
    this.V || this.N.init();
    this.V = !0;
  };
  function zy() {
    var a = Mg(Qg.D, "", function () {
      return {};
    });
    try {
      return (a("internal_sw_allowed"), !0);
    } catch (b) {
      return !1;
    }
  }
  function Ay(a) {
    var b;
    b = (a === void 0 ? {} : a).bs;
    var c = wy(b);
    if (c === null || !zy() || xy(c.origin)) return;
    if (!Sc()) {
      ty().J(void 0, void 0, 6);
      return;
    }
    var d = new yy(c);
    Hm(Cm.aa.Rm, {})[c.origin] = d;
  }
  var By = function (a, b, c, d) {
    var e;
    if ((e = xy(a)) == null || !e.delegate) {
      var f = Sc() ? 16 : 6;
      ty().D(f, void 0, void 0, b.commandType);
      d({ failureType: f });
      return;
    }
    xy(a).delegate(b, c, d);
  };
  function Cy(a, b, c, d, e) {
    var f = N(277) ? wy() : vy();
    if (f === null) {
      d(Sc() ? 16 : 6);
      return;
    }
    var g,
      h = (g = xy(f.origin)) == null ? void 0 : g.initTime,
      l = Math.round(Tb());
    By(
      f.origin,
      {
        commandType: 0,
        params: {
          url: a,
          method: 0,
          templates: b,
          body: "",
          processResponse: !1,
          sinceInit: h ? l - h : void 0,
          encryptionKeyString: e,
          reportEarlySuccess: N(441),
        },
      },
      function (n) {
        c(n);
      },
      function (n) {
        d(n.failureType);
      },
    );
  }
  function Dy(a, b, c, d) {
    var e = wy(a);
    if (e === null) {
      d("_is_sw=f" + (Sc() ? 16 : 6) + "te");
      return;
    }
    var f = b ? 1 : 0,
      g = Math.round(Tb()),
      h,
      l = (h = xy(e.origin)) == null ? void 0 : h.initTime,
      n = l ? g - l : void 0,
      p = N(412),
      q;
    N(432) ? (q = Uj() ? void 0 : w.location.href) : (q = w.location.href);
    By(
      e.origin,
      {
        commandType: 0,
        params: {
          url: a,
          method: f,
          templates: c,
          body: b || "",
          processResponse: !0,
          reportEarlySuccess: p,
          sinceInit: n,
          attributionReporting: !0,
          referer: q,
        },
      },
      function () {},
      function (r) {
        var t = "_is_sw=f" + r.failureType,
          u,
          v = (u = xy(e.origin)) == null ? void 0 : u.getState();
        v !== void 0 && (t += "s" + v);
        d(n ? t + ("t" + n) : t + "te");
      },
    );
  }
  var Ey = Ba(
      [
        '\n\'use strict\';const g=Object.freeze({cache:"no-store",credentials:"include",method:"GET",keepalive:!0,redirect:"follow"});async function h(b,a){const c=a.data?.url;if(c){a=[0,...(a.data.retryIntervals||[])];for(let d=0;d<a.length;++d){const e=a[d];e>0&&await new Promise(f=>{setTimeout(f,e)});try{await b.fetch(k(c,d),g);break}catch(f){}}}}function k(b,a){if(a===0)return b;b=new URL(b);b.searchParams.set("gap.shw_rt",`${a}`);return b.toString()}(function(b){b.onconnect=a=>{a=a.ports[0];a.onmessage=c=>h(b,c);a.start()}})(self);\n\n',
      ],
      [
        '\n\'use strict\';const g=Object.freeze({cache:"no-store",credentials:"include",method:"GET",keepalive:!0,redirect:"follow"});async function h(b,a){const c=a.data?.url;if(c){a=[0,...(a.data.retryIntervals||[])];for(let d=0;d<a.length;++d){const e=a[d];e>0&&await new Promise(f=>{setTimeout(f,e)});try{await b.fetch(k(c,d),g);break}catch(f){}}}}function k(b,a){if(a===0)return b;b=new URL(b);b.searchParams.set("gap.shw_rt",\\`\\${a}\\`);return b.toString()}(function(b){b.onconnect=a=>{a=a.ports[0];a.onmessage=c=>h(b,c);a.start()}})(self);\n\n',
      ],
    ),
    Fy,
    Gy = Ey.join(""),
    Hy = pc(),
    Ic = Hy ? Hy.createScript(Gy) : Gy;
  Fy = new Jc();
  var Iy = Ca(["about:blank"]),
    Jy = Object.freeze([500, 1500, 5e3, 3e4]);
  function Ky(a) {
    if (N(460)) {
      var b = Ly().instance;
      b && b.port.postMessage({ url: a, retryIntervals: Jy });
    }
  }
  function Ly() {
    var a = Gm(Cm.aa.Wm);
    return a ? a : Hm(Cm.aa.Wm, My());
  }
  function My() {
    try {
      if (!("SharedWorker" in w)) return {};
      var a = yg(62),
        b;
      if (a && A.head) {
        var c = Jq("META");
        A.head.appendChild(c);
        c.httpEquiv = "origin-trial";
        c.content = a;
        b = c;
      } else b = null;
      if (!b || !Ny()) return {};
      var d, e;
      if (Fy instanceof Jc) e = Fy.D;
      else throw Error("");
      d = rc(
        URL.createObjectURL(
          new Blob([e.toString()], { type: "text/javascript" }),
        ),
      );
      var f = Oc(d, { name: "gtm", extendedLifetime: !0 });
      f.port.start();
      return { instance: f };
    } catch (g) {
      return {};
    }
  }
  function Ny() {
    var a = !1;
    try {
      Oc(Gq(Iy), {
        get extendedLifetime() {
          return (a = !0);
        },
      });
    } catch (b) {}
    return a;
  }
  var Oy = function (a, b) {
      this.Lr = a;
      this.timeoutMs = b;
      this.Va = void 0;
    },
    Rl = function (a) {
      a.Va ||
        (a.Va = setTimeout(function () {
          a.Lr();
          a.Va = void 0;
        }, a.timeoutMs));
    },
    Sl = function (a) {
      a.Va && (clearTimeout(a.Va), (a.Va = void 0));
    };
  var Py = function () {
      this.Ir = Ag(66, 0);
      this.Lg = bb();
    },
    Qy = function (a) {
      var b = a.match(Kl)[3] || null,
        c = (b ? decodeURI(b) : b) || "",
        d = Nl(a, "label") || "",
        e = Nl(a, "random") || "";
      return c + ":" + Jl(d) + ":" + Jl(e);
    };
  Py.prototype.mg = function (a, b, c) {
    var d = Qy(a);
    if (!(this.Lg.has(d) || this.Lg.size >= this.Ir)) {
      var e = {};
      b && b > 0 && c && (e.ho = new Oy(c, b));
      this.Lg.set(d, e);
      var f;
      (f = e.ho) == null || Rl(f);
    }
  };
  var Tl = function (a, b) {
    var c = Qy(b),
      d,
      e;
    (d = a.Lg.get(c)) == null || (e = d.ho) == null || Sl(e);
    a.Lg.delete(c);
  };
  function qz() {
    return xo("dedupe_gclid", function () {
      return ss();
    });
  }
  var vz = { Ti: { so: "1", Gp: "2", fq: "3" } };
  function Az(a, b, c, d) {
    var e = dd(),
      f;
    if (e === 1)
      a: {
        var g = D(3);
        g = g.toLowerCase();
        for (
          var h = "https://" + g,
            l = "http://" + g,
            n = 1,
            p = A.getElementsByTagName("script"),
            q = 0;
          q < p.length && q < 100;
          q++
        ) {
          var r = p[q].src;
          if (r) {
            r = r.toLowerCase();
            if (r.indexOf(l) === 0) {
              f = 3;
              break a;
            }
            n === 1 && r.indexOf(h) === 0 && (n = 2);
          }
        }
        f = n;
      }
    else f = e;
    return (f === 2 || d || "http:" !== w.location.protocol ? a : b) + c;
  }
  function Bz(a, b, c, d, e) {
    if (!Ck(a)) {
      d.loadExperiments = sj();
      Fk(a, d, e);
      var f = Cz(a),
        g = function () {
          mk().container[a] && (mk().container[a].state = 3);
          Dz();
        },
        h = { destinationId: a, endpoint: 0 };
      if (Uj()) Yl(h, Vj() + "/" + Ez(f), void 0, g);
      else {
        var l = Yb(a, "GTM-"),
          n = Zj(),
          p = c ? "/gtag/js" : "/gtm.js",
          q = Fz(b, p + f);
        if (!q) {
          var r = D(3) + p;
          n &&
            Uc &&
            l &&
            (r = Uc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
          q = Az("https://", "http://", r + f);
        }
        Yl(h, q, void 0, g);
      }
    }
  }
  function Dz() {
    Gk() ||
      Mb(Hk(), function (a, b) {
        Gz(a, b.transportUrl, b.context);
        O(92);
      });
  }
  function Gz(a, b, c, d) {
    if (!Ek(a))
      if ((c.loadExperiments || (c.loadExperiments = sj()), Gk())) {
        var e = mk(),
          f = lk(a);
        f
          ? (f.state = 0)
          : ((f = { state: 0, transportUrl: b, context: c, parent: xk() }),
            (e.destinationArray[a] = [f]));
        nk({ ctid: a, isDestination: !0 }, d);
        O(91);
      } else {
        var g = mk(),
          h = lk(a);
        h
          ? (h.state = 1)
          : ((h = { context: c, state: 1, parent: xk() }),
            (g.destinationArray[a] = [h]));
        nk({ ctid: a, isDestination: !0 }, d);
        var l = { destinationId: a, endpoint: 0 };
        if (Uj()) {
          var n = "gtd" + Cz(a, !0);
          Yl(l, Vj() + "/" + Ez(n));
        } else {
          var p = "/gtag/destination" + Cz(a, !0),
            q = Fz(b, p);
          q || (q = Az("https://", "http://", D(3) + p));
          Yl(l, q);
        }
      }
  }
  function Cz(a, b) {
    b = b === void 0 ? !1 : b;
    var c = "?id=" + encodeURIComponent(a),
      d = D(19);
    d !== "dataLayer" && (c += "&l=" + d);
    if (!Yb(a, "GTM-") || b) c += "&cx=c";
    var e = c,
      f,
      g = { Vn: wg(15), Zn: D(14) };
    f = Df(g);
    c = e + ("&gtm=" + f);
    Zj() && (c += "&sign=" + uj.Zi);
    var h = c,
      l = wg(54);
    if (l === 1) {
      if (((h += "&fps=fc"), N(429))) {
        var n = D(60);
        n && (h += "&gdev=" + n);
      }
    } else l === 2 && (h += "&fps=fe");
    return h;
  }
  function Ez(a) {
    if (!N(413)) return a;
    var b = D(58);
    if (!b) return (O(182), a);
    try {
      return Ff(a, b);
    } catch (c) {
      return (O(183), a);
    }
  }
  function Fz(a, b) {
    if (!N(419)) return Xj(a, b);
    if (Yj() && a) {
      var c = D(58),
        d = D(18);
      if (c && d)
        try {
          b = d + "/" + Ff(b, c);
        } catch (e) {
          O(183);
        }
      return Wj(a, b);
    }
  }
  var Hz = new RegExp(
      /^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/,
    ),
    Iz = {
      cl: ["ecl"],
      customPixels: ["nonGooglePixels"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: [
        "customScripts",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      customScripts: [
        "html",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGooglePixels: [],
      nonGoogleScripts: ["nonGooglePixels"],
      nonGoogleIframes: ["nonGooglePixels"],
    },
    Jz = {
      cl: ["ecl"],
      customPixels: ["customScripts", "html"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: ["customScripts"],
      customScripts: ["html"],
      nonGooglePixels: [
        "customPixels",
        "customScripts",
        "html",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGoogleScripts: ["customScripts", "html"],
      nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"],
    },
    Kz =
      "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(
        " ",
      );
  function Lz() {
    var a = Mp("gtm.allowlist") || Mp("gtm.whitelist");
    a && O(9);
    yj &&
      (N(212)
        ? (a = void 0)
        : (a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"]));
    Hz.test(w.location && w.location.hostname) &&
      (yj
        ? O(116)
        : (O(117),
          vg(48) &&
            ((a = []),
            window.console &&
              window.console.log &&
              window.console.log("GTM blocked. See go/13687728."))));
    var b = a && Xb(Qb(a), Iz),
      c = Mp("gtm.blocklist") || Mp("gtm.blacklist");
    c || ((c = Mp("tagTypeBlacklist")) && O(3));
    c ? O(8) : (c = []);
    Hz.test(w.location && w.location.hostname) &&
      ((c = Qb(c)),
      c.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
    Qb(c).indexOf("google") >= 0 && O(2);
    var d = c && Xb(Qb(c), Jz),
      e = {};
    return function (f) {
      var g = f && f[Hf.Ya];
      if (!g || typeof g !== "string") return !0;
      g = g.replace(/^_*/, "");
      if (e[g] !== void 0) return e[g];
      var h = Cj[g] || [],
        l = !0;
      if (a) {
        var n;
        if ((n = l))
          a: {
            if (b.indexOf(g) < 0) {
              if (yj && h.indexOf("cmpPartners") >= 0) {
                n = !0;
                break a;
              }
              if (h && h.length > 0)
                for (var p = 0; p < h.length; p++) {
                  if (b.indexOf(h[p]) < 0) {
                    O(11);
                    n = !1;
                    break a;
                  }
                }
              else {
                n = !1;
                break a;
              }
            }
            n = !0;
          }
        l = n;
      }
      var q = !1;
      if (c) {
        var r = d.indexOf(g) >= 0;
        if (r) q = r;
        else {
          var t = Kb(d, h || []);
          t && O(10);
          q = t;
        }
      }
      var u = !l || q;
      !u &&
        (h.indexOf("sandboxedScripts") === -1
          ? 0
          : yj && h.indexOf("cmpPartners") >= 0
            ? !Mz()
            : b && b.indexOf("sandboxedScripts") !== -1
              ? 0
              : Kb(d, Kz)) &&
        (u = !0);
      return (e[g] = u);
    };
  }
  function Mz() {
    var a = Mg(Qg.D, D(5), function () {
      return {};
    });
    try {
      return (a("inject_cmp_banner"), !0);
    } catch (b) {
      return !1;
    }
  }
  var Nz = function () {
    this.J = 0;
    this.D = {};
  };
  Nz.prototype.addListener = function (a, b, c) {
    var d = ++this.J;
    this.D[a] = this.D[a] || {};
    this.D[a][String(d)] = { listener: b, Ze: c };
    return d;
  };
  Nz.prototype.removeListener = function (a, b) {
    var c = this.D[a],
      d = String(b);
    if (!c || !c[d]) return !1;
    delete c[d];
    return !0;
  };
  var Pz = function (a, b) {
    var c = [];
    Mb(Oz.D[a], function (d, e) {
      c.indexOf(e.listener) < 0 &&
        (e.Ze === void 0 || b.indexOf(e.Ze) >= 0) &&
        c.push(e.listener);
    });
    return c;
  };
  function Qz(a, b, c) {
    return {
      entityType: a,
      indexInOriginContainer: b,
      nameInOriginContainer: c,
      originContainerId: D(5),
      originCId: tk(),
    };
  }
  function Rz(a, b) {
    if (data.entities) {
      var c = data.entities[a];
      if (c) return c[b];
    }
  }
  var Tz = function (a, b) {
      this.D = !1;
      this.T = [];
      this.eventData = { tags: [] };
      this.V = !1;
      this.J = this.N = 0;
      Sz(this, a, b);
    },
    Uz = function (a, b, c, d) {
      if (wj.hasOwnProperty(b) || b === "__zone") return -1;
      var e = {};
      Id(d) && (e = Jd(d, e));
      e.id = c;
      e.status = "timeout";
      return a.eventData.tags.push(e) - 1;
    },
    Vz = function (a, b, c, d) {
      var e = a.eventData.tags[b];
      e && ((e.status = c), (e.executionTime = d));
    },
    Wz = function (a) {
      if (!a.D) {
        for (var b = a.T, c = 0; c < b.length; c++) b[c]();
        a.D = !0;
        a.T.length = 0;
      }
    },
    Sz = function (a, b, c) {
      b !== void 0 && a.lg(b);
      c &&
        w.setTimeout(function () {
          Wz(a);
        }, Number(c));
    };
  Tz.prototype.lg = function (a) {
    var b = this,
      c = Vb(function () {
        jd(function () {
          a(D(5), b.eventData);
        });
      });
    this.D ? c() : this.T.push(c);
  };
  var Xz = function (a) {
      a.N++;
      return Vb(function () {
        a.J++;
        a.V && a.J >= a.N && Wz(a);
      });
    },
    Yz = function (a) {
      a.V = !0;
      a.J >= a.N && Wz(a);
    };
  var Zz = {};
  function $z() {
    return w[aA()];
  }
  var bA = function (a) {
      if (nm()) {
        var b = $z();
        b(a + "require", "linker");
        b(a + "linker:passthrough", !0);
      }
    },
    cA = function (a) {
      var b = w;
      b.GoogleAnalyticsObject || (b.GoogleAnalyticsObject = a || "ga");
      var c = b.GoogleAnalyticsObject;
      if (b[c]) b.hasOwnProperty(c);
      else {
        var d = function () {
          var e = Qa.apply(0, arguments);
          d.q = d.q || [];
          d.q.push(e);
        };
        d.l = Number(Sb());
        b[c] = d;
      }
      return b[c];
    };
  function aA() {
    return w.GoogleAnalyticsObject || "ga";
  }
  function dA() {
    var a = D(5);
  }
  function eA(a, b) {
    return function () {
      var c = $z(),
        d = c && c.getByName && c.getByName(a);
      if (d) {
        var e = d.get("sendHitTask");
        d.set("sendHitTask", function (f) {
          var g = f.get("hitPayload"),
            h = f.get("hitCallback"),
            l = g.indexOf("&tid=" + b) < 0;
          l &&
            (f.set(
              "hitPayload",
              g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b),
              !0,
            ),
            f.set("hitCallback", void 0, !0));
          e(f);
          l &&
            (f.set("hitPayload", g, !0),
            f.set("hitCallback", h, !0),
            f.set("_x_19", void 0, !0),
            e(f));
        });
      }
    };
  }
  var kA = ["es", "1"],
    lA = {},
    mA = {};
  function nA(a, b) {
    if (bl) {
      var c;
      c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
      lA[a] = [
        ["e", c],
        ["eid", a],
      ];
      gq(a);
    }
  }
  function oA(a) {
    var b = a.eventId,
      c = a.Ng;
    if (!lA[b]) return [];
    var d = [];
    mA[b] || d.push(kA);
    d.push.apply(d, Aa(lA[b]));
    c && (mA[b] = !0);
    return d;
  }
  var pA = {};
  function qA(a, b, c) {
    pA[a] != null || (pA[a] = {});
    var d;
    (d = pA[a])[c] != null || (d[c] = {});
    pA[a][c][b] = (pA[a][c][b] || 0) + 1;
  }
  var rA = {},
    sA = {};
  function tA(a, b, c) {
    if (bl && b) {
      var d = Zk(b);
      rA[a] = rA[a] || [];
      rA[a].push(c + d);
      var e = b[Hf.Ya];
      if (!e) throw Error("Error: No function name given for function call.");
      var f = (jg[e] ? "1" : "2") + d;
      sA[a] = sA[a] || [];
      sA[a].push(f);
      gq(a);
    }
  }
  function uA(a) {
    var b = a.eventId,
      c = a.Ng,
      d = [],
      e = rA[b] || [];
    e.length && d.push(["tr", e.join(".")]);
    var f = sA[b] || [];
    f.length && d.push(["ti", f.join(".")]);
    c && (delete rA[b], delete sA[b]);
    return d;
  }
  function vA(a, b, c) {
    c = c === void 0 ? !1 : c;
    wA().addRestriction(0, a, b, c);
  }
  function xA(a, b, c) {
    c = c === void 0 ? !1 : c;
    wA().addRestriction(1, a, b, c);
  }
  function yA() {
    var a = tk();
    return wA().getRestrictions(1, a);
  }
  var zA = function () {
      this.container = {};
      this.D = {};
    },
    AA = function (a, b) {
      var c = a.container[b];
      c ||
        ((c = {
          _entity: { internal: [], external: [] },
          _event: { internal: [], external: [] },
        }),
        (a.container[b] = c));
      return c;
    };
  zA.prototype.addRestriction = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!d || !this.D[b]) {
      var e = AA(this, b);
      a === 0
        ? d
          ? e._entity.external.push(c)
          : e._entity.internal.push(c)
        : a === 1 &&
          (d ? e._event.external.push(c) : e._event.internal.push(c));
    }
  };
  zA.prototype.getRestrictions = function (a, b) {
    var c = AA(this, b);
    if (a === 0) {
      var d, e;
      return [].concat(
        Aa(
          (c == null
            ? void 0
            : (d = c._entity) == null
              ? void 0
              : d.internal) || [],
        ),
        Aa(
          (c == null
            ? void 0
            : (e = c._entity) == null
              ? void 0
              : e.external) || [],
        ),
      );
    }
    if (a === 1) {
      var f, g;
      return [].concat(
        Aa(
          (c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) ||
            [],
        ),
        Aa(
          (c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) ||
            [],
        ),
      );
    }
    return [];
  };
  zA.prototype.getExternalRestrictions = function (a, b) {
    var c = AA(this, b),
      d,
      e;
    return a === 0
      ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) ||
          []
      : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) ||
          [];
  };
  zA.prototype.removeExternalRestrictions = function (a) {
    var b = AA(this, a);
    b._event && (b._event.external = []);
    b._entity && (b._entity.external = []);
    this.D[a] = !0;
  };
  function wA() {
    return xo("r", function () {
      return new zA();
    });
  }
  function BA(a, b, c, d) {
    var e = hg[a],
      f = CA(a, b, c, d);
    if (!f) return null;
    var g = tg(e[Hf.Sm], c, []);
    if (g && g.length) {
      var h = g[0];
      f = BA(
        h.index,
        {
          onSuccess: f,
          onFailure: h.zn === 1 ? b.terminate : f,
          terminate: b.terminate,
        },
        c,
        d,
      );
    }
    return f;
  }
  function CA(a, b, c, d) {
    function e() {
      function x() {
        cn(3);
        var P = Tb() - K;
        Qz(1, a, hg[a][Hf.Ki]);
        tA(c.id, f, "7");
        Vz(c.Wc, E, "exception", P);
        N(109) && Ux(c, f, nx.R.bj);
        G || ((G = !0), h());
      }
      if (f[Hf.Xp]) h();
      else {
        var y = sg(f, c, []),
          z = y[Hf.uo];
        if (z != null)
          for (var C = 0; C < z.length; C++)
            if (!mo(z[C])) {
              h();
              return;
            }
        var E = Uz(c.Wc, String(f[Hf.Ya]), Number(f[Hf.Jh]), y[Hf.METADATA]),
          G = !1;
        y.vtp_gtmOnSuccess = function () {
          if (!G) {
            G = !0;
            var P = Tb() - K;
            tA(c.id, hg[a], "5");
            Vz(c.Wc, E, "success", P);
            N(109) && Ux(c, f, nx.R.dj);
            g();
          }
        };
        y.vtp_gtmOnFailure = function () {
          if (!G) {
            G = !0;
            var P = Tb() - K;
            tA(c.id, hg[a], "6");
            Vz(c.Wc, E, "failure", P);
            N(109) && Ux(c, f, nx.R.cj);
            h();
          }
        };
        y.vtp_gtmTagId = f.tag_id;
        y.vtp_gtmEventId = c.id;
        c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
        tA(c.id, f, "1");
        N(109) && Tx(c, f);
        var K = Tb();
        try {
          ug(y, { event: c, index: a, type: 1 });
        } catch (P) {
          x(P);
        }
        N(109) && Ux(c, f, nx.R.gn);
      }
    }
    var f = hg[a],
      g = b.onSuccess,
      h = b.onFailure,
      l = b.terminate;
    if (c.isBlocked(f)) return null;
    var n = tg(f[Hf.hn], c, []);
    if (n && n.length) {
      var p = n[0],
        q = BA(p.index, { onSuccess: g, onFailure: h, terminate: l }, c, d);
      if (!q) return null;
      g = q;
      h = p.zn === 2 ? l : q;
    }
    if (f[Hf.Jm] || f[Hf.Zp]) {
      var r = f[Hf.Jm] ? ig : c.xs,
        t = g,
        u = h;
      if (!r[a]) {
        var v = DA(a, r, Vb(e));
        g = v.onSuccess;
        h = v.onFailure;
      }
      return function () {
        r[a](t, u);
      };
    }
    return e;
  }
  function DA(a, b, c) {
    var d = [],
      e = [];
    b[a] = EA(d, e, c);
    return {
      onSuccess: function () {
        b[a] = FA;
        for (var f = 0; f < d.length; f++) d[f]();
      },
      onFailure: function () {
        b[a] = GA;
        for (var f = 0; f < e.length; f++) e[f]();
      },
    };
  }
  function EA(a, b, c) {
    return function (d, e) {
      a.push(d);
      b.push(e);
      c();
    };
  }
  function FA(a) {
    a();
  }
  function GA(a, b) {
    b();
  }
  var JA = function (a, b) {
    for (var c = [], d = 0; d < hg.length; d++)
      if (a[d]) {
        var e = hg[d];
        var f = Xz(b.Wc);
        try {
          var g = BA(d, { onSuccess: f, onFailure: f, terminate: f }, b, d);
          if (g) {
            var h = e[Hf.Ya];
            if (!h)
              throw Error("Error: No function name given for function call.");
            var l = jg[h];
            c.push({
              fo: d,
              priorityOverride:
                (l ? l.priorityOverride || 0 : 0) || Rz(e[Hf.Ya], 1) || 0,
              execute: g,
            });
          } else (HA(d, b), f());
        } catch (p) {
          f();
        }
      }
    c.sort(IA);
    for (var n = 0; n < c.length; n++) c[n].execute();
    return c.length > 0;
  };
  function KA(a, b) {
    if (!Oz) return !1;
    var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
      d = Pz(a.event, c ? String(c).split(",") : []);
    if (!d.length) return !1;
    for (var e = 0; e < d.length; ++e) {
      var f = Xz(b);
      try {
        d[e](a, f);
      } catch (g) {
        f();
      }
    }
    return !0;
  }
  function IA(a, b) {
    var c,
      d = b.priorityOverride,
      e = a.priorityOverride;
    c = d > e ? 1 : d < e ? -1 : 0;
    var f;
    if (c !== 0) f = c;
    else {
      var g = a.fo,
        h = b.fo;
      f = g > h ? 1 : g < h ? -1 : 0;
    }
    return f;
  }
  function HA(a, b) {
    if (bl) {
      var c = function (d) {
        var e = b.isBlocked(hg[d]) ? "3" : "4",
          f = tg(hg[d][Hf.Sm], b, []);
        f && f.length && c(f[0].index);
        tA(b.id, hg[d], e);
        var g = tg(hg[d][Hf.hn], b, []);
        g && g.length && c(g[0].index);
      };
      c(a);
    }
  }
  var LA = !1,
    Oz;
  function MA() {
    Oz || (Oz = new Nz());
    return Oz;
  }
  function NA(a) {
    var b = a["gtm.uniqueEventId"],
      c = a["gtm.priorityId"],
      d = a.event;
    if (N(109)) {
    }
    if (d === "gtm.js") {
      if (LA) return !1;
      LA = !0;
    }
    var e = !1,
      f = yA(),
      g = Jd(a, null);
    if (
      !f.every(function (t) {
        return t({ originalEventData: g });
      })
    ) {
      if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent")
        return !1;
      e = !0;
    }
    nA(b, d);
    var h = a.eventCallback,
      l = a.eventTimeout,
      n = {
        id: b,
        priorityId: c,
        name: d,
        isBlocked: OA(g, e),
        xs: [],
        logMacroError: function (t, u, v) {
          O(6);
          cn(4);
          Qz(2, u, v);
        },
        cachedModelValues: PA(),
        Wc: new Tz(function () {
          if (N(109)) {
          }
          gw(5, d);
          h && h.apply(h, Array.prototype.slice.call(arguments, 0));
        }, l),
        originalEventData: g,
      };
    N(109) && Qx(n.id);
    var p = Fg(n);
    N(109) && Rx(n.id);
    gw(2, d);
    e && (p = QA(p));
    N(109) && Px(b);
    var q = JA(p, n);
    q && gw(4, d);
    var r = KA(a, n.Wc);
    Yz(n.Wc);
    (d !== "gtm.js" && d !== "gtm.sync") || dA();
    return RA(p, q) || r;
  }
  function PA() {
    var a = {};
    a.event = Rp("event", 1);
    a.ecommerce = Rp("ecommerce", 1);
    a.gtm = Rp("gtm");
    a.eventModel = Rp("eventModel");
    return a;
  }
  function OA(a, b) {
    var c = Lz();
    return function (d) {
      var e = c(d);
      if ((!yj || !N(407)) && e) return !0;
      var f = d && d[Hf.Ya];
      if (!f || typeof f !== "string") return !0;
      f = f.replace(/^_*/, "");
      e && yj && N(407) && bl && qA(Number(a["gtm.uniqueEventId"]), f, "bl");
      var g,
        h = tk();
      g = wA().getRestrictions(0, h);
      var l = a;
      b &&
        ((l = Jd(a, null)), (l["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER));
      for (
        var n = !1, p = Cj[f] || [], q = m(g), r = q.next();
        !r.done;
        r = q.next()
      ) {
        var t = r.value;
        try {
          t({ entityId: f, securityGroups: p, originalEventData: l }) ||
            (n = !0);
        } catch (u) {
          n = !0;
        }
      }
      return n || e;
    };
  }
  function QA(a) {
    for (var b = [], c = 0; c < a.length; c++)
      if (a[c]) {
        var d = String(hg[c][Hf.Ya]);
        if (vj[d] || hg[c][Hf.aq] !== void 0 || Rz(d, 2)) b[c] = !0;
      }
    return b;
  }
  function RA(a, b) {
    if (!b) return b;
    for (var c = 0; c < a.length; c++)
      if (a[c] && hg[c] && !wj[String(hg[c][Hf.Ya])]) return !0;
    return !1;
  }
  var SA = Ag(61, 2e3),
    oo = ["ad_storage", "analytics_storage"];
  function TA(a) {
    a &&
      (a === 2 && UA() === 3 && (a = 4),
      (wo.gth = { l: VA, s: a }),
      ro(function () {
        var b = function () {
          Dr("gtg_load_status", { status: a, expires: Date.now() + 864e5 });
        };
        no() ? b() : rm(Vb(b), oo);
      }, oo));
  }
  function WA(a) {
    a = a === void 0 ? !1 : a;
    if (N(439) && Yj()) {
      var b = Gr("gtg_load_status"),
        c = b.value,
        d =
          a &&
          Gb(c == null ? void 0 : c.expires) &&
          (c == null ? void 0 : c.expires) < Date.now() + 36e5;
      return b.error === 0 && Gb(c == null ? void 0 : c.status) && !d
        ? c == null
          ? void 0
          : c.status
        : UA();
    }
  }
  function UA() {
    var a;
    return (a = wo.gth) == null ? void 0 : a.s;
  }
  function XA() {
    UA() === 1 && TA(3);
  }
  function VA() {
    TA(2);
  }
  function YA() {
    if (!WA(!0)) {
      wo.gth = { l: VA, s: 1 };
      var a = D(5),
        b = Yb(a, "GTM-") ? "/gtm.js" : "/gtag/js",
        c = "https://" + D(3) + b + "?id=" + a + "&gtg_health=1";
      cd(c, XA, XA);
      w.setTimeout(XA, SA);
    }
  }
  function ZA() {
    MA().addListener("gtm.init", function (a, b) {
      qj.J = !0;
      if (N(439) && Yj()) {
        var c = Bm(bm.ba.Ac);
        xm(c) ? zm(c, YA) : YA();
      }
      Om();
      b();
    });
  }
  function $A() {
    if (wo.pscdl !== void 0) Gm(Cm.aa.gi) === void 0 && Fm(Cm.aa.gi, wo.pscdl);
    else {
      var a = function (c) {
          wo.pscdl = c;
          Fm(Cm.aa.gi, c);
        },
        b = function () {
          a("error");
        };
      try {
        Rc.cookieDeprecationLabel
          ? (a("pending"),
            Rc.cookieDeprecationLabel.getValue().then(a).catch(b))
          : a("noapi");
      } catch (c) {
        b(c);
      }
    }
  }
  var aB = !1,
    bB = 0,
    cB = [];
  function dB(a) {
    if (!aB) {
      var b = A.createEventObject,
        c = A.readyState === "complete",
        d = A.readyState === "interactive";
      if (!a || a.type !== "readystatechange" || c || (!b && d)) {
        aB = !0;
        for (var e = 0; e < cB.length; e++) jd(cB[e]);
      }
      cB.push = function () {
        for (var f = Qa.apply(0, arguments), g = 0; g < f.length; g++) jd(f[g]);
        return 0;
      };
    }
  }
  function eB() {
    if (!aB && bB < 140) {
      bB++;
      try {
        var a, b;
        (b = (a = A.documentElement).doScroll) == null || b.call(a, "left");
        dB();
      } catch (c) {
        w.setTimeout(eB, 50);
      }
    }
  }
  function fB() {
    var a = w;
    aB = !1;
    bB = 0;
    if (
      (A.readyState === "interactive" && !A.createEventObject) ||
      A.readyState === "complete"
    )
      dB();
    else {
      hd(A, "DOMContentLoaded", dB);
      hd(A, "readystatechange", dB);
      if (A.createEventObject && A.documentElement.doScroll) {
        var b = !0;
        try {
          b = !a.frameElement;
        } catch (c) {}
        b && eB();
      }
      hd(a, "load", dB);
    }
  }
  function gB(a) {
    aB ? a() : cB.push(a);
  }
  function hB(a, b) {
    a.hasOwnProperty("gtm.uniqueEventId") ||
      Object.defineProperty(a, "gtm.uniqueEventId", { value: Co() });
    b.eventId = a["gtm.uniqueEventId"];
    b.priorityId = a["gtm.priorityId"];
    return { eventId: b.eventId, priorityId: b.priorityId };
  }
  function iB(a) {
    for (var b = m([J.m.yd, J.m.Rc]), c = b.next(); !c.done; c = b.next()) {
      var d = c.value,
        e = (a && a[d]) || pq.D[d];
      if (e) return e;
    }
  }
  function jB(a) {
    return !a.isGtmEvent ||
      (a.eventMetadata &&
        a.eventMetadata[R.C.qb] &&
        a.eventMetadata[R.C.Ta] !== tk())
      ? !1
      : !0;
  }
  var kB = !1;
  var lB = {},
    mB = {};
  function nB(a, b) {
    for (
      var c = [], d = [], e = {}, f = 0;
      f < a.length;
      e = { Sj: void 0, yj: void 0 }, f++
    ) {
      var g = a[f];
      if (g.indexOf("-") >= 0) {
        if (((e.Sj = Io(g, b)), e.Sj)) {
          var h = rk();
          Ib(
            h,
            (function (r) {
              return function (t) {
                return r.Sj.destinationId === t;
              };
            })(e),
          )
            ? c.push(g)
            : d.push(g);
        }
      } else {
        var l = lB[g] || [];
        e.yj = {};
        l.forEach(
          (function (r) {
            return function (t) {
              r.yj[t] = !0;
            };
          })(e),
        );
        for (var n = uk(), p = 0; p < n.length; p++)
          if (e.yj[n[p]]) {
            c = c.concat(rk());
            break;
          }
        var q = mB[g] || [];
        q.length && (c = c.concat(q));
      }
    }
    return { Mj: c, Kr: d };
  }
  function oB(a) {
    Mb(lB, function (b, c) {
      var d = c.indexOf(a);
      d >= 0 && c.splice(d, 1);
    });
  }
  function pB(a) {
    Mb(mB, function (b, c) {
      var d = c.indexOf(a);
      d >= 0 && c.splice(d, 1);
    });
  }
  function qB(a, b) {
    var c = {},
      d = ((c.event = a), c);
    b &&
      ((d.eventModel = Jd(b, null)),
      b[J.m.Bf] && (d.eventCallback = b[J.m.Bf]),
      b[J.m.mh] && (d.eventTimeout = b[J.m.mh]));
    return d;
  }
  function rB(a, b) {
    var c = a && a[J.m.xd];
    c === void 0 && ((c = Mp(J.m.xd, 2)), c === void 0 && (c = "default"));
    if (Fb(c) || Array.isArray(c)) {
      var d;
      d = b.isGtmEvent
        ? Fb(c)
          ? [c]
          : c
        : c.toString().replace(/\s+/g, "").split(",");
      var e = nB(d, b.isGtmEvent),
        f = e.Mj,
        g = e.Kr;
      if (g.length)
        for (var h = iB(a), l = 0; l < g.length; l++) {
          var n = Io(g[l], b.isGtmEvent);
          if (n) {
            var p = n.destinationId,
              q = void 0;
            ((q = lk(n.destinationId)) == null ? void 0 : q.state) === 0 ||
              Gz(p, h, {
                source: 3,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      var r = f.concat(g);
      return { Mj: Jo(f, b.isGtmEvent), tq: Jo(r, b.isGtmEvent) };
    }
  }
  var sB = 0;
  function tB(a) {
    el && a === void 0 && sB === 0 && (Pk("mcc", "1"), (sB = 1));
  }
  var uB = function () {
    this.messages = [];
    this.D = [];
  };
  uB.prototype.enqueue = function (a, b, c) {
    var d = this.messages.length + 1;
    a["gtm.uniqueEventId"] = b;
    a["gtm.priorityId"] = d;
    var e = oa(Object, "assign").call(Object, {}, c, {
        eventId: b,
        priorityId: d,
        fromContainerExecution: !0,
      }),
      f = { message: a, notBeforeEventId: b, priorityId: d, messageContext: e };
    this.messages.push(f);
    for (var g = 0; g < this.D.length; g++)
      try {
        this.D[g](f);
      } catch (h) {}
  };
  uB.prototype.listen = function (a) {
    this.D.push(a);
  };
  uB.prototype.get = function () {
    for (var a = {}, b = 0; b < this.messages.length; b++) {
      var c = this.messages[b],
        d = a[c.notBeforeEventId];
      d || ((d = []), (a[c.notBeforeEventId] = d));
      d.push(c);
    }
    return a;
  };
  uB.prototype.prune = function (a) {
    for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
      var e = this.messages[d];
      e.notBeforeEventId === a ? b.push(e) : c.push(e);
    }
    this.messages = c;
    return b;
  };
  function vB(a, b, c) {
    c.eventMetadata = c.eventMetadata || {};
    c.eventMetadata[R.C.Ta] = D(6);
    wB().enqueue(a, b, c);
  }
  function xB() {
    var a = yB;
    wB().listen(a);
  }
  function wB() {
    return xo("mb", function () {
      return new uB();
    });
  }
  var zB = 0,
    AB = 0,
    BB = {};
  var CB = !1,
    DB = void 0,
    EB = void 0;
  function FB(a, b, c) {
    var d = Jd(a, null);
    d.eventId = void 0;
    d.inheritParentConfig = void 0;
    Object.keys(b).some(function (f) {
      return b[f] !== void 0;
    }) && O(136);
    var e = Jd(b, null);
    Jd(c, e);
    vB(fp(uk()[0], e), a.eventId, d);
  }
  var GB = {},
    HB =
      ((GB.config = function (a, b) {
        var c = hB(a, b);
        if (!(a.length < 2) && Fb(a[1])) {
          var d = {};
          if (a.length > 2) {
            if ((a[2] !== void 0 && !Id(a[2])) || a.length > 3) return;
            d = a[2];
          }
          var e = Io(a[1], b.isGtmEvent);
          if (e) {
            var f, g, h;
            a: {
              if (!vg(7)) {
                var l = wk(xk());
                if (Ik(l)) {
                  var n = l.parent,
                    p = n.isDestination;
                  h = { Nr: wk(n), Gr: p };
                  break a;
                }
              }
              h = void 0;
            }
            var q = h;
            q && ((f = q.Nr), (g = q.Gr));
            nA(c.eventId, "gtag.config");
            var r = e.destinationId,
              t = e.id !== r;
            if (t ? rk().indexOf(r) === -1 : uk().indexOf(r) === -1) {
              if (!b.inheritParentConfig && !d[J.m.Nc]) {
                var u = iB(d);
                if (t)
                  Gz(r, u, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
                else if (f !== void 0 && f.containers.indexOf(r) !== -1) {
                  var v = d;
                  DB ? FB(b, v, DB) : EB || (EB = Jd(v, null));
                } else
                  Bz(r, u, !0, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
              }
            } else {
              if (f && (O(128), g && O(130), b.inheritParentConfig)) {
                var x;
                var y = d;
                EB
                  ? (FB(b, EB, y), (x = !1))
                  : ((!y[J.m.Bd] && vg(11) && DB) || (DB = Jd(y, null)),
                    (x = !0));
                x && f.containers && f.containers.join(",");
                return;
              }
              el && (sB === 1 && (Mk.mcc = !1), (sB = 2));
              if (vg(11) && !t && !d[J.m.Bd]) {
                var z = CB;
                CB = !0;
                var C = d,
                  E = Object.keys(C).length > 0 ? 2 : 1,
                  G,
                  K,
                  P =
                    (b == null
                      ? void 0
                      : (K = b.originatingEntity) == null
                        ? void 0
                        : K.originContainerId) || "";
                G = P ? (Yb(P, "GTM-") ? 3 : 2) : 1;
                if (z) {
                  if (
                    (O(184),
                    AB === G || (AB !== 3 && G !== 3) || O(185),
                    (zB !== 2 && E !== 2) || O(186),
                    zB === 2 && E === 2)
                  ) {
                    var fa;
                    a: {
                      var ca = BB,
                        Q = Object.keys(ca),
                        S = Object.keys(C);
                      if (Q.length !== S.length) fa = !0;
                      else {
                        for (
                          var ma = m(Q), ka = ma.next();
                          !ka.done;
                          ka = ma.next()
                        ) {
                          var V = ka.value;
                          if (!C.hasOwnProperty(V) || ca[V] !== C[V]) {
                            fa = !0;
                            break a;
                          }
                        }
                        fa = !1;
                      }
                    }
                    fa && O(189);
                  }
                } else ((zB = E), (AB = G), (BB = C));
                if (z) return;
              }
              kB || O(43);
              if (!b.noTargetGroup)
                if (t) {
                  pB(e.id);
                  var U = e.id,
                    ea = d[J.m.qh] || "default";
                  ea = String(ea).split(",");
                  for (var pa = 0; pa < ea.length; pa++) {
                    var qa = mB[ea[pa]] || [];
                    mB[ea[pa]] = qa;
                    qa.indexOf(U) < 0 && qa.push(U);
                  }
                } else {
                  oB(e.id);
                  var Fa = e.id,
                    Va = d[J.m.qh] || "default";
                  Va = Va.toString().split(",");
                  for (var ib = 0; ib < Va.length; ib++) {
                    var ub = lB[Va[ib]] || [];
                    lB[Va[ib]] = ub;
                    ub.indexOf(Fa) < 0 && ub.push(Fa);
                  }
                }
              delete d[J.m.qh];
              var hb = b.eventMetadata || {};
              hb.hasOwnProperty(R.C.Fd) ||
                (hb[R.C.Fd] = !b.fromContainerExecution);
              b.eventMetadata = hb;
              delete d[J.m.Bf];
              for (var Zb = t ? [e.id] : rk(), $b = 0; $b < Zb.length; $b++) {
                var ke = d,
                  Ji = Zb[$b],
                  Ue = Jd(b, null),
                  Pf = Io(Ji, Ue.isGtmEvent);
                Pf && pq.push("config", [ke], Pf, Ue);
              }
            }
          }
        }
      }),
      (GB.consent = function (a, b) {
        if (a.length === 3) {
          O(39);
          var c = hB(a, b),
            d = a[1],
            e = {},
            f = En(a[2]),
            g;
          for (g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              e[g] =
                g === J.m.Sg
                  ? Array.isArray(h)
                    ? NaN
                    : Number(h)
                  : g === J.m.mc
                    ? (Array.isArray(h) ? h : [h]).map(Fn)
                    : Gn(h);
            }
          b.fromContainerExecution || (e[J.m.Z] && O(139), e[J.m.Ka] && O(140));
          d === "default"
            ? io(e)
            : d === "update"
              ? ko(e, c)
              : d === "declare" && b.fromContainerExecution && ho(e);
        }
      }),
      (GB.container_config = function (a, b) {
        if (jB(b) && a.length === 3 && Fb(a[1]) && Id(a[2])) {
          var c = a[2],
            d = Io(a[1], !0);
          if (d) {
            var e = d.destinationId,
              f = Jd(b, null),
              g = Io(e, f.isGtmEvent);
            g && pq.push("container_config", [c], g, f);
          }
        }
      }),
      (GB.destination_config = function (a, b) {
        if (jB(b) && a.length === 3 && Fb(a[1]) && Id(a[2])) {
          var c = a[2],
            d = Io(a[1], !0);
          if (d) {
            var e = d.destinationId,
              f = Jd(b, null),
              g = Io(e, f.isGtmEvent);
            g && pq.push("destination_config", [c], g, f);
          }
        }
      }),
      (GB.event = function (a, b) {
        var c = a[1];
        if (!(a.length < 2) && Fb(c)) {
          var d = void 0;
          if (a.length > 2) {
            if ((!Id(a[2]) && a[2] !== void 0) || a.length > 3) return;
            d = a[2];
          }
          var e = qB(c, d),
            f = hB(a, b),
            g = f.eventId,
            h = f.priorityId;
          e["gtm.uniqueEventId"] = g;
          h && (e["gtm.priorityId"] = h);
          if (c === "optimize.callback")
            return ((e.eventModel = e.eventModel || {}), e);
          var l = rB(d, b);
          if (l) {
            for (
              var n = l.Mj,
                p = l.tq,
                q = p.map(function (P) {
                  return P.id;
                }),
                r = p.map(function (P) {
                  return P.destinationId;
                }),
                t = n.map(function (P) {
                  return P.id;
                }),
                u = m(rk()),
                v = u.next();
              !v.done;
              v = u.next()
            ) {
              var x = v.value;
              r.indexOf(x) < 0 && t.push(x);
            }
            nA(g, c);
            for (var y = m(t), z = y.next(); !z.done; z = y.next()) {
              var C = z.value,
                E = Jd(b, null),
                G = Jd(d, null);
              delete G[J.m.Bf];
              var K = E.eventMetadata || {};
              K.hasOwnProperty(R.C.Fd) ||
                (K[R.C.Fd] = !E.fromContainerExecution);
              K[R.C.Wi] = q.slice();
              K[R.C.hg] = r.slice();
              E.eventMetadata = K;
              oq(c, G, C, E);
            }
            e.eventModel = e.eventModel || {};
            q.length > 0
              ? (e.eventModel[J.m.xd] = q.join(","))
              : delete e.eventModel[J.m.xd];
            kB || O(43);
            b.noGtmEvent === void 0 &&
              b.eventMetadata &&
              b.eventMetadata[R.C.fn] &&
              (b.noGtmEvent = !0);
            e.eventModel[J.m.Mc] && (b.noGtmEvent = !0);
            return b.noGtmEvent ? void 0 : e;
          }
        }
      }),
      (GB.get = function (a, b) {
        O(53);
        if (a.length === 4 && Fb(a[1]) && Fb(a[2]) && Eb(a[3])) {
          var c = Io(a[1], b.isGtmEvent),
            d = String(a[2]),
            e = a[3];
          if (c) {
            kB || O(43);
            var f = iB();
            if (
              Ib(rk(), function (h) {
                return c.destinationId === h;
              })
            ) {
              hB(a, b);
              var g = {};
              Jd(((g[J.m.Gf] = d), (g[J.m.Ff] = e), g), null);
              qq(
                d,
                function (h) {
                  jd(function () {
                    e(h);
                  });
                },
                c.id,
                b,
              );
            } else
              Gz(c.destinationId, f, {
                source: 4,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      }),
      (GB.js = function (a, b) {
        if (a.length === 2 && a[1].getTime) {
          kB = !0;
          var c = hB(a, b),
            d = c.eventId,
            e = c.priorityId,
            f = {};
          return (
            (f.event = "gtm.js"),
            (f["gtm.start"] = a[1].getTime()),
            (f["gtm.uniqueEventId"] = d),
            (f["gtm.priorityId"] = e),
            f
          );
        }
      }),
      (GB.policy = function (a) {
        if (a.length === 3 && Fb(a[1]) && Eb(a[2])) {
          if ((fy(a[1], a[2]), O(74), a[1] === "all")) {
            O(75);
            var b = !1;
            try {
              b = a[2](D(5), "unknown", {});
            } catch (c) {}
            b || O(76);
          }
        } else O(73);
      }),
      (GB.reset_target_config = function (a, b) {
        if (jB(b) && a.length === 2 && Fb(a[1])) {
          var c = Io(a[1], !0);
          if (c) {
            var d = Io(c.destinationId, !0);
            d && pq.push("reset_target_config", [], d, {});
          }
        }
      }),
      (GB.set = function (a, b) {
        var c = void 0;
        a.length === 2 && Id(a[1])
          ? (c = Jd(a[1], null))
          : a.length === 3 &&
            Fb(a[1]) &&
            ((c = {}),
            Id(a[2]) || Array.isArray(a[2])
              ? (c[a[1]] = Jd(a[2], null))
              : (c[a[1]] = a[2]));
        if (c) {
          var d = hB(a, b),
            e = d.eventId,
            f = d.priorityId;
          Jd(c, null);
          D(5);
          var g = Jd(c, null);
          pq.push("set", [g], void 0, b);
          c["gtm.uniqueEventId"] = e;
          f && (c["gtm.priorityId"] = f);
          delete c.event;
          b.overwriteModelFields = !0;
          return c;
        }
      }),
      GB),
    IB = {},
    JB = ((IB.policy = !0), IB);
  var LB = function (a) {
    if (KB(a)) return a;
    this.value = a;
  };
  LB.prototype.getUntrustedMessageValue = function () {
    return this.value;
  };
  var KB = function (a) {
    return !a || Gd(a) !== "object" || Id(a)
      ? !1
      : "getUntrustedMessageValue" in a;
  };
  LB.prototype.getUntrustedMessageValue = LB.prototype.getUntrustedMessageValue;
  var MB = !1,
    NB = [];
  function OB() {
    if (!MB) {
      MB = !0;
      for (var a = 0; a < NB.length; a++) jd(NB[a]);
    }
  }
  function PB(a) {
    MB ? jd(a) : NB.push(a);
  }
  var QB = 0,
    RB = {},
    SB = [],
    TB = [],
    UB = !1,
    VB = !1;
  function WB(a, b) {
    return (
      a.messageContext.eventId - b.messageContext.eventId ||
      a.messageContext.priorityId - b.messageContext.priorityId
    );
  }
  function XB(a, b, c) {
    a.eventCallback = b;
    c && (a.eventTimeout = c);
    return YB(a);
  }
  function ZB(a, b) {
    if (!Gb(b) || b < 0) b = 0;
    var c = Bo(),
      d = 0,
      e = !1,
      f = void 0;
    f = w.setTimeout(function () {
      e || ((e = !0), a());
      f = void 0;
    }, b);
    return function () {
      var g = c ? c.subscribers : 1;
      ++d === g &&
        (f && (w.clearTimeout(f), (f = void 0)), e || (a(), (e = !0)));
    };
  }
  function $B(a) {
    if (a == null || typeof a !== "object") return !1;
    if (a.event) return !0;
    if (Nb(a)) {
      var b = a[0];
      if (b === "config" || b === "event" || b === "js" || b === "get")
        return !0;
    }
    return !1;
  }
  function aC() {
    var a;
    if (TB.length) a = TB.shift();
    else if (SB.length) a = SB.shift();
    else return;
    var b;
    var c = a;
    if (UB || !$B(c.message)) b = c;
    else {
      UB = !0;
      var d = c.message["gtm.uniqueEventId"],
        e,
        f;
      typeof d === "number"
        ? ((e = d - 2), (f = d - 1))
        : ((e = Co()), (f = Co()), (c.message["gtm.uniqueEventId"] = Co()));
      var g = {},
        h = {
          message:
            ((g.event = "gtm.init_consent"), (g["gtm.uniqueEventId"] = e), g),
          messageContext: { eventId: e },
        },
        l = {},
        n = {
          message: ((l.event = "gtm.init"), (l["gtm.uniqueEventId"] = f), l),
          messageContext: { eventId: f },
        };
      SB.unshift(n, c);
      b = h;
    }
    return b;
  }
  function bC() {
    for (var a = !1, b; !VB && (b = aC()); ) {
      VB = !0;
      delete Jp.eventModel;
      Lp();
      var c = b,
        d = c.message,
        e = c.messageContext;
      if (d == null) VB = !1;
      else {
        e.fromContainerExecution && Qp();
        try {
          if (Eb(d))
            try {
              d.call(Np);
            } catch (G) {}
          else if (Array.isArray(d)) {
            if (Fb(d[0])) {
              var f = d[0].split("."),
                g = f.pop(),
                h = d.slice(1),
                l = Mp(f.join("."), 2);
              if (l != null)
                try {
                  l[g].apply(l, h);
                } catch (G) {}
            }
          } else {
            var n = void 0;
            if (Nb(d))
              a: {
                if (d.length && Fb(d[0])) {
                  var p = HB[d[0]];
                  if (p && (!e.fromContainerExecution || !JB[d[0]])) {
                    n = p(d, e);
                    break a;
                  }
                }
                n = void 0;
              }
            else n = d;
            if (n) {
              var q;
              for (
                var r = n,
                  t = r._clear || e.overwriteModelFields,
                  u = m(Object.keys(r)),
                  v = u.next();
                !v.done;
                v = u.next()
              ) {
                var x = v.value;
                x !== "_clear" && (t && Pp(x), Pp(x, r[x]));
              }
              Bj || (Bj = r["gtm.start"]);
              var y = r["gtm.uniqueEventId"];
              r.event
                ? (typeof y !== "number" &&
                    ((y = Co()),
                    (r["gtm.uniqueEventId"] = y),
                    Pp("gtm.uniqueEventId", y)),
                  (q = NA(r)))
                : (q = !1);
              a = q || a;
            }
          }
        } finally {
          e.fromContainerExecution && Lp(!0);
          var z = d["gtm.uniqueEventId"];
          if (typeof z === "number") {
            for (var C = RB[String(z)] || [], E = 0; E < C.length; E++)
              TB.push(cC(C[E]));
            C.length && TB.sort(WB);
            delete RB[String(z)];
            z > QB && (QB = z);
          }
          VB = !1;
        }
      }
    }
    return !a;
  }
  function dC() {
    if (N(109)) {
      var a = !vg(51);
    }
    var c = bC();
    if (N(109)) {
    }
    try {
      var e = w[D(19)],
        f = D(5),
        g = e.hide;
      if (g && g[f] !== void 0 && g.end) {
        g[f] = !1;
        var h = !0,
          l;
        for (l in g)
          if (g.hasOwnProperty(l) && g[l] === !0) {
            h = !1;
            break;
          }
        h && (g.end(), (g.end = null));
      }
    } catch (n) {
      D(5);
    }
    return c;
  }
  function yB(a) {
    if (QB < a.notBeforeEventId) {
      var b = String(a.notBeforeEventId);
      RB[b] = RB[b] || [];
      RB[b].push(a);
    } else
      (TB.push(cC(a)),
        TB.sort(WB),
        jd(function () {
          VB || bC();
        }));
  }
  function cC(a) {
    return { message: a.message, messageContext: a.messageContext };
  }
  function eC() {
    function a(f) {
      var g = {};
      if (KB(f)) {
        var h = f;
        f = KB(h) ? h.getUntrustedMessageValue() : void 0;
        g.fromContainerExecution = !0;
      }
      return { message: f, messageContext: g };
    }
    var b = Vc(D(19), []),
      c = Ao();
    c.pruned === !0 && O(83);
    RB = wB().get();
    xB();
    gB(function () {
      if (!c.gtmDom) {
        c.gtmDom = !0;
        var f = {};
        b.push(((f.event = "gtm.dom"), f));
      }
    });
    PB(function () {
      if (!c.gtmLoad) {
        c.gtmLoad = !0;
        var f = {};
        b.push(((f.event = "gtm.load"), f));
      }
    });
    c.subscribers = (c.subscribers || 0) + 1;
    var d = b.push;
    b.push = function () {
      var f;
      if (wo.SANDBOXED_JS_SEMAPHORE > 0) {
        f = [];
        for (var g = 0; g < arguments.length; g++) f[g] = new LB(arguments[g]);
      } else f = [].slice.call(arguments, 0);
      var h = f.map(function (q) {
        return a(q);
      });
      SB.push.apply(SB, h);
      var l = d.apply(b, f),
        n = Math.max(100, Ag(1, 300));
      if (this.length > n)
        for (O(4), c.pruned = !0; this.length > n; ) this.shift();
      var p = typeof l !== "boolean" || l;
      return bC() && p;
    };
    var e = b.slice(0).map(function (f) {
      return a(f);
    });
    SB.push.apply(SB, e);
    if (!vg(51)) {
      if (N(109)) {
      }
      jd(dC);
    }
  }
  var YB = function (a) {
    return w[D(19)].push(a);
  };
  function fC(a) {
    YB(a);
  }
  function gC() {
    var a,
      b = Pj(w.location.href);
    (a = b.hostname + b.pathname) && Pk("dl", encodeURIComponent(a));
    var c;
    var d = D(5);
    if (d) {
      var e = vg(7) ? 1 : 0,
        f = Dk(),
        g = f && f.fromContainerExecution ? 1 : 0,
        h = (f && f.source) || 0,
        l = D(6);
      c = d + ";" + l + ";" + g + ";" + h + ";" + e;
    } else c = void 0;
    var n = c;
    n && Pk("tdp", n);
    var p = Iq(!0);
    p !== void 0 && Pk("frm", String(p));
  }
  var hC = Tk(),
    iC = void 0;
  function jC(a) {
    return Vk(a, function (b) {
      return b.lb > 0 ? String(b.lb) : void 0;
    });
  }
  function kC() {
    if (Qn() || el)
      (Pk(
        "csp",
        function () {
          var a = jC(hC);
          Wk(hC);
          return a;
        },
        !1,
      ),
        Pk(
          "mde",
          function () {
            var a = jC(Yk);
            Wk(Yk);
            return a;
          },
          !1,
        ),
        w.addEventListener("securitypolicyviolation", lC));
  }
  function lC(a) {
    if (a.disposition === "enforce") {
      O(179);
      var b = ll(a.effectiveDirective);
      if (b) {
        var c;
        a: {
          var d = a.blockedURI;
          if (el && d) {
            var e = jl(b, d);
            if (e) {
              c = hl[b][e];
              break a;
            }
          }
          c = void 0;
        }
        var f = c;
        if (f) {
          var g;
          a: {
            try {
              var h = new URL(a.blockedURI),
                l = h.pathname.indexOf(";");
              g =
                l >= 0
                  ? h.origin + h.pathname.substring(0, l)
                  : h.origin + h.pathname;
              break a;
            } catch (y) {}
            g = void 0;
          }
          var n = g;
          if (n) {
            for (var p = m(f), q = p.next(); !q.done; q = p.next()) {
              var r = q.value;
              if (!r.Wn) {
                r.Wn = !0;
                var t = { eventId: r.eventId, priorityId: r.priorityId };
                if (Qn()) {
                  var u = t,
                    v = {
                      type: 1,
                      blockedUrl: n,
                      endpoint: r.endpoint,
                      violation: a.effectiveDirective,
                    };
                  if (Qn()) {
                    var x = Wn("TAG_DIAGNOSTICS", {
                      eventId: u == null ? void 0 : u.eventId,
                      priorityId: u == null ? void 0 : u.priorityId,
                    });
                    x.tagDiagnostics = v;
                    Pn(x);
                  }
                }
                mC(r.destinationId, r.endpoint);
              }
            }
            kl(b, a.blockedURI);
          }
        }
      }
    }
  }
  function mC(a, b) {
    Xk(hC, a, b);
    Qk("csp", !0);
    Qk("mde", !0);
    b !== 61 &&
      b !== 56 &&
      iC === void 0 &&
      (iC = w.setTimeout(function () {
        hC.lb > 0 && Om(!1);
        iC = void 0;
      }, 500));
  }
  var nC = void 0;
  function oC() {
    N(236) &&
      w.addEventListener("pageshow", function (a) {
        a &&
          (Pk("bfc", function () {
            return nC ? "1" : "0";
          }),
          a.persisted ? ((nC = !0), Qk("bfc", !0), Om()) : (nC = !1));
      });
  }
  function pC() {
    var a;
    var b = vk();
    if (b)
      if (b.canonicalContainerId) a = b.canonicalContainerId;
      else {
        var c,
          d =
            b.scriptContainerId ||
            ((c = b.destinations) == null ? void 0 : c[0]);
        a = d ? "_" + d : void 0;
      }
    else a = void 0;
    var e = a;
    e && Pk("pcid", e);
  }
  var qC = {},
    rC =
      ((qC[1] = function () {
        return w.fetch;
      }),
      (qC[2] = function () {
        return Math.random;
      }),
      (qC[3] = function () {
        return Rc.sendBeacon;
      }),
      (qC[4] = function () {
        return w.XMLHttpRequest;
      }),
      qC);
  function sC() {
    for (
      var a = [], b = m(Object.keys(rC)), c = b.next();
      !c.done;
      c = b.next()
    ) {
      var d = c.value,
        e = rC[d](),
        f;
      if (!(f = typeof e !== "function")) {
        var g = Function.prototype.toString.call(e);
        f = ac(g, "{ [native code] }") || ac(g, "{\n    [native code]\n}");
      }
      f || a.push(d);
    }
    a.length > 0 && Pk("jsp", a.join("~"));
  }
  var tC = /^(https?:)?\/\//;
  function uC() {
    var a = yk();
    if (a) {
      var b;
      a: {
        var c,
          d = (c = a.scriptElement) == null ? void 0 : c.src;
        if (d) {
          var e;
          try {
            var f;
            e = (f = xd()) == null ? void 0 : f.getEntriesByType("resource");
          } catch (q) {}
          if (e) {
            for (var g = -1, h = m(e), l = h.next(); !l.done; l = h.next()) {
              var n = l.value;
              if (
                n.initiatorType === "script" &&
                ((g += 1), n.name.replace(tC, "") === d.replace(tC, ""))
              ) {
                b = g;
                break a;
              }
            }
            O(146);
          } else O(145);
        }
        b = void 0;
      }
      var p = b;
      p !== void 0 &&
        (a.canonicalContainerId && Pk("rtg", String(a.canonicalContainerId)),
        Pk("slo", String(p)),
        Pk("hlo", a.htmlLoadOrder || "-1"),
        Pk("lst", String(a.loadScriptType || "0")));
    } else O(144);
  }
  function PC() {}
  var QC = function () {};
  QC.prototype.toString = function () {
    return "undefined";
  };
  var RC = new QC();
  var YC = {};
  function ZC(a) {
    bl && (YC[a] = (YC[a] || 0) + 1);
  }
  function $C() {
    var a = [];
    YC[1] && a.push("1." + YC[1]);
    YC[2] && a.push("2." + YC[2]);
    YC[3] && a.push("3." + YC[3]);
    return a.length ? [["odp", a.join("~")]] : [];
  }
  function aD() {
    (N(212) || N(405)) &&
      D(5).indexOf("GTM-") !== 0 &&
      (fy("detect_link_click_events", function (a, b, c) {
        var d = c.options;
        return N(405)
          ? ((d == null ? void 0 : d.waitForTags) === !0 && ZC(1), !0)
          : (d == null ? void 0 : d.waitForTags) !== !0;
      }),
      fy("detect_form_submit_events", function (a, b, c) {
        var d = c.options;
        return N(405)
          ? ((d == null ? void 0 : d.waitForTags) === !0 && ZC(2), !0)
          : (d == null ? void 0 : d.waitForTags) !== !0;
      }),
      fy("detect_youtube_activity_events", function (a, b, c) {
        var d = c.options;
        return N(405)
          ? ((d == null ? void 0 : d.fixMissingApi) === !0 && ZC(3), !0)
          : (d == null ? void 0 : d.fixMissingApi) !== !0;
      }));
    (N(212) || N(407)) &&
      yj &&
      vA(tk(), function (a) {
        var b, c, d;
        b = a.entityId;
        c = a.securityGroups;
        d = a.originalEventData;
        var e = "__" + b,
          f = Rz(e, 5) || !(!jg[e] || !jg[e][5]) || c.includes("cmpPartners");
        return N(407)
          ? (f || (bl && qA(Number(d["gtm.uniqueEventId"]), b, "r")), !0)
          : f;
      });
  }
  function bD(a, b) {
    function c(g) {
      var h = Pj(g),
        l = Jj(h, "protocol"),
        n = Jj(h, "host", !0),
        p = Jj(h, "port"),
        q = Jj(h, "path").toLowerCase().replace(/\/$/, "");
      if (
        l === void 0 ||
        (l === "http" && p === "80") ||
        (l === "https" && p === "443")
      )
        ((l = "web"), (p = "default"));
      return [l, n, p, q];
    }
    for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
      if (d[f] !== e[f]) return !1;
    return !0;
  }
  function cD(a) {
    return dD(a) ? 1 : 0;
  }
  function dD(a) {
    var b = a.arg0,
      c = a.arg1;
    if (a.any_of && Array.isArray(c)) {
      for (var d = 0; d < c.length; d++) {
        var e = Jd(a, {});
        Jd({ arg1: c[d], any_of: void 0 }, e);
        if (cD(e)) return !0;
      }
      return !1;
    }
    switch (a["function"]) {
      case "_cn":
        return qh(b, c);
      case "_css":
        var f;
        a: {
          if (b)
            try {
              for (var g = 0; g < lh.length; g++) {
                var h = lh[g];
                if (b[h] != null) {
                  f = b[h](c);
                  break a;
                }
              }
            } catch (l) {}
          f = !1;
        }
        return f;
      case "_ew":
        return mh(b, c);
      case "_eq":
        return rh(b, c);
      case "_ge":
        return sh(b, c);
      case "_gt":
        return uh(b, c);
      case "_lc":
        return nh(b, c);
      case "_le":
        return th(b, c);
      case "_lt":
        return vh(b, c);
      case "_re":
        return ph(b, c, a.ignore_case);
      case "_sw":
        return wh(b, c);
      case "_um":
        return bD(b, c);
    }
    return !1;
  }
  var eD = function () {
    this.D = this.gppString = void 0;
  };
  eD.prototype.reset = function () {
    this.D = this.gppString = void 0;
  };
  var fD = new eD();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    function (a, b) {
      return a + b;
    },
  );
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    function (a, b) {
      return a + b;
    },
  );
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(
    function (a, b) {
      return a + b;
    },
  );
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  Kq({
    xt: 0,
    wt: 1,
    rt: 2,
    jt: 3,
    st: 4,
    kt: 5,
    vt: 6,
    nt: 7,
    ot: 8,
    it: 9,
    mt: 10,
    zt: 11,
  }).map(function (a) {
    return Number(a);
  });
  Kq({ Bt: 0, Ct: 1, At: 2 }).map(function (a) {
    return Number(a);
  });
  var gD = function (a, b, c, d) {
    Qq.call(this);
    this.Ld = b;
    this.Uc = c;
    this.Xb = d;
    this.rb = new Map();
    this.Md = 0;
    this.ma = new Map();
    this.Sa = new Map();
    this.V = void 0;
    this.J = a;
  };
  xa(gD, Qq);
  gD.prototype.N = function () {
    delete this.D;
    this.rb.clear();
    this.ma.clear();
    this.Sa.clear();
    this.V && (Mq(this.J, "message", this.V), delete this.V);
    delete this.J;
    delete this.Xb;
    Qq.prototype.N.call(this);
  };
  var hD = function (a) {
      if (a.D) return a.D;
      a.Uc && a.Uc(a.J) ? (a.D = a.J) : (a.D = Hq(a.J, a.Ld));
      var b;
      return (b = a.D) != null ? b : null;
    },
    jD = function (a, b, c) {
      if (hD(a))
        if (a.D === a.J) {
          var d = a.rb.get(b);
          d && d(a.D, c);
        } else {
          var e = a.ma.get(b);
          if (e && e.Lj) {
            iD(a);
            var f = ++a.Md;
            a.Sa.set(f, {
              Xh: e.Xh,
              Mq: e.In(c),
              persistent: b === "addEventListener",
            });
            a.D.postMessage(e.Lj(c, f), "*");
          }
        }
    },
    iD = function (a) {
      a.V ||
        ((a.V = function (b) {
          try {
            var c;
            c = a.Xb ? a.Xb(b) : void 0;
            if (c) {
              var d = c.Qr,
                e = a.Sa.get(d);
              if (e) {
                e.persistent || a.Sa.delete(d);
                var f;
                (f = e.Xh) == null || f.call(e, e.Mq, c.payload);
              }
            }
          } catch (g) {}
        }),
        Lq(a.J, "message", a.V));
    };
  var kD = function (a, b) {
      var c = b.listener,
        d = (0, a.__gpp)("addEventListener", c);
      d && c(d, !0);
    },
    lD = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    mD = {
      In: function (a) {
        return a.listener;
      },
      Lj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          c
        );
      },
      Xh: function (a, b) {
        var c = b.__gppReturn;
        a(c.returnValue, c.success);
      },
    },
    nD = {
      In: function (a) {
        return a.listener;
      },
      Lj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      Xh: function (a, b) {
        var c = b.__gppReturn,
          d = c.returnValue.data;
        a == null || a(d, c.success);
      },
    };
  function oD(a) {
    var b = {};
    typeof a.data === "string" ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Qr: b.__gppReturn.callId };
  }
  var pD = function (a, b) {
    var c;
    c = (b === void 0 ? {} : b).timeoutMs;
    Qq.call(this);
    this.caller = new gD(
      a,
      "__gppLocator",
      function (d) {
        return typeof d.__gpp === "function";
      },
      oD,
    );
    this.caller.rb.set("addEventListener", kD);
    this.caller.ma.set("addEventListener", mD);
    this.caller.rb.set("removeEventListener", lD);
    this.caller.ma.set("removeEventListener", nD);
    this.timeoutMs = c != null ? c : 500;
  };
  xa(pD, Qq);
  pD.prototype.N = function () {
    this.caller.dispose();
    Qq.prototype.N.call(this);
  };
  pD.prototype.addEventListener = function (a) {
    var b = this,
      c = Eq(function () {
        a(qD, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    jD(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          var h;
          ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 ||
          e.pingData.gppVersion === "1" ||
          e.pingData.gppVersion === "1.0"
            ? (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 1,
                  gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                  applicableSections: [-1],
                },
              }))
            : Array.isArray(e.pingData.applicableSections)
              ? (g = e)
              : (b.removeEventListener(e.listenerId),
                (g = {
                  eventName: "signalStatus",
                  data: "ready",
                  pingData: {
                    internalErrorState: 2,
                    gppString:
                      "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                    applicableSections: [-1],
                  },
                }));
          a(g, f);
        } catch (l) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (n) {
              a(rD, !0);
              return;
            }
          a(sD, !0);
        }
      },
    });
  };
  pD.prototype.removeEventListener = function (a) {
    jD(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var sD = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    qD = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    rD = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function tD(a) {
    var b;
    if (!(b = a.pingData.signalStatus === "ready")) {
      var c = a.pingData.applicableSections;
      b = !c || (c.length === 1 && c[0] === -1);
    }
    if (b) {
      fD.gppString = a.pingData.gppString;
      var d = a.pingData.applicableSections.join(",");
      fD.D = d;
    }
  }
  function uD() {
    try {
      var a = new pD(w, { timeoutMs: -1 });
      hD(a.caller) && a.addEventListener(tD);
    } catch (b) {}
  }
  function vD() {
    var a = [
        ["cv", D(1)],
        ["rv", D(14)],
        [
          "tc",
          hg.filter(function (c) {
            return c;
          }).length,
        ],
      ],
      b = wg(15);
    b && a.push(["x", b]);
    Sk() && a.push(["tag_exp", Sk()]);
    return a;
  }
  var wD = 0,
    xD = 0,
    yD = void 0,
    zD = Ag(63, 2e3);
  function AD() {
    if (N(468) && bl) {
      xD++;
      yD = Tb();
      var a = w.jQuery;
      if (a && typeof a === "function")
        try {
          var b = a(A);
          (b.on || b.bind).call(b, "ajaxComplete", function () {
            yD && Tb() < yD + zD && wD++;
          });
        } catch (c) {}
    }
  }
  function BD() {
    var a = [];
    wD > 0 && a.push(["ajx", String(wD)]);
    xD > 0 && a.push(["ajdc", String(xD)]);
    return a;
  }
  var CD = {},
    DD = {};
  function ED(a) {
    var b = a.eventId,
      c = a.Ng,
      d = [],
      e = CD[b] || [];
    e.length && d.push(["hf", e.join(".")]);
    var f = DD[b] || [];
    f.length && d.push(["ht", f.join(".")]);
    c && (delete CD[b], delete DD[b]);
    return d;
  }
  function FD() {
    return !1;
  }
  function GD() {
    var a = {};
    return function (b, c, d) {};
  }
  function HD() {
    var a = ID;
    return function (b, c, d) {
      var e = d && d.event;
      JD(c);
      var f = bi(b) ? void 0 : 1,
        g = new pb();
      Mb(c, function (r, t) {
        var u = Xd(t, void 0, f);
        u === void 0 && t !== void 0 && O(44);
        g.set(r, u);
      });
      a.Pb(Dg());
      var h = {
        tn: Rg(b),
        eventId: e == null ? void 0 : e.id,
        priorityId: e !== void 0 ? e.priorityId : void 0,
        lg:
          e !== void 0
            ? function (r) {
                e.Wc.lg(r);
              }
            : void 0,
        Nb: function () {
          return b;
        },
        log: function () {},
        Sq: {
          index: d == null ? void 0 : d.index,
          type: d == null ? void 0 : d.type,
          name: d == null ? void 0 : d.name,
        },
        Xr: !!Rz(b, 3),
        originalEventData: e == null ? void 0 : e.originalEventData,
      };
      e &&
        e.cachedModelValues &&
        (h.cachedModelValues = {
          gtm: e.cachedModelValues.gtm,
          ecommerce: e.cachedModelValues.ecommerce,
        });
      if (FD()) {
        var l = GD(),
          n,
          p;
        h.xb = {
          Zj: [],
          ng: {},
          hc: function (r, t, u) {
            t === 1 && (n = r);
            t === 7 && (p = u);
            l(r, t, u);
          },
          Wh: vi(),
        };
        h.log = function (r) {
          var t = Qa.apply(1, arguments);
          n && l(n, 4, { level: r, source: p, message: t });
        };
      }
      var q = vf(a, h, [b, g]);
      a.Pb();
      q instanceof Ua && (q.type === "return" ? (q = q.data) : (q = void 0));
      return B(q, void 0, f);
    };
  }
  function JD(a) {
    var b = a.gtmOnSuccess,
      c = a.gtmOnFailure;
    Eb(b) &&
      (a.gtmOnSuccess = function () {
        jd(b);
      });
    Eb(c) &&
      (a.gtmOnFailure = function () {
        jd(c);
      });
  }
  function KD(a) {}
  KD.K = "internal.addAdsClickIds";
  function LD(a, b) {
    var c = this;
  }
  LD.publicName = "addConsentListener";
  var MD = !1;
  function ND(a) {
    for (var b = 0; b < a.length; ++b)
      if (MD)
        try {
          a[b]();
        } catch (c) {
          O(77);
        }
      else a[b]();
  }
  function OD(a, b, c) {
    var d = this,
      e;
    return e;
  }
  OD.K = "internal.addDataLayerEventListener";
  function PD(a, b, c) {}
  PD.publicName = "addDocumentEventListener";
  function QD(a, b, c, d) {}
  QD.publicName = "addElementEventListener";
  function RD(a) {
    return a.M.ub();
  }
  function SD(a) {}
  SD.publicName = "addEventCallback";
  function gE(a) {}
  gE.K = "internal.addFormAbandonmentListener";
  function hE(a, b, c, d) {}
  hE.K = "internal.addFormData";
  var iE = {},
    jE = [],
    kE = {},
    lE = 0,
    mE = 0;
  function tE(a, b) {}
  tE.K = "internal.addFormInteractionListener";
  function AE(a, b) {}
  AE.K = "internal.addFormSubmitListener";
  function FE(a) {}
  FE.K = "internal.addGaSendListener";
  function GE(a) {
    if (!a) return {};
    var b = a.Sq;
    return Qz(b.type, b.index, b.name);
  }
  function HE(a) {
    return a ? { originatingEntity: GE(a) } : {};
  }
  var JE = function (a, b, c) {
      IE().updateZone(a, b, c);
    },
    LE = function (a, b, c, d, e) {
      var f = {},
        g = IE();
      c = c && Xb(c, KE);
      for (var h = g.createZone(a, c), l = 0; l < b.length; l++) {
        var n = String(b[l]);
        if (g.registerChild(n, D(5), h)) {
          var p = n,
            q = a,
            r = f,
            t = d,
            u = e;
          if (Yb(p, "GTM-"))
            Bz(p, void 0, !1, { source: 1, fromContainerExecution: !0 });
          else {
            var v = ep("js", Sb());
            Bz(p, void 0, !0, { source: 1, fromContainerExecution: !0 });
            var x = { originatingEntity: t, inheritParentConfig: u };
            vB(v, q, x);
            vB(fp(p, r), q, x);
          }
        }
      }
      return h;
    },
    IE = function () {
      return xo("zones", function () {
        return new ME();
      });
    },
    NE = {
      zone: 1,
      cn: 1,
      css: 1,
      ew: 1,
      eq: 1,
      ge: 1,
      gt: 1,
      lc: 1,
      le: 1,
      lt: 1,
      re: 1,
      sw: 1,
      um: 1,
    },
    KE = {
      cl: ["ecl"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
    },
    ME = function () {
      this.D = {};
      this.J = {};
      this.N = 0;
    };
  k = ME.prototype;
  k.isActive = function (a, b) {
    for (var c, d = 0; d < a.length && !(c = this.D[a[d]]); d++);
    if (!c) return !0;
    if (!this.isActive([c.Rj], b)) return !1;
    for (var e = 0; e < c.Og.length; e++) if (this.J[c.Og[e]].Se(b)) return !0;
    return !1;
  };
  k.getIsAllowedFn = function (a, b) {
    if (!this.isActive(a, b))
      return function () {
        return !1;
      };
    for (var c, d = 0; d < a.length && !(c = this.D[a[d]]); d++);
    if (!c)
      return function () {
        return !0;
      };
    for (var e = [], f = 0; f < c.Og.length; f++) {
      var g = this.J[c.Og[f]];
      g.Se(b) && e.push(g);
    }
    if (!e.length)
      return function () {
        return !1;
      };
    var h = this.getIsAllowedFn([c.Rj], b);
    return function (l, n) {
      n = n || [];
      if (!h(l, n)) return !1;
      for (var p = 0; p < e.length; ++p) if (e[p].N(l, n)) return !0;
      return !1;
    };
  };
  k.unregisterChild = function (a) {
    for (var b = 0; b < a.length; b++) delete this.D[a[b]];
  };
  k.createZone = function (a, b) {
    var c = String(++this.N);
    this.J[c] = new OE(a, b);
    return c;
  };
  k.updateZone = function (a, b, c) {
    var d = this.J[a];
    d && d.T(b, c);
  };
  k.registerChild = function (a, b, c) {
    var d = this.D[a];
    if ((!d && wo[a]) || (!d && Ck(a)) || (d && d.Rj !== b)) return !1;
    if (d) return (d.Og.push(c), !1);
    this.D[a] = { Rj: b, Og: [c] };
    return !0;
  };
  var OE = function (a, b) {
    this.J = null;
    this.D = [{ eventId: a, Se: !0 }];
    if (b) {
      this.J = {};
      for (var c = 0; c < b.length; c++) this.J[b[c]] = !0;
    }
  };
  OE.prototype.T = function (a, b) {
    var c = this.D[this.D.length - 1];
    a <= c.eventId || (c.Se !== b && this.D.push({ eventId: a, Se: b }));
  };
  OE.prototype.Se = function (a) {
    for (var b = this.D.length - 1; b >= 0; b--)
      if (this.D[b].eventId <= a) return this.D[b].Se;
    return !1;
  };
  OE.prototype.N = function (a, b) {
    b = b || [];
    if (!this.J || NE[a] || this.J[a]) return !0;
    for (var c = 0; c < b.length; ++c) if (this.J[b[c]]) return !0;
    return !1;
  };
  function PE(a) {
    var b = wo.zones;
    return b
      ? b.getIsAllowedFn(uk(), a)
      : function () {
          return !0;
        };
  }
  function QE() {
    var a = wo.zones;
    a && a.unregisterChild(uk());
  }
  function RE() {
    xA(tk(), function (a) {
      var b = a.originalEventData["gtm.uniqueEventId"],
        c = wo.zones;
      return c ? c.isActive(uk(), b) : !0;
    });
    vA(tk(), function (a) {
      var b, c;
      b = a.entityId;
      c = a.securityGroups;
      return PE(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c);
    });
  }
  var SE = function (a, b) {
    this.tagId = a;
    this.canonicalId = b;
  };
  function TE(a, b) {
    var c = this;
    if (!Nh(a) || (!Gh(b) && !Ih(b)))
      throw H(this.getName(), ["string", "Object|undefined"], arguments);
    var d = B(b, this.M, 1) || {},
      e = d.firstPartyUrl,
      f = d.onLoad,
      g = d.loadByDestination === !0,
      h = d.isGtmEvent === !0;
    ND([
      function () {
        I(c, "load_google_tags", a, e);
      },
    ]);
    if (g) {
      if (Ek(a)) return a;
    } else if (Ck(a)) return a;
    var l = 6,
      n = RD(this);
    h && (l = 7);
    n.Nb() === "__zone" && (l = 1);
    var p = { source: l, fromContainerExecution: !0 },
      q = function (r) {
        vA(
          r,
          function (t) {
            for (
              var u = wA().getExternalRestrictions(0, tk()),
                v = m(u),
                x = v.next();
              !x.done;
              x = v.next()
            ) {
              var y = x.value;
              if (!y(t)) return !1;
            }
            return !0;
          },
          !0,
        );
        xA(
          r,
          function (t) {
            for (
              var u = wA().getExternalRestrictions(1, tk()),
                v = m(u),
                x = v.next();
              !x.done;
              x = v.next()
            ) {
              var y = x.value;
              if (!y(t)) return !1;
            }
            return !0;
          },
          !0,
        );
        f && f(new SE(a, r));
      };
    g ? Gz(a, e, p, q) : Bz(a, e, !Yb(a, "GTM-"), p, q);
    f &&
      n.Nb() === "__zone" &&
      LE(Number.MIN_SAFE_INTEGER, [a], null, GE(RD(this)));
    return a;
  }
  TE.K = "internal.loadGoogleTag";
  function UE(a) {
    return new Pd("", function (b) {
      var c = this.evaluate(b);
      if (c instanceof Pd)
        return new Pd("", function () {
          var d = Qa.apply(0, arguments),
            e = this,
            f = Jd(RD(this), null);
          f.eventId = a.eventId;
          f.priorityId = a.priorityId;
          f.originalEventData = a.originalEventData;
          var g = d.map(function (l) {
              return e.evaluate(l);
            }),
            h = this.M.sb();
          h.Zd(f);
          return c.Ob.apply(c, [h].concat(Aa(g)));
        });
    });
  }
  function VE(a, b, c) {
    var d = this;
  }
  VE.K = "internal.addGoogleTagRestriction";
  var WE = {},
    XE = [];
  function dF(a, b) {}
  dF.K = "internal.addHistoryChangeListener";
  function eF(a, b, c) {}
  eF.publicName = "addWindowEventListener";
  function fF(a, b) {
    return !0;
  }
  fF.publicName = "aliasInWindow";
  function gF(a, b, c) {}
  gF.K = "internal.appendRemoteConfigParameter";
  function hF(a) {
    var b;
    return b;
  }
  hF.publicName = "callInWindow";
  function iF(a) {}
  iF.publicName = "callLater";
  function jF(a) {}
  jF.K = "callOnDomReady";
  function kF(a) {}
  kF.K = "callOnWindowLoad";
  function lF(a, b) {
    var c;
    return c;
  }
  lF.K = "internal.computeGtmParameter";
  function mF(a, b) {
    var c = this;
  }
  mF.K = "internal.consentScheduleFirstTry";
  function nF(a, b) {
    var c = this;
  }
  nF.K = "internal.consentScheduleRetry";
  function oF(a) {
    var b;
    return b;
  }
  oF.K = "internal.copyFromCrossContainerData";
  function pF(a, b) {
    var c;
    if (!Nh(a) || (!Sh(b) && b !== null && !Ih(b)))
      throw H(this.getName(), ["string", "number|undefined"], arguments);
    I(this, "read_data_layer", a);
    c = (b || 2) !== 2 ? Mp(a, 1) : Op(a, [w, A]);
    var d = Xd(c, this.M, bi(RD(this).Nb()) ? 2 : 1);
    d === void 0 && c !== void 0 && O(45);
    return d;
  }
  pF.publicName = "copyFromDataLayer";
  function qF(a) {
    var b = void 0;
    return b;
  }
  qF.K = "internal.copyFromDataLayerCache";
  function rF(a) {
    var b;
    return b;
  }
  rF.publicName = "copyFromWindow";
  function sF(a) {
    var b = void 0;
    return Xd(b, this.M, 1);
  }
  sF.K = "internal.copyKeyFromWindow";
  var tF = function (a) {
    return a === bm.ba.Wa && tm[a] === am.Na.Je && !mo(J.m.X);
  };
  var uF = function () {
      return "0";
    },
    vF = function (a) {
      if (typeof a !== "string") return "";
      var b = ["gclid", "dclid", "wbraid", "_gl"];
      N(102) && b.push("gbraid");
      return Qj(a, b, "0");
    };
  var wF = {},
    xF = {},
    yF = {},
    zF = {},
    AF = {},
    BF = {},
    CF = {},
    DF = {},
    EF = {},
    FF = {},
    GF = {},
    HF = {},
    IF = {},
    JF = {},
    KF = {},
    LF = {},
    MF = {},
    NF = {},
    OF = {},
    PF = {},
    QF = {},
    RF = {},
    SF = {},
    TF = {},
    UF = {},
    VF = {},
    WF =
      ((VF[J.m.Oa] = ((wF[2] = [tF]), wF)),
      (VF[J.m.Mf] = ((xF[2] = [tF]), xF)),
      (VF[J.m.Ef] = ((yF[2] = [tF]), yF)),
      (VF[J.m.Hl] = ((zF[2] = [tF]), zF)),
      (VF[J.m.Il] = ((AF[2] = [tF]), AF)),
      (VF[J.m.Jl] = ((BF[2] = [tF]), BF)),
      (VF[J.m.Kl] = ((CF[2] = [tF]), CF)),
      (VF[J.m.Ll] = ((DF[2] = [tF]), DF)),
      (VF[J.m.Cd] = ((EF[2] = [tF]), EF)),
      (VF[J.m.Nf] = ((FF[2] = [tF]), FF)),
      (VF[J.m.Of] = ((GF[2] = [tF]), GF)),
      (VF[J.m.Pf] = ((HF[2] = [tF]), HF)),
      (VF[J.m.Qf] = ((IF[2] = [tF]), IF)),
      (VF[J.m.Rf] = ((JF[2] = [tF]), JF)),
      (VF[J.m.Sf] = ((KF[2] = [tF]), KF)),
      (VF[J.m.Tf] = ((LF[2] = [tF]), LF)),
      (VF[J.m.Uf] = ((MF[2] = [tF]), MF)),
      (VF[J.m.yb] = ((NF[1] = [tF]), NF)),
      (VF[J.m.kd] = ((OF[1] = [tF]), OF)),
      (VF[J.m.pd] = ((PF[1] = [tF]), PF)),
      (VF[J.m.qe] = ((QF[1] = [tF]), QF)),
      (VF[J.m.jf] =
        ((RF[1] = [
          function (a) {
            return N(102) && tF(a);
          },
        ]),
        RF)),
      (VF[J.m.Ic] = ((SF[1] = [tF]), SF)),
      (VF[J.m.ya] = ((TF[1] = [tF]), TF)),
      (VF[J.m.Xa] = ((UF[1] = [tF]), UF)),
      VF),
    XF = {},
    YF =
      ((XF[J.m.yb] = uF),
      (XF[J.m.kd] = uF),
      (XF[J.m.pd] = uF),
      (XF[J.m.qe] = uF),
      (XF[J.m.jf] = uF),
      (XF[J.m.Ic] = function (a) {
        if (!Id(a)) return {};
        var b = Jd(a, null);
        delete b.match_id;
        return b;
      }),
      (XF[J.m.ya] = vF),
      (XF[J.m.Xa] = vF),
      XF),
    ZF = {},
    $F = {},
    aG = (($F[R.C.Pa] = ((ZF[2] = [tF]), ZF)), $F),
    bG = {};
  var cG = function (a, b, c, d) {
    this.D = a;
    this.N = b;
    this.T = c;
    this.V = d;
  };
  cG.prototype.getValue = function (a) {
    a = a === void 0 ? bm.ba.Tc : a;
    if (
      !this.N.some(function (b) {
        return b(a);
      })
    )
      return this.T.some(function (b) {
        return b(a);
      })
        ? this.V(this.D)
        : this.D;
  };
  cG.prototype.J = function () {
    return Gd(this.D) === "array" || Id(this.D) ? Jd(this.D, null) : this.D;
  };
  var dG = function () {},
    eG = function (a, b) {
      this.conditions = a;
      this.D = b;
    },
    fG = function (a, b, c) {
      var d,
        e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
        f,
        g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
      return new cG(c, e, g, a.D[b] || dG);
    },
    gG,
    hG;
  var iG,
    jG = !1;
  function kG() {
    jG = !0;
    vg(52) && ((iG = productSettings), (productSettings = void 0));
    iG = iG || {};
  }
  function lG(a) {
    jG || kG();
    return iG[a];
  }
  var mG = function (a, b, c) {
      this.eventName = b;
      this.F = c;
      this.D = {};
      this.isAborted = !1;
      this.target = a;
      this.metadata = {};
      for (
        var d = c.eventMetadata || {}, e = m(Object.keys(d)), f = e.next();
        !f.done;
        f = e.next()
      ) {
        var g = f.value;
        W(this, g, d[g]);
      }
    },
    kv = function (a, b) {
      var c, d;
      return (c = a.D[b]) == null
        ? void 0
        : (d = c.getValue) == null
          ? void 0
          : d.call(c, T(a, R.C.ig));
    },
    X = function (a, b, c) {
      var d = a.D,
        e;
      c === void 0
        ? (e = void 0)
        : (gG != null || (gG = new eG(WF, YF)), (e = fG(gG, b, c)));
      d[b] = e;
    };
  mG.prototype.mergeHitDataForKey = function (a, b) {
    var c, d, e;
    c =
      (d = this.D[a]) == null ? void 0 : (e = d.J) == null ? void 0 : e.call(d);
    if (!c) return (X(this, a, b), !0);
    if (!Id(c)) return !1;
    X(this, a, oa(Object, "assign").call(Object, c, b));
    return !0;
  };
  var nG = function (a, b) {
    b = b === void 0 ? {} : b;
    for (var c = m(Object.keys(a.D)), d = c.next(); !d.done; d = c.next()) {
      var e = d.value,
        f = void 0,
        g = void 0,
        h = void 0;
      b[e] =
        (f = a.D[e]) == null
          ? void 0
          : (h = (g = f).J) == null
            ? void 0
            : h.call(g);
    }
    return b;
  };
  mG.prototype.copyToHitData = function (a, b, c) {
    var d = M(this.F, a);
    d === void 0 && (d = b);
    if (Fb(d) && c !== void 0)
      try {
        d = c(d);
      } catch (e) {}
    d !== void 0 && X(this, a, d);
  };
  var T = function (a, b) {
      var c = a.metadata[b];
      if (b === R.C.ig) {
        var d;
        return c == null ? void 0 : (d = c.J) == null ? void 0 : d.call(c);
      }
      var e;
      return c == null
        ? void 0
        : (e = c.getValue) == null
          ? void 0
          : e.call(c, T(a, R.C.ig));
    },
    W = function (a, b, c) {
      var d = a.metadata,
        e;
      c === void 0
        ? (e = c)
        : (hG != null || (hG = new eG(aG, bG)), (e = fG(hG, b, c)));
      d[b] = e;
    },
    oG = function (a, b) {
      b = b === void 0 ? {} : b;
      for (
        var c = m(Object.keys(a.metadata)), d = c.next();
        !d.done;
        d = c.next()
      ) {
        var e = d.value,
          f = void 0,
          g = void 0,
          h = void 0;
        b[e] =
          (f = a.metadata[e]) == null
            ? void 0
            : (h = (g = f).J) == null
              ? void 0
              : h.call(g);
      }
      return b;
    },
    pG = function (a, b, c) {
      var d = lG(a.target.destinationId);
      return d && d[b] !== void 0 ? d[b] : c;
    },
    qG = function (a) {
      for (
        var b = new mG(a.target, a.eventName, a.F),
          c = nG(a),
          d = m(Object.keys(c)),
          e = d.next();
        !e.done;
        e = d.next()
      ) {
        var f = e.value;
        X(b, f, c[f]);
      }
      for (
        var g = oG(a), h = m(Object.keys(g)), l = h.next();
        !l.done;
        l = h.next()
      ) {
        var n = l.value;
        W(b, n, g[n]);
      }
      b.isAborted = a.isAborted;
      return b;
    },
    rG = function (a) {
      var b = a.F,
        c = b.eventId,
        d = b.priorityId;
      return d ? c + "_" + d : String(c);
    };
  mG.prototype.accept = function () {
    var a = Hm(Cm.aa.Ci, {}),
      b = rG(this),
      c = this.target.destinationId;
    a[b] || (a[b] = {});
    a[b][c] = tk();
    var d = Cm.aa.Ci;
    if (Dm(d)) {
      var e;
      (e = Em(d)) == null || e.notify();
    }
  };
  mG.prototype.canBeAccepted = function (a) {
    var b = Gm(Cm.aa.Ci);
    if (!b) return !0;
    var c = b[rG(this)];
    if (!c) return !0;
    var d = c[a != null ? a : this.target.destinationId];
    return d === void 0 || d === tk();
  };
  function sG(a) {
    return {
      getDestinationId: function () {
        return a.target.destinationId;
      },
      getEventName: function () {
        return a.eventName;
      },
      setEventName: function (b) {
        a.eventName = b;
      },
      getHitData: function (b) {
        return kv(a, b);
      },
      setHitData: function (b, c) {
        X(a, b, c);
      },
      setHitDataIfNotDefined: function (b, c) {
        kv(a, b) === void 0 && X(a, b, c);
      },
      copyToHitData: function (b, c) {
        a.copyToHitData(b, c);
      },
      getMetadata: function (b) {
        return T(a, b);
      },
      setMetadata: function (b, c) {
        W(a, b, c);
      },
      isAborted: function () {
        return a.isAborted;
      },
      abort: function () {
        a.isAborted = !0;
      },
      getFromEventContext: function (b) {
        return M(a.F, b);
      },
      tb: function () {
        return a;
      },
      getHitKeys: function () {
        return Object.keys(a.D);
      },
      getMergedValues: function (b) {
        return a.F.getMergedValues(b, 3);
      },
      mergeHitDataForKey: function (b, c) {
        return Id(c) ? a.mergeHitDataForKey(b, c) : !1;
      },
      accept: function () {
        a.accept();
      },
      canBeAccepted: function (b) {
        return a.canBeAccepted(b);
      },
    };
  }
  function tG(a, b) {
    var c;
    return c;
  }
  tG.K = "internal.copyPreHit";
  function uG(a, b) {
    var c = null;
    if (!Nh(a) || !Nh(b))
      throw H(this.getName(), ["string", "string"], arguments);
    I(this, "access_globals", "readwrite", a);
    I(this, "access_globals", "readwrite", b);
    var d = [w, A],
      e = a.split("."),
      f = bc(w, e, d),
      g = e[e.length - 1];
    if (f === void 0) throw Error("Path " + a + " does not exist.");
    var h = f[g];
    if (h) return Eb(h) ? Xd(h, this.M, 2) : null;
    var l;
    h = function () {
      if (!Eb(l.push))
        throw Error("Object at " + b + " in window is not an array.");
      l.push.call(l, arguments);
    };
    f[g] = h;
    var n = b.split("."),
      p = bc(w, n, d),
      q = n[n.length - 1];
    if (p === void 0) throw Error("Path " + n + " does not exist.");
    l = p[q];
    l === void 0 && ((l = []), (p[q] = l));
    c = function () {
      h.apply(h, Array.prototype.slice.call(arguments, 0));
    };
    return Xd(c, this.M, 2);
  }
  uG.publicName = "createArgumentsQueue";
  function vG(a) {
    return Xd(
      function (c) {
        var d = $z();
        if (typeof c === "function")
          d(function () {
            c(function (f, g, h) {
              var l = $z(),
                n = l && l.getByName && l.getByName(f);
              return new w.gaplugins.Linker(n).decorate(g, h);
            });
          });
        else if (Array.isArray(c)) {
          var e = String(c[0]).split(".");
          b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c);
        } else if (c === "isLoaded") return !!d.loaded;
      },
      this.M,
      1,
    );
  }
  vG.K = "internal.createGaCommandQueue";
  function wG(a) {
    return Xd(
      function () {
        if (!Eb(e.push))
          throw Error("Object at " + a + " in window is not an array.");
        e.push.apply(e, Array.prototype.slice.call(arguments, 0));
      },
      this.M,
      bi(RD(this).Nb()) ? 2 : 1,
    );
  }
  wG.publicName = "createQueue";
  function xG(a, b) {
    var c = null;
    if (!Nh(a) || !Oh(b))
      throw H(this.getName(), ["string", "string|undefined"], arguments);
    try {
      var d = (b || "")
        .split("")
        .filter(function (e) {
          return "ig".indexOf(e) >= 0;
        })
        .join("");
      c = new Ud(new RegExp(a, d));
    } catch (e) {}
    return c;
  }
  xG.K = "internal.createRegex";
  function yG(a) {}
  yG.K = "internal.declareConsentState";
  function zG(a) {
    var b = "";
    return b;
  }
  zG.K = "internal.decodeUrlHtmlEntities";
  function AG(a, b, c) {
    var d;
    return d;
  }
  AG.K = "internal.decorateUrlWithGaCookies";
  function BG() {}
  BG.K = "internal.deferCustomEvents";
  function CG(a) {
    return N(423) || DG ? A.querySelector(a) : null;
  }
  function EG(a) {
    return N(423) || DG ? A.querySelectorAll(a) : null;
  }
  function FG(a, b) {
    if (N(423))
      try {
        return a.closest(b);
      } catch (e) {
        return null;
      }
    else {
      if (!DG) return null;
      if (Element.prototype.closest)
        try {
          return a.closest(b);
        } catch (e) {
          return null;
        }
      var c =
          Element.prototype.matches ||
          Element.prototype.webkitMatchesSelector ||
          Element.prototype.mozMatchesSelector ||
          Element.prototype.msMatchesSelector ||
          Element.prototype.oMatchesSelector,
        d = a;
      if (!A.documentElement.contains(d)) return null;
      do {
        try {
          if (c.call(d, b)) return d;
        } catch (e) {
          break;
        }
        d = d.parentElement || d.parentNode;
      } while (d !== null && d.nodeType === 1);
      return null;
    }
  }
  var GG = !1;
  if (A.querySelectorAll)
    try {
      var HG = A.querySelectorAll(":root");
      HG && HG.length == 1 && HG[0] == A.documentElement && (GG = !0);
    } catch (a) {}
  var DG = GG;
  function IG() {
    var a = w.screen;
    return { width: a ? a.width : 0, height: a ? a.height : 0 };
  }
  function JG(a) {
    if (A.hidden) return !0;
    var b = a.getBoundingClientRect();
    if (b.top === b.bottom || b.left === b.right || !w.getComputedStyle)
      return !0;
    var c = w.getComputedStyle(a, null);
    if (c.visibility === "hidden") return !0;
    for (var d = a, e = c; d; ) {
      if (e.display === "none") return !0;
      var f = e.opacity,
        g = e.filter;
      if (g) {
        var h = g.indexOf("opacity(");
        h >= 0 &&
          ((g = g.substring(h + 8, g.indexOf(")", h))),
          g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)),
          (f = String(Math.min(Number(g), Number(f)))));
      }
      if (f !== void 0 && Number(f) <= 0) return !0;
      (d = d.parentElement) && (e = w.getComputedStyle(d, null));
    }
    return !1;
  }
  function OH(a) {
    var b;
    return b;
  }
  OH.K = "internal.detectUserProvidedData";
  function TH(a, b) {
    return f;
  }
  TH.K = "internal.enableAutoEventOnClick";
  function aI(a, b) {
    return p;
  }
  aI.K = "internal.enableAutoEventOnElementVisibility";
  function bI() {}
  bI.K = "internal.enableAutoEventOnError";
  var cI = {},
    dI = [],
    eI = {},
    fI = 0,
    gI = 0;
  function mI(a, b) {
    var c = this;
    return d;
  }
  mI.K = "internal.enableAutoEventOnFormInteraction";
  function rI(a, b) {
    var c = this;
    return f;
  }
  rI.K = "internal.enableAutoEventOnFormSubmit";
  function wI() {
    var a = this;
  }
  wI.K = "internal.enableAutoEventOnGaSend";
  var xI = {},
    yI = [];
  function FI(a, b) {
    var c = this;
    return f;
  }
  FI.K = "internal.enableAutoEventOnHistoryChange";
  var GI = ["http://", "https://", "javascript:", "file://"];
  function KI(a, b) {
    var c = this;
    return h;
  }
  KI.K = "internal.enableAutoEventOnLinkClick";
  var LI, MI;
  function XI(a, b) {
    var c = this;
    return d;
  }
  XI.K = "internal.enableAutoEventOnScroll";
  function YI(a) {
    return function () {
      if (a.limit && a.Oj >= a.limit) a.Uh && w.clearInterval(a.Uh);
      else {
        a.Oj++;
        var b = Tb();
        YB({
          event: a.eventName,
          "gtm.timerId": a.Uh,
          "gtm.timerEventNumber": a.Oj,
          "gtm.timerInterval": a.interval,
          "gtm.timerLimit": a.limit,
          "gtm.timerStartTime": a.eo,
          "gtm.timerCurrentTime": b,
          "gtm.timerElapsedTime": b - a.eo,
          "gtm.triggers": a.Cs,
        });
      }
    };
  }
  function ZI(a, b) {
    return f;
  }
  ZI.K = "internal.enableAutoEventOnTimer";
  var Kc = Ca(["data-gtm-yt-inspected-"]),
    aJ = ["www.youtube.com", "www.youtube-nocookie.com"],
    bJ,
    cJ = !1;
  function mJ(a, b) {
    var c = this;
    return e;
  }
  mJ.K = "internal.enableAutoEventOnYouTubeActivity";
  cJ = !1;
  function nJ(a, b) {
    if (!Nh(a) || !Hh(b))
      throw H(this.getName(), ["string", "Object|undefined"], arguments);
    var c = b ? B(b) : {},
      d = a,
      e = !1;
    return e;
  }
  nJ.K = "internal.evaluateBooleanExpression";
  var oJ;
  function pJ(a) {
    var b = !1;
    return b;
  }
  pJ.K = "internal.evaluateMatchingRules";
  var rJ = [J.m.X, J.m.Z];
  function xJ() {
    return jr(7) && jr(9) && jr(10);
  }
  function CJ(a) {
    if (N(10)) return;
    var b = Yj() || !!ak(a.F);
    N(431) && (b = vg(50) || !!ak(a.F));
    if (b) return;
    Ay();
  }
  function HJ() {
    var a;
    a = a === void 0 ? document : a;
    var b;
    return !(
      (b = a.featurePolicy) == null ||
      !b.allowedFeatures().includes("attribution-reporting")
    );
  }
  function OJ(a) {
    W(a, R.C.Fa, !0);
    W(a, R.C.Cb, Tb());
    W(a, R.C.Zm, a.F.eventMetadata[R.C.Fa]);
  }
  var $J = function (a, b) {
      if (a && (Fb(a) && (a = Io(a)), a)) {
        var c = void 0,
          d = !1,
          e = M(b, J.m.xp);
        if (e && Array.isArray(e)) {
          c = [];
          for (var f = 0; f < e.length; f++) {
            var g = Io(e[f]);
            g &&
              (c.push(g),
              (a.id === g.id ||
                (a.id === a.destinationId &&
                  a.destinationId === g.destinationId)) &&
                (d = !0));
          }
        }
        if (!c || d) {
          var h = M(b, J.m.Al),
            l;
          if (h) {
            l = Array.isArray(h) ? h : [h];
            var n = M(b, J.m.yl),
              p = M(b, J.m.zl),
              q = M(b, J.m.Bl),
              r = Gn(M(b, J.m.wp)),
              t = n || p,
              u = 1;
            a.prefix !== "UA" || c || (u = 5);
            for (var v = 0; v < l.length; v++)
              if (v < u)
                if (c) {
                  var x = c,
                    y = l[v],
                    z = r,
                    C = b,
                    E = { Ud: t, options: q };
                  O(21);
                  if (y && z) {
                    E = E || {};
                    for (
                      var G = {
                          countryNameCode: z,
                          destinationNumber: y,
                          retrievalTime: Sb(),
                        },
                        K = 0;
                      K < x.length;
                      K++
                    ) {
                      var P = x[K];
                      UJ[P.id] ||
                        (P &&
                        P.prefix === "AW" &&
                        !G.adData &&
                        P.ids.length >= 2
                          ? ((G.adData = {
                              ak: P.ids[Ko[0]],
                              cl: P.ids[Ko[1]],
                            }),
                            VJ(G.adData, C),
                            (UJ[P.id] = !0))
                          : P &&
                            P.prefix === "UA" &&
                            !G.gaData &&
                            ((G.gaData = { gaWpid: P.destinationId }),
                            (UJ[P.id] = !0)));
                    }
                    (G.gaData || G.adData) &&
                      WJ(XJ, E, void 0, C)(E.Ud, G, E.options);
                  }
                } else if (a.prefix === "AW" && a.ids[Ko[1]]) {
                  var fa = a.ids[Ko[0]],
                    ca = a.ids[Ko[1]],
                    Q = l[v],
                    S = b,
                    ma = { Ud: t, options: q };
                  O(22);
                  if (Q) {
                    ma = ma || {};
                    var ka = WJ(YJ, ma, fa, S),
                      V = { ak: fa, cl: ca };
                    ma.Ud === void 0 && (V.autoreplace = Q);
                    VJ(V, S);
                    ka(2, ma.Ud, V, Q, 0, Sb(), ma.options);
                  }
                } else if (a.prefix === "UA") {
                  var U = a.destinationId,
                    ea = l[v],
                    pa = { Ud: t };
                  O(23);
                  if (ea) {
                    pa = pa || {};
                    var qa = WJ(ZJ, pa, U),
                      Fa = {};
                    pa.Ud !== void 0
                      ? (Fa.receiver = pa.Ud)
                      : (Fa.replace = ea);
                    Fa.ga_wpid = U;
                    Fa.destination = ea;
                    qa(2, Sb(), Fa);
                  }
                }
          }
        }
      }
    },
    VJ = function (a, b) {
      a.dma = xr();
      yr() && (a.dmaCps = wr());
      pr(b) ? (a.npa = "0") : (a.npa = "1");
    },
    WJ = function (a, b, c, d) {
      var e = w;
      if (e[a.functionName]) return (b.Mn && jd(b.Mn), e[a.functionName]);
      var f = aK();
      e[a.functionName] = f;
      if (a.additionalQueues)
        for (var g = 0; g < a.additionalQueues.length; g++)
          e[a.additionalQueues[g]] = e[a.additionalQueues[g]] || aK();
      a.idKey && e[a.idKey] === void 0 && (e[a.idKey] = c);
      Yl(
        {
          destinationId: D(5),
          endpoint: 0,
          eventId: d == null ? void 0 : d.eventId,
          priorityId: d == null ? void 0 : d.priorityId,
        },
        Az("https://", "http://", a.scriptUrl),
        b.Mn,
        b.gu,
      );
      return f;
    },
    aK = function () {
      function a() {
        a.q = a.q || [];
        a.q.push(arguments);
      }
      return a;
    },
    YJ = {
      functionName: "_googWcmImpl",
      idKey: "_googWcmAk",
      scriptUrl: "www.gstatic.com/wcm/loader.js",
    },
    ZJ = {
      functionName: "_gaPhoneImpl",
      idKey: "ga_wpid",
      scriptUrl: "www.gstatic.com/gaphone/loader.js",
    },
    bK = { qo: yg(2), kq: "5" },
    XJ = {
      functionName: "_googCallTrackingImpl",
      additionalQueues: [ZJ.functionName, YJ.functionName],
      scriptUrl:
        "www.gstatic.com/call-tracking/call-tracking_" +
        (bK.qo || bK.kq) +
        ".js",
    },
    UJ = {};
  var gK = {};
  function iK(a) {
    var b = WA(!1);
    b && a.mergeHitDataForKey(J.m.Bb, { gtb: b });
  }
  var jK = { Ma: { gk: 1, bn: 2, ln: 3, mn: 4, nn: 5, Xm: 6 } };
  jK.Ma[jK.Ma.gk] = "ADOBE_COMMERCE";
  jK.Ma[jK.Ma.bn] = "SQUARESPACE";
  jK.Ma[jK.Ma.ln] = "WOO_COMMERCE";
  jK.Ma[jK.Ma.mn] = "WOO_COMMERCE_LEGACY";
  jK.Ma[jK.Ma.nn] = "WORD_PRESS";
  jK.Ma[jK.Ma.Xm] = "SHOPIFY";
  function kK(a) {
    var b = w;
    return Ij(b.escape(b.atob(a)));
  }
  function lK() {
    try {
      if (!N(243)) return [];
      var a = N(430);
      if (a) {
        var b = Gm(Cm.aa.Km);
        if (Array.isArray(b)) return b;
      }
      Wr("4");
      var c = [],
        d;
      a: {
        try {
          d = !!CG('script[data-requiremodule^="mage/"]');
          break a;
        } catch (z) {}
        d = !1;
      }
      d && c.push(jK.Ma.gk);
      var e;
      a: {
        try {
          var f = kK("YXNzZXRzLnNxdWFyZXNwYWNlLmNvbS8=");
          e = f ? !!CG('script[src^="//' + f + '"]') : !1;
          break a;
        } catch (z) {}
        e = !1;
      }
      e && c.push(jK.Ma.bn);
      var g;
      a: {
        if (N(425))
          try {
            var h = kK("c2hvcGlmeS5jb20="),
              l = kK("c2hvcGlmeWNkbi5jb20=");
            g =
              h && l
                ? !!CG(
                    'script[src*="cdn.' +
                      h +
                      '"],meta[property="og:image"][content*="cdn.' +
                      (h + '"],link[rel="preconnect"][href*="cdn.') +
                      (h + '"],link[rel="preconnect"][href*="fonts.') +
                      (l +
                        '"],link[rel="preconnect"][href*="iterable-shopify"],link[rel="preconnect"][href*="v.') +
                      (h + '"]'),
                  )
                : !1;
            break a;
          } catch (z) {}
        g = !1;
      }
      g && c.push(jK.Ma.Xm);
      var n;
      a: {
        try {
          n = !!CG(
            'script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]',
          );
          break a;
        } catch (z) {}
        n = !1;
      }
      n && c.push(jK.Ma.mn);
      var p;
      a: {
        try {
          var q,
            r = ((q = A.location) == null ? void 0 : q.hostname) || "",
            t,
            u = ((t = A.location) == null ? void 0 : t.origin) || "",
            v = kK("LndvcmRwcmVzcy5jb20="),
            x = kK("Ly9zLncub3Jn");
          p =
            v && x
              ? ac(r, v) ||
                !!CG(
                  '[src^="' +
                    u +
                    '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="' +
                    (x + '"]'),
                )
              : !1;
          break a;
        } catch (z) {}
        p = !1;
      }
      p && c.push(jK.Ma.nn);
      var y;
      a: {
        try {
          y = !!CG(
            '[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]',
          );
          break a;
        } catch (z) {}
        y = !1;
      }
      y && c.push(jK.Ma.ln);
      Xr("4");
      aB && a && Fm(Cm.aa.Km, c);
      return c;
    } catch (z) {}
    return [];
  }
  function XK(a) {
    if (N(425) && T(a, R.C.cg)) {
      var b = a.mergeHitDataForKey,
        c = J.m.Bb,
        d = {};
      b.call(a, c, d);
    }
  }
  var YK =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " ",
    );
  function ZK(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function $K(a) {
    var b = a.google_tag_data,
      c;
    if (b != null && b.uach) {
      var d = b.uach,
        e = oa(Object, "assign").call(Object, {}, d);
      d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
      c = e;
    } else c = null;
    return c;
  }
  function aL(a) {
    var b, c;
    return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) !=
      null
      ? c
      : null;
  }
  function bL(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
          ? void 0
          : c.getHighEntropyValues) === "function"
    );
  }
  function cL(a) {
    if (!bL(a)) return null;
    var b = ZK(a);
    if (b.uach_promise) return b.uach_promise;
    var c = a.navigator.userAgentData
      .getHighEntropyValues(YK)
      .then(function (d) {
        b.uach != null || (b.uach = d);
        return d;
      });
    return (b.uach_promise = c);
  }
  var dL = function (a) {
      var b = {};
      b[J.m.Nf] = a.architecture;
      b[J.m.Of] = a.bitness;
      a.fullVersionList &&
        (b[J.m.Pf] = a.fullVersionList
          .map(function (c) {
            return (
              encodeURIComponent(c.brand || "") +
              ";" +
              encodeURIComponent(c.version || "")
            );
          })
          .join("|"));
      b[J.m.Qf] = a.mobile ? "1" : "0";
      b[J.m.Rf] = a.model;
      b[J.m.Sf] = a.platform;
      b[J.m.Tf] = a.platformVersion;
      b[J.m.Uf] = a.wow64 ? "1" : "0";
      return b;
    },
    eL = function (a) {
      var b = 0,
        c = function (h, l) {
          try {
            a(h, l);
          } catch (n) {}
        },
        d = w,
        e = $K(d);
      if (e) c(e);
      else {
        var f = aL(d);
        if (f) {
          b = Math.min(Math.max(isFinite(b) ? b : 0, 0), 1e3);
          var g = d.setTimeout(function () {
            c.Cg || ((c.Cg = !0), O(106), c(null, Error("Timeout")));
          }, b);
          f.then(function (h) {
            c.Cg || ((c.Cg = !0), O(104), d.clearTimeout(g), c(h));
          }).catch(function (h) {
            c.Cg || ((c.Cg = !0), O(105), d.clearTimeout(g), c(null, h));
          });
        } else c(null);
      }
    },
    gL = function () {
      var a = w;
      if (bL(a) && ((fL = Tb()), !aL(a))) {
        var b = cL(a);
        b &&
          (b.then(function () {
            O(95);
          }),
          b.catch(function () {
            O(96);
          }));
      }
    },
    fL;
  function iL(a, b) {
    b = b === void 0 ? !1 : b;
    var c = T(a, R.C.hg),
      d = pG(a, "custom_event_accept_rules", !1) && !b;
    if (c) {
      var e = c.indexOf(a.target.destinationId) >= 0,
        f = !0;
      T(a, R.C.qb) && (f = T(a, R.C.Ta) === tk());
      e && f ? W(a, R.C.bi, !0) : (W(a, R.C.bi, !1), d || (a.isAborted = !0));
      if (a.canBeAccepted()) {
        var g = sk().indexOf(a.target.destinationId) >= 0,
          h = !1;
        if (!g) {
          var l,
            n =
              (l = lk(a.target.destinationId)) == null
                ? void 0
                : l.canonicalContainerId;
          n && (h = tk() === n);
        }
        g || h ? T(a, R.C.bi) && a.accept() : (a.isAborted = !0);
      } else a.isAborted = !0;
    }
  }
  var qL = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
    rL = /^www.googleadservices.com$/;
  function sL(a) {
    a || (a = tL());
    return a.Ds
      ? !1
      : a.mr ||
          a.nr ||
          a.rr ||
          a.qr ||
          a.Re ||
          a.Nh ||
          a.Wq ||
          a.bc === "aw.ds" ||
          (N(235) && a.bc === "aw.dv") ||
          a.ar
        ? !0
        : !1;
  }
  function tL() {
    var a = {},
      b = Ms(!0);
    a.Ds = !!b._up;
    var c = pu(),
      d = Su();
    a.mr = c.aw !== void 0;
    a.nr = c.dc !== void 0;
    a.rr = c.wbraid !== void 0;
    a.qr = c.gbraid !== void 0;
    a.bc = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
    a.Re = d.Re;
    a.Nh = d.Nh;
    var e = A.referrer ? Jj(Pj(A.referrer), "host") : "";
    a.ar = qL.test(e);
    a.Wq = rL.test(e);
    return a;
  }
  function uL() {
    var a = w.__uspapi;
    if (Eb(a)) {
      var b = "";
      try {
        a("getUSPData", 1, function (c, d) {
          if (d && c) {
            var e = c.uspString;
            e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e);
          }
        });
      } catch (c) {}
      return b;
    }
  }
  function xL(a) {
    el &&
      ((Wm = !0),
      a.eventName === J.m.na
        ? bn(a.F, a.target.id)
        : (T(a, R.C.Fc) || (Zm[a.target.id] = !0), tB(T(a, R.C.Ta))));
  }
  var DL = { Jp: { Js: "cd", vo: "ce", Ks: "cf", Ls: "cpf", Ms: "cu" } };
  function FL(a, b) {
    b = b === void 0 ? !0 : b;
    var c = Cb(xb.GTAG_EVENT_FEATURE_CHANNEL || []);
    c && (X(a, J.m.If, c), b && Ab());
  }
  function RL(a) {}
  var vM = function (a, b) {
      if (!b.isGtmEvent) {
        var c = M(b, J.m.Gf),
          d = M(b, J.m.Ff),
          e = M(b, c);
        if (e === void 0) {
          var f = void 0;
          sM.hasOwnProperty(c)
            ? (f = sM[c])
            : tM.hasOwnProperty(c) && (f = tM[c]);
          f === 1 && (f = uM(c));
          Fb(f)
            ? $z()(function () {
                var g,
                  h,
                  l,
                  n =
                    (l =
                      (g = $z()) == null
                        ? void 0
                        : (h = g.getByName) == null
                          ? void 0
                          : h.call(g, a)) == null
                      ? void 0
                      : l.get(f);
                d(n);
              })
            : d(void 0);
        } else d(e);
      }
    },
    wM = function (a, b) {
      var c = a[J.m.vd],
        d = b + ".",
        e = a[J.m.xa] || "",
        f = c === void 0 ? !!a.use_anchor : c === "fragment",
        g = !!a[J.m.Oc];
      e = String(e).replace(/\s+/g, "").split(",");
      var h = $z();
      h(d + "require", "linker");
      h(d + "linker:autoLink", e, f, g);
    },
    AM = function (a, b, c) {
      if (!c.isGtmEvent || !xM[a]) {
        var d = !mo(J.m.la),
          e = function (f) {
            var g = "gtm" + String(Co()),
              h,
              l = $z(),
              n = yM(b, "", c),
              p,
              q = n.createOnlyFields._useUp;
            if (c.isGtmEvent || zM(b, n.createOnlyFields)) {
              c.isGtmEvent &&
                ((h = n.createOnlyFields), n.gtmTrackerName && (h.name = g));
              l(function () {
                var t,
                  u =
                    l == null
                      ? void 0
                      : (t = l.getByName) == null
                        ? void 0
                        : t.call(l, b);
                u && (p = u.get("clientId"));
                if (!c.isGtmEvent) {
                  var v;
                  l == null || (v = l.remove) == null || v.call(l, b);
                }
              });
              l("create", a, c.isGtmEvent ? h : n.createOnlyFields);
              d &&
                mo(J.m.la) &&
                ((d = !1),
                l(function () {
                  var t,
                    u,
                    v =
                      (t = $z()) == null
                        ? void 0
                        : (u = t.getByName) == null
                          ? void 0
                          : u.call(t, c.isGtmEvent ? g : b);
                  !v ||
                    (v.get("clientId") == p && q) ||
                    (c.isGtmEvent
                      ? ((n.fieldsToSet["&gcu"] = "1"),
                        (n.fieldsToSet["&sst.gcut"] = Bn[f]))
                      : ((n.fieldsToSend["&gcu"] = "1"),
                        (n.fieldsToSend["&sst.gcut"] = Bn[f])),
                    v.set(n.fieldsToSet),
                    c.isGtmEvent
                      ? v.send("pageview")
                      : v.send("pageview", n.fieldsToSend));
                }));
              c.isGtmEvent &&
                l(function () {
                  var t;
                  l == null || (t = l.remove) == null || t.call(l, g);
                });
            }
          };
        qo(function () {
          return void e(J.m.la);
        }, J.m.la);
        qo(function () {
          return void e(J.m.X);
        }, J.m.X);
        qo(function () {
          return void e(J.m.Z);
        }, J.m.Z);
        c.isGtmEvent && (xM[a] = !0);
      }
    },
    BM = function (a, b) {
      Zj() && b && (a[J.m.Ub] = b);
    },
    KM = function (a, b, c) {
      function d() {
        var S = Qa.apply(0, arguments);
        S[0] = x ? x + "." + S[0] : "" + S[0];
        u.apply(window, S);
      }
      function e(S) {
        function ma(qa, Fa) {
          for (var Va = 0; Fa && Va < Fa.length; Va++) d(qa, Fa[Va]);
        }
        var ka = c.isGtmEvent,
          V = ka ? CM(y) : DM(b, c);
        if (V) {
          var U = {};
          BM(U, S);
          d("require", "ec", "ec.js", U);
          ka && V.qj && d("set", "&cu", V.qj);
          var ea = V.action;
          if (ka || ea === "impressions")
            if ((ma("ec:addImpression", V.Hn), !ka)) return;
          if (ea === "promo_click" || ea === "promo_view" || (ka && V.Ig)) {
            var pa = V.Ig;
            ma("ec:addPromo", pa);
            if (pa && pa.length > 0 && ea === "promo_click") {
              ka ? d("ec:setAction", ea, V.Zb) : d("ec:setAction", ea);
              return;
            }
            if (!ka) return;
          }
          ea !== "promo_view" &&
            ea !== "impressions" &&
            (ma("ec:addProduct", V.Xd), d("ec:setAction", ea, V.Zb));
        }
      }
      function f(S) {
        if (S) {
          var ma = {};
          if (Id(S))
            for (var ka in EM)
              EM.hasOwnProperty(ka) && FM(EM[ka], ka, S[ka], ma);
          BM(ma, E);
          d("require", "linkid", ma);
        }
      }
      function g() {
        var S = M(c, J.m.up);
        if (S) {
          var ma = D(19);
          d("require", S, { dataLayer: ma });
          d("require", "render");
        }
      }
      function h() {
        var S = M(c, J.m.ue);
        u(function () {
          if (!c.isGtmEvent && Id(S)) {
            var ma = y.fieldsToSend,
              ka,
              V,
              U =
                (ka = v()) == null
                  ? void 0
                  : (V = ka.getByName) == null
                    ? void 0
                    : V.call(ka, x),
              ea;
            for (ea in S)
              if (S[ea] != null && /^(dimension|metric)\d+$/.test(ea)) {
                var pa = void 0,
                  qa = (pa = U) == null ? void 0 : pa.get(uM(S[ea]));
                GM(ma, ea, qa);
              }
          }
        });
      }
      function l(S, ma, ka) {
        ka && (ma = String(ma));
        y.fieldsToSend[S] = ma;
      }
      function n() {
        if (y.displayfeatures) {
          var S = "_dc_gtm_" + p.replace(/[^A-Za-z0-9-]/g, "");
          d("require", "displayfeatures", void 0, { cookieName: S });
        }
      }
      var p = a,
        q = Io(a),
        r = c.eventMetadata[R.C.hg];
      if (!(q && r && r.indexOf(q.destinationId) < 0)) {
        el &&
          ((Wm = !0),
          b === J.m.na
            ? bn(c, a)
            : (c.eventMetadata[R.C.Fc] || (Zm[a] = !0),
              tB(c.eventMetadata[R.C.Ta])));
        var t,
          u = c.isGtmEvent ? cA(M(c, "gaFunctionName")) : cA();
        if (Eb(u)) {
          var v = $z,
            x;
          x = c.isGtmEvent
            ? M(c, "name") || M(c, "gtmTrackerName")
            : "gtag_" + p.split("-").join("_");
          var y = yM(x, b, c);
          !c.isGtmEvent &&
            zM(x, y.createOnlyFields) &&
            (u(function () {
              var S, ma;
              v() &&
                ((S = v()) == null || (ma = S.remove) == null || ma.call(S, x));
            }),
            (HM[x] = !1));
          u("create", p, y.createOnlyFields);
          var z = c.isGtmEvent && y.fieldsToSet[J.m.Ub];
          if ((!c.isGtmEvent && y.createOnlyFields[J.m.Ub]) || z) {
            var C = Xj(
              c.isGtmEvent ? y.fieldsToSet[J.m.Ub] : y.createOnlyFields[J.m.Ub],
              "/analytics.js",
            );
            C && (t = C);
          }
          var E = c.isGtmEvent
            ? y.fieldsToSet[J.m.Ub]
            : y.createOnlyFields[J.m.Ub];
          if (E) {
            var G = c.isGtmEvent
              ? y.fieldsToSet[J.m.Df]
              : y.createOnlyFields[J.m.Df];
            G && !HM[x] && ((HM[x] = !0), u(eA(x, G)));
          }
          c.isGtmEvent
            ? y.enableRecaptcha && d("require", "recaptcha", "recaptcha.js")
            : (h(), f(y.linkAttribution));
          var K = y[J.m.fb];
          K && K[J.m.xa] && wM(K, x);
          d("set", y.fieldsToSet);
          if (c.isGtmEvent) {
            if (y.enableLinkId) {
              var P = {};
              BM(P, E);
              d("require", "linkid", "linkid.js", P);
            }
            AM(p, x, c);
          }
          if (b === J.m.rc)
            if (c.isGtmEvent) {
              n();
              if (y.remarketingLists) {
                var fa = "_dc_gtm_" + p.replace(/[^A-Za-z0-9-]/g, "");
                d("require", "adfeatures", { cookieName: fa });
              }
              e(E);
              d("send", "pageview");
              y.createOnlyFields._useUp && bA(x + ".");
            } else (g(), d("send", "pageview", y.fieldsToSend));
          else
            b === J.m.na
              ? (g(),
                $J(p, c),
                M(c, J.m.Kb) && (Hu(["aw", "dc"]), bA(x + ".")),
                Ju(["aw", "dc"]),
                y.sendPageView != 0 && d("send", "pageview", y.fieldsToSend),
                AM(p, x, c))
              : b === J.m.Gb
                ? vM(x, c)
                : b === "screen_view"
                  ? d("send", "screenview", y.fieldsToSend)
                  : b === "timing_complete"
                    ? ((y.fieldsToSend.hitType = "timing"),
                      l("timingCategory", y.eventCategory, !0),
                      c.isGtmEvent
                        ? l("timingVar", y.timingVar, !0)
                        : l("timingVar", y.name, !0),
                      l("timingValue", Ob(y.value)),
                      y.eventLabel !== void 0 &&
                        l("timingLabel", y.eventLabel, !0),
                      d("send", y.fieldsToSend))
                    : b === "exception"
                      ? d("send", "exception", y.fieldsToSend)
                      : (b === "" && c.isGtmEvent) ||
                        (b === "track_social" && c.isGtmEvent
                          ? ((y.fieldsToSend.hitType = "social"),
                            l("socialNetwork", y.socialNetwork, !0),
                            l("socialAction", y.socialAction, !0),
                            l("socialTarget", y.socialTarget, !0))
                          : ((c.isGtmEvent || IM[b]) && e(E),
                            c.isGtmEvent && n(),
                            (y.fieldsToSend.hitType = "event"),
                            l("eventCategory", y.eventCategory, !0),
                            l("eventAction", y.eventAction || b, !0),
                            y.eventLabel !== void 0 &&
                              l("eventLabel", y.eventLabel, !0),
                            y.value !== void 0 && l("eventValue", Ob(y.value))),
                        d("send", y.fieldsToSend));
          var ca = t && !c.eventMetadata[R.C.dn];
          if (!JM && (!c.isGtmEvent || ca)) {
            JM = !0;
            var Q = function () {
              c.onFailure();
            };
            cd(
              t || "https://www.google-analytics.com/analytics.js",
              function () {
                var S;
                ((S = v()) == null ? 0 : S.loaded) || Q();
              },
              Q,
            );
          }
        } else jd(c.onFailure);
      }
    },
    LM = function (a, b, c, d) {
      ro(
        function () {
          KM(a, b, d);
        },
        [J.m.la, J.m.X],
      );
    },
    zM = function (a, b) {
      var c = MM[a];
      MM[a] = Jd(b, null);
      if (!c) return !1;
      for (var d in b) if (b.hasOwnProperty(d) && b[d] !== c[d]) return !0;
      for (var e in c) if (c.hasOwnProperty(e) && c[e] !== b[e]) return !0;
      return !1;
    },
    DM = function (a, b) {
      function c(u) {
        return {
          id: d(J.m.Da),
          affiliation: d(J.m.Yk),
          revenue: d(J.m.Ea),
          tax: d(J.m.al),
          shipping: d(J.m.rd),
          coupon: d(J.m.Zk),
          list: d(J.m.oi) || d(J.m.Af) || u,
        };
      }
      for (
        var d = function (u) {
            return M(b, u);
          },
          e = d(J.m.wa),
          f,
          g = 0;
        e && g < e.length && !(f = e[g][J.m.oi] || e[g][J.m.Af]);
        g++
      );
      var h = d(J.m.ue);
      if (Id(h))
        for (var l = 0; e && l < e.length; ++l) {
          var n = e[l],
            p;
          for (p in h)
            h.hasOwnProperty(p) &&
              /^(dimension|metric)\d+$/.test(p) &&
              h[p] != null &&
              GM(n, p, n[h[p]]);
        }
      var q = null,
        r = d(J.m.ep);
      if (a === J.m.Fb || a === J.m.me) q = { action: a, Zb: c(), Xd: NM(e) };
      else if (a === J.m.ie) q = { action: "add", Zb: c(), Xd: NM(e) };
      else if (a === J.m.je) q = { action: "remove", Zb: c(), Xd: NM(e) };
      else if (a === J.m.qc) q = { action: "detail", Zb: c(f), Xd: NM(e) };
      else if (a === J.m.nc) q = { action: "impressions", Hn: NM(e) };
      else if (a === J.m.oc) q = { action: "promo_view", Ig: NM(r) || NM(e) };
      else if ((a === "select_content" && r && r.length > 0) || a === J.m.Gc)
        q = { action: "promo_click", Ig: NM(r) || NM(e) };
      else if (a === "select_content" || a === J.m.ke)
        q = {
          action: "click",
          Zb: { list: d(J.m.oi) || d(J.m.Af) || f },
          Xd: NM(e),
        };
      else if (a === J.m.jd || a === "checkout_progress") {
        var t = { step: a === J.m.jd ? 1 : d(J.m.ni), option: d(J.m.ih) };
        q = { action: "checkout", Xd: NM(e), Zb: Jd(c(), t) };
      } else
        a === "set_checkout_option" &&
          (q = {
            action: "checkout_option",
            Zb: { step: d(J.m.ni), option: d(J.m.ih) },
          });
      q && (q.qj = d(J.m.nb));
      return q;
    },
    CM = function (a) {
      var b = a.gtmEcommerceData;
      if (!b) return null;
      var c = {};
      b.currencyCode && (c.qj = b.currencyCode);
      if (b.impressions) {
        c.action = "impressions";
        var d = b.impressions;
        c.Hn = b.translateIfKeyEquals === "impressions" ? NM(d) : d;
      }
      if (b.promoView) {
        c.action = "promo_view";
        var e = b.promoView.promotions;
        c.Ig = b.translateIfKeyEquals === "promoView" ? NM(e) : e;
      }
      if (b.promoClick) {
        var f = b.promoClick;
        c.action = "promo_click";
        var g = f.promotions;
        c.Ig = b.translateIfKeyEquals === "promoClick" ? NM(g) : g;
        c.Zb = f.actionField;
        return c;
      }
      for (var h in b)
        if (
          b[h] !== void 0 &&
          h !== "translateIfKeyEquals" &&
          h !== "impressions" &&
          h !== "promoView" &&
          h !== "promoClick" &&
          h !== "currencyCode"
        ) {
          c.action = h;
          var l = b[h].products;
          c.Xd = b.translateIfKeyEquals === "products" ? NM(l) : l;
          c.Zb = b[h].actionField;
          break;
        }
      return Object.keys(c).length ? c : null;
    },
    NM = function (a) {
      function b(e) {
        function f(h, l) {
          for (var n = 0; n < l.length; n++) {
            var p = l[n];
            if (e[p]) {
              g[h] = e[p];
              break;
            }
          }
        }
        var g = Jd(e, null);
        f("id", ["id", "item_id", "promotion_id"]);
        f("name", ["name", "item_name", "promotion_name"]);
        f("brand", ["brand", "item_brand"]);
        f("variant", ["variant", "item_variant"]);
        f("list", ["list_name", "item_list_name"]);
        f("position", ["list_position", "creative_slot", "index"]);
        (function () {
          if (e.category) g.category = e.category;
          else {
            for (var h = "", l = 0; l < OM.length; l++)
              e[OM[l]] !== void 0 && (h && (h += "/"), (h += e[OM[l]]));
            h && (g.category = h);
          }
        })();
        f("listPosition", ["list_position"]);
        f("creative", ["creative_name"]);
        f("list", ["list_name"]);
        f("position", ["list_position", "creative_slot"]);
        return g;
      }
      for (var c = [], d = 0; a && d < a.length; d++)
        a[d] && Id(a[d]) && c.push(b(a[d]));
      return c.length ? c : void 0;
    },
    yM = function (a, b, c) {
      var d = function (Q) {
          return M(c, Q);
        },
        e = {},
        f = {},
        g = {},
        h = {},
        l = PM(d(J.m.mp));
      !c.isGtmEvent && l && GM(f, "exp", l);
      g["&gtm"] = Tp({
        Ra: c.eventMetadata[R.C.Ta],
        Lh: !0,
        kc: !!c.eventMetadata[R.C.qb],
      });
      c.isGtmEvent || (g._no_slc = !0);
      nm() && (h._cs = QM);
      var n = d(J.m.ue);
      if (!c.isGtmEvent && Id(n))
        for (var p in n)
          if (
            n.hasOwnProperty(p) &&
            /^(dimension|metric)\d+$/.test(p) &&
            n[p] != null
          ) {
            var q = d(String(n[p]));
            q !== void 0 && GM(f, p, q);
          }
      for (var r = !c.isGtmEvent, t = tp(c), u = 0; u < t.length; ++u) {
        var v = t[u];
        if (c.isGtmEvent) {
          var x = d(v);
          RM.hasOwnProperty(v)
            ? (e[v] = x)
            : SM.hasOwnProperty(v)
              ? (h[v] = x)
              : (g[v] = x);
        } else {
          var y = void 0;
          v !== J.m.Ha ? (y = d(v)) : (y = c.getMergedValues(v));
          if (TM.hasOwnProperty(v)) FM(TM[v], v, y, e);
          else if (UM.hasOwnProperty(v)) FM(UM[v], v, y, g);
          else if (tM.hasOwnProperty(v)) FM(tM[v], v, y, f);
          else if (sM.hasOwnProperty(v)) FM(sM[v], v, y, h);
          else if (/^(dimension|metric|content_group)\d+$/.test(v))
            FM(1, v, y, f);
          else if (v === J.m.Ha) {
            var z = ec(y);
            z && (f["&did"] = z);
            var C = void 0,
              E = void 0;
            b === J.m.na
              ? (C = ec(c.getMergedValues(v), "."))
              : ((C = ec(c.getMergedValues(v, 1), ".")),
                (E = ec(c.getMergedValues(v, 2), ".")));
            C && (f["&gdid"] = C);
            E && (f["&edid"] = E);
          } else
            v === J.m.eb &&
              t.indexOf(J.m.nd) < 0 &&
              (h.cookieName = String(y) + "_ga");
          VM[v] &&
            (c.J.hasOwnProperty(v) ||
              (b === J.m.na && c.D.hasOwnProperty(v))) &&
            (r = !1);
        }
      }
      r && (f["&jsscut"] = "1");
      (d(J.m.Yg) !== !1 && d(J.m.uc) !== !1 && xJ()) ||
        (g.allowAdFeatures = !1);
      g.allowAdPersonalizationSignals = pr(c);
      !c.isGtmEvent && d(J.m.Kb) && (h._useUp = !0);
      if (c.isGtmEvent) {
        h.name = h.name || e.gtmTrackerName;
        var G = g.hitCallback;
        g.hitCallback = function () {
          Eb(G) && G();
          c.onSuccess();
        };
      } else {
        GM(h, "cookieDomain", "auto");
        GM(g, "forceSSL", !0);
        GM(e, "eventCategory", WM(b));
        XM[b] && GM(f, "nonInteraction", !0);
        b === "login" || b === "sign_up" || b === "share"
          ? GM(e, "eventLabel", d(J.m.vl))
          : b === "search" || b === "view_search_results"
            ? GM(e, "eventLabel", d(J.m.Cp))
            : b === "select_content" && GM(e, "eventLabel", d(J.m.ap));
        var K = e[J.m.fb] || {},
          P = K[J.m.Kf];
        P || (P != 0 && K[J.m.xa])
          ? (h.allowLinker = !0)
          : P === !1 && GM(h, "useAmpClientId", !1);
        f.hitCallback = c.onSuccess;
        h.name = a;
      }
      qr() && (g["&gcs"] = rr());
      g["&gcd"] = vr(c);
      nm() &&
        (mo(J.m.la) || (h.storage = "none"),
        mo([J.m.X, J.m.Z]) || ((g.allowAdFeatures = !1), (h.storeGac = !1)));
      yr() && (g["&dma_cps"] = wr());
      g["&dma"] = xr();
      Uq(br()) && (g["&tcfd"] = zr());
      Sk() && (g["&tag_exp"] = Sk());
      var fa = ak(c) || d(J.m.Ub),
        ca = d(J.m.Df);
      fa && (c.isGtmEvent || (h[J.m.Ub] = fa), (h._cd2l = !0));
      ca && !c.isGtmEvent && (h[J.m.Df] = ca);
      e.fieldsToSend = f;
      e.fieldsToSet = g;
      e.createOnlyFields = h;
      return e;
    },
    QM = function (a) {
      return mo(a);
    },
    PM = function (a) {
      if (Array.isArray(a)) {
        for (var b = [], c = 0; c < a.length; c++) {
          var d = a[c];
          if (d != null) {
            var e = d.id,
              f = d.variant;
            e != null && f != null && b.push(String(e) + "." + String(f));
          }
        }
        return b.length > 0 ? b.join("!") : void 0;
      }
    },
    GM = function (a, b, c) {
      a.hasOwnProperty(b) || (a[b] = c);
    },
    WM = function (a) {
      var b = "general";
      YM[a]
        ? (b = "ecommerce")
        : ZM[a]
          ? (b = "engagement")
          : a === "exception" && (b = "error");
      return b;
    },
    uM = function (a) {
      return a && Fb(a)
        ? a.replace(/(_[a-z])/g, function (b) {
            return b[1].toUpperCase();
          })
        : a;
    },
    FM = function (a, b, c, d) {
      if (c !== void 0)
        if (
          ($M[b] && (c = Pb(c)),
          b !== "anonymize_ip" || c || (c = void 0),
          a === 1)
        )
          d[uM(b)] = c;
        else if (Fb(a)) d[a] = c;
        else
          for (var e in a)
            a.hasOwnProperty(e) && c[e] !== void 0 && (d[a[e]] = c[e]);
    },
    JM = !1,
    HM = {},
    xM = {},
    aN = {},
    VM =
      ((aN[J.m.Rb] = 1),
      (aN[J.m.uc] = 1),
      (aN[J.m.Ib] = 1),
      (aN[J.m.Ab] = 1),
      (aN[J.m.Tb] = 1),
      (aN[J.m.nd] = 1),
      (aN[J.m.vc] = 1),
      (aN[J.m.eb] = 1),
      (aN[J.m.od] = 1),
      (aN[J.m.xl] = 1),
      (aN[J.m.ya] = 1),
      (aN[J.m.Lf] = 1),
      (aN[J.m.Xa] = 1),
      (aN[J.m.Jb] = 1),
      aN),
    bN = {},
    sM =
      ((bN.client_storage = "storage"),
      (bN.sample_rate = 1),
      (bN.site_speed_sample_rate = 1),
      (bN.store_gac = 1),
      (bN.use_amp_client_id = 1),
      (bN[J.m.Sb] = 1),
      (bN[J.m.zb] = "storeGac"),
      (bN[J.m.Ib] = 1),
      (bN[J.m.Ab] = 1),
      (bN[J.m.Tb] = 1),
      (bN[J.m.nd] = 1),
      (bN[J.m.vc] = 1),
      (bN[J.m.od] = 1),
      bN),
    cN = {},
    SM =
      ((cN._cs = 1),
      (cN._useUp = 1),
      (cN.allowAnchor = 1),
      (cN.allowLinker = 1),
      (cN.alwaysSendReferrer = 1),
      (cN.clientId = 1),
      (cN.cookieDomain = 1),
      (cN.cookieExpires = 1),
      (cN.cookieFlags = 1),
      (cN.cookieName = 1),
      (cN.cookiePath = 1),
      (cN.cookieUpdate = 1),
      (cN.legacyCookieDomain = 1),
      (cN.legacyHistoryImport = 1),
      (cN.name = 1),
      (cN.sampleRate = 1),
      (cN.siteSpeedSampleRate = 1),
      (cN.storage = 1),
      (cN.storeGac = 1),
      (cN.useAmpClientId = 1),
      (cN._cd2l = 1),
      cN),
    UM = { anonymize_ip: 1 },
    dN = {},
    tM =
      ((dN.campaign = {
        content: "campaignContent",
        id: "campaignId",
        medium: "campaignMedium",
        name: "campaignName",
        source: "campaignSource",
        term: "campaignKeyword",
      }),
      (dN.app_id = 1),
      (dN.app_installer_id = 1),
      (dN.app_name = 1),
      (dN.app_version = 1),
      (dN.description = "exDescription"),
      (dN.fatal = "exFatal"),
      (dN.language = 1),
      (dN.page_hostname = "hostname"),
      (dN.transport_type = "transport"),
      (dN[J.m.nb] = "currencyCode"),
      (dN[J.m.xi] = 1),
      (dN[J.m.ya] = "location"),
      (dN[J.m.Lf] = "page"),
      (dN[J.m.Xa] = "referrer"),
      (dN[J.m.Jb] = "title"),
      (dN[J.m.yi] = 1),
      (dN[J.m.Oa] = 1),
      dN),
    eN = {},
    TM =
      ((eN.content_id = 1),
      (eN.event_action = 1),
      (eN.event_category = 1),
      (eN.event_label = 1),
      (eN.link_attribution = 1),
      (eN.name = 1),
      (eN[J.m.fb] = 1),
      (eN[J.m.vl] = 1),
      (eN[J.m.wd] = 1),
      (eN[J.m.Ea] = 1),
      eN),
    RM = {
      displayfeatures: 1,
      enableLinkId: 1,
      enableRecaptcha: 1,
      eventAction: 1,
      eventCategory: 1,
      eventLabel: 1,
      gaFunctionName: 1,
      gtmEcommerceData: 1,
      gtmTrackerName: 1,
      linker: 1,
      remarketingLists: 1,
      socialAction: 1,
      socialNetwork: 1,
      socialTarget: 1,
      timingVar: 1,
      value: 1,
    },
    OM = [
      "item_category",
      "item_category2",
      "item_category3",
      "item_category4",
      "item_category5",
    ],
    fN = {},
    EM = ((fN.levels = 1), (fN[J.m.Ab] = "duration"), (fN[J.m.nd] = 1), fN),
    gN = {},
    $M =
      ((gN.anonymize_ip = 1),
      (gN.fatal = 1),
      (gN.send_page_view = 1),
      (gN.store_gac = 1),
      (gN.use_amp_client_id = 1),
      (gN[J.m.zb] = 1),
      (gN[J.m.xi] = 1),
      gN),
    hN = {},
    IM =
      ((hN.checkout_progress = 1),
      (hN.select_content = 1),
      (hN.set_checkout_option = 1),
      (hN[J.m.ie] = 1),
      (hN[J.m.je] = 1),
      (hN[J.m.jd] = 1),
      (hN[J.m.ke] = 1),
      (hN[J.m.nc] = 1),
      (hN[J.m.Gc] = 1),
      (hN[J.m.oc] = 1),
      (hN[J.m.Fb] = 1),
      (hN[J.m.me] = 1),
      (hN[J.m.qc] = 1),
      hN),
    iN = {},
    YM =
      ((iN.checkout_progress = 1),
      (iN.set_checkout_option = 1),
      (iN[J.m.Nk] = 1),
      (iN[J.m.Ok] = 1),
      (iN[J.m.ie] = 1),
      (iN[J.m.je] = 1),
      (iN[J.m.Pk] = 1),
      (iN[J.m.jd] = 1),
      (iN[J.m.Fb] = 1),
      (iN[J.m.me] = 1),
      (iN[J.m.Qk] = 1),
      iN),
    jN = {},
    ZM =
      ((jN.generate_lead = 1),
      (jN.login = 1),
      (jN.search = 1),
      (jN.select_content = 1),
      (jN.share = 1),
      (jN.sign_up = 1),
      (jN.view_search_results = 1),
      (jN[J.m.ke] = 1),
      (jN[J.m.nc] = 1),
      (jN[J.m.Gc] = 1),
      (jN[J.m.oc] = 1),
      (jN[J.m.qc] = 1),
      jN),
    kN = {},
    XM =
      ((kN.view_search_results = 1),
      (kN[J.m.nc] = 1),
      (kN[J.m.oc] = 1),
      (kN[J.m.qc] = 1),
      kN),
    MM = {};
  function lN(a, b, c, d) {}
  lN.K = "internal.executeEventProcessor";
  function mN(a) {
    var b;
    return Xd(b, this.M, 1);
  }
  mN.K = "internal.executeJavascriptString";
  function nN(a) {
    var b;
    return b;
  }
  function oN(a) {
    var b = "";
    return b;
  }
  oN.K = "internal.generateClientId";
  function pN(a) {
    var b = {};
    return Xd(b);
  }
  pN.K = "internal.getAdsCookieWritingOptions";
  function qN(a, b) {
    var c = !1;
    return c;
  }
  qN.K = "internal.getAllowAdPersonalization";
  function rN() {
    var a;
    return a;
  }
  rN.K = "internal.getAndResetEventUsage";
  function sN(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  sN.K = "internal.getAuid";
  function tN() {
    var a = new pb();
    return a;
  }
  tN.publicName = "getContainerVersion";
  function uN(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  uN.publicName = "getCookieValues";
  function vN() {
    var a = "";
    return a;
  }
  vN.K = "internal.getCorePlatformServicesParam";
  function wN() {
    return kn();
  }
  wN.K = "internal.getCountryCode";
  function xN() {
    var a = [];
    a = rk();
    return Xd(a);
  }
  xN.K = "internal.getDestinationIds";
  function yN(a) {
    var b = new pb();
    return b;
  }
  yN.K = "internal.getDeveloperIds";
  function zN(a) {
    var b;
    return b;
  }
  zN.K = "internal.getEcsidCookieValue";
  function AN(a, b) {
    var c = null;
    return c;
  }
  AN.K = "internal.getElementAttribute";
  function BN(a) {
    var b = null;
    return b;
  }
  BN.K = "internal.getElementById";
  function CN(a) {
    var b = "";
    return b;
  }
  CN.K = "internal.getElementInnerText";
  function DN(a) {
    var b = null;
    return b;
  }
  DN.K = "internal.getElementParent";
  function EN(a) {
    var b = null;
    return b;
  }
  EN.K = "internal.getElementPreviousSibling";
  function FN(a, b) {
    var c = null;
    return Xd(c);
  }
  FN.K = "internal.getElementProperty";
  function GN(a) {
    var b;
    return b;
  }
  GN.K = "internal.getElementValue";
  function HN(a) {
    var b = 0;
    return b;
  }
  HN.K = "internal.getElementVisibilityRatio";
  function IN(a) {
    var b = null;
    return b;
  }
  IN.K = "internal.getElementsByCssSelector";
  function JN(a) {
    var b;
    if (!Nh(a)) throw H(this.getName(), ["string"], arguments);
    I(this, "read_event_data", a);
    var c;
    a: {
      var d = a,
        e = RD(this).originalEventData;
      if (e) {
        for (
          var f = e, g = {}, h = {}, l = {}, n = [], p = d.split("\\\\"), q = 0;
          q < p.length;
          q++
        ) {
          for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
            for (var u = r[t].split("."), v = 0; v < u.length; v++)
              (n.push(u[v]), v !== u.length - 1 && n.push(l));
            t !== r.length - 1 && n.push(h);
          }
          q !== p.length - 1 && n.push(g);
        }
        for (
          var x = [], y = "", z = m(n), C = z.next();
          !C.done;
          C = z.next()
        ) {
          var E = C.value;
          E === l
            ? (x.push(y), (y = ""))
            : (y = E === g ? y + "\\" : E === h ? y + "." : y + E);
        }
        y && x.push(y);
        for (var G = m(x), K = G.next(); !K.done; K = G.next()) {
          if (f == null) {
            c = void 0;
            break a;
          }
          f = f[K.value];
        }
        c = f;
      } else c = void 0;
    }
    b = Xd(c, this.M, 1);
    return b;
  }
  JN.K = "internal.getEventData";
  function KN(a) {
    var b = null;
    return b;
  }
  KN.K = "internal.getFirstElementByCssSelector";
  var LN = {};
  LN.disableUserDataWithoutCcd = N(223);
  function MN() {
    return Xd(LN);
  }
  MN.K = "internal.getFlags";
  function NN() {
    var a;
    return a;
  }
  NN.K = "internal.getGsaExperimentId";
  function ON() {
    return new Ud(RC);
  }
  ON.K = "internal.getHtmlId";
  function PN(a) {
    var b;
    return b;
  }
  PN.K = "internal.getIframingState";
  function QN(a, b) {
    var c = {};
    return Xd(c);
  }
  QN.K = "internal.getLinkerValueFromLocation";
  function RN() {
    var a = new pb();
    return a;
  }
  RN.K = "internal.getPrivacyStrings";
  function SN(a, b) {
    var c;
    return c;
  }
  SN.K = "internal.getProductSettingsParameter";
  function TN(a, b) {
    var c;
    return c;
  }
  TN.publicName = "getQueryParameters";
  function UN(a, b) {
    var c;
    return c;
  }
  UN.publicName = "getReferrerQueryParameters";
  function VN(a) {
    var b = "";
    if (!Oh(a)) throw H(this.getName(), ["string|undefined"], arguments);
    I(this, "get_referrer", a);
    b = Lj(Pj(A.referrer), a);
    return b;
  }
  VN.publicName = "getReferrerUrl";
  function WN() {
    return ln();
  }
  WN.K = "internal.getRegionCode";
  function XN(a, b) {
    var c;
    return c;
  }
  XN.K = "internal.getRemoteConfigParameter";
  function YN(a, b) {
    var c = null;
    return c;
  }
  YN.K = "internal.getScopedElementsByCssSelector";
  function ZN() {
    var a = new pb();
    a.set("width", 0);
    a.set("height", 0);
    return a;
  }
  ZN.K = "internal.getScreenDimensions";
  function $N() {
    var a = "";
    return a;
  }
  $N.K = "internal.getTopSameDomainUrl";
  function aO() {
    var a = "";
    return a;
  }
  aO.K = "internal.getTopWindowUrl";
  function bO(a) {
    var b = "";
    if (!Oh(a)) throw H(this.getName(), ["string|undefined"], arguments);
    I(this, "get_url", a);
    b = Jj(Pj(w.location.href), a);
    return b;
  }
  bO.publicName = "getUrl";
  function cO() {
    I(this, "get_user_agent");
    return Rc.userAgent;
  }
  cO.K = "internal.getUserAgent";
  function dO() {
    var a;
    return a ? Xd(dL(a)) : a;
  }
  dO.K = "internal.getUserAgentClientHints";
  function gO() {
    var a = w;
    return (a.gaGlobal = a.gaGlobal || {});
  }
  function hO(a, b) {
    var c = gO();
    if (c.vid === void 0 || (b && !c.from_cookie))
      ((c.vid = a), (c.from_cookie = b));
  }
  function JO(a) {
    (BJ(a) || Uj()) && X(a, J.m.Nl, ln() || kn());
    !BJ(a) && Uj() && X(a, J.m.Mi, "::");
  }
  function KO(a) {
    Uj() && (BJ(a) || on() || X(a, J.m.tl, !0));
  }
  function WP(a) {
    a.copyToHitData(J.m.Oa);
    if (N(411)) {
      var b = M(a.F, J.m.zc);
      b && (Hp(b, function () {}), X(a, J.m.zc, b));
    } else a.copyToHitData(J.m.zc);
  }
  var $P = function (a) {
    for (
      var b = {}, c = String(ZP.cookie).split(";"), d = 0;
      d < c.length;
      d++
    ) {
      var e = c[d].split("="),
        f = e[0].trim();
      if (f && a(f)) {
        var g = e.slice(1).join("=").trim();
        g && (g = decodeURIComponent(g));
        var h = void 0,
          l = void 0;
        ((h = b)[(l = f)] || (h[l] = [])).push(g);
      }
    }
    return b;
  };
  var aQ = window,
    ZP = document,
    bQ = function (a) {
      var b = aQ._gaUserPrefs;
      if (
        (b && b.ioo && b.ioo()) ||
        ZP.documentElement.hasAttribute("data-google-analytics-opt-out") ||
        (a && aQ["ga-disable-" + a] === !0)
      )
        return !0;
      try {
        var c = aQ.external;
        if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0;
      } catch (f) {}
      for (
        var d =
            $P(function (f) {
              return f === "AMP_TOKEN";
            }).AMP_TOKEN || [],
          e = 0;
        e < d.length;
        e++
      )
        if (d[e] == "$OPT_OUT") return !0;
      return ZP.getElementById("__gaOptOutExtension") ? !0 : !1;
    };
  var eQ =
    "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(
      " ",
    );
  function fQ() {
    var a = A.location,
      b,
      c =
        a == null
          ? void 0
          : (b = a.search) == null
            ? void 0
            : b.replace("?", ""),
      d;
    if (c) {
      for (
        var e = [], f = Hj(c, !0), g = m(eQ), h = g.next();
        !h.done;
        h = g.next()
      ) {
        var l = h.value,
          n = f[l];
        if (n)
          for (var p = 0; p < n.length; p++) {
            var q = n[p];
            q !== void 0 && e.push({ name: l, value: q });
          }
      }
      d = e;
    } else d = [];
    return d;
  }
  function oQ(a) {
    if (!N(411)) {
      Mb(a, function (c) {
        c.charAt(0) === "_" && delete a[c];
      });
      var b = a[J.m.zc] || {};
      Mb(b, function (c) {
        c.charAt(0) === "_" && delete b[c];
      });
    }
  }
  function LQ(a) {}
  function MQ(a) {
    var b = function () {};
    return b;
  }
  function NQ(a, b) {}
  var OQ = F.P.Jk,
    PQ = F.P.Kk;
  function QQ(a, b) {
    var c = rk();
    c && c.indexOf(b) > -1 && (a[R.C.qb] = !0);
  }
  var RQ = function (a, b, c) {
    for (var d = 0; d < b.length; d++)
      a.hasOwnProperty(b[d]) && (a[String(b[d])] = c(a[String(b[d])]));
  };
  function SQ(a, b, c) {
    var d = this;
    if (!Nh(a) || !Hh(b) || !Hh(c))
      throw H(
        this.getName(),
        ["string", "Object|undefined", "Object|undefined"],
        arguments,
      );
    var e = b ? B(b) : {};
    ND([
      function () {
        return I(d, "configure_google_tags", a, e);
      },
    ]);
    var f = c ? B(c) : {},
      g = RD(this);
    f.originatingEntity = GE(g);
    vB(fp(a, e), g.eventId, f);
  }
  SQ.K = "internal.gtagConfig";
  function TQ(a, b, c) {
    var d = this;
  }
  TQ.K = "internal.gtagDestinationConfig";
  function VQ(a, b) {}
  VQ.publicName = "gtagSet";
  function WQ() {
    var a = {};
    return a;
  }
  function XQ(a) {}
  XQ.K = "internal.initializeServiceWorker";
  function YQ(a, b) {}
  YQ.publicName = "injectHiddenIframe";
  var ZQ = (function () {
    var a = 0;
    return function (b) {
      switch (b) {
        case 1:
          a |= 1;
          break;
        case 2:
          a |= 2;
          break;
        case 3:
          a |= 4;
      }
      return a;
    };
  })();
  function $Q(a, b, c, d, e) {}
  $Q.K = "internal.injectHtml";
  var dR = {};
  function fR(a, b, c, d) {}
  var gR = { dl: 1, id: 1 },
    hR = {};
  function iR(a, b, c, d) {}
  N(160) ? (iR.publicName = "injectScript") : (fR.publicName = "injectScript");
  iR.K = "internal.injectScript";
  function jR() {
    var a = !1;
    return a;
  }
  jR.K = "internal.isAutoPiiEligible";
  function kR(a) {
    var b = !0;
    return b;
  }
  kR.publicName = "isConsentGranted";
  function lR(a) {
    var b = !1;
    return b;
  }
  lR.K = "internal.isDebugMode";
  function mR() {
    return nn();
  }
  mR.K = "internal.isDmaRegion";
  function nR() {
    return aB;
  }
  nR.K = "internal.isDomReady";
  function oR(a) {
    var b = !1;
    return b;
  }
  oR.K = "internal.isEntityInfrastructure";
  function pR(a) {
    var b = !1;
    if (!Sh(a)) throw H(this.getName(), ["number"], [a]);
    b = N(a);
    return b;
  }
  pR.K = "internal.isFeatureEnabled";
  function qR() {
    var a = !1;
    return a;
  }
  qR.K = "internal.isFpfe";
  function rR() {
    var a = !1;
    return a;
  }
  rR.K = "internal.isGcpConversion";
  function sR() {
    var a = !1;
    return a;
  }
  sR.K = "internal.isLandingPage";
  function tR() {
    var a = !1;
    return a;
  }
  tR.K = "internal.isOgt";
  function uR() {
    var a;
    return a;
  }
  uR.K = "internal.isSafariPcmEligibleBrowser";
  function vR() {
    var a = qi(function (b) {
      RD(this).log("error", b);
    });
    a.publicName = "JSON";
    return a;
  }
  function wR(a) {
    var b = void 0;
    if (!Nh(a)) throw H(this.getName(), ["string"], arguments);
    b = Pj(a);
    return Xd(b);
  }
  wR.K = "internal.legacyParseUrl";
  function xR() {
    return !1;
  }
  var yR = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {
      return !1;
    },
    removeItem: function (a) {},
  };
  function zR() {
    try {
      I(this, "logging");
    } catch (d) {
      return;
    }
    if (!console) return;
    for (
      var a = Array.prototype.slice.call(arguments, 0), b = 0;
      b < a.length;
      b++
    )
      a[b] = B(a[b], this.M);
    var c = RD(this);
    console.log.apply(console, a);
    GE(c);
  }
  zR.publicName = "logToConsole";
  function AR(a, b) {}
  AR.K = "internal.mergeRemoteConfig";
  function BR(a, b, c) {
    c = c === void 0 ? !0 : c;
    var d = [];
    return Xd(d);
  }
  BR.K = "internal.parseCookieValuesFromString";
  function CR(a) {
    var b = void 0;
    if (typeof a !== "string") return;
    a && Yb(a, "//") && (a = A.location.protocol + a);
    if (typeof URL === "function") {
      var c;
      a: {
        var d;
        try {
          d = new URL(a);
        } catch (x) {
          c = void 0;
          break a;
        }
        for (
          var e = {}, f = Array.from(d.searchParams), g = 0;
          g < f.length;
          g++
        ) {
          var h = f[g][0],
            l = f[g][1];
          e.hasOwnProperty(h)
            ? typeof e[h] === "string"
              ? (e[h] = [e[h], l])
              : e[h].push(l)
            : (e[h] = l);
        }
        c = Xd({
          href: d.href,
          origin: d.origin,
          protocol: d.protocol,
          username: d.username,
          password: d.password,
          host: d.host,
          hostname: d.hostname,
          port: d.port,
          pathname: d.pathname,
          search: d.search,
          searchParams: e,
          hash: d.hash,
        });
      }
      return c;
    }
    var n;
    try {
      n = Pj(a);
    } catch (x) {
      return;
    }
    if (!n.protocol || !n.host) return;
    var p = {};
    if (n.search)
      for (
        var q = n.search.replace("?", "").split("&"), r = 0;
        r < q.length;
        r++
      ) {
        var t = q[r].split("="),
          u = t[0],
          v = Ij(t.splice(1).join("=")) || "";
        v = v.replace(/\+/g, " ");
        p.hasOwnProperty(u)
          ? typeof p[u] === "string"
            ? (p[u] = [p[u], v])
            : p[u].push(v)
          : (p[u] = v);
      }
    n.searchParams = p;
    n.origin = n.protocol + "//" + n.host;
    n.username = "";
    n.password = "";
    b = Xd(n);
    return b;
  }
  CR.publicName = "parseUrl";
  function DR(a) {}
  DR.K = "internal.processAsNewEvent";
  function ER(a, b, c) {
    var d;
    return d;
  }
  ER.K = "internal.pushToDataLayer";
  function FR(a) {
    var b = Qa.apply(1, arguments),
      c = !1;
    return c;
  }
  FR.publicName = "queryPermission";
  function GR(a) {
    var b = this;
  }
  GR.K = "internal.queueAdsTransmission";
  function HR(a) {
    var b = void 0;
    return b;
  }
  HR.publicName = "readAnalyticsStorage";
  function IR() {
    var a = "";
    return a;
  }
  IR.publicName = "readCharacterSet";
  function JR() {
    return D(19);
  }
  JR.K = "internal.readDataLayerName";
  function KR() {
    var a = "";
    return a;
  }
  KR.publicName = "readTitle";
  function LR(a, b) {
    var c = this;
  }
  LR.K = "internal.registerCcdCallback";
  function MR(a, b) {
    return !0;
  }
  MR.K = "internal.registerDestination";
  var NR = ["config", "event", "get", "set"];
  function OR(a, b, c) {}
  OR.K = "internal.registerGtagCommandListener";
  function PR(a, b) {
    var c = !1;
    return c;
  }
  PR.K = "internal.removeDataLayerEventListener";
  function QR(a, b) {}
  QR.K = "internal.removeFormData";
  function RR() {}
  RR.publicName = "resetDataLayer";
  function SR(a, b, c) {
    var d = void 0;
    return d;
  }
  SR.K = "internal.scrubUrlParams";
  function TR(a) {}
  TR.K = "internal.sendAdsHit";
  function UR(a, b, c, d) {}
  UR.K = "internal.sendGtagEvent";
  function VR(a, b, c) {}
  VR.publicName = "sendPixel";
  function WR(a, b) {}
  WR.K = "internal.setAnchorHref";
  function YR(a) {}
  YR.K = "internal.setContainerConsentDefaults";
  function ZR(a, b, c, d) {
    var e = this;
    d = d === void 0 ? !0 : d;
    var f = !1;
    return f;
  }
  ZR.publicName = "setCookie";
  function $R(a) {}
  $R.K = "internal.setCorePlatformServices";
  function aS(a, b) {}
  aS.K = "internal.setDataLayerValue";
  function bS(a) {}
  bS.publicName = "setDefaultConsentState";
  function cS(a, b) {}
  cS.K = "internal.setDelegatedConsentType";
  function dS(a, b) {}
  dS.K = "internal.setFormAction";
  function eS(a, b, c) {
    c = c === void 0 ? !1 : c;
  }
  eS.K = "internal.setInCrossContainerData";
  function fS(a, b, c) {
    return !1;
  }
  fS.publicName = "setInWindow";
  function gS(a, b, c) {}
  gS.K = "internal.setProductSettingsParameter";
  function hS(a, b, c) {}
  hS.K = "internal.setRemoteConfigParameter";
  function iS(a, b) {}
  iS.K = "internal.setTransmissionMode";
  function jS(a, b, c, d) {
    var e = this;
  }
  jS.publicName = "sha256";
  function kS(a, b, c) {}
  kS.K = "internal.sortRemoteConfigParameters";
  function lS(a) {}
  lS.K = "internal.storeAdsBraidLabels";
  function mS(a, b) {
    var c = void 0;
    return c;
  }
  mS.K = "internal.subscribeToCrossContainerData";
  function nS(a) {}
  nS.K = "internal.taskSendAdsHits";
  var oS = {},
    pS = {};
  oS.getItem = function (a) {
    var b = null;
    return b;
  };
  oS.setItem = function (a, b) {};
  oS.removeItem = function (a) {};
  oS.clear = function () {};
  oS.publicName = "templateStorage";
  oS.resetForTest = function () {
    for (var a = m(Object.keys(pS)), b = a.next(); !b.done; b = a.next())
      delete pS[b.value];
  };
  function qS(a, b) {
    var c = !1;
    return c;
  }
  qS.K = "internal.testRegex";
  function rS(a) {
    var b;
    return b;
  }
  function sS(a, b) {}
  sS.K = "internal.trackUsage";
  function tS(a, b) {
    var c;
    return c;
  }
  tS.K = "internal.unsubscribeFromCrossContainerData";
  function uS(a) {}
  uS.publicName = "updateConsentState";
  function vS(a) {
    var b = !1;
    return b;
  }
  vS.K = "internal.userDataNeedsEncryption";
  var wS;
  function xS(a, b, c) {
    wS = wS || new Bi();
    wS.add(a, b, c);
  }
  function yS(a, b) {
    var c = (wS = wS || new Bi());
    if (c.D.hasOwnProperty(a))
      throw Error(
        "Attempting to add a private function which already exists: " + a + ".",
      );
    if (c.contains(a))
      throw Error(
        "Attempting to add a private function with an existing API name: " +
          a +
          ".",
      );
    c.D[a] = Eb(b) ? Vh(a, b) : Wh(a, b);
  }
  function zS() {
    return function (a) {
      var b;
      var c = wS;
      if (c.contains(a)) b = c.get(a, this);
      else {
        var d;
        if ((d = c.D.hasOwnProperty(a))) {
          var e = this.M.ub();
          if (e) {
            var f = !1,
              g = e.Nb();
            if (g) {
              bi(g) || (f = !0);
            }
            d = f;
          } else d = !0;
        }
        if (d) {
          var h = c.D.hasOwnProperty(a) ? c.D[a] : void 0;
          b = h;
        } else throw Error(a + " is not a valid API name.");
      }
      return b;
    };
  }
  function AS() {
    var a = function (c) {
        return void yS(c.K, c);
      },
      b = function (c) {
        return void xS(c.publicName, c);
      };
    b(LD);
    b(SD);
    b(fF);
    b(hF);
    b(iF);
    b(pF);
    b(rF);
    b(uG);
    b(vR());
    b(wG);
    b(tN);
    b(uN);
    b(TN);
    b(UN);
    b(VN);
    b(bO);
    b(VQ);
    b(YQ);
    b(kR);
    b(zR);
    b(CR);
    b(FR);
    b(HR);
    b(IR);
    b(KR);
    b(VR);
    b(ZR);
    b(bS);
    b(fS);
    b(jS);
    b(oS);
    b(uS);
    xS("Math", $h());
    xS("Object", zi);
    xS("TestHelper", Di());
    xS("assertApi", Xh);
    xS("assertThat", Yh);
    xS("decodeUri", ci);
    xS("decodeUriComponent", di);
    xS("encodeUri", ei);
    xS("encodeUriComponent", fi);
    xS("fail", ki);
    xS("generateRandom", ni);
    xS("getTimestamp", oi);
    xS("getTimestampMillis", oi);
    xS("getType", pi);
    xS("makeInteger", ri);
    xS("makeNumber", si);
    xS("makeString", ti);
    xS("makeTableMap", ui);
    xS("mock", xi);
    xS("mockObject", yi);
    xS("fromBase64", nN, !("atob" in w));
    xS("localStorage", yR, !xR());
    xS("toBase64", rS, !("btoa" in w));
    a(KD);
    a(OD);
    a(hE);
    a(tE);
    a(AE);
    a(FE);
    a(VE);
    a(dF);
    a(gF);
    a(jF);
    a(kF);
    a(lF);
    a(mF);
    a(nF);
    a(oF);
    a(qF);
    a(sF);
    a(tG);
    a(vG);
    a(xG);
    a(yG);
    a(zG);
    a(AG);
    a(BG);
    a(OH);
    a(TH);
    a(aI);
    a(bI);
    a(mI);
    a(rI);
    a(wI);
    a(FI);
    a(KI);
    a(XI);
    a(ZI);
    a(mJ);
    a(nJ);
    a(pJ);
    a(lN);
    a(mN);
    a(oN);
    a(pN);
    a(qN);
    a(rN);
    a(sN);
    a(vN);
    a(wN);
    a(xN);
    a(yN);
    a(zN);
    a(AN);
    a(BN);
    a(CN);
    a(DN);
    a(EN);
    a(FN);
    a(GN);
    a(HN);
    a(IN);
    a(JN);
    a(KN);
    a(MN);
    a(NN);
    a(ON);
    a(PN);
    a(QN);
    a(RN);
    a(SN);
    a(WN);
    a(XN);
    a(YN);
    a(ZN);
    a($N);
    a(aO);
    a(dO);
    a(SQ);
    a(TQ);
    a(XQ);
    a($Q);
    a(iR);
    a(jR);
    a(lR);
    a(mR);
    a(nR);
    a(oR);
    a(pR);
    a(qR);
    a(rR);
    a(sR);
    a(tR);
    a(uR);
    a(wR);
    a(TE);
    a(AR);
    a(BR);
    a(DR);
    a(ER);
    a(GR);
    a(JR);
    a(LR);
    a(MR);
    a(OR);
    a(PR);
    a(QR);
    a(SR);
    a(TR);
    a(UR);
    a(WR);
    a(YR);
    a($R);
    a(aS);
    a(cS);
    a(dS);
    a(eS);
    a(gS);
    a(hS);
    a(iS);
    a(kS);
    a(lS);
    a(mS);
    a(nS);
    a(qS);
    a(sS);
    a(tS);
    a(vS);
    yS("internal.IframingStateSchema", WQ());
    yS("internal.quickHash", mi);
    N(160) ? b(iR) : b(fR);
    return zS();
  }
  var ID;
  function BS() {
    var a = data.sandboxed_scripts,
      b = data.security_groups,
      c = data.runtime || [],
      d = data.runtime_lines;
    ID = new tf();
    CS();
    dg = HD();
    var e = ID,
      f = AS(),
      g = new Qd("require", f);
    g.Ua();
    e.D.D.set("require", g);
    lb.set("require", g);
    for (var h = 0; h < c.length; h++) {
      var l = c[h];
      if (!Array.isArray(l) || l.length < 3) {
        if (l.length === 0) continue;
        break;
      }
      d && d[h] && d[h].length && Cg(l, d[h]);
      try {
        ID.execute(l);
      } catch (q) {}
    }
    if (a && a.length)
      for (var n = 0; n < a.length; n++) {
        var p = a[n].replace(/^_*/, "");
        Cj[p] = ["sandboxedScripts"];
      }
    DS(b);
  }
  function CS() {
    ID.ed(function (a, b, c) {
      wo.SANDBOXED_JS_SEMAPHORE = wo.SANDBOXED_JS_SEMAPHORE || 0;
      wo.SANDBOXED_JS_SEMAPHORE++;
      try {
        return a.apply(b, c);
      } finally {
        wo.SANDBOXED_JS_SEMAPHORE--;
      }
    });
  }
  function DS(a) {
    a &&
      Mb(a, function (b, c) {
        for (var d = 0; d < c.length; d++) {
          var e = c[d].replace(/^_*/, "");
          Cj[e] = Cj[e] || [];
          Cj[e].push(b);
        }
      });
  }
  function ES(a) {
    vB(dp("developer_id." + a, !0), 0, {});
  }
  var FS = Array.isArray;
  function GS(a, b) {
    return Jd(a, b || null);
  }
  function Y(a) {
    return window.encodeURIComponent(a);
  }
  function HS(a, b, c) {
    gd(a, b, c);
  }
  function IS(a) {
    var b = ["veinteractive.com", "ve-interactive.cn"];
    if (!a) return !1;
    var c = Jj(Pj(a), "host");
    if (!c) return !1;
    for (var d = 0; b && d < b.length; d++) {
      var e = b[d] && b[d].toLowerCase();
      if (e) {
        var f = c.length - e.length;
        f > 0 && e.charAt(0) !== "." && (f--, (e = "." + e));
        if (f >= 0 && c.indexOf(e, f) === f) return !0;
      }
    }
    return !1;
  }
  function JS(a, b, c) {
    for (var d = {}, e = !1, f = 0; a && f < a.length; f++)
      a[f] &&
        a[f].hasOwnProperty(b) &&
        a[f].hasOwnProperty(c) &&
        ((d[a[f][b]] = a[f][c]), (e = !0));
    return e ? d : null;
  }
  function KS(a, b) {
    var c = {};
    if (a) for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
    if (b) {
      var e = JS(b, "parameter", "parameterValue");
      e && (c = GS(e, c));
    }
    return c;
  }
  function LS(a, b, c) {
    return a === void 0 || a === c ? b : a;
  }
  function MS(a, b, c) {
    return cd(a, b, c, void 0);
  }
  function NS(a, b) {
    return Mp(a, b || 2);
  }
  function OS(a, b) {
    w[a] = b;
  }
  function PS(a, b, c) {
    var d = w;
    b && (d[a] === void 0 || (c && !d[a])) && (d[a] = b);
    return d[a];
  }
  var QS = {},
    RS = L.O;
  var Z = { securityGroups: {} };

  ((Z.securityGroups.access_globals = ["google"]),
    (function () {
      function a(b, c, d) {
        var e = { key: d, read: !1, write: !1, execute: !1 };
        switch (c) {
          case "read":
            e.read = !0;
            break;
          case "write":
            e.write = !0;
            break;
          case "readwrite":
            e.read = e.write = !0;
            break;
          case "execute":
            e.execute = !0;
            break;
          default:
            throw Error("Invalid " + b + " request " + c);
        }
        return e;
      }
      (function (b) {
        Z.__access_globals = b;
        Z.__access_globals.H = "access_globals";
        Z.__access_globals.isVendorTemplate = !0;
        Z.__access_globals.priorityOverride = 0;
        Z.__access_globals.isInfrastructure = !1;
        Z.__access_globals["5"] = !1;
      })(function (b) {
        for (
          var c = b.vtp_keys || [],
            d = b.vtp_createPermissionError,
            e = [],
            f = [],
            g = [],
            h = 0;
          h < c.length;
          h++
        ) {
          var l = c[h],
            n = l.key;
          l.read && e.push(n);
          l.write && f.push(n);
          l.execute && g.push(n);
        }
        return {
          assert: function (p, q, r) {
            if (!Fb(r)) throw d(p, {}, "Key must be a string.");
            if (q === "read") {
              if (e.indexOf(r) > -1) return;
            } else if (q === "write") {
              if (f.indexOf(r) > -1) return;
            } else if (q === "readwrite") {
              if (f.indexOf(r) > -1 && e.indexOf(r) > -1) return;
            } else if (q === "execute") {
              if (g.indexOf(r) > -1) return;
            } else
              throw d(
                p,
                {},
                "Operation must be either 'read', 'write', or 'execute', was " +
                  q,
              );
            throw d(
              p,
              {},
              "Prohibited " + q + " on global variable: " + r + ".",
            );
          },
          W: a,
        };
      });
    })());
  ((Z.securityGroups.get_referrer = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_referrer = b;
        Z.__get_referrer.H = "get_referrer";
        Z.__get_referrer.isVendorTemplate = !0;
        Z.__get_referrer.priorityOverride = 0;
        Z.__get_referrer.isInfrastructure = !1;
        Z.__get_referrer["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Fb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified.",
                  );
                if (!Fb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified.",
              );
          },
          W: a,
        };
      });
    })());
  ((Z.securityGroups.read_event_data = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_event_data = b;
        Z.__read_event_data.H = "read_event_data";
        Z.__read_event_data.isVendorTemplate = !0;
        Z.__read_event_data.priorityOverride = 0;
        Z.__read_event_data.isInfrastructure = !1;
        Z.__read_event_data["5"] = !1;
      })(function (b) {
        var c = b.vtp_eventDataAccess,
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (g != null && !Fb(g))
              throw e(f, { key: g }, "Key must be a string.");
            if (c !== "any") {
              try {
                if (c === "specific" && g != null && kh(g, d)) return;
              } catch (h) {
                throw e(f, { key: g }, "Invalid key filter.");
              }
              throw e(f, { key: g }, "Prohibited read from event data.");
            }
          },
          W: a,
        };
      });
    })());

  ((Z.securityGroups.read_data_layer = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_data_layer = b;
        Z.__read_data_layer.H = "read_data_layer";
        Z.__read_data_layer.isVendorTemplate = !0;
        Z.__read_data_layer.priorityOverride = 0;
        Z.__read_data_layer.isInfrastructure = !1;
        Z.__read_data_layer["5"] = !1;
      })(function (b) {
        var c = b.vtp_allowedKeys || "specific",
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Fb(g)) throw e(f, {}, "Keys must be strings.");
            if (c !== "any") {
              try {
                if (kh(g, d)) return;
              } catch (h) {
                throw e(f, {}, "Invalid key filter.");
              }
              throw e(
                f,
                {},
                "Prohibited read from data layer variable: " + g + ".",
              );
            }
          },
          W: a,
        };
      });
    })());

  ((Z.securityGroups.gaawe = ["google"]),
    (function () {
      function a(f, g, h) {
        for (var l = 0; l < g.length; l++)
          f.hasOwnProperty(g[l]) && (f[g[l]] = h(f[g[l]]));
      }
      function b(f, g, h) {
        var l = {},
          n = function (u, v) {
            l[u] = l[u] || v;
          },
          p = function (u, v, x) {
            x = x === void 0 ? !1 : x;
            c.push(PQ);
            if (u) {
              l.items = l.items || [];
              for (var y = {}, z = 0; z < u.length; y = { Gg: void 0 }, z++)
                ((y.Gg = {}),
                  Mb(
                    u[z],
                    (function (E) {
                      return function (G, K) {
                        x && G === "id"
                          ? (E.Gg.promotion_id = K)
                          : x && G === "name"
                            ? (E.Gg.promotion_name = K)
                            : (E.Gg[G] = K);
                      };
                    })(y),
                  ),
                  l.items.push(y.Gg));
            }
            if (v)
              for (var C in v) d.hasOwnProperty(C) ? n(d[C], v[C]) : n(C, v[C]);
          },
          q;
        f.vtp_getEcommerceDataFrom === "dataLayer"
          ? (q = f.vtp_gtmCachedValues.eventModel) ||
            (q = f.vtp_gtmCachedValues.ecommerce)
          : ((q = f.vtp_ecommerceMacroData),
            Id(q) && q.ecommerce && !q.items && (q = q.ecommerce));
        if (Id(q)) {
          var r = !1,
            t;
          for (t in q)
            q.hasOwnProperty(t) &&
              (r || (c.push(OQ), (r = !0)),
              t === "currencyCode"
                ? n("currency", q.currencyCode)
                : t === "impressions" && g === J.m.nc
                  ? p(q.impressions, null)
                  : t === "promoClick" && g === J.m.Gc
                    ? p(q.promoClick.promotions, q.promoClick.actionField, !0)
                    : t === "promoView" && g === J.m.oc
                      ? p(q.promoView.promotions, q.promoView.actionField, !0)
                      : e.hasOwnProperty(t)
                        ? g === e[t] && p(q[t].products, q[t].actionField)
                        : (l[t] = q[t]));
          GS(l, h);
        }
      }
      var c = [],
        d = { id: "transaction_id", revenue: "value", list: "item_list_name" },
        e = {
          click: "select_item",
          detail: "view_item",
          add: "add_to_cart",
          remove: "remove_from_cart",
          checkout: "begin_checkout",
          checkout_option: "checkout_option",
          purchase: "purchase",
          refund: "refund",
        };
      (function (f) {
        Z.__gaawe = f;
        Z.__gaawe.H = "gaawe";
        Z.__gaawe.isVendorTemplate = !0;
        Z.__gaawe.priorityOverride = 0;
        Z.__gaawe.isInfrastructure = !1;
        Z.__gaawe["5"] = !0;
      })(function (f) {
        var g;
        g = f.vtp_migratedToV2
          ? String(f.vtp_measurementIdOverride)
          : String(f.vtp_measurementIdOverride || f.vtp_measurementId);
        if (Fb(g) && g.indexOf("G-") === 0) {
          var h = String(f.vtp_eventName),
            l = {};
          c = [];
          f.vtp_sendEcommerceData &&
            (vn.hasOwnProperty(h) || h === "checkout_option") &&
            b(f, h, l);
          var n = f.vtp_eventSettingsVariable;
          if (n) for (var p in n) n.hasOwnProperty(p) && (l[p] = n[p]);
          if (f.vtp_eventSettingsTable) {
            var q = JS(f.vtp_eventSettingsTable, "parameter", "parameterValue"),
              r;
            for (r in q) l[r] = q[r];
          }
          var t = JS(f.vtp_eventParameters, "name", "value"),
            u;
          for (u in t) t.hasOwnProperty(u) && (l[u] = t[u]);
          var v = f.vtp_userDataVariable;
          v && (l[J.m.Lb] = v);
          if (l.hasOwnProperty(J.m.zc) || f.vtp_userProperties) {
            var x = l[J.m.zc] || {};
            GS(JS(f.vtp_userProperties, "name", "value"), x);
            l[J.m.zc] = x;
          }
          var y = {
              originatingEntity: Qz(
                1,
                f.vtp_gtmEntityIndex,
                f.vtp_gtmEntityName,
              ),
            },
            z = {};
          c.length > 0 && (z[R.C.Tl] = c);
          QQ(z, g);
          Object.keys(z).length > 0 && (y.eventMetadata = z);
          a(l, wn, function (E) {
            return Pb(E);
          });
          a(l, yn, function (E) {
            return Number(E);
          });
          var C = f.vtp_gtmEventId;
          y.noGtmEvent = !0;
          vB(gp(g, h, l), C, y);
          jd(f.vtp_gtmOnSuccess);
        } else jd(f.vtp_gtmOnFailure);
      });
    })());

  ((Z.securityGroups.load_google_tags = ["google"]),
    (function () {
      function a(b, c, d) {
        return { tagId: c, firstPartyUrl: d };
      }
      (function (b) {
        Z.__load_google_tags = b;
        Z.__load_google_tags.H = "load_google_tags";
        Z.__load_google_tags.isVendorTemplate = !0;
        Z.__load_google_tags.priorityOverride = 0;
        Z.__load_google_tags.isInfrastructure = !1;
        Z.__load_google_tags["5"] = !1;
      })(function (b) {
        var c = b.vtp_allowedTagIds || "specific",
          d = b.vtp_allowFirstPartyUrls || !1,
          e = b.vtp_allowedFirstPartyUrls || "specific",
          f = b.vtp_urls || [],
          g = b.vtp_tagIds || [],
          h = b.vtp_createPermissionError;
        return {
          assert: function (l, n, p) {
            (function (q) {
              if (!Fb(q)) throw h(l, {}, "Tag ID must be a string.");
              if (c !== "any" && (c !== "specific" || g.indexOf(q) === -1))
                throw h(l, {}, "Prohibited Tag ID: " + q + ".");
            })(n);
            (function (q) {
              if (q !== void 0) {
                if (!Fb(q)) throw h(l, {}, "First party URL must be a string.");
                if (d) {
                  if (e === "any") return;
                  if (e === "specific")
                    try {
                      if (Ch(Pj(q), f)) return;
                    } catch (r) {
                      throw h(l, {}, "Invalid first party URL filter.");
                    }
                }
                throw h(l, {}, "Prohibited first party URL: " + q);
              }
            })(p);
          },
          W: a,
        };
      });
    })());

  ((Z.securityGroups.ua = ["google"]),
    (function () {
      function a(n, p) {
        for (var q in n)
          if (!h[q] && n.hasOwnProperty(q)) {
            var r = g[q] ? Pb(n[q]) : n[q];
            q != "anonymizeIp" || r || (r = void 0);
            p[q] = r;
          }
      }
      function b(n) {
        var p = {};
        n.vtp_gaSettings &&
          GS(JS(n.vtp_gaSettings.vtp_fieldsToSet, "fieldName", "value"), p);
        GS(JS(n.vtp_fieldsToSet, "fieldName", "value"), p);
        Pb(p.urlPassthrough) && (p._useUp = !0);
        n.vtp_transportUrl && (p._x_19 = n.vtp_transportUrl);
        return p;
      }
      function c(n, p) {
        return p === void 0 ? p : n(p);
      }
      function d(n, p, q) {
        var r = function (Q, S, ma) {
            for (var ka in Q)
              if (t.hasOwnProperty(ka)) {
                var V = ma[S] || {};
                V.actionField = V.actionField || {};
                V.actionField[t[ka]] = Q[ka];
                ma[S] = V;
              }
          },
          t = {
            transaction_id: "id",
            affiliation: "affiliation",
            value: "revenue",
            tax: "tax",
            shipping: "shipping",
            coupon: "coupon",
            item_list_name: "list",
          },
          u = {},
          v =
            ((u[J.m.ke] = "click"),
            (u[J.m.qc] = "detail"),
            (u[J.m.ie] = "add"),
            (u[J.m.je] = "remove"),
            (u[J.m.jd] = "checkout"),
            (u[J.m.Fb] = "purchase"),
            (u[J.m.me] = "refund"),
            u),
          x;
        if (n.vtp_useEcommerceDataLayer) {
          var y = !1;
          n.vtp_useGA4SchemaForEcommerce &&
            ((x = n.vtp_gtmCachedValues.eventModel), (y = !!x));
          y || (x = NS("ecommerce", 1));
        } else
          n.vtp_ecommerceMacroData &&
            ((x = n.vtp_ecommerceMacroData.ecommerce),
            !x &&
              n.vtp_useGA4SchemaForEcommerce &&
              (x = n.vtp_ecommerceMacroData));
        if (!Id(x)) return;
        x = Object(x);
        var z = {},
          C = x.currencyCode;
        n.vtp_useGA4SchemaForEcommerce && (C = C || x.currency);
        var E = Ub(p, "currencyCode", C);
        E && (z.currencyCode = E);
        x.impressions && (z.impressions = x.impressions);
        x.promoView && (z.promoView = x.promoView);
        if (n.vtp_useGA4SchemaForEcommerce) {
          if (q === J.m.nc && !x.impressions)
            x.items &&
              ((z.impressions = x.items),
              (z.translateIfKeyEquals = "impressions"));
          else if (q === J.m.oc && !x.promoView)
            ((x.promoView = {}),
              x.items &&
                ((z.promoView = {}),
                (z.promoView.promotions = x.items),
                (z.translateIfKeyEquals = "promoView")));
          else if (q === J.m.Gc && !x.promoClick)
            ((x.promoClick = {}),
              x.items &&
                ((z.promoClick = {}),
                (z.promoClick.promotions = x.items),
                (z.translateIfKeyEquals = "promoClick"),
                r(x, "promoClick", z)));
          else if (v.hasOwnProperty(q)) {
            var G = v[q];
            !x[G] &&
              x.items &&
              ((z[G] = {}),
              (z[G].products = x.items),
              (z.translateIfKeyEquals = "products"),
              r(x, G, z));
          }
          var K = z.translateIfKeyEquals;
          if (K === "promoClick" || K === "products") return z;
        }
        if (x.promoClick) return ((z.promoClick = x.promoClick), z);
        for (
          var P =
              "detail checkout checkout_option click add remove purchase refund".split(
                " ",
              ),
            fa = 0;
          fa < P.length;
          fa++
        ) {
          var ca = x[P[fa]];
          if (ca) return ((z[P[fa]] = ca), z);
        }
        n.vtp_useGA4SchemaForEcommerce && v.hasOwnProperty(q) && r(x, v[q], z);
        return z;
      }
      function e(n, p) {
        if (
          !f &&
          (!Yj() ||
            !p._x_19 ||
            n.vtp_useDebugVersion ||
            n.vtp_useInternalVersion)
        ) {
          var q = n.vtp_useDebugVersion
            ? "u/analytics_debug.js"
            : "analytics.js";
          n.vtp_useInternalVersion &&
            !n.vtp_useDebugVersion &&
            (q = "internal/" + q);
          f = !0;
          var r = n.vtp_gtmOnFailure,
            t = Xj(p._x_19, "/analytics.js"),
            u = Az(
              "https:",
              "http:",
              "//www.google-analytics.com/" + q,
              p && !!p.forceSSL,
            );
          MS(
            q === "analytics.js" && t ? t : u,
            function () {
              var v = $z();
              (v && v.loaded) || r();
            },
            r,
          );
        }
      }
      var f,
        g = {
          allowAnchor: !0,
          allowLinker: !0,
          alwaysSendReferrer: !0,
          anonymizeIp: !0,
          cookieUpdate: !0,
          exFatal: !0,
          forceSSL: !0,
          javaEnabled: !0,
          legacyHistoryImport: !0,
          nonInteraction: !0,
          useAmpClientId: !0,
          useBeacon: !0,
          storeGac: !0,
          allowAdFeatures: !0,
          allowAdPersonalizationSignals: !0,
          _cd2l: !0,
        },
        h = { urlPassthrough: !0 },
        l = function (n) {
          function p() {
            if (
              n.vtp_doubleClick ||
              n.vtp_advertisingFeaturesType == "DISPLAY_FEATURES"
            )
              x.displayfeatures = !0;
          }
          var q = {},
            r = {},
            t = {};
          if (n.vtp_gaSettings) {
            var u = n.vtp_gaSettings;
            GS(JS(u.vtp_contentGroup, "index", "group"), q);
            GS(JS(u.vtp_dimension, "index", "dimension"), r);
            GS(JS(u.vtp_metric, "index", "metric"), t);
            var v = GS(u);
            v.vtp_fieldsToSet = void 0;
            v.vtp_contentGroup = void 0;
            v.vtp_dimension = void 0;
            v.vtp_metric = void 0;
            n = GS(n, v);
          }
          GS(JS(n.vtp_contentGroup, "index", "group"), q);
          GS(JS(n.vtp_dimension, "index", "dimension"), r);
          GS(JS(n.vtp_metric, "index", "metric"), t);
          var x = b(n),
            y = String(n.vtp_trackingId || ""),
            z = "",
            C = "",
            E = "";
          n.vtp_setTrackerName && typeof n.vtp_trackerName == "string"
            ? n.vtp_trackerName !== "" &&
              ((E = n.vtp_trackerName), (C = E + "."))
            : ((E = "gtm" + String(Co())), (C = E + "."));
          var G = function (pa, qa) {
            for (var Fa in qa) qa.hasOwnProperty(Fa) && (x[pa + Fa] = qa[Fa]);
          };
          G("contentGroup", q);
          G("dimension", r);
          G("metric", t);
          n.vtp_enableEcommerce &&
            ((z = n.vtp_gtmCachedValues.event),
            (x.gtmEcommerceData = d(n, x, z)));
          if (n.vtp_trackType === "TRACK_EVENT")
            ((z = "track_event"),
              p(),
              (x.eventCategory = String(n.vtp_eventCategory)),
              (x.eventAction = String(n.vtp_eventAction)),
              (x.eventLabel = c(String, n.vtp_eventLabel)),
              (x.value = c(Ob, n.vtp_eventValue)));
          else if (n.vtp_trackType == "TRACK_PAGEVIEW") {
            if (
              ((z = J.m.rc),
              p(),
              n.vtp_advertisingFeaturesType ==
                "DISPLAY_FEATURES_WITH_REMARKETING_LISTS" &&
                (x.remarketingLists = !0),
              n.vtp_autoLinkDomains)
            ) {
              var K = {};
              K[J.m.xa] = n.vtp_autoLinkDomains;
              K.use_anchor = n.vtp_useHashAutoLink;
              K[J.m.Oc] = n.vtp_decorateFormsAutoLink;
              x[J.m.fb] = K;
            }
          } else
            n.vtp_trackType === "TRACK_SOCIAL"
              ? ((z = "track_social"),
                (x.socialNetwork = String(n.vtp_socialNetwork)),
                (x.socialAction = String(n.vtp_socialAction)),
                (x.socialTarget = String(n.vtp_socialActionTarget)))
              : n.vtp_trackType == "TRACK_TIMING" &&
                ((z = "timing_complete"),
                (x.eventCategory = String(n.vtp_timingCategory)),
                (x.timingVar = String(n.vtp_timingVar)),
                (x.value = Ob(n.vtp_timingValue)),
                (x.eventLabel = c(String, n.vtp_timingLabel)));
          n.vtp_enableRecaptcha && (x.enableRecaptcha = !0);
          n.vtp_enableLinkId && (x.enableLinkId = !0);
          var P = {};
          a(x, P);
          x.name || (P.gtmTrackerName = E);
          P.gaFunctionName = n.vtp_functionName;
          n.vtp_nonInteraction !== void 0 &&
            (P.nonInteraction = n.vtp_nonInteraction);
          var fa = Gp(
            Fp(
              Ep(
                Dp(
                  wp(new vp(n.vtp_gtmEventId, n.vtp_gtmPriorityId), P),
                  n.vtp_gtmOnSuccess,
                ),
                n.vtp_gtmOnFailure,
              ),
              !0,
            ),
          );
          n.vtp_useDebugVersion &&
            n.vtp_useInternalVersion &&
            (fa.eventMetadata[R.C.dn] = !0);
          LM(y, z, Date.now(), fa);
          var ca = cA(n.vtp_functionName);
          if (Eb(ca)) {
            var Q = function (pa) {
              var qa = [].slice.call(arguments, 0);
              qa[0] = C + qa[0];
              ca.apply(window, qa);
            };
            if (n.vtp_trackType == "TRACK_TRANSACTION") {
            } else if (n.vtp_trackType == "DECORATE_LINK") {
            } else if (n.vtp_trackType == "DECORATE_FORM") {
            } else if (n.vtp_trackType == "TRACK_DATA") {
            }
            e(n, x);
          } else jd(n.vtp_gtmOnFailure);
        };
      Z.__ua = l;
      Z.__ua.H = "ua";
      Z.__ua.isVendorTemplate = !0;
      Z.__ua.priorityOverride = 0;
      Z.__ua.isInfrastructure = !1;
      Z.__ua["5"] = !1;
    })());
  ((Z.securityGroups.get_url = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_url = b;
        Z.__get_url.H = "get_url";
        Z.__get_url.isVendorTemplate = !0;
        Z.__get_url.priorityOverride = 0;
        Z.__get_url.isInfrastructure = !1;
        Z.__get_url["5"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"),
          b.vtp_fragment && c.push("fragment"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Fb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified.",
                  );
                if (!Fb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified.",
              );
          },
          W: a,
        };
      });
    })());

  ((Z.securityGroups.logging = ["google"]),
    (function () {
      function a() {
        return {};
      }
      (function (b) {
        Z.__logging = b;
        Z.__logging.H = "logging";
        Z.__logging.isVendorTemplate = !0;
        Z.__logging.priorityOverride = 0;
        Z.__logging.isInfrastructure = !1;
        Z.__logging["5"] = !1;
      })(function (b) {
        var c = b.vtp_environments || "debug",
          d = b.vtp_createPermissionError;
        return {
          assert: function (e) {
            var f;
            if ((f = c !== "all" && !0)) {
              var g = !1;
              f = !g;
            }
            if (f) throw d(e, {}, "Logging is not enabled in all environments");
          },
          W: a,
        };
      });
    })());
  ((Z.securityGroups.configure_google_tags = ["google"]),
    (function () {
      function a(b, c, d) {
        return { tagId: c, configuration: d };
      }
      (function (b) {
        Z.__configure_google_tags = b;
        Z.__configure_google_tags.H = "configure_google_tags";
        Z.__configure_google_tags.isVendorTemplate = !0;
        Z.__configure_google_tags.priorityOverride = 0;
        Z.__configure_google_tags.isInfrastructure = !1;
        Z.__configure_google_tags["5"] = !1;
      })(function (b) {
        var c = b.vtp_allowedTagIds || "specific",
          d = b.vtp_tagIds || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Fb(g)) throw e(f, {}, "Tag ID must be a string.");
            if (c !== "any" && (c !== "specific" || d.indexOf(g) === -1))
              throw e(f, {}, "Prohibited configuration for Tag ID: " + g + ".");
          },
          W: a,
        };
      });
    })());

  var SS = {},
    zo = {
      dataLayer: Np,
      callback: function (a) {
        SS.hasOwnProperty(a) && Eb(SS[a]) && SS[a]();
        delete SS[a];
      },
      bootstrap: 0,
    };
  function TS() {
    yo();
    Ak();
    Dz();
    Wb(Cj, Z.securityGroups);
    var a = wk(xk()),
      b,
      c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
    Vn(c, a == null ? void 0 : a.parent);
    (c !== 2 && c !== 4 && c !== 3) || O(142);
    pg = { Eq: Ig };
  }
  function US() {
    var a = D(60);
    a && a && (gK[a] = !0);
  }
  function gn() {
    try {
      if (vg(47) || !Jk()) {
        tj();
        if (N(109)) {
        }
        jb[6] = !0;
        var a = xo("debugGroupId", function () {
          return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
        });
        co(a);
        Fo();
        uD();
        cr();
        $A();
        if (Bk()) {
          D(5);
          QE();
          wA().removeExternalRestrictions(tk());
        } else {
          gL();
          Sv();
          ng();
          jg = Z;
          kg = cD;
          ey();
          BS();
          TS();
          aD();
          en || ((dn = jn()), dn["0"] && Hm(Cm.aa.Ge, JSON.stringify(dn)));
          uo();
          eC();
          fB();
          MB = !1;
          A.readyState === "complete" ? OB() : hd(w, "load", OB);
          ZA();
          bl &&
            (Xp(jq),
            w.setInterval(iq, 864e5),
            Xp(vD),
            Xp(oA),
            Xp(sx),
            Xp(mq),
            Xp(ED),
            Xp(uA),
            (YC = {}),
            Xp($C),
            N(468) && bl && Xp(BD));
          el &&
            (Tm(),
            Wo(),
            gC(),
            uC(),
            pC(),
            Pk("bt", String(vg(47) ? 2 : vg(50) ? 1 : 0)),
            Pk("ct", String(vg(47) ? 0 : vg(50) ? 1 : 3)),
            kC(),
            oC(),
            sC(),
            hw());
          PC();
          cn(1);
          RE();
          zo.bootstrap = Tb();
          vg(51) && dC();
          N(109) && Ox();
          typeof w.name === "string" &&
          Yb(w.name, "web-pixel-sandbox-CUSTOM") &&
          yd()
            ? ES("dMDg0Yz")
            : w.Shopify && (ES("dN2ZkMj"), yd() && ES("dNTU0Yz"));
          US();
        }
      }
    } catch (b) {
      (cn(5), fq());
    }
  }
  (function (a) {
    function b() {
      n = A.documentElement.getAttribute("data-tag-assistant-present");
      In(n) && (l = h.Ul);
    }
    function c() {
      l && Uc ? g(l) : a();
    }
    if (!w[D(37)]) {
      var d = !1;
      if (A.referrer) {
        var e = Pj(A.referrer);
        d = Lj(e, "host") === D(38);
      }
      if (!d) {
        var f = $r(D(39));
        d = !(!f.length || !f[0].length);
      }
      d && ((w[D(37)] = !0), cd(D(40)));
    }
    var g = function (u) {
        var v = "GTM",
          x = "GTM";
        yj && ((v = "OGT"), (x = "GTAG"));
        var y = D(23),
          z = w[y];
        z ||
          ((z = []),
          (w[y] = z),
          cd(
            "https://" +
              D(3) +
              "/debug/bootstrap?id=" +
              D(5) +
              "&src=" +
              x +
              "&cond=" +
              String(u) +
              "&gtm=" +
              Tp(),
          ));
        var C = {
          messageType: "CONTAINER_STARTING",
          data: {
            scriptSource: Uc,
            containerProduct: v,
            debug: !1,
            id: D(5),
            targetRef: { ctid: D(5), isDestination: qk(), canonicalId: D(6) },
            aliases: uk(),
            destinations: rk(),
          },
        };
        C.data.resume = function () {
          a();
        };
        vg(2) && (C.data.initialPublish = !0);
        z.push(C);
      },
      h = { Op: 1, qm: 2, Nm: 3, Dk: 4, Ul: 5 };
    h[h.Op] = "GTM_DEBUG_LEGACY_PARAM";
    h[h.qm] = "GTM_DEBUG_PARAM";
    h[h.Nm] = "REFERRER";
    h[h.Dk] = "COOKIE";
    h[h.Ul] = "EXTENSION_PARAM";
    var l = void 0,
      n = void 0,
      p = Jj(w.location, "query", !1, void 0, "gtm_debug");
    In(p) && (l = h.qm);
    if (!l && A.referrer) {
      var q = Pj(A.referrer);
      Lj(q, "host") === D(24) && (l = h.Nm);
    }
    if (!l) {
      var r = $r("__TAG_ASSISTANT");
      r.length && r[0].length && (l = h.Dk);
    }
    l || b();
    if (!l && Hn(n)) {
      var t = !1;
      hd(
        A,
        "TADebugSignal",
        function () {
          t || ((t = !0), b(), c());
        },
        !1,
      );
      w.setTimeout(function () {
        t || ((t = !0), b(), c());
      }, 200);
    } else c();
  })(function () {
    !vg(47) || jn()["0"] ? gn() : fn();
  });
})();
