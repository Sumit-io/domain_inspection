/**
 * Copyright (c) 2017-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Platform Policy
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
fbq.version = "2.9.261";
fbq._releaseSegment = "stable";
fbq.pendingConfigs = ["global_config"];
fbq.__openBridgeRollout = 1.0;
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e, t, n) {
      return (
        (t = f(t)),
        l(
          e,
          m() ? Reflect.construct(t, n || [], f(e).constructor) : t.apply(e, n),
        )
      );
    }
    function l(e, t) {
      if (t && (G(t) == "object" || typeof t == "function")) return t;
      if (t !== void 0)
        throw new TypeError(
          "Derived constructors may only return object or undefined",
        );
      return s(e);
    }
    function s(e) {
      if (e === void 0)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called",
        );
      return e;
    }
    function u(e, t) {
      if (typeof t != "function" && t !== null)
        throw new TypeError(
          "Super expression must either be null or a function",
        );
      ((e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        t && _(e, t));
    }
    function c(e) {
      var t = typeof Map == "function" ? new Map() : void 0;
      return (
        (c = function (n) {
          if (n === null || !p(n)) return n;
          if (typeof n != "function")
            throw new TypeError(
              "Super expression must either be null or a function",
            );
          if (t !== void 0) {
            if (t.has(n)) return t.get(n);
            t.set(n, e);
          }
          function e() {
            return d(n, arguments, f(this).constructor);
          }
          return (
            (e.prototype = Object.create(n.prototype, {
              constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0,
              },
            })),
            _(e, n)
          );
        }),
        c(e)
      );
    }
    function d(e, t, n) {
      if (m()) return Reflect.construct.apply(null, arguments);
      var r = [null];
      r.push.apply(r, t);
      var o = new (e.bind.apply(e, r))();
      return (n && _(o, n.prototype), o);
    }
    function m() {
      try {
        var e = !Boolean.prototype.valueOf.call(
          Reflect.construct(Boolean, [], function () {}),
        );
      } catch (e) {}
      return (m = function () {
        return !!e;
      })();
    }
    function p(e) {
      try {
        return Function.toString.call(e).indexOf("[native code]") !== -1;
      } catch (t) {
        return typeof e == "function";
      }
    }
    function _(e, t) {
      return (
        (_ = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (e, t) {
              return ((e.__proto__ = t), e);
            }),
        _(e, t)
      );
    }
    function f(e) {
      return (
        (f = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        f(e)
      );
    }
    function g() {
      var e,
        t,
        n = typeof Symbol == "function" ? Symbol : {},
        r = n.iterator || "@@iterator",
        o = n.toStringTag || "@@toStringTag";
      function a(n, r, o, a) {
        var s = r && r.prototype instanceof l ? r : l,
          u = Object.create(s.prototype);
        return (
          h(
            u,
            "_invoke",
            (function (n, r, o) {
              var a,
                l,
                s,
                u = 0,
                c = o || [],
                d = !1,
                m = {
                  p: 0,
                  n: 0,
                  v: e,
                  a: p,
                  f: p.bind(e, 4),
                  d: function (n, r) {
                    return ((a = n), (l = 0), (s = e), (m.n = r), i);
                  },
                };
              function p(n, r) {
                for (l = n, s = r, t = 0; !d && u && !o && t < c.length; t++) {
                  var o,
                    a = c[t],
                    p = m.p,
                    _ = a[2];
                  n > 3
                    ? (o = _ === r) &&
                      ((s = a[(l = a[4]) ? 5 : ((l = 3), 3)]),
                      (a[4] = a[5] = e))
                    : a[0] <= p &&
                      ((o = n < 2 && p < a[1])
                        ? ((l = 0), (m.v = r), (m.n = a[1]))
                        : p < _ &&
                          (o = n < 3 || a[0] > r || r > _) &&
                          ((a[4] = n), (a[5] = r), (m.n = _), (l = 0)));
                }
                if (o || n > 1) return i;
                throw ((d = !0), r);
              }
              return function (o, c, _) {
                if (u > 1) throw TypeError("Generator is already running");
                for (
                  d && c === 1 && p(c, _), l = c, s = _;
                  (t = l < 2 ? e : s) || !d;
                ) {
                  a ||
                    (l
                      ? l < 3
                        ? (l > 1 && (m.n = -1), p(l, s))
                        : (m.n = s)
                      : (m.v = s));
                  try {
                    if (((u = 2), a)) {
                      if ((l || (o = "next"), (t = a[o]))) {
                        if (!(t = t.call(a, s)))
                          throw TypeError("iterator result is not an object");
                        if (!t.done) return t;
                        ((s = t.value), l < 2 && (l = 0));
                      } else
                        (l === 1 && (t = a.return) && t.call(a),
                          l < 2 &&
                            ((s = TypeError(
                              "The iterator does not provide a '" +
                                o +
                                "' method",
                            )),
                            (l = 1)));
                      a = e;
                    } else if ((t = (d = m.n < 0) ? s : n.call(r, m)) !== i)
                      break;
                  } catch (t) {
                    ((a = e), (l = 1), (s = t));
                  } finally {
                    u = 1;
                  }
                }
                return { value: t, done: d };
              };
            })(n, o, a),
            !0,
          ),
          u
        );
      }
      var i = {};
      function l() {}
      function s() {}
      function u() {}
      t = Object.getPrototypeOf;
      var c = [][r]
          ? t(t([][r]()))
          : (h((t = {}), r, function () {
              return this;
            }),
            t),
        d = (u.prototype = l.prototype = Object.create(c));
      function m(e) {
        return (
          Object.setPrototypeOf
            ? Object.setPrototypeOf(e, u)
            : ((e.__proto__ = u), h(e, o, "GeneratorFunction")),
          (e.prototype = Object.create(d)),
          e
        );
      }
      return (
        (s.prototype = u),
        h(d, "constructor", u),
        h(u, "constructor", s),
        (s.displayName = "GeneratorFunction"),
        h(u, o, "GeneratorFunction"),
        h(d),
        h(d, o, "Generator"),
        h(d, r, function () {
          return this;
        }),
        h(d, "toString", function () {
          return "[object Generator]";
        }),
        (g = function () {
          return { w: a, m: m };
        })()
      );
    }
    function h(e, t, n, r) {
      var o = Object.defineProperty;
      try {
        o({}, "", {});
      } catch (e) {
        o = 0;
      }
      ((h = function (t, n, r, a) {
        function e(e, n) {
          h(t, e, function (t) {
            return this._invoke(e, n, t);
          });
        }
        n
          ? o
            ? o(t, n, {
                value: r,
                enumerable: !a,
                configurable: !a,
                writable: !a,
              })
            : (t[n] = r)
          : (e("next", 0), e("throw", 1), e("return", 2));
      }),
        h(e, t, n, r));
    }
    function y(e, t, n, r, o, a, i) {
      try {
        var l = e[a](i),
          s = l.value;
      } catch (e) {
        return void n(e);
      }
      l.done ? t(s) : Promise.resolve(s).then(r, o);
    }
    function C(e) {
      return function () {
        var t = this,
          n = arguments;
        return new Promise(function (r, o) {
          var a = e.apply(t, n);
          function i(e) {
            y(a, r, o, i, l, "next", e);
          }
          function l(e) {
            y(a, r, o, i, l, "throw", e);
          }
          i(void 0);
        });
      };
    }
    function b(e, t) {
      var n = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        (t &&
          (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })),
          n.push.apply(n, r));
      }
      return n;
    }
    function v(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2
          ? b(Object(n), !0).forEach(function (t) {
              S(e, t, n[t]);
            })
          : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : b(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t),
                );
              });
      }
      return e;
    }
    function S(e, t, n) {
      return (
        (t = M(t)) in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function R(e, t) {
      return k(e) || E(e, t) || V(e, t) || L();
    }
    function L() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function E(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          ((u = !0), (o = e));
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function k(e) {
      if (Array.isArray(e)) return e;
    }
    function I(e) {
      return x(e) || D(e) || V(e) || T();
    }
    function T() {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function D(e) {
      if (
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] !=
            null) ||
        e["@@iterator"] != null
      )
        return Array.from(e);
    }
    function x(e) {
      if (Array.isArray(e)) return H(e);
    }
    function $(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function P(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        ((r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, M(r.key), r));
      }
    }
    function N(e, t, n) {
      return (
        t && P(e.prototype, t),
        n && P(e, n),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function M(e) {
      var t = w(e, "string");
      return G(t) == "symbol" ? t : t + "";
    }
    function w(e, t) {
      if (G(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (G(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function A(e, t) {
      (O(e, t), t.add(e));
    }
    function F(e, t, n) {
      (O(e, t), t.set(e, n));
    }
    function O(e, t) {
      if (t.has(e))
        throw new TypeError(
          "Cannot initialize the same private elements twice on an object",
        );
    }
    function B(e, t) {
      return e.get(q(e, t));
    }
    function W(e, t, n) {
      return (e.set(q(e, t), n), n);
    }
    function q(e, t, n) {
      if (typeof e == "function" ? e === t : e.has(t))
        return arguments.length < 3 ? t : n;
      throw new TypeError("Private element is not present on this object");
    }
    function U(e, t) {
      var n =
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]) ||
        e["@@iterator"];
      if (!n) {
        if (
          Array.isArray(e) ||
          (n = V(e)) ||
          (t && e && typeof e.length == "number")
        ) {
          n && (e = n);
          var r = 0,
            o = function () {};
          return {
            s: o,
            n: function () {
              return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
            },
            e: function (t) {
              throw t;
            },
            f: o,
          };
        }
        throw new TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
        );
      }
      var a,
        i = !0,
        l = !1;
      return {
        s: function () {
          n = n.call(e);
        },
        n: function () {
          var e = n.next();
          return ((i = e.done), e);
        },
        e: function (t) {
          ((l = !0), (a = t));
        },
        f: function () {
          try {
            i || n.return == null || n.return();
          } finally {
            if (l) throw a;
          }
        },
      };
    }
    function V(e, t) {
      if (e) {
        if (typeof e == "string") return H(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? H(e, t)
              : void 0
        );
      }
    }
    function H(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    function G(e) {
      "@babel/helpers - typeof";
      return (
        (G =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        G(e)
      );
    }
    (a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("generateEventId", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e() {
                var e = new Date().getTime(),
                  t = "xxxxxxxsx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                    /[xy]/g,
                    function (t) {
                      var n = ((e + Math.random() * 16) % 16) | 0;
                      return (
                        (e = Math.floor(e / 16)),
                        (t == "x" ? n : (n & 3) | 8).toString(16)
                      );
                    },
                  );
                return t;
              }
              function t(t, n) {
                var r = e();
                return (
                  (n != null ? n : "none") +
                  "." +
                  (t != null ? t : "none") +
                  "." +
                  r
                );
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("handleEventIdOverride", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging");
              function t(t, n, r, o) {
                if (t != null && (t.eventID != null || t.event_id != null)) {
                  var a = t.eventID,
                    i = t.event_id,
                    l = a != null ? a : i;
                  if (l !== null && G(l) === "object")
                    if ("eventID" in l || "event_id" in l)
                      l = l.eventID != null ? l.eventID : l.event_id;
                    else {
                      var s;
                      e.logUserError({
                        pixelID: o || "",
                        type: "INVALID_EVENT_ID_FORMAT",
                        eventName:
                          (s = r.get("ev")) !== null && s !== void 0 ? s : "",
                      });
                    }
                  (l == null &&
                    (n.event_id != null || n.eventID != null) &&
                    e.consoleWarn(
                      "eventID is being sent in the 3rd parameter, it should be in the 4th parameter.",
                    ),
                    r.containsKey("eid")
                      ? l == null || l.length == 0
                        ? e.logUserError({
                            pixelID: o || "",
                            type: "NO_EVENT_ID",
                          })
                        : r.replaceEntry("eid", l)
                      : r.append("eid", l));
                }
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("normalizeSignalsFBEventsDOBType", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsQE"),
                t = a.getFbeventsModules("normalizeSignalsFBEventsStringType"),
                n = t.normalize,
                r = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                i = r.looksLikeHashed,
                l = r.trim,
                s = a.getFbeventsModules("SignalsFBEventsLogging"),
                u = s.logError;
              function c(e, t, n) {
                var r = new Date().getFullYear();
                return !(
                  e < 1800 ||
                  e > r + 1 ||
                  t < 1 ||
                  t > 12 ||
                  n < 1 ||
                  n > 31
                );
              }
              function d(e) {
                return e.replace(/\D/g, " ");
              }
              function m(e, t, n) {
                var r = 0,
                  o = 0,
                  a = 0;
                return (
                  e > 31
                    ? ((r = e), (o = t > 12 ? n : t), (a = t > 12 ? t : n))
                    : t > 31
                      ? ((r = t), (o = n > 12 ? e : n), (a = n > 12 ? n : e))
                      : ((r = n), (o = e > 12 ? t : e), (a = e > 12 ? e : t)),
                  c(r, o, a)
                    ? String(r).padStart(4, "0") +
                      String(o).padStart(2, "0") +
                      String(a).padStart(2, "0")
                    : null
                );
              }
              function p(e) {
                var t = l(d(e)),
                  n = t.split(" ").filter(function (e) {
                    return e.length > 0;
                  });
                if (n.length >= 3) {
                  var r = parseInt(n[0]),
                    o = parseInt(n[1]),
                    a = parseInt(n[2]),
                    i = m(r, o, a);
                  if (i != null) return i;
                }
                return n.length === 1 && n[0].length === 8 ? n[0] : e;
              }
              function _(e) {
                return i(e) ? e : p(e);
              }
              function f(e, t, r) {
                if (e == null) return null;
                if (typeof e != "string") return e;
                try {
                  return r
                    ? n(e, { lowercase: !0, strip: "whitespace_only" })
                    : _(e);
                } catch (e) {
                  ((e.message = "[normalizeDOB]: ".concat(e.message)), u(e));
                }
                return e;
              }
              o.exports = f;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsEmailType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = e.trim,
                  r =
                    /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i;
                function i(e) {
                  return r.test(e);
                }
                function l(e) {
                  var r = null;
                  if (e != null)
                    if (t(e)) r = e;
                    else {
                      var o = n(e.toLowerCase());
                      r = i(o) ? o : null;
                    }
                  return r;
                }
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("normalizeSignalsFBEventsEnumType", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsShared"),
                t = e.unicodeSafeTruncate,
                n = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                r = n.looksLikeHashed,
                i = n.trim;
              function l(e) {
                var n =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : {},
                  o = null,
                  a = n.caseInsensitive,
                  l = n.lowercase,
                  s = n.options,
                  u = n.truncate,
                  c = n.uppercase;
                if (e != null && s != null && Array.isArray(s) && s.length)
                  if (typeof e == "string" && r(e)) o = e;
                  else {
                    var d = i(String(e));
                    if (
                      (l === !0 && (d = d.toLowerCase()),
                      c === !0 && (d = d.toUpperCase()),
                      u != null && u !== 0 && (d = t(d, u)),
                      a === !0)
                    ) {
                      for (var m = d.toLowerCase(), p = 0; p < s.length; ++p)
                        if (m === s[p].toLowerCase()) {
                          d = s[p];
                          break;
                        }
                    }
                    o = s.indexOf(d) > -1 ? d : null;
                  }
                return o;
              }
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsPhoneNumberType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                  t = e.logError,
                  n = a.getFbeventsModules("SignalsFBEventsQE"),
                  r = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  i = r.looksLikeHashed,
                  l = /^0*/,
                  s = /[\-@#<>\'\",; ]|\(|\)|\+|[a-z]/gi,
                  u =
                    /(?:(?![0-9\uD800-\uDFFF])[^]|[\uD800-\uDBFF][\uDC00-\uDFFF])/gi;
                function c(e, n, r) {
                  if (!r)
                    try {
                      return m(e);
                    } catch (e) {
                      ((e.message = "[normalizePhoneNumber]: ".concat(
                        e.message,
                      )),
                        t(e));
                    }
                  return d(e);
                }
                function d(e) {
                  var t = null;
                  if (e != null)
                    if (i(e)) t = e;
                    else {
                      var n = String(e);
                      t = n.replace(s, "").replace(l, "");
                    }
                  return t;
                }
                function m(e) {
                  return e == null
                    ? null
                    : i(e)
                      ? e
                      : String(e).replace(u, "").replace(l, "");
                }
                o.exports = c;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsPostalCodeType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = e.trim;
                function r(e) {
                  var r = null;
                  if (e != null && typeof e == "string")
                    if (t(e)) r = e;
                    else {
                      var o = n(String(e).toLowerCase().split("-", 1)[0]);
                      o.length >= 2 && (r = o);
                    }
                  return r;
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "normalizeSignalsFBEventsStringType",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.keys,
                  n = a.getFbeventsModules("SignalsFBEventsShared"),
                  r = n.unicodeSafeTruncate,
                  i = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  l = i.looksLikeHashed,
                  s = i.strip,
                  u = a.getFbeventsModules("SignalsFBEventsQE"),
                  c = a.getFbeventsModules("SignalsPixelPIIConstants"),
                  d = c.STATE_MAPPINGS,
                  m = c.COUNTRY_MAPPINGS,
                  p = a.getFbeventsModules("SignalsFBEventsLogging"),
                  _ = p.logError;
                function f(e) {
                  var t =
                      arguments.length > 1 && arguments[1] !== void 0
                        ? arguments[1]
                        : {},
                    n = null;
                  if (e != null)
                    if (l(e) && typeof e == "string")
                      t.rejectHashed !== !0 && (n = e);
                    else {
                      var o = String(e);
                      (t.strip != null && (o = s(o, t.strip)),
                        t.lowercase === !0
                          ? (o = o.toLowerCase())
                          : t.uppercase === !0 && (o = o.toUpperCase()),
                        t.truncate != null &&
                          t.truncate !== 0 &&
                          (o = r(o, t.truncate)),
                        t.test != null && t.test !== ""
                          ? (n = new RegExp(t.test).test(o) ? o : null)
                          : (n = o));
                    }
                  return n;
                }
                function g(e) {
                  return f(e, { strip: "whitespace_and_punctuation" });
                }
                function h(e, n) {
                  if (e.length === 2) return e;
                  if (n[e] != null) return n[e];
                  var r = U(t(n)),
                    o;
                  try {
                    for (r.s(); !(o = r.n()).done; ) {
                      var a = o.value;
                      if (e.includes(a)) {
                        var i = n[a];
                        return i;
                      }
                    }
                  } catch (e) {
                    r.e(e);
                  } finally {
                    r.f();
                  }
                  return e.toLowerCase();
                }
                function y(e, t) {
                  if (l(e) || typeof e != "string") return e;
                  var n = e;
                  switch (
                    ((n = n.toLowerCase().trim()),
                    (n = n.replace(/[^a-z]/g, "")),
                    (n = h(n, t)),
                    n.length)
                  ) {
                    case 0:
                      return null;
                    case 1:
                      return n;
                    default:
                      return n.substring(0, 2);
                  }
                }
                function C(e, t, n) {
                  if (e == null) return null;
                  var r = e;
                  if (!n)
                    try {
                      r = y(r, m);
                    } catch (e) {
                      ((e.message = "[NormalizeCountry]: " + e.message), _(e));
                    }
                  return f(r, {
                    truncate: 2,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                    lowercase: !0,
                  });
                }
                function b(e, t, n) {
                  if (e == null) return null;
                  var r = e;
                  if (!n)
                    try {
                      r = y(r, d);
                    } catch (e) {
                      ((e.message = "[NormalizeState]: " + e.message), _(e));
                    }
                  return f(r, {
                    truncate: 2,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                    lowercase: !0,
                  });
                }
                function v(e) {
                  return f(e, {
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                  });
                }
                o.exports = {
                  normalize: f,
                  normalizeName: g,
                  normalizeCity: v,
                  normalizeState: b,
                  normalizeCountry: C,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("PixelQueue", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsLogging"),
                n = t.logWarning,
                r = a.getFbeventsModules("WebStorage"),
                i = r.getLocalStorage,
                l = a.getFbeventsModules("WebStorageMutex"),
                s = a.getFbeventsModules("SignalsFBEventsPageStatusMonitor"),
                u = s.initPageStatusMonitor,
                c = s.subscribeToPageStatus,
                d = 1440 * 60 * 1e3,
                m = 30 * 1e3,
                p = 5;
              function _(e) {
                var t = e.prev,
                  n = e.next;
                (n && (n.prev = t),
                  t && (t.next = n),
                  (e.next = null),
                  (e.prev = null));
              }
              function f(e, t) {
                return {
                  item: e,
                  next: null,
                  prev: null,
                  retryCount: 0,
                  enqueuedAt: t != null ? t : Date.now(),
                };
              }
              function g() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                  /[xy]/g,
                  function (e) {
                    var t = (Math.random() * 16) | 0,
                      n = e === "x" ? t : (t & 3) | 8;
                    return n.toString(16);
                  },
                );
              }
              function h(e, t) {
                var n;
                return (
                  e +
                  "^$" +
                  ((n = t == null ? void 0 : t.queueNameSuffix) !== null &&
                  n !== void 0
                    ? n
                    : "")
                );
              }
              var y = new WeakMap(),
                C = new WeakMap(),
                b = new WeakMap(),
                v = new WeakMap(),
                S = new WeakMap(),
                R = new WeakMap(),
                L = new WeakMap(),
                E = new WeakMap(),
                k = new WeakMap(),
                I = new WeakMap(),
                T = new WeakMap(),
                D = new WeakMap(),
                x = new WeakMap(),
                P = new WeakMap(),
                M = new WeakMap(),
                w = new WeakSet(),
                O = (function () {
                  function t(n, r) {
                    var o,
                      a,
                      i = this;
                    ($(this, t),
                      A(this, w),
                      F(this, y, void 0),
                      F(this, C, void 0),
                      F(this, b, void 0),
                      F(this, v, void 0),
                      F(this, S, void 0),
                      F(this, R, void 0),
                      F(this, L, void 0),
                      F(this, E, 0),
                      F(this, k, void 0),
                      F(this, I, void 0),
                      F(this, T, void 0),
                      F(this, D, void 0),
                      F(this, x, void 0),
                      F(this, P, void 0),
                      F(this, M, void 0));
                    var l = {
                      item: null,
                      prev: null,
                      next: null,
                      retryCount: 0,
                      enqueuedAt: 0,
                    };
                    (W(y, this, l),
                      W(C, this, l),
                      W(b, this, l.next),
                      W(v, this, n),
                      W(
                        R,
                        this,
                        (o = r == null ? void 0 : r.queueNameSuffix) !== null &&
                          o !== void 0
                          ? o
                          : "",
                      ),
                      W(S, this, h(n, r)),
                      W(L, this, null),
                      W(E, this, 0),
                      W(
                        k,
                        this,
                        (a = r == null ? void 0 : r.maxAgeInMs) !== null &&
                          a !== void 0
                          ? a
                          : d,
                      ),
                      W(D, this, B(S, this) + "^$" + g()),
                      W(T, this, null),
                      W(x, this, !1),
                      W(P, this, !1),
                      W(M, this, !1),
                      W(I, this, [
                        c(function (e) {
                          e === "inactive" && q(w, i, H).call(i);
                        }),
                      ]),
                      typeof e != "undefined" && e.requestAnimationFrame
                        ? e.requestAnimationFrame(function () {
                            return q(w, i, z).call(i);
                          })
                        : setTimeout(function () {
                            return q(w, i, z).call(i);
                          }, 0));
                  }
                  return N(t, [
                    {
                      key: "setHandler",
                      value: function (t) {
                        return (W(L, this, t), q(w, this, Q).call(this), this);
                      },
                    },
                    {
                      key: "enqueue",
                      value: function (t) {
                        (q(w, this, X).call(this, t),
                          this.isActive()
                            ? q(w, this, Q).call(this)
                            : q(w, this, J).call(this));
                      },
                    },
                    {
                      key: "dequeueItem",
                      value: function () {
                        if (B(T, this) != null) return null;
                        for (var e = B(b, this); e && e.retryCount >= p; )
                          e = e.next;
                        return e
                          ? (W(b, this, e.next), e)
                          : (W(b, this, null), null);
                      },
                    },
                    {
                      key: "markItemAsCompleted",
                      value: function (t) {
                        var e,
                          n,
                          r = t.prev,
                          o = t.next;
                        (_(t),
                          B(C, this) === t &&
                            W(C, this, r != null ? r : B(y, this)),
                          B(b, this) === t && W(b, this, o),
                          W(E, this, ((e = B(E, this)), (n = e--), e)),
                          this.isActive() || q(w, this, J).call(this));
                      },
                    },
                    {
                      key: "markItemAsFailed",
                      value: function (t) {
                        var e = t.retryCount || 0,
                          n = e + 1;
                        ((t.retryCount = n),
                          !(n >= p) &&
                            (B(C, this) !== t &&
                              (_(t),
                              B(b, this) === t && W(b, this, t.next),
                              q(w, this, V).call(this, t)),
                            this.isActive() && q(w, this, Q).call(this)));
                      },
                    },
                    {
                      key: "markItem",
                      value: function (t, n) {
                        n
                          ? this.markItemAsCompleted(t)
                          : this.markItemAsFailed(t);
                      },
                    },
                    {
                      key: "length",
                      value: function () {
                        return B(E, this);
                      },
                    },
                    {
                      key: "isActive",
                      value: function () {
                        var e = B(T, this);
                        return e == null
                          ? !0
                          : Date.now() - e > m
                            ? (q(w, this, G).call(this), !0)
                            : !1;
                      },
                    },
                    {
                      key: "getFullName",
                      value: function () {
                        return B(S, this);
                      },
                    },
                    {
                      key: "getQueueNameSuffix",
                      value: function () {
                        return B(R, this);
                      },
                    },
                    {
                      key: "disableStorage",
                      value: function () {
                        W(M, this, !0);
                      },
                    },
                    {
                      key: "destroy",
                      value: function () {
                        B(I, this).forEach(function (e) {
                          return e();
                        });
                      },
                    },
                  ]);
                })();
              function V(e) {
                var t,
                  n =
                    (t = B(C, this)) !== null && t !== void 0 ? t : B(y, this);
                ((n.next = e),
                  (e.prev = n),
                  (e.next = null),
                  W(C, this, e),
                  B(b, this) == null && W(b, this, e));
              }
              function H() {
                B(T, this) == null &&
                  (W(T, this, Date.now()), q(w, this, j).call(this));
              }
              function G() {
                (B(T, this) != null || !B(x, this)) &&
                  (W(x, this, !0), W(T, this, null), q(w, this, z).call(this));
              }
              function z() {
                (q(w, this, Y).call(this), q(w, this, K).call(this));
              }
              function j() {
                q(w, this, J).call(this);
              }
              function K() {
                B(E, this) > 0 && B(L, this) && B(L, this).call(this, this);
              }
              function Q() {
                var t = this;
                if (!B(P, this) && !(B(E, this) === 0 || !B(L, this))) {
                  W(P, this, !0);
                  var r = function () {
                    try {
                      (W(P, t, !1), q(w, t, K).call(t));
                    } catch (e) {
                      n(e, "pixel", "qualityChecker");
                    }
                  };
                  typeof e != "undefined" && e.requestAnimationFrame
                    ? e.requestAnimationFrame(r)
                    : setTimeout(r, 0);
                }
              }
              function X(e, t) {
                var n,
                  r,
                  o = f(e, t);
                (q(w, this, V).call(this, o),
                  W(E, this, ((n = B(E, this)), (r = n++), n)));
              }
              function Y() {
                var e = this,
                  t = i();
                if (t) {
                  var r = this.getFullName() + "^$",
                    o = new l(r);
                  o.lock(function (o) {
                    var a = Date.now() - B(k, e);
                    try {
                      for (var i = 0; i < t.length; i++) {
                        var l = t.key(i);
                        if (typeof l == "string" && l.startsWith(r)) {
                          var s = t.getItem(l);
                          if ((t.removeItem(l), s != null && s.startsWith("{")))
                            try {
                              var u = JSON.parse(s);
                              if (u.ts > a) {
                                var c = U(u.items),
                                  d;
                                try {
                                  for (c.s(); !(d = c.n()).done; ) {
                                    var m,
                                      p = d.value,
                                      _ =
                                        (m = p.enqueuedAt) !== null &&
                                        m !== void 0
                                          ? m
                                          : u.ts,
                                      f = p.item;
                                    _ > a && q(w, e, X).call(e, f, _);
                                  }
                                } catch (e) {
                                  c.e(e);
                                } finally {
                                  c.f();
                                }
                              }
                            } catch (e) {}
                        }
                      }
                    } catch (e) {
                      n(e, "pixel", "qualityChecker");
                    } finally {
                      (o.unlock(), q(w, e, Q).call(e));
                    }
                  });
                }
              }
              function J() {
                var e = i();
                if (e && !B(M, this)) {
                  var t = q(w, this, Z).call(this);
                  if (t.length === 0) {
                    e.getItem(B(D, this)) != null && e.removeItem(B(D, this));
                    return;
                  }
                  var r = { ts: Date.now(), items: t };
                  try {
                    e.setItem(B(D, this), JSON.stringify(r));
                  } catch (e) {
                    n(e, "pixel", "qualityChecker");
                  }
                }
              }
              function Z() {
                for (
                  var e = [], t = B(y, this).next, n = Date.now() - B(k, this);
                  t;
                )
                  (t.enqueuedAt > n &&
                    e.push({ item: t.item, enqueuedAt: t.enqueuedAt }),
                    (t = t.next));
                return e;
              }
              (typeof e != "undefined" && u(), (o.exports = O));
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsConvertNodeToHTMLElement", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e(e) {
                return (typeof HTMLElement == "undefined"
                  ? "undefined"
                  : G(HTMLElement)) === "object"
                  ? e instanceof HTMLElement
                  : e !== null &&
                      G(e) === "object" &&
                      e.nodeType === Node.ELEMENT_NODE &&
                      typeof e.nodeName == "string";
              }
              function t(t) {
                return e(t) ? t : null;
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsEventPayload", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                t = new WeakMap(),
                n = (function () {
                  function n() {
                    ($(this, n), F(this, t, void 0), W(t, this, new Map()));
                  }
                  return N(
                    n,
                    [
                      {
                        key: "has",
                        value: function (n) {
                          return B(t, this).has(n);
                        },
                      },
                      {
                        key: "get",
                        value: function (n) {
                          var e = B(t, this).get(n);
                          return e == null || e.length === 0
                            ? null
                            : e[e.length - 1];
                        },
                      },
                      {
                        key: "getAll",
                        value: function (n) {
                          var e = B(t, this).get(n);
                          return e ? I(e) : null;
                        },
                      },
                      {
                        key: "getEventId",
                        value: function () {
                          for (
                            var e = [
                                "eid",
                                "eid[]",
                                encodeURIComponent("eid[]"),
                              ],
                              t = 0,
                              n = e;
                            t < n.length;
                            t++
                          ) {
                            var r = n[t],
                              o = this.get(r);
                            if (o != null && o.length > 0) return o;
                          }
                          return null;
                        },
                      },
                      {
                        key: "getAllParams",
                        value: function () {
                          var e = [],
                            n = U(B(t, this).entries()),
                            r;
                          try {
                            for (n.s(); !(r = n.n()).done; ) {
                              var o = R(r.value, 2),
                                a = o[0],
                                i = o[1],
                                l = U(i),
                                s;
                              try {
                                for (l.s(); !(s = l.n()).done; ) {
                                  var u = s.value;
                                  e.push({ name: a, value: u });
                                }
                              } catch (e) {
                                l.e(e);
                              } finally {
                                l.f();
                              }
                            }
                          } catch (e) {
                            n.e(e);
                          } finally {
                            n.f();
                          }
                          return e;
                        },
                      },
                      {
                        key: "forEach",
                        value: function (n) {
                          var e = U(B(t, this).entries()),
                            r;
                          try {
                            for (e.s(); !(r = e.n()).done; ) {
                              var o = R(r.value, 2),
                                a = o[0],
                                i = o[1],
                                l = U(i),
                                s;
                              try {
                                for (l.s(); !(s = l.n()).done; ) {
                                  var u = s.value;
                                  n(a, u);
                                }
                              } catch (e) {
                                l.e(e);
                              } finally {
                                l.f();
                              }
                            }
                          } catch (t) {
                            e.e(t);
                          } finally {
                            e.f();
                          }
                        },
                      },
                      {
                        key: "set",
                        value: function (n, r) {
                          return (B(t, this).set(n, [r]), this);
                        },
                      },
                      {
                        key: "setFromArray",
                        value: function (n, r) {
                          return (
                            r.length > 0 && B(t, this).set(n, I(r)),
                            this
                          );
                        },
                      },
                      {
                        key: "setAsDict",
                        value: function (t, n) {
                          for (var e = 0; e < n.length; e++)
                            this.set("".concat(t, "[").concat(e, "]"), n[e]);
                          return this;
                        },
                      },
                      {
                        key: "append",
                        value: function (n, r) {
                          var e = B(t, this).get(n);
                          return (
                            e != null ? e.push(r) : B(t, this).set(n, [r]),
                            this
                          );
                        },
                      },
                      {
                        key: "delete",
                        value: function (n) {
                          return (B(t, this).delete(n), this);
                        },
                      },
                      {
                        key: "merge",
                        value: function (t) {
                          var e = this;
                          return (
                            t.forEach(function (t, n) {
                              e.append(t, n);
                            }),
                            this
                          );
                        },
                      },
                      {
                        key: "toQueryString",
                        value: function () {
                          var e = [];
                          return (
                            this.forEach(function (t, n) {
                              e.push(
                                "".concat(t, "=").concat(encodeURIComponent(n)),
                              );
                            }),
                            e.join("&")
                          );
                        },
                      },
                      {
                        key: "toFormData",
                        value: function () {
                          var t = new FormData(),
                            n = e.eval("fix_fbevent_uri_error");
                          return (
                            this.forEach(function (e, r) {
                              if (n)
                                try {
                                  t.append(decodeURIComponent(e), r);
                                } catch (n) {
                                  t.append(e, r);
                                }
                              else t.append(decodeURIComponent(e), r);
                            }),
                            t
                          );
                        },
                      },
                      {
                        key: "toObject",
                        value: function () {
                          var e = {};
                          return (
                            this.forEach(function (t, n) {
                              e[t] = n;
                            }),
                            e
                          );
                        },
                      },
                      {
                        key: "toJSON",
                        value: function () {
                          return this.getAllParams();
                        },
                      },
                    ],
                    [
                      {
                        key: "fromJSON",
                        value: function (t) {
                          var e = new n(),
                            r = U(t),
                            o;
                          try {
                            for (r.s(); !(o = r.n()).done; ) {
                              var a = o.value,
                                i = a.name,
                                l = a.value;
                              e.append(i, l);
                            }
                          } catch (e) {
                            r.e(e);
                          } finally {
                            r.f();
                          }
                          return e;
                        },
                      },
                    ],
                  );
                })();
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsEventValidation", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logUserError,
                n = /^[+-]?\d+(\.\d+)?$/,
                r = "number",
                i = "currency_code",
                l = {
                  AED: 1,
                  ARS: 1,
                  AUD: 1,
                  BOB: 1,
                  BRL: 1,
                  CAD: 1,
                  CHF: 1,
                  CLP: 1,
                  CNY: 1,
                  COP: 1,
                  CRC: 1,
                  CZK: 1,
                  DKK: 1,
                  EUR: 1,
                  GBP: 1,
                  GTQ: 1,
                  HKD: 1,
                  HNL: 1,
                  HUF: 1,
                  IDR: 1,
                  ILS: 1,
                  INR: 1,
                  ISK: 1,
                  JPY: 1,
                  KRW: 1,
                  MOP: 1,
                  MXN: 1,
                  MYR: 1,
                  NIO: 1,
                  NOK: 1,
                  NZD: 1,
                  PEN: 1,
                  PHP: 1,
                  PLN: 1,
                  PYG: 1,
                  QAR: 1,
                  RON: 1,
                  RUB: 1,
                  SAR: 1,
                  SEK: 1,
                  SGD: 1,
                  THB: 1,
                  TRY: 1,
                  TWD: 1,
                  USD: 1,
                  UYU: 1,
                  VEF: 1,
                  VND: 1,
                  ZAR: 1,
                },
                s = {
                  value: { isRequired: !0, type: r },
                  currency: { isRequired: !0, type: i },
                },
                u = {
                  AddPaymentInfo: {},
                  AddToCart: {},
                  AddToWishlist: {},
                  CompleteRegistration: {},
                  Contact: {},
                  CustomEvent: {
                    validationSchema: { event: { isRequired: !0 } },
                  },
                  CustomizeProduct: {},
                  Donate: {},
                  FindLocation: {},
                  InitiateCheckout: {},
                  Lead: {},
                  PageView: {},
                  PixelInitialized: {},
                  Purchase: { validationSchema: s },
                  Schedule: {},
                  Search: {},
                  StartTrial: {},
                  SubmitApplication: {},
                  Subscribe: {},
                  ViewContent: {},
                },
                c = {
                  agent: !0,
                  automaticmatchingconfig: !0,
                  codeless: !0,
                  tracksingleonly: !0,
                  "cbdata.onetrustid": !0,
                },
                d = Object.prototype.hasOwnProperty;
              function m() {
                return { error: null, warnings: [] };
              }
              function p(e) {
                return { error: e, warnings: [] };
              }
              function _(e) {
                return { error: null, warnings: e };
              }
              function f(e) {
                if (e) {
                  var t = e.toLowerCase(),
                    n = c[t];
                  if (n !== !0)
                    return p({
                      metadata: t,
                      type: "UNSUPPORTED_METADATA_ARGUMENT",
                    });
                }
                return m();
              }
              function g(e) {
                var t =
                  arguments.length > 1 && arguments[1] !== void 0
                    ? arguments[1]
                    : {};
                if (!e) return p({ type: "NO_EVENT_NAME" });
                var n = u[e];
                return n
                  ? h(e, t, n)
                  : _([{ eventName: e, type: "NONSTANDARD_EVENT" }]);
              }
              function h(e, t, o) {
                var a = o.validationSchema,
                  s = [];
                for (var u in a)
                  if (d.call(a, u)) {
                    var c = a[u],
                      m = t[u];
                    if (c) {
                      if (c.isRequired != null && !d.call(t, u))
                        return p({
                          eventName: e,
                          param: u,
                          type: "REQUIRED_PARAM_MISSING",
                        });
                      if (c.type != null && typeof c.type == "string") {
                        var f = !0;
                        switch (c.type) {
                          case r:
                            {
                              var g =
                                (typeof m == "string" ||
                                  typeof m == "number") &&
                                n.test("".concat(m));
                              (g &&
                                Number(m) < 0 &&
                                s.push({
                                  eventName: e || "null",
                                  param: u,
                                  type: "NEGATIVE_EVENT_PARAM",
                                }),
                                (f = g));
                            }
                            break;
                          case i:
                            f = typeof m == "string" && !!l[m.toUpperCase()];
                            break;
                        }
                        if (!f)
                          return p({
                            eventName: e,
                            param: u,
                            type: "INVALID_PARAM",
                          });
                      }
                    }
                  }
                return _(s);
              }
              function y(e, n) {
                var r = g(e, n);
                if ((r.error && t(r.error), r.warnings))
                  for (var o = 0; o < r.warnings.length; o++) t(r.warnings[o]);
                return r;
              }
              o.exports = {
                validateEvent: g,
                validateEventAndLog: y,
                validateMetadata: f,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsAddGmailSuffixToEmail",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = a.getFbeventsModules("SignalsFBEventsLogging"),
                  r = n.logError,
                  i = a.getFbeventsModules("SignalsFBEventsUtils"),
                  l = i.each,
                  s = i.keys,
                  u = a.getFbeventsModules("SignalsPixelPIIUtils"),
                  c = u.isEmail,
                  d = u.isPhoneNumber,
                  m = u.getGenderCharacter,
                  p = a.getFbeventsModules("SignalsFBEventsQE");
                function _(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    (e.em != null &&
                      e.em.trim() !== "" &&
                      !t(e.em) &&
                      typeof e.em == "string" &&
                      !e.em.includes("@") &&
                      (e.em = e.em + "@gmail.com"),
                      e.email != null &&
                        e.email.trim() !== "" &&
                        !t(e.email) &&
                        typeof e.email == "string" &&
                        !e.email.includes("@") &&
                        (e.email = e.email + "@gmail.com"));
                  } catch (e) {
                    ((e.message = "[NormalizeAddSuffix]:" + e.message), r(e));
                  }
                  return e;
                }
                o.exports = _;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsAsyncParamUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsParamList"),
                t = a.getFbeventsModules("signalsFBEventsSendEventImpl");
              function n(e) {
                for (
                  e.asyncParamPromisesAllSettled = !0;
                  e.eventQueue.length > 0;
                ) {
                  var t = e.eventQueue.shift();
                  r(e, t);
                }
              }
              function r(e, n) {
                var r = I(e.asyncParamFetchers.values()),
                  o = U(r),
                  a;
                try {
                  for (o.s(); !(a = o.n()).done; ) {
                    var i = a.value,
                      l = i.callback;
                    l != null && l(i.result, n, e);
                  }
                } catch (e) {
                  o.e(e);
                } finally {
                  o.f();
                }
                t(n, e);
              }
              function i(e) {
                var t = I(e.asyncParamFetchers.keys());
                Promise.allSettled(
                  I(e.asyncParamFetchers.values()).map(function (e) {
                    return e.request;
                  }),
                ).then(function (r) {
                  ((e.asyncParamPromisesAllSettled = !0),
                    r.forEach(function (n, r) {
                      if (n.status === "fulfilled") {
                        var o = t[r],
                          a = e.asyncParamFetchers.get(o);
                        a != null &&
                          a.result == null &&
                          ((a.result = n.value),
                          e.asyncParamFetchers.set(o, a));
                      }
                    }),
                    n(e));
                });
              }
              o.exports = {
                flushAsyncParamEventQueue: n,
                registerAsyncParamAllSettledListener: i,
                appendAsyncParamsAndSendEvent: r,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsAutomaticPageViewEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function t() {
                  return [];
                }
                o.exports = new e(t);
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsBaseEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.map,
                n = e.keys,
                r = (function () {
                  function e(t) {
                    ($(this, e),
                      S(this, "_regKey", 0),
                      S(this, "_subscriptions", {}),
                      (this._coerceArgs = t || null));
                  }
                  return N(e, [
                    {
                      key: "listen",
                      value: function (t) {
                        var e = this,
                          n = "".concat(this._regKey++);
                        return (
                          (this._subscriptions[n] = t),
                          function () {
                            delete e._subscriptions[n];
                          }
                        );
                      },
                    },
                    {
                      key: "listenOnce",
                      value: function (t) {
                        var e = null,
                          n = function () {
                            return (
                              e && e(),
                              (e = null),
                              t.apply(void 0, arguments)
                            );
                          };
                        return ((e = this.listen(n)), e);
                      },
                    },
                    {
                      key: "trigger",
                      value: function () {
                        for (
                          var e = this,
                            r = arguments.length,
                            o = new Array(r),
                            a = 0;
                          a < r;
                          a++
                        )
                          o[a] = arguments[a];
                        return t(n(this._subscriptions), function (t) {
                          if (
                            t in e._subscriptions &&
                            e._subscriptions[t] != null
                          ) {
                            var n;
                            return (n = e._subscriptions)[t].apply(n, o);
                          } else return null;
                        });
                      },
                    },
                    {
                      key: "triggerWeakly",
                      value: function () {
                        var e =
                          this._coerceArgs != null
                            ? this._coerceArgs.apply(this, arguments)
                            : null;
                        return e == null ? [] : this.trigger.apply(this, I(e));
                      },
                    },
                  ]);
                })();
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsBotBlockingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    rules: t.objectWithFields({
                      spider_bot_rules: t.string(),
                      browser_patterns: t.string(),
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsBrowserPropertiesConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    enableEventSuppression: t.allowNull(t.boolean()),
                    enableBackupTimeout: t.allowNull(t.boolean()),
                    experiment: t.allowNull(t.string()),
                    fbcParamsConfig: t.allowNull(
                      t.objectWithFields({
                        params: t.allowNull(
                          t.arrayOf(
                            t.objectWithFields({
                              ebp_path: t.string(),
                              prefix: t.string(),
                              query: t.string(),
                            }),
                          ),
                        ),
                      }),
                    ),
                    enableFbcParamSplitIOS: t.allowNull(t.boolean()),
                    enableFbcParamSplitAndroid: t.allowNull(t.boolean()),
                    enableAemSourceTagToLocalStorage: t.allowNull(t.boolean()),
                    enableEBPaaP: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsBufferConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    delayInMs: t.number(),
                    experimentName: t.allowNull(t.string()),
                    enableMultiEid: t.allowNull(t.boolean()),
                    onlyBufferPageView: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsCCRuleEvaluatorConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    ccRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.stringOrNumber()),
                            rule: t.allowNull(t.objectOrString()),
                          }),
                        ),
                      ),
                    ),
                    wcaRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.stringOrNumber()),
                            rule: t.allowNull(t.objectOrString()),
                          }),
                        ),
                      ),
                    ),
                    valueRules: t.allowNull(
                      t.arrayOf(
                        t.allowNull(
                          t.objectWithFields({
                            id: t.allowNull(t.string()),
                            rule: t.allowNull(t.object()),
                          }),
                        ),
                      ),
                    ),
                    blacklistedIframeReferrers: t.allowNull(
                      t.mapOf(t.boolean()),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsCensor", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.each,
                n = e.map;
              function r(e) {
                if (e == null) return null;
                if (e === "") return "";
                if (typeof e == "number") e = e.toString();
                else if (typeof e != "string") return null;
                var t = /[A-Z]/g,
                  n = /[a-z]/g,
                  r = /[0-9]/g,
                  o =
                    /(?:[\0-\x1F0-9A-Za-z\x7F-\u201C\u201E-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/g,
                  a = e.replace(t, "^");
                return (
                  (a = a.replace(n, "*")),
                  (a = a.replace(r, "#")),
                  (a = a.replace(o, "~")),
                  a
                );
              }
              var i = [
                  "ph",
                  "phone",
                  "em",
                  "email",
                  "fn",
                  "ln",
                  "f_name",
                  "l_name",
                  "external_id",
                  "gender",
                  "db",
                  "dob",
                  "ct",
                  "st",
                  "zp",
                  "country",
                  "city",
                  "state",
                  "zip",
                  "zip_code",
                  "zp",
                  "cn",
                  "firstName",
                  "surname",
                  "pn",
                  "gender",
                  "name",
                  "lastName",
                  "bd",
                  "first_name",
                  "address",
                  "last_name",
                  "birthday",
                  "email_preferences_token",
                  "consent_global_email_nl",
                  "consent_global_email_drip",
                  "consent_fide_email_nl",
                  "consent_fide_email_drip",
                  "$country",
                  "$city",
                  "$gender",
                  "dOB",
                  "user_email",
                  "email_sha256",
                  "primaryPhone",
                  "lastNameEng",
                  "firstNameEng",
                  "eMailAddress",
                  "pp",
                  "postcode",
                  "profile_name",
                  "account_name",
                  "email_paypal",
                  "zip_code",
                  "fbq_custom_name",
                ],
                l = n(i, function (e) {
                  return "ud[".concat(e, "]");
                }).concat(
                  n(i, function (e) {
                    return "udff[".concat(e, "]");
                  }),
                );
              function s(e) {
                var n = {};
                return (
                  t(i, function (t) {
                    var o = r(e[t]);
                    o != null && (n[t] = o);
                  }),
                  n
                );
              }
              o.exports = {
                censoredIneligibleKeysWithUD: l,
                getCensoredPayload: s,
                censorPII: r,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsClientHintConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    disableBackupTimeout: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsClientSidePixelForkingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    forkedPixelIds: n.allowNull(n.arrayOf(n.string())),
                    forkedPixelIdsInBrowserChannel: n.allowNull(
                      n.arrayOf(n.string()),
                    ),
                    forkedPixelIdsInServerChannel: n.allowNull(
                      n.arrayOf(n.string()),
                    ),
                    forkedPixelsInBrowserChannel: n.arrayOf(
                      n.objectWithFields({
                        destination_pixel_id: n.string(),
                        domains: n.allowNull(n.arrayOf(n.string())),
                      }),
                    ),
                    forkedPixelsInServerChannel: n.arrayOf(
                      n.objectWithFields({
                        destination_pixel_id: n.string(),
                        domains: n.allowNull(n.arrayOf(n.string())),
                      }),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceAutomaticMatchingConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    selectedMatchKeys: n.arrayOf(n.string()),
                  });
                o.exports = function (e) {
                  return t(e, r);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceBatchingConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = e.enforce,
                  i = function (o) {
                    var e = n(
                      o,
                      t.objectWithFields({
                        max_batch_size: t.number(),
                        wait_time_ms: t.number(),
                      }),
                    );
                    return e != null
                      ? {
                          batchWaitTimeMs: e.wait_time_ms,
                          maxBatchSize: e.max_batch_size,
                        }
                      : r(
                          o,
                          t.objectWithFields({
                            batchWaitTimeMs: t.number(),
                            maxBatchSize: t.number(),
                          }),
                        );
                  };
                o.exports = function (e) {
                  return n(e, i);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceInferedEventsConfig",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    buttonSelector: n.allowNull(n.string()),
                    disableRestrictedData: n.allowNull(n.boolean()),
                  });
                o.exports = function (e) {
                  return t(e, r);
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceParameterExtractors",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.filter,
                  n = e.map,
                  r = a.getFbeventsModules(
                    "signalsFBEventsCoerceStandardParameter",
                  );
                function i(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.domain_uri,
                    n = e.event_type,
                    r = e.extractor_type,
                    o = e.id,
                    a = typeof t == "string" ? t : null,
                    i =
                      n != null && typeof n == "string" && n !== "" ? n : null,
                    l =
                      o != null && typeof o == "string" && o !== "" ? o : null,
                    s =
                      r === "CONSTANT_VALUE" ||
                      r === "CSS" ||
                      r === "GLOBAL_VARIABLE" ||
                      r === "GTM" ||
                      r === "JSON_LD" ||
                      r === "META_TAG" ||
                      r === "OPEN_GRAPH" ||
                      r === "RDFA" ||
                      r === "SCHEMA_DOT_ORG" ||
                      r === "URI"
                        ? r
                        : null;
                  return a != null && i != null && l != null && s != null
                    ? { domain_uri: a, event_type: i, extractor_type: s, id: l }
                    : null;
                }
                function l(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.extractor_config;
                  if (t == null || G(t) !== "object") return null;
                  var n = t.parameter_type,
                    o = t.value,
                    a = r(n),
                    i =
                      o != null && typeof o == "string" && o !== "" ? o : null;
                  return a != null && i != null
                    ? { parameter_type: a, value: i }
                    : null;
                }
                function s(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.parameter_type,
                    n = e.selector,
                    o = r(t),
                    a =
                      n != null && typeof n == "string" && n !== "" ? n : null;
                  return o != null && a != null
                    ? { parameter_type: o, selector: a }
                    : null;
                }
                function u(e) {
                  if (e == null || G(e) !== "object") return null;
                  var r = e.extractor_config;
                  if (r == null || G(r) !== "object") return null;
                  var o = r.parameter_selectors;
                  if (Array.isArray(o)) {
                    var a = n(o, s),
                      i = t(a, Boolean);
                    if (a.length === i.length)
                      return { parameter_selectors: i };
                  }
                  return null;
                }
                function c(e) {
                  if (e == null || G(e) !== "object") return null;
                  var t = e.extractor_config;
                  if (t == null || G(t) !== "object") return null;
                  var n = t.context,
                    o = t.parameter_type,
                    a = t.value,
                    i =
                      n != null && typeof n == "string" && n !== "" ? n : null,
                    l = r(o),
                    s =
                      a != null && typeof a == "string" && a !== "" ? a : null;
                  return i != null && l != null && s != null
                    ? { context: i, parameter_type: l, value: s }
                    : null;
                }
                function d(e) {
                  var t = i(e);
                  if (t == null || e == null || G(e) !== "object") return null;
                  var n = t.domain_uri,
                    r = t.event_type,
                    o = t.extractor_type,
                    a = t.id;
                  if (o === "CSS") {
                    var s = u(e);
                    if (s != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: s,
                        extractor_type: "CSS",
                        id: a,
                      };
                  }
                  if (o === "CONSTANT_VALUE") {
                    var d = l(e);
                    if (d != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: d,
                        extractor_type: "CONSTANT_VALUE",
                        id: a,
                      };
                  }
                  if (o === "GLOBAL_VARIABLE")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "GLOBAL_VARIABLE",
                      id: a,
                    };
                  if (o === "GTM")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "GTM",
                      id: a,
                    };
                  if (o === "JSON_LD")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "JSON_LD",
                      id: a,
                    };
                  if (o === "META_TAG")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "META_TAG",
                      id: a,
                    };
                  if (o === "OPEN_GRAPH")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "OPEN_GRAPH",
                      id: a,
                    };
                  if (o === "RDFA")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "RDFA",
                      id: a,
                    };
                  if (o === "SCHEMA_DOT_ORG")
                    return {
                      domain_uri: n,
                      event_type: r,
                      extractor_type: "SCHEMA_DOT_ORG",
                      id: a,
                    };
                  if (o === "URI") {
                    var m = c(e);
                    if (m != null)
                      return {
                        domain_uri: n,
                        event_type: r,
                        extractor_config: m,
                        extractor_type: "URI",
                        id: a,
                      };
                  }
                  return null;
                }
                o.exports = d;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("signalsFBEventsCoercePixelID", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logUserError,
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = n.coerce;
              function l(e) {
                var n = i(e, r.fbid());
                if (n == null) {
                  var o = JSON.stringify(n);
                  return (
                    t({
                      pixelID: o != null ? o : "undefined",
                      type: "INVALID_PIXEL_ID",
                    }),
                    null
                  );
                }
                return n;
              }
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "signalsFBEventsCoerceStandardParameter",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.FBSet,
                  n = new t([
                    "content_category",
                    "content_ids",
                    "content_name",
                    "content_type",
                    "currency",
                    "contents",
                    "num_items",
                    "order_id",
                    "predicted_ltv",
                    "search_string",
                    "status",
                    "subscription_id",
                    "value",
                    "id",
                    "item_price",
                    "quantity",
                    "ct",
                    "db",
                    "em",
                    "external_id",
                    "fn",
                    "ge",
                    "ln",
                    "namespace",
                    "ph",
                    "st",
                    "zp",
                  ]);
                function r(e) {
                  return typeof e == "string" && n.has(e) ? e : null;
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsConfigLoadedEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function n(e) {
                var n = t(e);
                return n != null ? [n] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsConfigStore", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "signalsFBEventsCoerceAutomaticMatchingConfig",
                ),
                t = a.getFbeventsModules("signalsFBEventsCoerceBatchingConfig"),
                n = a.getFbeventsModules(
                  "signalsFBEventsCoerceInferedEventsConfig",
                ),
                r = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logError,
                s = a.getFbeventsModules("SignalsFBEventsQE"),
                u = a.getFbeventsModules(
                  "SignalsFBEventsBrowserPropertiesConfigTypedef",
                ),
                c = a.getFbeventsModules("SignalsFBEventsBufferConfigTypedef"),
                d = a.getFbeventsModules(
                  "SignalsFBEventsESTRuleEngineConfigTypedef",
                ),
                m = a.getFbeventsModules(
                  "SignalsFBEventsDataProcessingOptionsConfigTypedef",
                ),
                p = a.getFbeventsModules(
                  "SignalsFBEventsDisabledExtensionsConfigTypedef",
                ),
                _ = a.getFbeventsModules(
                  "SignalsFBEventsDefaultCustomDataConfigTypedef",
                ),
                f = a.getFbeventsModules(
                  "SignalsFBEventsMicrodataConfigTypedef",
                ),
                g = a.getFbeventsModules(
                  "SignalsFBEventsOpenBridgeConfigTypedef",
                ),
                h = a.getFbeventsModules(
                  "SignalsFBEventsParallelFireConfigTypedef",
                ),
                y = a.getFbeventsModules(
                  "SignalsFBEventsProhibitedSourcesTypedef",
                ),
                C = a.getFbeventsModules(
                  "SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef",
                ),
                b = a.getFbeventsModules("SignalsFBEventsTyped"),
                v = b.Typed,
                R = b.coerce,
                L = a.getFbeventsModules("SignalsFBEventsUnwantedDataTypedef"),
                E = a.getFbeventsModules(
                  "SignalsFBEventsEventValidationConfigTypedef",
                ),
                k = a.getFbeventsModules(
                  "SignalsFBEventsProtectedDataModeConfigTypedef",
                ),
                I = a.getFbeventsModules(
                  "SignalsFBEventsClientHintConfigTypedef",
                ),
                T = a.getFbeventsModules(
                  "SignalsFBEventsCCRuleEvaluatorConfigTypedef",
                ),
                D = a.getFbeventsModules(
                  "SignalsFBEventsRestrictedDomainsConfigTypedef",
                ),
                x = a.getFbeventsModules(
                  "SignalsFBEventsIABPCMAEBridgeConfigTypedef",
                ),
                P = a.getFbeventsModules(
                  "SignalsFBEventsCookieDeprecationLabelConfigTypedef",
                ),
                M = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedEventsConfigTypedef",
                ),
                w = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedEventNamesConfigTypedef",
                ),
                A = a.getFbeventsModules(
                  "SignalsFBEventsUnwantedParamsConfigTypedef",
                ),
                F = a.getFbeventsModules(
                  "SignalsFBEventsStandardParamChecksConfigTypedef",
                ),
                O = a.getFbeventsModules(
                  "SignalsFBEventsClientSidePixelForkingConfigTypedef",
                ),
                B = a.getFbeventsModules("SignalsFBEventsCookieConfigTypedef"),
                W = a.getFbeventsModules("SignalsFBEventsGatingConfigTypedef"),
                q = a.getFbeventsModules(
                  "SignalsFBEventsProhibitedPixelConfigTypedef",
                ),
                U = a.getFbeventsModules("SignalsFBEventsWebchatConfigTypedef"),
                V = a.getFbeventsModules(
                  "SignalsFBEventsImagePixelOpenBridgeConfigTypedef",
                ),
                H = a.getFbeventsModules(
                  "SignalsFBEventsBotBlockingConfigTypedef",
                ),
                G = a.getFbeventsModules(
                  "SignalsFBEventsURLMetadataConfigTypedef",
                ),
                z = a.getFbeventsModules(
                  "SignalsFBEventsQualityCheckerConfigTypedef",
                ),
                j = a.getFbeventsModules("SignalsFBEventsMetaQEConfigTypedef"),
                K = a.getFbeventsModules(
                  "SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef",
                ),
                Q = "global",
                X = {
                  automaticMatching: e,
                  openbridge: g,
                  batching: t,
                  inferredEvents: n,
                  microdata: f,
                  prohibitedSources: y,
                  unwantedData: L,
                  dataProcessingOptions: m,
                  parallelfire: h,
                  buffer: c,
                  browserProperties: u,
                  defaultCustomData: _,
                  estRuleEngine: d,
                  eventValidation: E,
                  protectedDataMode: k,
                  clientHint: I,
                  ccRuleEvaluator: T,
                  restrictedDomains: D,
                  IABPCMAEBridge: x,
                  cookieDeprecationLabel: P,
                  unwantedEvents: M,
                  unwantedEventNames: w,
                  unwantedParams: A,
                  standardParamChecks: F,
                  clientSidePixelForking: O,
                  cookie: B,
                  gating: W,
                  prohibitedPixels: q,
                  triggersgwpixeltrackcommand: C,
                  webchat: U,
                  imagepixelopenbridge: V,
                  botblocking: H,
                  disabledExtensions: p,
                  urlMetadata: G,
                  qualityChecker: z,
                  metaQE: j,
                  googleAnalyticsBridge: K,
                },
                Y = (function () {
                  function e() {
                    var t;
                    ($(this, e),
                      S(
                        this,
                        "_configStore",
                        ((t = {
                          automaticMatching: {},
                          batching: {},
                          inferredEvents: {},
                          microdata: {},
                          prohibitedSources: {},
                          unwantedData: {},
                          dataProcessingOptions: {},
                          openbridge: {},
                          parallelfire: {},
                          buffer: {},
                          defaultCustomData: {},
                          estRuleEngine: {},
                        }),
                        S(
                          S(
                            S(
                              S(
                                S(
                                  S(
                                    S(
                                      S(
                                        S(
                                          S(t, "defaultCustomData", {}),
                                          "browserProperties",
                                          {},
                                        ),
                                        "eventValidation",
                                        {},
                                      ),
                                      "protectedDataMode",
                                      {},
                                    ),
                                    "clientHint",
                                    {},
                                  ),
                                  "ccRuleEvaluator",
                                  {},
                                ),
                                "restrictedDomains",
                                {},
                              ),
                              "IABPCMAEBridge",
                              {},
                            ),
                            "cookieDeprecationLabel",
                            {},
                          ),
                          "unwantedEvents",
                          {},
                        ),
                        S(
                          S(
                            S(
                              S(
                                S(
                                  S(
                                    S(
                                      S(
                                        S(
                                          S(t, "unwantedParams", {}),
                                          "standardParamChecks",
                                          {},
                                        ),
                                        "unwantedEventNames",
                                        {},
                                      ),
                                      "clientSidePixelForking",
                                      {},
                                    ),
                                    "cookie",
                                    {},
                                  ),
                                  "gating",
                                  {},
                                ),
                                "prohibitedPixels",
                                {},
                              ),
                              "triggersgwpixeltrackcommand",
                              {},
                            ),
                            "webchat",
                            {},
                          ),
                          "imagepixelopenbridge",
                          {},
                        ),
                        S(
                          S(
                            S(
                              S(
                                S(
                                  S(t, "botblocking", {}),
                                  "disabledExtensions",
                                  {},
                                ),
                                "urlMetadata",
                                {},
                              ),
                              "qualityChecker",
                              {},
                            ),
                            "metaQE",
                            {},
                          ),
                          "googleAnalyticsBridge",
                          {},
                        )),
                      ));
                  }
                  return N(e, [
                    {
                      key: "set",
                      value: function (t, n, o) {
                        var e = t == null ? Q : r(t);
                        if (e != null) {
                          var a = J(n);
                          a != null &&
                            this._configStore[a] != null &&
                            (this._configStore[a][e] =
                              X[a] != null ? X[a](o) : o);
                        }
                      },
                    },
                    {
                      key: "setExperimental",
                      value: function (t) {
                        var e = R(
                          t,
                          v.objectWithFields({
                            config: v.object(),
                            experimentName: v.string(),
                            pixelID: r,
                            pluginName: v.string(),
                          }),
                        );
                        if (e != null) {
                          var n = e.config,
                            o = e.experimentName,
                            a = e.pixelID,
                            i = e.pluginName;
                          s.isInTest(o) && this.set(a, i, n);
                        }
                      },
                    },
                    {
                      key: "get",
                      value: function (t, n) {
                        return this._configStore[n][t != null ? t : Q];
                      },
                    },
                    {
                      key: "getWithGlobalFallback",
                      value: function (t, n) {
                        var e = Q,
                          r = this._configStore[n];
                        return (
                          t != null &&
                            Object.prototype.hasOwnProperty.call(r, t) &&
                            (e = t),
                          r[e]
                        );
                      },
                    },
                    {
                      key: "getAutomaticMatchingConfig",
                      value: function (t) {
                        return (
                          l(
                            new Error(
                              "Calling legacy api getAutomaticMatchingConfig",
                            ),
                          ),
                          this.get(t, "automaticMatching")
                        );
                      },
                    },
                    {
                      key: "getInferredEventsConfig",
                      value: function (t) {
                        return (
                          l(
                            new Error(
                              "Calling legacy api getInferredEventsConfig",
                            ),
                          ),
                          this.get(t, "inferredEvents")
                        );
                      },
                    },
                  ]);
                })();
              function J(e) {
                var t,
                  n = R(e, v.string());
                if (n == null) return null;
                var r = Object.keys(X);
                return (t = r.find(function (e) {
                  return e === n;
                })) !== null && t !== void 0
                  ? t
                  : null;
              }
              o.exports = new Y();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsCookieConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    fbcParamsConfig: t.allowNull(
                      t.objectWithFields({
                        params: t.arrayOf(
                          t.objectWithFields({
                            ebp_path: t.string(),
                            prefix: t.string(),
                            query: t.string(),
                          }),
                        ),
                      }),
                    ),
                    enableFbcParamSplitAll: t.allowNull(t.boolean()),
                    maxMultiFbcQueueSize: t.allowNull(t.number()),
                    enableFbcParamSplitSafariOnly: t.allowNull(t.boolean()),
                    enableAemSourceTagToLocalStorage: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsCookieDeprecationLabelConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    delayInMs: t.allowNull(t.number()),
                    disableBackupTimeout: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsCorrectPIIPlacement",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                  t = e.logError,
                  n = a.getFbeventsModules("SignalsFBEventsUtils"),
                  r = n.each,
                  i = n.keys,
                  l = a.getFbeventsModules("SignalsPixelPIIUtils"),
                  s = l.isZipCode,
                  u = a.getFbeventsModules("SignalsPixelPIIUtils"),
                  c = u.isEmail,
                  d = u.isPhoneNumber,
                  m = u.getGenderCharacter,
                  p = a.getFbeventsModules("SignalsFBEventsQE"),
                  _ = a.getFbeventsModules("SignalsPixelPIIConstants"),
                  f = _.PII_KEYS_TO_ALIASES_EXPANDED;
                function g(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    var n = {};
                    (r(i(e), function (t) {
                      typeof t == "string" && typeof t.toLowerCase == "function"
                        ? (n[t.toLowerCase()] = e[t])
                        : (n[t] = e[t]);
                    }),
                      r(i(f), function (t) {
                        if (e[t] == null) {
                          var o = f[t];
                          r(o, function (r) {
                            e[t] == null &&
                              r in n &&
                              n[r] != null &&
                              (e[t] = n[r]);
                          });
                        }
                      }),
                      r(i(e), function (t) {
                        var n = e[t];
                        if (n != null) {
                          if (e.em == null && c(n)) {
                            e.em = n;
                            return;
                          }
                          if (e.ph == null && d(n)) {
                            e.ph = n;
                            return;
                          }
                          if (e.zp == null && s(n)) {
                            e.zp = n;
                            return;
                          }
                          if (
                            e.ge == null &&
                            typeof n == "string" &&
                            typeof n.toLowerCase == "function" &&
                            (m(n.toLowerCase()) == "m" ||
                              m(n.toLowerCase()) == "f")
                          ) {
                            e.ge = m(n);
                            return;
                          }
                        }
                      }));
                  } catch (e) {
                    ((e.message = "[Placement Fix]:" + e.message), t(e));
                  }
                  return e;
                }
                o.exports = g;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDataProcessingOptionsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    dataProcessingOptions: t.withValidation({
                      def: t.arrayOf(t.string()),
                      validators: [
                        function (e) {
                          return e.reduce(function (e, t) {
                            return e === !0 && t === "LDU";
                          }, !0);
                        },
                      ],
                    }),
                    dataProcessingCountry: t.withValidation({
                      def: t.allowNull(t.number()),
                      validators: [
                        function (e) {
                          return e === null || e === 0 || e === 1;
                        },
                      ],
                    }),
                    dataProcessingState: t.withValidation({
                      def: t.allowNull(t.number()),
                      validators: [
                        function (e) {
                          return e === null || e === 0 || e === 1e3;
                        },
                      ],
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDefaultCustomDataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    enable_order_id: t.boolean(),
                    enable_value: t.boolean(),
                    enable_currency: t.boolean(),
                    enable_contents: t.boolean(),
                    enable_content_ids: t.boolean(),
                    enable_content_type: t.boolean(),
                    experiment: t.allowNull(t.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsDisabledExtensionsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    disabledExtensions: t.withValidation({
                      def: t.arrayOf(t.string()),
                      validators: [
                        function (e) {
                          return e.reduce(function (e, t) {
                            return (
                              e === !0 &&
                              t ===
                                "whatsapp_marketing_messaging_customer_subscription"
                            );
                          }, !0);
                        },
                      ],
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsDoAutomaticMatching",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                  t = e.keys,
                  n = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                  r = a.getFbeventsModules("SignalsFBEventsEvents"),
                  i = r.piiAutomatched;
                function l(e, r, o, a, l, s) {
                  var u = s != null ? s : n.get(r.id, "automaticMatching");
                  if (t(o).length > 0 && u != null) {
                    var c = u.selectedMatchKeys;
                    for (var d in o)
                      c.indexOf(d) >= 0 &&
                        ((r.userDataFormFields[d] = o[d]),
                        l != null &&
                          d in l &&
                          (r.censoredUserDataFormatFormFields[d] = l[d]),
                        a != null &&
                          d in a &&
                          (r.alternateUserDataFormFields[d] = a[d]));
                    i.trigger(r);
                  }
                }
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsESTRuleEngineConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    experimentName: t.allowNull(t.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsEvents", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsConfigLoadedEvent"),
                n = a.getFbeventsModules("SignalsFBEventsFiredEvent"),
                r = a.getFbeventsModules(
                  "SignalsFBEventsGetCustomParametersEvent",
                ),
                i = a.getFbeventsModules(
                  "SignalsFBEventsGetIWLParametersEvent",
                ),
                l = a.getFbeventsModules("SignalsFBEventsIWLBootStrapEvent"),
                s = a.getFbeventsModules("SignalsFBEventsPIIAutomatchedEvent"),
                u = a.getFbeventsModules("SignalsFBEventsPIIConflictingEvent"),
                c = a.getFbeventsModules("SignalsFBEventsPIIInvalidatedEvent"),
                d = a.getFbeventsModules("SignalsFBEventsPluginLoadedEvent"),
                m = a.getFbeventsModules("SignalsFBEventsSetEventIDEvent"),
                p = a.getFbeventsModules(
                  "SignalsFBEventsSetIWLExtractorsEvent",
                ),
                _ = a.getFbeventsModules("SignalsFBEventsSetESTRules"),
                f = a.getFbeventsModules("SignalsFBEventsSetCCRules"),
                g = a.getFbeventsModules(
                  "SignalsFBEventsValidateCustomParametersEvent",
                ),
                h = a.getFbeventsModules(
                  "SignalsFBEventsLateValidateCustomParametersEvent",
                ),
                y = a.getFbeventsModules(
                  "SignalsFBEventsValidateUrlParametersEvent",
                ),
                C = a.getFbeventsModules(
                  "SignalsFBEventsValidateGetClickIDFromBrowserProperties",
                ),
                b = a.getFbeventsModules("SignalsFBEventsExtractPII"),
                v = a.getFbeventsModules(
                  "SignalsFBEventsGetAutomaticParametersEvent",
                ),
                S = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                R = a.getFbeventsModules(
                  "SignalsFBEventsAutomaticPageViewEvent",
                ),
                L = a.getFbeventsModules("SignalsFBEventsWebChatEvent"),
                E = {
                  configLoaded: t,
                  execEnd: new e(),
                  fired: n,
                  getCustomParameters: r,
                  getIWLParameters: i,
                  iwlBootstrap: l,
                  piiAutomatched: s,
                  piiConflicting: u,
                  piiInvalidated: c,
                  pluginLoaded: d,
                  setEventId: m,
                  setIWLExtractors: p,
                  setESTRules: _,
                  setCCRules: f,
                  validateCustomParameters: g,
                  lateValidateCustomParameters: h,
                  validateUrlParameters: y,
                  getClickIDFromBrowserProperties: C,
                  extractPii: b,
                  getAutomaticParameters: v,
                  SendEventEvent: S,
                  automaticPageView: R,
                  webchatEvent: L,
                };
              o.exports = E;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsEventValidationConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    unverifiedEventNames: t.allowNull(t.arrayOf(t.string())),
                    enableEventSanitization: t.allowNull(t.boolean()),
                    restrictedEventNames: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsExperimentNames", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = {
                NO_OP_EXPERIMENT: "no_op_exp",
                AUTOMATIC_PARAMETERS_JSON_AUTO_FIX:
                  "automatic_parameters_json_auto_fix",
                BUTTON_CLICK_OPTIMIZE_EXPERIMENT_V2:
                  "button_click_optimize_experiment_v2",
                HIGH_FETCH_PRIORITY_IMAGE: "high_fetch_priority_image",
                MICRODATA_REFACTOR_MIGRATION_AUTOMATIC_PARAMETERS:
                  "microdata_refactor_migration_automatic_parameters",
                MICRODATA_REFACTOR_MIGRATION_PAGE_META_DATA:
                  "microdata_refactor_migration_page_meta_data",
                COOKIE_TTL_FIX: "cookie_ttl_fix",
                IN_MEMORY_COOKIE_JAR: "in_memory_cookie_jar",
                PAGE_TITLE_OG_FALLBACK: "page_title_og_fallback",
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsExperimentsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = e.enforce,
                  i = t.arrayOf(
                    t.objectWithFields({
                      allocation: t.number(),
                      code: t.string(),
                      name: t.string(),
                      passRate: t.number(),
                    }),
                  );
                o.exports = i;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsExperimentsV2Typedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = e.enforce,
                  i = t.arrayOf(
                    t.objectWithFields({
                      evaluationType: t.enumeration({
                        eventlevel: "EVENT_LEVEL",
                        pageloadlevel: "PAGE_LOAD_LEVEL",
                      }),
                      universe: t.string(),
                      allocation: t.number(),
                      code: t.string(),
                      name: t.string(),
                      passRate: t.number(),
                    }),
                  );
                o.exports = i;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsExtractPII", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.Typed,
                i = n.coerce;
              function l(e, n, o) {
                var a = i(e, t),
                  l = r.allowNull(r.object()),
                  s = r.allowNull(r.object());
                return a != null ? [{ pixel: a, form: l, button: s }] : null;
              }
              var s = new e(l);
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsFBQ", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var r = a.getFbeventsModules("SignalsEventValidation"),
                i = a.getFbeventsModules("handleEventIdOverride"),
                l = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                s = a.getFbeventsModules("SignalsFBEventsEvents"),
                u = s.configLoaded,
                c = a.getFbeventsModules("SignalsFBEventsFireLock"),
                d = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                m = a.getFbeventsModules("SignalsFBEventsLogging"),
                p = a.getFbeventsModules("SignalsFBEventsOptIn"),
                _ = a.getFbeventsModules("SignalsFBEventsUtils"),
                f = a.getFbeventsModules("signalsFBEventsGetIsIosInAppBrowser"),
                g = a.getFbeventsModules("SignalsFBEventsGetValidUrl"),
                h = a.getFbeventsModules("SignalsFBEventsResolveLink"),
                y = a.getFbeventsModules("SignalsPixelCookieUtils"),
                C = y.CLICK_ID_PARAMETER,
                b = y.readPackedCookie,
                R = y.CLICKTHROUGH_COOKIE_NAME,
                L = a.getFbeventsModules("SignalsFBEventsQE"),
                E = a.getFbeventsModules("SignalsFBEventsQEV2"),
                k = a.getFbeventsModules("SignalsFBEventsModuleEncodings"),
                T = a.getFbeventsModules("SignalsParamList"),
                D = a.getFbeventsModules("signalsFBEventsSendEvent"),
                x = D.sendEvent,
                P = a.getFbeventsModules("SignalsFBEventsAsyncParamUtils"),
                M = P.registerAsyncParamAllSettledListener,
                w = P.flushAsyncParamEventQueue,
                A = _.each,
                F = _.keys,
                O = _.map,
                B = _.some,
                W = m.logError,
                q = m.logUserError,
                U = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                V = a.getFbeventsModules("SignalsFBEventsPixelQueueState"),
                H = V.trySetQueueHandler,
                G = {
                  AutomaticMatching: !0,
                  AutomaticMatchingForPartnerIntegrations: !0,
                  DefaultCustomData: !0,
                  Buffer: !0,
                  CommonIncludes: !0,
                  FirstPartyCookies: !0,
                  IWLBootstrapper: !0,
                  IWLParameters: !0,
                  IdentifyIntegration: !0,
                  InferredEvents: !0,
                  Microdata: !0,
                  MicrodataJsonLd: !0,
                  OpenBridge: !0,
                  ParallelFire: !0,
                  ProhibitedSources: !0,
                  Timespent: !0,
                  UnwantedData: !0,
                  LocalComputation: !0,
                  IABPCMAEBridge: !0,
                  BrowserProperties: !0,
                  ESTRuleEngine: !0,
                  EventValidation: !0,
                  ProtectedDataMode: !0,
                  PrivacySandbox: !0,
                  ClientHint: !0,
                  CCRuleEvaluator: !0,
                  ProhibitedPixels: !0,
                  LastExternalReferrer: !0,
                  CookieDeprecationLabel: !0,
                  UnwantedEvents: !0,
                  UnwantedEventNames: !0,
                  UnwantedParams: !0,
                  StandardParamChecks: !0,
                  ShopifyAppIntegratedPixel: !0,
                  clientSidePixelForking: !0,
                  ShadowTest: !0,
                  TopicsAPI: !0,
                  Gating: !0,
                  AutomaticParameters: !0,
                  LeadEventId: !0,
                  EngagementData: !0,
                  TriggerSgwPixelTrackCommand: !0,
                  DomainBlocking: !0,
                  WebChat: !0,
                  ScrollDepth: !0,
                  PageMetadata: !0,
                  WebsitePerformance: !0,
                  ImagePixelOpenBridge: !0,
                  WebpageContentExtractor: !0,
                  BotBlocking: !0,
                  URLParamSchematization: !0,
                  URLMetadata: !0,
                  PrivacyPreservingDataLookup: !0,
                  GoogleAnalyticsBridge: !0,
                  BrowserPropertiesPlatform: !0,
                },
                z = {
                  Track: 0,
                  TrackCustom: 4,
                  TrackSingle: 1,
                  TrackSingleCustom: 2,
                  TrackSingleSystem: 3,
                  TrackSystem: 5,
                },
                j = "global_config",
                K = 200,
                Q = [
                  "InferredEvents",
                  "Microdata",
                  "AutomaticParameters",
                  "EngagementData",
                  "PageMetadata",
                  "ScrollDepth",
                  "WebChat",
                ],
                X = { AutomaticSetup: Q },
                Y = {
                  AutomaticMatching: ["inferredevents", "identity"],
                  AutomaticMatchingForPartnerIntegrations: [
                    "automaticmatchingforpartnerintegrations",
                  ],
                  CommonIncludes: ["commonincludes"],
                  DefaultCustomData: ["defaultcustomdata"],
                  FirstPartyCookies: ["cookie"],
                  IWLBootstrapper: ["iwlbootstrapper"],
                  IWLParameters: ["iwlparameters"],
                  ESTRuleEngine: ["estruleengine"],
                  IdentifyIntegration: ["identifyintegration"],
                  Buffer: ["buffer"],
                  InferredEvents: ["inferredevents", "identity"],
                  Microdata: ["microdata", "identity"],
                  MicrodataJsonLd: ["jsonld_microdata"],
                  ParallelFire: ["parallelfire"],
                  ProhibitedSources: ["prohibitedsources"],
                  Timespent: ["timespent"],
                  UnwantedData: ["unwanteddata"],
                  LocalComputation: ["localcomputation"],
                  IABPCMAEBridge: ["iabpcmaebridge"],
                  BrowserProperties: ["browserproperties"],
                  EventValidation: ["eventvalidation"],
                  ProtectedDataMode: ["protecteddatamode"],
                  PrivacySandbox: ["privacysandbox"],
                  ClientHint: ["clienthint"],
                  CCRuleEvaluator: ["ccruleevaluator"],
                  ProhibitedPixels: ["prohibitedpixels"],
                  LastExternalReferrer: ["lastexternalreferrer"],
                  CookieDeprecationLabel: ["cookiedeprecationlabel"],
                  UnwantedEvents: ["unwantedevents"],
                  UnwantedEventNames: ["unwantedeventnames"],
                  UnwantedParams: ["unwantedparams"],
                  ShopifyAppIntegratedPixel: ["shopifyappintegratedpixel"],
                  clientSidePixelForking: ["clientsidepixelforking"],
                  TopicsAPI: ["topicsapi"],
                  Gating: ["gating"],
                  AutomaticParameters: ["automaticparameters"],
                  LeadEventId: ["leadeventid"],
                  EngagementData: ["engagementdata"],
                  TriggerSgwPixelTrackCommand: ["triggersgwpixeltrackcommand"],
                  DomainBlocking: ["domainblocking"],
                  WebChat: ["webchat"],
                  ScrollDepth: ["scrolldepth"],
                  PageMetadata: ["pagemetadata"],
                  WebsitePerformance: ["websiteperformance"],
                  ImagePixelOpenBridge: ["imagepixelopenbridge"],
                  WebpageContentExtractor: ["webpagecontentextractor"],
                  BotBlocking: ["botblocking"],
                  URLParamSchematization: ["urlparamschematization"],
                  URLMetadata: ["urlmetadata"],
                  PrivacyPreservingDataLookup: ["privacypreservingdatalookup"],
                  GoogleAnalyticsBridge: ["googleanalyticsbridge"],
                  BrowserPropertiesPlatform: ["browserpropertiesplatform"],
                };
              function J(e) {
                return !!(G[e] || X[e]);
              }
              var Z = function (t) {
                var e = t.pixelID,
                  n = t.version,
                  r = t.releaseSegment,
                  o = t.noMin,
                  a = t.domain,
                  i = new T(function (e) {
                    return { finalValue: e };
                  });
                return (
                  i.append("v", n),
                  i.append("r", r),
                  o === !0 && i.append("no_min", !0),
                  a != null && a != "" && i.append("domain", a),
                  k.addEncodings(i),
                  ""
                    .concat(d.CONFIG.CDN_BASE_URL, "signals/config/")
                    .concat(e, "?")
                    .concat(i.toPayload().toQueryString())
                );
              };
              function ee(e) {
                var t = e.pixelID,
                  n = e.version,
                  r = e.releaseSegment,
                  o = e.domain,
                  a = e.noMin;
                d.loadJSFile(
                  Z({
                    pixelID: t,
                    version: n,
                    releaseSegment: r,
                    noMin: a,
                    domain: o,
                  }),
                );
              }
              var te = (function () {
                function o(e, t) {
                  var n = this;
                  ($(this, o),
                    S(this, "VALID_FEATURES", G),
                    S(this, "optIns", new p(X)),
                    S(this, "configsLoaded", {}),
                    S(this, "locks", c.global),
                    S(this, "pluginConfig", l),
                    S(this, "disableFirstPartyCookies", !1),
                    S(this, "disableAutoConfig", !1),
                    S(this, "asyncParamFetchers", new Map()),
                    S(this, "eventQueue", []),
                    S(this, "asyncParamPromisesAllSettled", !0),
                    S(this, "disableAsyncParamBackupTimeout", !1),
                    S(this, "fbp", null),
                    (this.VERSION = e.version),
                    (this.RELEASE_SEGMENT = e._releaseSegment),
                    (this.pixelsByID = t),
                    (this.fbq = e),
                    A(e.pendingConfigs || [], function (e) {
                      return n.locks.lockConfig(e);
                    }));
                }
                return N(o, [
                  {
                    key: "optIn",
                    value: function (t, n) {
                      var e = this,
                        r =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                      if (typeof n != "string" || !J(n))
                        throw new Error(
                          'Invalid Argument: "' +
                            n +
                            '" is not a valid opt-in feature',
                        );
                      return (
                        J(n) &&
                          (this.optIns.optIn(t, n, r),
                          A([n].concat(I(X[n] || [])), function (t) {
                            Y[t] &&
                              A(Y[t], function (t) {
                                return e.fbq.loadPlugin(t);
                              });
                          })),
                        this
                      );
                    },
                  },
                  {
                    key: "optOut",
                    value: function (t, n) {
                      return (this.optIns.optOut(t, n), this);
                    },
                  },
                  {
                    key: "consent",
                    value: function (t) {
                      return (
                        t === "revoke"
                          ? this.locks.lockConsent()
                          : t === "grant"
                            ? this.locks.unlockConsent()
                            : q({ action: t, type: "INVALID_CONSENT_ACTION" }),
                        this
                      );
                    },
                  },
                  {
                    key: "setUserProperties",
                    value: function (t, n) {
                      var e = this.pluginConfig.get(
                        null,
                        "dataProcessingOptions",
                      );
                      if (
                        !(e != null && e.dataProcessingOptions.includes("LDU"))
                      ) {
                        if (
                          !Object.prototype.hasOwnProperty.call(
                            this.pixelsByID,
                            t,
                          )
                        ) {
                          q({ pixelID: t, type: "PIXEL_NOT_INITIALIZED" });
                          return;
                        }
                        this.trackSingleSystem({
                          systemCategory: "user_properties",
                          pixel: t,
                          eventName: "UserProperties",
                          customData: v({}, n),
                        });
                      }
                    },
                  },
                  {
                    key: "trackSingle",
                    value: function (t, n, o, a) {
                      return (
                        r.validateEventAndLog(n, o),
                        this.trackSingleGeneric({
                          pixel: t,
                          eventName: n,
                          customData: o,
                          trackMethod: z.TrackSingle,
                          eventData: a,
                        })
                      );
                    },
                  },
                  {
                    key: "trackSingleCustom",
                    value: function (t, n, r, o) {
                      return this.trackSingleGeneric({
                        pixel: t,
                        eventName: n,
                        customData: r,
                        trackMethod: z.TrackSingleCustom,
                        eventData: o,
                      });
                    },
                  },
                  {
                    key: "trackSingleSystem",
                    value: function (t) {
                      var e = t.systemCategory,
                        n = t.pixel,
                        r = t.eventName,
                        o = t.customData,
                        a = t.eventData,
                        i = t.customParams,
                        l = t.experimentId;
                      return this.trackSingleGeneric({
                        pixel: n,
                        eventName: r,
                        customData: o,
                        trackMethod: z.TrackSingleSystem,
                        eventData: a || null,
                        systemCategory: e,
                        customParams: i,
                        experimentId: l,
                      });
                    },
                  },
                  {
                    key: "trackSingleGeneric",
                    value: function (t) {
                      var e = t.pixel,
                        n = t.eventName,
                        r = t.customData,
                        o = t.trackMethod,
                        a = t.eventData,
                        i = t.systemCategory,
                        l = t.customParams,
                        s = t.experimentId,
                        u = typeof e == "string" ? e : e.id,
                        c = s;
                      if (
                        ((c == null || c === "") && (c = Date.now().toString()),
                        !Object.prototype.hasOwnProperty.call(
                          this.pixelsByID,
                          u,
                        ))
                      ) {
                        var d = { pixelID: u, type: "PIXEL_NOT_INITIALIZED" };
                        return (
                          i == null
                            ? q(d)
                            : W(new Error(d.type + " " + d.pixelID)),
                          this
                        );
                      }
                      var m = this.getDefaultSendData(u, n, a, c);
                      return (
                        (m.customData = r),
                        i != null && (m.customParameters = { es: i }),
                        l != null &&
                          (m.customParameters = v(
                            v({}, m.customParameters),
                            l,
                          )),
                        (m.customParameters = v(
                          v({}, m.customParameters),
                          {},
                          { tm: "".concat(o) },
                        )),
                        this.fire(m, !1),
                        this
                      );
                    },
                  },
                  {
                    key: "_validateSend",
                    value: function (t, n) {
                      if (!t.eventName || !t.eventName.length) {
                        var e = E.isInMetaQEControl(t.pixelId);
                        if (!e)
                          ((t.eventName = ""),
                            (t.customParameters = v(
                              v({}, t.customParameters),
                              {},
                              { "ie[d]": "1" },
                            )),
                            q({ type: "NO_EVENT_NAME" }));
                        else throw new Error("Event name not specified");
                      }
                      if (!t.pixelId || !t.pixelId.length)
                        throw new Error("PixelId not specified");
                      if (
                        (t.set &&
                          A(
                            O(F(t.set), function (e) {
                              return r.validateMetadata(e);
                            }),
                            function (e) {
                              if (e.error) throw new Error(e.error);
                              e.warnings.length && A(e.warnings, q);
                            },
                          ),
                        n)
                      ) {
                        var o = r.validateEvent(
                          t.eventName,
                          t.customData || {},
                        );
                        if (o.error) throw new Error(o.error);
                        o.warnings && o.warnings.length && A(o.warnings, q);
                      }
                      return this;
                    },
                  },
                  {
                    key: "_argsHasAnyUserData",
                    value: function (t) {
                      var e = t.userData != null && F(t.userData).length > 0,
                        n =
                          t.userDataFormFields != null &&
                          F(t.userDataFormFields).length > 0;
                      return e || n;
                    },
                  },
                  {
                    key: "fire",
                    value: function (n) {
                      var t =
                        arguments.length > 1 && arguments[1] !== void 0
                          ? arguments[1]
                          : !1;
                      if (
                        (this._validateSend(n, t),
                        (this._argsHasAnyUserData(n) &&
                          !this.fbq.loadPlugin("identity")) ||
                          this.locks.isLocked())
                      )
                        return (e.fbq("fire", n), this);
                      var r = n.customParameters,
                        o = "";
                      (r && r.es && typeof r.es == "string" && (o = r.es),
                        (n.customData = n.customData || {}));
                      var a = this.fbq.getEventCustomParameters(
                        this.getPixel(n.pixelId),
                        n.eventName,
                        n.customData,
                        o,
                        n.eventData,
                      );
                      return (
                        i(n.eventData, n.customData || {}, a, n.pixelId),
                        r &&
                          A(F(r), function (e) {
                            if (a.containsKey(e)) {
                              var t = E.isInMetaQEControl(n.pixelId);
                              if (!t)
                                (a.replaceEntry(e, r[e]),
                                  a.append("ie[c]", "1"));
                              else
                                throw new Error(
                                  "Custom parameter ".concat(
                                    e,
                                    " already specified.",
                                  ),
                                );
                            } else a.append(e, r[e]);
                          }),
                        x(
                          {
                            customData: n.customData,
                            customParams: a,
                            eventName: n.eventName,
                            eventData: n.eventData,
                            id: n.pixelId,
                            piiTranslator: null,
                            experimentId: n.experimentId,
                          },
                          this,
                        ),
                        this
                      );
                    },
                  },
                  {
                    key: "callMethod",
                    value: function (t) {
                      var e = t[0],
                        n = Array.prototype.slice.call(t, 1);
                      if (typeof e != "string") {
                        q({ type: "FBQ_NO_METHOD_NAME" });
                        return;
                      }
                      if (typeof this[e] == "function")
                        try {
                          this[e].apply(this, n);
                        } catch (e) {
                          W(e);
                        }
                      else q({ method: e, type: "INVALID_FBQ_METHOD" });
                    },
                  },
                  {
                    key: "getDefaultSendData",
                    value: function (t, n, r, o) {
                      var e = this.getPixel(t),
                        a = {
                          eventData: r || {},
                          eventName: n,
                          pixelId: t,
                          experimentId: o,
                        };
                      return (
                        e &&
                          (e.userData && (a.userData = e.userData),
                          e.agent != null && e.agent !== ""
                            ? (a.set = { agent: e.agent })
                            : this.fbq.agent != null &&
                              this.fbq.agent !== "" &&
                              (a.set = { agent: this.fbq.agent })),
                        a
                      );
                    },
                  },
                  {
                    key: "getOptedInPixels",
                    value: function (t) {
                      var e = this;
                      return this.optIns.listPixelIds(t).map(function (t) {
                        return e.pixelsByID[t];
                      });
                    },
                  },
                  {
                    key: "getPixel",
                    value: function (t) {
                      return this.pixelsByID[t];
                    },
                  },
                  {
                    key: "loadConfig",
                    value: function (r) {
                      if (
                        !(
                          this.fbq.disableConfigLoading === !0 ||
                          Object.prototype.hasOwnProperty.call(
                            this.configsLoaded,
                            r,
                          )
                        ) &&
                        (this.locks.lockConfig(r),
                        !this.fbq.pendingConfigs ||
                          B(this.fbq.pendingConfigs, function (e) {
                            return e === r;
                          }) === !1)
                      ) {
                        var e = n.href,
                          o = t.referrer,
                          a = h(e, o, { google: !0 }),
                          i = g(a),
                          l = "";
                        (i != null && (l = i.hostname),
                          ee({
                            pixelID: r,
                            version: this.VERSION,
                            releaseSegment:
                              this.RELEASE_SEGMENT != null
                                ? this.RELEASE_SEGMENT
                                : "stable",
                            domain: l,
                            noMin: this.fbq._no_min,
                          }));
                      }
                    },
                  },
                  {
                    key: "configLoaded",
                    value: function (t) {
                      var e = this;
                      ((this.configsLoaded[t] = !0),
                        u.trigger(t),
                        this.locks.releaseConfig(t),
                        H(
                          t,
                          this.fbq.version,
                          this.fbq._releaseSegment,
                          this.pluginConfig.get(t, "qualityChecker"),
                        ),
                        t !== j &&
                          (M(this),
                          this.disableAsyncParamBackupTimeout ||
                            setTimeout(function () {
                              w(e);
                            }, K)));
                    },
                  },
                ]);
              })();
              o.exports = te;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFeatureGate", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore");
              function t(e, t) {
                return isNaN(t) ? !1 : n(e, t.toString());
              }
              function n(t, n) {
                var r = e.get(n, "gating");
                if (r == null || r.gatings == null) return !1;
                var o = r.gatings.find(function (e) {
                  return e != null && e.name === t;
                });
                return o != null && o.passed === !0;
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFillParamList", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var r = a.getFbeventsModules("SignalsParamList"),
                i = a.getFbeventsModules("SignalsFBEventsQE"),
                l = a.getFbeventsModules("SignalsFBEventsQEV2"),
                s = a.getFbeventsModules("SignalsFBEventsLogging"),
                u = s.logError,
                c = a.getFbeventsModules("SignalsFBEventsUtils"),
                d = c.each,
                m = e.top !== e;
              function p(o) {
                var a = o.customData,
                  s = o.customParams,
                  u = o.eventName,
                  c = o.id,
                  d = o.piiTranslator,
                  p = o.documentLink,
                  _ = o.referrerLink,
                  f = o.timestamp,
                  g = o.experimentId,
                  h = a != null ? v({}, a) : null,
                  y = n.href;
                Object.prototype.hasOwnProperty.call(o, "documentLink")
                  ? (y = p)
                  : (o.documentLink = y);
                var C = t.referrer;
                Object.prototype.hasOwnProperty.call(o, "referrerLink")
                  ? (C = _)
                  : (o.referrerLink = C);
                var b = new r(d);
                (b.append("id", c),
                  b.append("ev", u),
                  b.append("dl", y),
                  b.append("rl", C),
                  b.append("if", m),
                  b.append("ts", f),
                  b.append("cd", h),
                  b.append("sw", e.screen.width),
                  b.append("sh", e.screen.height),
                  s && b.addRange(s));
                var S = i.get();
                (S != null && b.append("exp", i.getCode(c)),
                  l.isInTest("event_level_no_op_experiment", g));
                var R = c == null ? void 0 : c.toString(),
                  L = l.getExperimentResultParams(g, R);
                return (L != null && L.length > 0 && b.append("expv2", L), b);
              }
              o.exports = p;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsFilterProtectedModeEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.Typed,
                  i = a.getFbeventsModules(
                    "SignalsFBEventsMessageParamsTypedef",
                  ),
                  l = new e(r.tuple([i]));
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsFiredEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsEventPayload");
              function n(e, n) {
                var r = null;
                (e === "GET" ||
                  e === "POST" ||
                  e === "BEACON" ||
                  e === "FETCH") &&
                  (r = e);
                var o = n instanceof t ? n : null;
                return r != null && o != null ? [r, o] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsFireEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logInfo,
                n = a.getFbeventsModules("SignalsFBEventsEvents"),
                r = n.fired,
                i = a.getFbeventsModules("SignalsFBEventsQE"),
                l = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                s = l.NO_OP_EXPERIMENT,
                u = a.getFbeventsModules("SignalsFBEventsQEV2"),
                c = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                d = c.HIGH_FETCH_PRIORITY_IMAGE,
                m = a.getFbeventsModules("signalsFBEventsSendBeacon"),
                p = a.getFbeventsModules("signalsFBEventsSendGET"),
                _ = a.getFbeventsModules("signalsFBEventsSendFormPOST"),
                f = a.getFbeventsModules("SignalsEventPayload"),
                h = a.getFbeventsModules("SignalsFBEventsForkEvent"),
                y = a.getFbeventsModules("SignalsFBEventsGetTimingsEvent"),
                b = a.getFbeventsModules("signalsFBEventsSendFetch"),
                v = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                S = a.getFbeventsModules("signalsFBEventsFillParamList"),
                R = a.getFbeventsModules("SignalsParamList"),
                L = "SubscribedButtonClick";
              function E(e) {
                (h.trigger(e),
                  e.id === "568414510204424" &&
                    t(
                      new Error("Event fired for pixel 568414510204424"),
                      "pixel",
                      e.eventName,
                    ));
                var n = S(e);
                y.trigger(n);
                var r = !v();
                i.isInTest(s);
                var o = n.toPayload();
                k(o, e.experimentId);
              }
              function k(e, t) {
                var n = e.get("ev"),
                  o = !v();
                if (o && n === L && m(e)) {
                  r.trigger("BEACON", e);
                  return;
                }
                var a = e.get("id"),
                  i = u.isInMetaQETreatment(a) || u.isInTest(d, t),
                  l = u.getExperimentResultParams(t, a);
                if (p(e, { highFetchPriority: i, expv2: l })) {
                  r.trigger("GET", e);
                  return;
                }
                if (o && m(e)) {
                  r.trigger("BEACON", e);
                  return;
                }
                (_(e), r.trigger("POST", e));
              }
              function I(e) {
                return T.apply(this, arguments);
              }
              function T() {
                return (
                  (T = C(
                    g().m(function e(t) {
                      var n;
                      return g().w(function (e) {
                        for (;;)
                          switch (e.n) {
                            case 0:
                              return ((e.n = 1), b(t));
                            case 1:
                              return (
                                (n = e.v),
                                r.trigger("FETCH", t),
                                e.a(2, n)
                              );
                          }
                      }, e);
                    }),
                  )),
                  T.apply(this, arguments)
                );
              }
              o.exports = E;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsFireLock", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function (e) {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsUtils"),
                n = t.each,
                r = t.keys,
                i = (function () {
                  function e() {
                    ($(this, e),
                      S(this, "_locks", {}),
                      S(this, "_callbacks", []));
                  }
                  return N(e, [
                    {
                      key: "lock",
                      value: function (t) {
                        this._locks[t] = !0;
                      },
                    },
                    {
                      key: "release",
                      value: function (t) {
                        Object.prototype.hasOwnProperty.call(this._locks, t) &&
                          (delete this._locks[t],
                          r(this._locks).length === 0 &&
                            n(this._callbacks, function (e) {
                              return e(t);
                            }));
                      },
                    },
                    {
                      key: "onUnlocked",
                      value: function (t) {
                        this._callbacks.push(t);
                      },
                    },
                    {
                      key: "isLocked",
                      value: function () {
                        return r(this._locks).length > 0;
                      },
                    },
                    {
                      key: "lockPlugin",
                      value: function (t) {
                        this.lock("plugin:".concat(t));
                      },
                    },
                    {
                      key: "releasePlugin",
                      value: function (t) {
                        this.release("plugin:".concat(t));
                      },
                    },
                    {
                      key: "lockConfig",
                      value: function (t) {
                        this.lock("config:".concat(t));
                      },
                    },
                    {
                      key: "releaseConfig",
                      value: function (t) {
                        this.release("config:".concat(t));
                      },
                    },
                    {
                      key: "lockConsent",
                      value: function () {
                        this.lock("consent");
                      },
                    },
                    {
                      key: "unlockConsent",
                      value: function () {
                        this.release("consent");
                      },
                    },
                  ]);
                })();
              ((e = i), S(i, "global", new e()), (o.exports = i));
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsForkEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                r = a.getFbeventsModules("SignalsFBEventsTyped"),
                i = r.Typed,
                l = r.coerce,
                s = i.objectWithFields({
                  customData: i.allowNull(i.object()),
                  customParams: function (n) {
                    return n instanceof t ? n : void 0;
                  },
                  eventName: i.string(),
                  id: i.string(),
                  piiTranslator: function (t) {
                    return typeof t == "function" ? t : void 0;
                  },
                  documentLink: i.allowNull(i.string()),
                  referrerLink: i.allowNull(i.string()),
                }),
                u = new e(i.tuple([s]));
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGatingConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    gatings: n.arrayOf(
                      n.allowNull(
                        n.objectWithFields({
                          name: n.allowNull(n.string()),
                          passed: n.allowNull(n.boolean()),
                        }),
                      ),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetAutomaticParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.Typed,
                  r = t.coerce;
                function i(e, t) {
                  var o = r(e, n.string()),
                    a = r(t, n.string());
                  return o != null && a != null ? [o, a] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.Typed,
                  i = n.coerce;
                function l(e, n, o, a, l) {
                  var s = i(e, t),
                    u = i(n, r.string()),
                    c = {};
                  o != null && G(o) === "object" && (c = o);
                  var d = a != null && typeof a == "string" ? a : null,
                    m = {};
                  return (
                    l != null && G(l) === "object" && (m = l),
                    s != null && u != null ? [s, u, c, d, m] : null
                  );
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("signalsFBEventsGetIsChrome", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function t() {
                var t = e.chrome,
                  n = e.navigator,
                  r = n.vendor,
                  o = e.opr !== void 0,
                  a = n.userAgent.indexOf("Edg") > -1,
                  i = n.userAgent.match("CriOS");
                return (
                  !i &&
                  t !== null &&
                  t !== void 0 &&
                  r === "Google Inc." &&
                  o === !1 &&
                  a === !1
                );
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "signalsFBEventsGetIsIosInAppBrowser",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                function t() {
                  var t = e.navigator,
                    n = t.userAgent.indexOf("AppleWebKit"),
                    r = t.userAgent.indexOf("FBIOS"),
                    o = t.userAgent.indexOf("Instagram"),
                    a = t.userAgent.indexOf("MessengerLiteForiOS");
                  return n !== null && (r != -1 || o != -1 || a != -1);
                }
                function n(e) {
                  return t();
                }
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetIWLParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsConvertNodeToHTMLElement"),
                  n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  r = a.getFbeventsModules("SignalsFBEventsTyped"),
                  i = r.coerce;
                function l() {
                  for (
                    var e = arguments.length, r = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    r[o] = arguments[o];
                  var a = r[0];
                  if (a == null || G(a) !== "object") return null;
                  var l = a.unsafePixel,
                    s = a.unsafeTarget,
                    u = i(l, n),
                    c = s instanceof Node ? t(s) : null;
                  return u != null && c != null
                    ? [{ pixel: u, target: c }]
                    : null;
                }
                o.exports = new e(l);
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsGetTimingsEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList");
              function n(e) {
                var n = null,
                  r = e instanceof t ? e : null;
                return r != null ? [r] : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsGetValidUrl", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = function (t) {
                if (t == null) return null;
                try {
                  var e = new URL(t);
                  return e;
                } catch (e) {
                  return null;
                }
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ measurementId: t.string() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsGuardrail", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrailTypedef"),
                t = a.getFbeventsModules("SignalsFBEventsExperimentsTypedef"),
                n = a.getFbeventsModules(
                  "SignalsFBEventsLegacyExperimentGroupsTypedef",
                ),
                r = a.getFbeventsModules("SignalsFBEventsTypeVersioning"),
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.coerce,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.reduce,
                c = function () {
                  return Math.random();
                },
                d = {};
              function m(e) {
                var t = e.passRate,
                  n = e.name;
                t != null && (e.passed = c() < t);
              }
              var p = (function () {
                function t() {
                  $(this, t);
                }
                return N(t, [
                  {
                    key: "setGuardrails",
                    value: function (n) {
                      var t = l(n, e);
                      if (t != null) {
                        this._guardrails = t;
                        var r = U(this._guardrails),
                          o;
                        try {
                          for (r.s(); !(o = r.n()).done; ) {
                            var a = o.value;
                            if (a.name != null) {
                              var i = a.name,
                                s = { passed: null },
                                u = v(v({}, s), a);
                              d[i] = u;
                            }
                          }
                        } catch (e) {
                          r.e(e);
                        } finally {
                          r.f();
                        }
                      }
                    },
                  },
                  {
                    key: "eval",
                    value: function (t, n) {
                      var e = d[t];
                      return e
                        ? e.enableForPixels && e.enableForPixels.includes(n)
                          ? !0
                          : e.passed != null
                            ? e.passed
                            : (m(e), e.passed != null ? e.passed : !1)
                        : !1;
                    },
                  },
                  {
                    key: "enable",
                    value: function (t) {
                      var e = d[t];
                      if (e != null) e.passed = !0;
                      else {
                        var n = { passed: !0 };
                        d[t] = n;
                      }
                    },
                  },
                  {
                    key: "disable",
                    value: function (t) {
                      var e = d[t];
                      if (e != null) e.passed = !1;
                      else {
                        var n = { passed: !1 };
                        d[t] = n;
                      }
                    },
                  },
                ]);
              })();
              o.exports = new p();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsGuardrailTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.Typed,
                n = e.coerce,
                r = e.enforce,
                i = t.arrayOf(
                  t.objectWithFields({
                    name: t.allowNull(t.string()),
                    passRate: t.allowNull(t.number()),
                    enableForPixels: t.allowNull(t.arrayOf(t.string())),
                    code: t.allowNull(t.string()),
                    passed: t.allowNull(t.boolean()),
                  }),
                );
              o.exports = i;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsIABPCMAEBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    enableAutoEventId: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsImagePixelOpenBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ enabled: t.boolean() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("signalsFBEventsInjectMethod", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("signalsFBEventsMakeSafe");
              function t(t, n, r) {
                var o = t[n],
                  a = e(r);
                t[n] = function () {
                  for (
                    var e = arguments.length, t = new Array(e), n = 0;
                    n < e;
                    n++
                  )
                    t[n] = arguments[n];
                  var r = o.apply(this, t);
                  return (a.apply(this, t), r);
                };
              }
              o.exports = t;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsIsHostMeta", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = function (t) {
                if (typeof t != "string") return !1;
                var e = t.match(/^(.*\.)*(meta\.com)\.?$/i);
                return e !== null;
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsIsURLFromMeta", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("signalsFBEventsIsHostMeta");
              function t(e) {
                if (typeof e != "string" || e === "") return null;
                try {
                  var t = new URL(e);
                  return t.hostname;
                } catch (e) {
                  return null;
                }
              }
              function n(n, r) {
                var o = t(n),
                  a = t(r),
                  i = o != null && e(o),
                  l = a != null && e(a);
                return i || l;
              }
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsIWLBootStrapEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function n() {
                for (
                  var e = arguments.length, n = new Array(e), r = 0;
                  r < e;
                  r++
                )
                  n[r] = arguments[r];
                var o = n[0];
                if (o == null || G(o) !== "object") return null;
                var a = o.graphToken,
                  i = o.pixelID,
                  l = t(i);
                return a != null && typeof a == "string" && l != null
                  ? [{ graphToken: a, pixelID: l }]
                  : null;
              }
              var r = new e(n);
              o.exports = r;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsJSLoader", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.stringStartsWith,
                i = {
                  CDN_BASE_URL: "https://connect.facebook.net/",
                  SGW_INSTANCE_FRL: "https://gw.conversionsapigateway.com",
                };
              function l() {
                for (
                  var e = t.getElementsByTagName("script"), n = 0;
                  n < e.length;
                  n++
                ) {
                  var r = e[n];
                  if (r && r.src && r.src.indexOf(i.CDN_BASE_URL) !== -1)
                    return r;
                }
                return null;
              }
              var s = u();
              function u() {
                try {
                  if (e.trustedTypes && e.trustedTypes.createPolicy) {
                    var t = e.trustedTypes;
                    return t.createPolicy("connect.facebook.net/fbevents", {
                      createScriptURL: function (t) {
                        var e = r(t, i.CDN_BASE_URL),
                          n = r(t, i.SGW_INSTANCE_FRL);
                        if (!e && !n) throw new Error("Disallowed script URL");
                        return t;
                      },
                    });
                  }
                } catch (e) {}
                return null;
              }
              function c(e) {
                var n = t.createElement("script");
                (s != null ? (n.src = s.createScriptURL(e)) : (n.src = e),
                  (n.async = !0));
                var r = l();
                r && r.parentNode
                  ? r.parentNode.insertBefore(n, r)
                  : t.head && t.head.firstChild && t.head.appendChild(n);
              }
              o.exports = { CONFIG: i, loadJSFile: c };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsLateValidateCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("SignalsFBEventsPixelTypedef");
                function l() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(t, r.tuple([r.string(), r.object(), r.string()]));
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsLegacyExperimentGroupsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = e.enforce,
                  i = a.getFbeventsModules("SignalsFBEventsTypeVersioning"),
                  l = i.upgrade;
                function s(e) {
                  return e != null && G(e) === "object"
                    ? Object.values(e)
                    : null;
                }
                var u = function (n) {
                  var e = Array.isArray(n) ? n : s(n);
                  return r(
                    e,
                    t.arrayOf(
                      t.objectWithFields({
                        code: t.string(),
                        name: t.string(),
                        passRate: t.number(),
                        range: t.tuple([t.number(), t.number()]),
                      }),
                    ),
                  );
                };
                function c(e) {
                  var t = e.name,
                    n = e.code,
                    r = e.range,
                    o = e.passRate;
                  return {
                    allocation: r[1] - r[0],
                    code: n,
                    name: t,
                    passRate: o,
                  };
                }
                o.exports = l(u, function (e) {
                  return e.map(c);
                });
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsLogging", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("signalsFBEventsIsURLFromMeta"),
                r = a.getFbeventsModules("SignalsFBEventsUtils"),
                i = r.isArray,
                l = r.isInstanceOf,
                s = r.map,
                u = a.getFbeventsModules("SignalsParamList"),
                c = a.getFbeventsModules("signalsFBEventsSendGET"),
                d = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                m = !1;
              function p() {
                m = !0;
              }
              var _ = !0;
              function f() {
                _ = !1;
              }
              var g = !1;
              function h() {
                g = !0;
              }
              var y = "console",
                C = "warn",
                b = [];
              function v(t) {
                e[y] && e[y][C] && (e[y][C](t), g && b.push(t));
              }
              var S = !1;
              function R() {
                S = !0;
              }
              function L(e) {
                S || v("[Meta Pixel] - ".concat(e));
              }
              var E = "Meta Pixel Error",
                k = function () {
                  e.postMessage != null && e.postMessage.apply(e, arguments);
                },
                I = {};
              function T(e) {
                switch (e.type) {
                  case "FBQ_NO_METHOD_NAME":
                    return "You must provide an argument to fbq().";
                  case "INVALID_FBQ_METHOD": {
                    var t = e.method;
                    return "\"fbq('".concat(
                      t,
                      "', ...);\" is not a valid fbq command.",
                    );
                  }
                  case "INVALID_FBQ_METHOD_PARAMETER": {
                    var n = e.invalidParamName,
                      r = e.invalidParamValue,
                      o = e.method,
                      a = e.params;
                    return "Call to \"fbq('"
                      .concat(o, "', ")
                      .concat(x(a), ');" with parameter "')
                      .concat(n, '" has an invalid value of "')
                      .concat(D(r), '"');
                  }
                  case "INVALID_PIXEL_ID": {
                    var i = e.pixelID;
                    return "Invalid PixelID: ".concat(i, ".");
                  }
                  case "DUPLICATE_PIXEL_ID": {
                    var l = e.pixelID;
                    return "Duplicate Pixel ID: ".concat(l, ".");
                  }
                  case "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID": {
                    var s = e.metadataValue,
                      u = e.pixelID;
                    return "Trying to set argument "
                      .concat(s, " for uninitialized Pixel ID ")
                      .concat(u, ".");
                  }
                  case "CONFLICTING_VERSIONS":
                    return "Multiple pixels with conflicting versions were detected on this page.";
                  case "MULTIPLE_PIXELS":
                    return "Multiple pixels were detected on this page.";
                  case "UNSUPPORTED_METADATA_ARGUMENT": {
                    var c = e.metadata;
                    return "Unsupported metadata argument: ".concat(c, ".");
                  }
                  case "REQUIRED_PARAM_MISSING": {
                    var d = e.param,
                      m = e.eventName;
                    return "Required parameter '"
                      .concat(d, "' is missing for event '")
                      .concat(m, "'.");
                  }
                  case "INVALID_PARAM": {
                    var p = e.param,
                      _ = e.eventName;
                    return "Parameter '"
                      .concat(p, "' is invalid for event '")
                      .concat(_, "'.");
                  }
                  case "NO_EVENT_NAME":
                    return 'Missing event name. Track events must be logged with an event name fbq("track", eventName)';
                  case "NO_EVENT_ID": {
                    var f = e.pixelID;
                    return "got null or empty eventID from 4th parameter for Pixel ID: ".concat(
                      f,
                      ".",
                    );
                  }
                  case "INVALID_EVENT_ID_FORMAT": {
                    var g = e.pixelID,
                      h = e.eventName;
                    return "Incorrect eventID type. The eventID parameter needs to be a string for Pixel ID: "
                      .concat(g, " for event '")
                      .concat(h);
                  }
                  case "NONSTANDARD_EVENT": {
                    var y = e.eventName;
                    return (
                      "You are sending a non-standard event '".concat(
                        y,
                        "'. ",
                      ) +
                      "The preferred way to send these events is using trackCustom. See 'https://developers.facebook.com/docs/ads-for-websites/pixel-events/#events' for more information."
                    );
                  }
                  case "NEGATIVE_EVENT_PARAM": {
                    var C = e.param,
                      b = e.eventName;
                    return "Parameter '"
                      .concat(C, "' is negative for event '")
                      .concat(b, "'.");
                  }
                  case "PII_INVALID_TYPE": {
                    var v = e.key_type,
                      S = e.key_val;
                    return "An invalid "
                      .concat(v, " was specified for '")
                      .concat(
                        S,
                        "'. This data will not be sent with any events for this Pixel.",
                      );
                  }
                  case "PII_UNHASHED_PII": {
                    var R = e.key;
                    return "The value for the '".concat(
                      R,
                      "' key appeared to be PII. This data will not be sent with any events for this Pixel.",
                    );
                  }
                  case "INVALID_CONSENT_ACTION": {
                    var L = e.action;
                    return "\"fbq('".concat(
                      L,
                      "', ...);\" is not a valid fbq('consent', ...) action. Valid actions are 'revoke' and 'grant'.",
                    );
                  }
                  case "INVALID_JSON_LD": {
                    var E = e.jsonLd;
                    return "Unable to parse JSON-LD tag. Malformed JSON found: '".concat(
                      E,
                      "'.",
                    );
                  }
                  case "SITE_CODELESS_OPT_OUT": {
                    var k = e.pixelID;
                    return "Unable to open Codeless events interface for pixel as the site has opted out. Pixel ID: ".concat(
                      k,
                      ".",
                    );
                  }
                  case "PIXEL_NOT_INITIALIZED": {
                    var I = e.pixelID;
                    return "Pixel ".concat(I, " not found");
                  }
                  case "UNWANTED_CUSTOM_DATA":
                    return "Removed parameters from custom data due to potential violations. Go to Events Manager to learn more.";
                  case "UNWANTED_URL_DATA":
                    return "Removed URL query parameters due to potential violations.";
                  case "UNWANTED_EVENT_NAME":
                    return "Blocked Event due to potential violations.";
                  case "UNVERIFIED_EVENT":
                    return "You are attempting to send an unverified event. The event was suppressed. Go to Events Manager to learn more.";
                  case "RESTRICTED_EVENT":
                    return "You are attempting to send a restricted event. The event was suppressed. Go to Events Manager to learn more.";
                  case "INVALID_PARAM_FORMAT": {
                    var T = e.invalidParamName;
                    return "Invalid parameter format for ".concat(
                      T,
                      ". Please refer https://developers.facebook.com/docs/meta-pixel/reference/ for valid parameter specifications.",
                    );
                  }
                  default:
                    return (
                      F(
                        new Error(
                          "INVALID_USER_ERROR - "
                            .concat(e.type, " - ")
                            .concat(JSON.stringify(e)),
                        ),
                      ),
                      "Invalid User Error."
                    );
                }
              }
              var D = function (t) {
                  if (typeof t == "string") return "'".concat(t, "'");
                  if (typeof t == "undefined") return "undefined";
                  if (t === null) return "null";
                  if (
                    !i(t) &&
                    t.constructor != null &&
                    t.constructor.name != null
                  )
                    return t.constructor.name;
                  try {
                    return JSON.stringify(t) || "undefined";
                  } catch (e) {
                    return "undefined";
                  }
                },
                x = function (t) {
                  return s(t, D).join(", ");
                };
              function $(e) {
                var t = e.toString(),
                  n = null,
                  r = null;
                return (
                  l(e, Error) &&
                    ((n = e.fileName), (r = e.stackTrace || e.stack)),
                  { str: t, fileName: n, stack: r }
                );
              }
              function P() {
                var t = e.fbq.instance.pluginConfig.get(
                  null,
                  "dataProcessingOptions",
                );
                return !!(t != null && t.dataPrivacyOptions.includes("LDU"));
              }
              function N() {
                return e.fbq && e.fbq._releaseSegment
                  ? e.fbq._releaseSegment
                  : "unknown";
              }
              function M() {
                var r = Math.random(),
                  o = N();
                return (
                  (_ && r < 0.01) ||
                  o === "canary" ||
                  n(e.location.href, t.referrer) ||
                  e.fbq.alwaysLogErrors
                );
              }
              function w(t, n, r, o, a) {
                try {
                  if (P() || (e.fbq && e.fbq.disableErrorLogging) || !M())
                    return;
                  var i = new u(null);
                  (o != null && o !== ""
                    ? i.append("p", o)
                    : i.append("p", "pixel"),
                    a != null && a !== "" && i.append("pn", a),
                    i.append("sl", r.toString()),
                    i.append(
                      "v",
                      e.fbq && e.fbq.version ? e.fbq.version : "unknown",
                    ),
                    i.append("e", t.str),
                    t.fileName != null &&
                      t.fileName !== "" &&
                      i.append("f", t.fileName),
                    t.stack != null && t.stack !== "" && i.append("s", t.stack),
                    i.append("ue", n ? "1" : "0"),
                    i.append("rs", N()));
                  var l = i.toPayload();
                  c(l, {
                    url: d.CONFIG.CDN_BASE_URL + "/log/error",
                    ignoreRequestLengthCheck: !0,
                  });
                } catch (e) {}
              }
              function A(t) {
                var n = JSON.stringify(t);
                if (!Object.prototype.hasOwnProperty.call(I, n)) I[n] = !0;
                else return;
                var r = T(t);
                L(r);
                var o = "pixelID" in t && t.pixelID != null ? t.pixelID : null;
                (k(
                  {
                    action: "FB_LOG",
                    logMessage: r,
                    logType: E,
                    error: t,
                    pixelId: o,
                    url: e.location.href,
                  },
                  "*",
                ),
                  w({ str: r, fileName: null, stack: null }, !0, 0));
              }
              function F(e, t, n) {
                if (e instanceof TypeError) {
                  O(e);
                  return;
                }
                (w($(e), !1, 0, t, n), m && L(e.toString()));
              }
              function O(e, t, n) {
                (w($(e), !1, 1, t, n), m && L(e.toString()));
              }
              function B(e, t, n) {
                (w($(e), !1, 2, t, n), m && L(e.toString()));
              }
              function W(e, t, n) {
                (w({ str: e, fileName: null, stack: null }, !1, 2, t, n),
                  m && L(e));
              }
              var q = {
                consoleWarn: v,
                disableAllLogging: R,
                disableSampling: f,
                enableVerboseDebugLogging: p,
                logError: F,
                logUserError: A,
                logWarning: O,
                logInfoString: W,
                logInfo: B,
                enableBufferedLoggedWarnings: h,
                bufferedLoggedWarnings: b,
              };
              o.exports = q;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsMakeSafe", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logError;
              function n(e) {
                return function () {
                  try {
                    for (
                      var n = arguments.length, r = new Array(n), o = 0;
                      o < n;
                      o++
                    )
                      r[o] = arguments[o];
                    e.apply(this, r);
                  } catch (e) {
                    t(e);
                  }
                };
              }
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsMessageParamsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = a.getFbeventsModules("SignalsParamList"),
                  r = t.objectWithFields({
                    customData: t.allowNull(t.object()),
                    customParams: function (t) {
                      return t instanceof n ? t : void 0;
                    },
                    eventName: t.string(),
                    id: t.string(),
                    piiTranslator: function (t) {
                      return typeof t == "function" ? t : void 0;
                    },
                    documentLink: t.allowNull(t.string()),
                    referrerLink: t.allowNull(t.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMetaQEConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    meta_qe: t.objectWithFields({
                      in_treatment: t.boolean(),
                      in_control: t.boolean(),
                    }),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsMicrodataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    waitTimeMs: t.allowNull(
                      t.withValidation({
                        def: t.number(),
                        validators: [
                          function (e) {
                            return e > 0 && e < 1e4;
                          },
                        ],
                      }),
                    ),
                    enablePageHash: t.allowNull(t.boolean()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsMobileAppBridge", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsTelemetry"),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.each,
                i = "fbmq-0.1",
                l = {
                  AddPaymentInfo: "fb_mobile_add_payment_info",
                  AddToCart: "fb_mobile_add_to_cart",
                  AddToWishlist: "fb_mobile_add_to_wishlist",
                  CompleteRegistration: "fb_mobile_complete_registration",
                  InitiateCheckout: "fb_mobile_initiated_checkout",
                  Other: "other",
                  Purchase: "fb_mobile_purchase",
                  Search: "fb_mobile_search",
                  ViewContent: "fb_mobile_content_view",
                },
                s = {
                  content_ids: "fb_content_id",
                  content_type: "fb_content_type",
                  currency: "fb_currency",
                  num_items: "fb_num_items",
                  search_string: "fb_search_string",
                  value: "_valueToSum",
                  contents: "fb_content",
                },
                u = {};
              function c(e) {
                return "fbmq_" + e[1];
              }
              function d(t) {
                if (
                  Object.prototype.hasOwnProperty.call(u, [0]) &&
                  Object.prototype.hasOwnProperty.call(u[t[0]], t[1])
                )
                  return !0;
                var n = e[c(t)],
                  r =
                    n && n.getProtocol.call && n.getProtocol() === i ? n : null;
                return (
                  r !== null &&
                    ((u[t[0]] = u[t[0]] || {}), (u[t[0]][t[1]] = r)),
                  r !== null
                );
              }
              function m(e) {
                var t = [],
                  n = u[e.id] || {};
                for (var r in n)
                  Object.prototype.hasOwnProperty.call(n, r) && t.push(n[r]);
                return t;
              }
              function p(e) {
                return m(e).length > 0;
              }
              function _(e) {
                return Object.prototype.hasOwnProperty.call(l, e) ? l[e] : e;
              }
              function f(e) {
                return Object.prototype.hasOwnProperty.call(s, e) ? s[e] : e;
              }
              function g(e) {
                if (typeof e == "string") return e;
                if (typeof e == "number") return isNaN(e) ? void 0 : e;
                try {
                  return JSON.stringify(e);
                } catch (e) {}
                if (e.toString && e.toString.call) return e.toString();
              }
              function h(e) {
                var t = {};
                if (e != null && G(e) === "object") {
                  for (var n in e)
                    if (Object.prototype.hasOwnProperty.call(e, n)) {
                      var r = g(e[n]);
                      r != null && (t[f(n)] = r);
                    }
                }
                return t;
              }
              var y = 0;
              function C() {
                var e = y;
                ((y = 0), t.logMobileNativeForwarding(e));
              }
              function b(e, t, n) {
                (r(m(e), function (r) {
                  return r.sendEvent(e.id, _(t), JSON.stringify(h(n)));
                }),
                  y++,
                  setTimeout(C, 0));
              }
              o.exports = {
                pixelHasActiveBridge: p,
                registerBridge: d,
                sendEvent: b,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsModuleEncodings", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.coerce,
                r = a.getFbeventsModules(
                  "SignalsFBEventsModuleEncodingsTypedef",
                ),
                i = a.getFbeventsModules("SignalsParamList"),
                l = a.getFbeventsModules("SignalsFBEventsTyped"),
                s = l.Typed,
                u = a.getFbeventsModules("SignalsFBEventsUtils"),
                c = u.map,
                d = u.keys,
                m = u.filter,
                p = a.getFbeventsModules("SignalsFBEventsQE"),
                _ = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                f = (function () {
                  function t() {
                    $(this, t);
                  }
                  return N(t, [
                    {
                      key: "setModuleEncodings",
                      value: function (t) {
                        var e = n(t, r);
                        e != null && (this.moduleEncodings = e);
                      },
                    },
                    {
                      key: "addEncodings",
                      value: function (r) {
                        var t = this;
                        if (
                          !(
                            e.fbq == null ||
                            e.fbq.__fbeventsResolvedModules == null
                          ) &&
                          this.moduleEncodings != null
                        ) {
                          var o = n(
                            e.fbq.__fbeventsResolvedModules,
                            s.object(),
                          );
                          if (o != null) {
                            var a = m(
                              c(d(o), function (e) {
                                return t.moduleEncodings.map != null &&
                                  e in t.moduleEncodings.map
                                  ? t.moduleEncodings.map[e]
                                  : null;
                              }),
                              function (e) {
                                return e != null;
                              },
                            );
                            a.length > 0 &&
                              (this.moduleEncodings.hash != null &&
                                r.append("hme", this.moduleEncodings.hash),
                              r.append("ex_m", a.join(",")));
                          }
                        }
                      },
                    },
                  ]);
                })();
              o.exports = new f();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsModuleEncodingsTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    map: t.allowNull(t.object()),
                    hash: t.allowNull(t.string()),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsNetworkConfig", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = {
                ENDPOINT: "https://www.facebook.com/tr/",
                INSTAGRAM_TRIGGER_ATTRIBUTION: "https://www.instagram.com/tr/",
                GPS_ENDPOINT:
                  "https://www.facebook.com/privacy_sandbox/pixel/register/trigger/",
                TOPICS_API_ENDPOINT:
                  "https://www.facebook.com/privacy_sandbox/topics/registration/",
              };
              o.exports = e;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsNormalizers", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules(
                  "normalizeSignalsFBEventsStringType",
                ),
                t = e.normalize,
                n = e.normalizeState,
                r = e.normalizeCountry;
              o.exports = {
                email: a.getFbeventsModules(
                  "normalizeSignalsFBEventsEmailType",
                ),
                enum: a.getFbeventsModules("normalizeSignalsFBEventsEnumType"),
                postal_code: a.getFbeventsModules(
                  "normalizeSignalsFBEventsPostalCodeType",
                ),
                phone_number: a.getFbeventsModules(
                  "normalizeSignalsFBEventsPhoneNumberType",
                ),
                dob: a.getFbeventsModules("normalizeSignalsFBEventsDOBType"),
                normalize_state: n,
                normalize_country: r,
                string: t,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsOpenBridgeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    endpoints: t.arrayOf(
                      t.objectWithFields({
                        targetDomain: t.allowNull(t.string()),
                        endpoint: t.allowNull(t.string()),
                        usePathCookie: t.allowNull(t.boolean()),
                        fallbackDomain: t.allowNull(t.string()),
                        enrichmentDisabled: t.allowNull(t.boolean()),
                        alwaysRetry: t.allowNull(t.boolean()),
                      }),
                    ),
                    eventsFilter: t.allowNull(
                      t.objectWithFields({
                        filteringMode: t.allowNull(t.string()),
                        eventNames: t.allowNull(t.arrayOf(t.string())),
                      }),
                    ),
                    additionalUserData: t.allowNull(
                      t.objectWithFields({
                        sendFBLoginID: t.allowNull(t.boolean()),
                        useSGWUserData: t.allowNull(t.boolean()),
                      }),
                    ),
                    blockedWebsites: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsOptIn", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.each,
                n = e.filter,
                r = e.keys,
                i = e.some;
              function l(e) {
                t(r(e), function (t) {
                  if (
                    i(e[t], function (t) {
                      return Object.prototype.hasOwnProperty.call(e, t);
                    })
                  )
                    throw new Error(
                      "Circular subOpts are not allowed. " +
                        t +
                        " depends on another subOpt",
                    );
                });
              }
              var s = (function () {
                function e() {
                  var t =
                    arguments.length > 0 && arguments[0] !== void 0
                      ? arguments[0]
                      : {};
                  ($(this, e),
                    S(this, "_opts", {}),
                    (this._subOpts = t),
                    l(this._subOpts));
                }
                return N(e, [
                  {
                    key: "_getOpts",
                    value: function (t) {
                      return [].concat(
                        I(
                          Object.prototype.hasOwnProperty.call(this._subOpts, t)
                            ? this._subOpts[t]
                            : [],
                        ),
                        [t],
                      );
                    },
                  },
                  {
                    key: "_setOpt",
                    value: function (t, n, r) {
                      var e = this._opts[n] || (this._opts[n] = {});
                      e[t] = r;
                    },
                  },
                  {
                    key: "optIn",
                    value: function (n, r) {
                      var e = this,
                        o =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                      return (
                        t(this._getOpts(r), function (t) {
                          var a = o == !0 && e.isOptedOut(n, r);
                          a || e._setOpt(n, t, !0);
                        }),
                        this
                      );
                    },
                  },
                  {
                    key: "optOut",
                    value: function (n, r) {
                      var e = this;
                      return (
                        t(this._getOpts(r), function (t) {
                          return e._setOpt(n, t, !1);
                        }),
                        this
                      );
                    },
                  },
                  {
                    key: "isOptedIn",
                    value: function (t, n) {
                      return this._opts[n] != null && this._opts[n][t] === !0;
                    },
                  },
                  {
                    key: "isOptedOut",
                    value: function (t, n) {
                      return this._opts[n] != null && this._opts[n][t] === !1;
                    },
                  },
                  {
                    key: "listPixelIds",
                    value: function (t) {
                      var e = this._opts[t];
                      return e != null
                        ? n(r(e), function (t) {
                            return e[t] === !0;
                          })
                        : [];
                    },
                  },
                ]);
              })();
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPageStatusEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = t.coerce;
              function i(e) {
                var t = r(e, n.string());
                return t === "active" || t === "inactive" ? [t] : null;
              }
              var l = new e(i);
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPageStatusMonitor", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsFBEventsPageStatusEvent"),
                r = !1;
              function i() {
                r ||
                  (typeof e != "undefined" &&
                    ((r = !0),
                    e.addEventListener("pagehide", function () {
                      n.trigger("inactive");
                    }),
                    typeof t != "undefined" &&
                      t.visibilityState &&
                      t.addEventListener("visibilitychange", function () {
                        t.visibilityState === "hidden"
                          ? n.trigger("inactive")
                          : t.visibilityState === "visible" &&
                            n.trigger("active");
                      })));
              }
              function l(e) {
                return n.listen(e);
              }
              function s(e) {
                return n.listenOnce(e);
              }
              o.exports = {
                initPageStatusMonitor: i,
                subscribeToPageStatus: l,
                subscribeToPageStatusOnce: s,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsParallelFireConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({ target: t.string() });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIAutomatchedEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIConflictingEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                var l = new e(i);
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsPIIInvalidatedEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce;
                function i(e) {
                  var n = r(e, t);
                  return n != null ? [n] : null;
                }
                o.exports = new e(i);
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsPixelCookie", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                t = e.logWarning,
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.getCurrentTime,
                i = "fb",
                l = 4,
                s = 5,
                u = ["AQ", "Ag", "Aw", "BA", "BQ", "Bg"],
                c = 2,
                d = 8,
                m = "__DOT__",
                p = new RegExp(m, "g"),
                _ = /\./g,
                f = "pixel",
                g = "cookie",
                h = (function () {
                  function e(t) {
                    ($(this, e),
                      typeof t == "string"
                        ? this.maybeUpdatePayload(t)
                        : ((this.subdomainIndex = t.subdomainIndex),
                          (this.creationTime = t.creationTime),
                          (this.payload = t.payload),
                          (this.appendix = t.appendix)));
                  }
                  return N(
                    e,
                    [
                      {
                        key: "pack",
                        value: function () {
                          var e =
                              this.payload != null
                                ? this.payload.replace(_, m)
                                : "",
                            t = [
                              i,
                              this.subdomainIndex,
                              this.creationTime,
                              e,
                              this.appendix,
                            ].filter(function (e) {
                              return e != null;
                            });
                          return t.join(".");
                        },
                      },
                      {
                        key: "maybeUpdatePayload",
                        value: function (t) {
                          (this.payload === null || this.payload !== t) &&
                            ((this.payload = t), (this.creationTime = r()));
                        },
                      },
                    ],
                    [
                      {
                        key: "unpack",
                        value: function (r) {
                          try {
                            var n = r.split(".");
                            if (n.length !== l && n.length !== s) return null;
                            var o = R(n, 5),
                              a = o[0],
                              m = o[1],
                              _ = o[2],
                              h = o[3],
                              y = o[4];
                            if (y != null) {
                              if (y.length !== c && y.length !== d)
                                throw new Error("Illegal appendix length");
                              if (y.length === c && !u.includes(y))
                                throw new Error("Illegal appendix");
                            }
                            if (a !== i)
                              if (a.includes(i))
                                t(
                                  new Error(
                                    "Unexpected version number '".concat(
                                      n[0],
                                      "'",
                                    ),
                                  ),
                                  f,
                                  g,
                                );
                              else
                                throw new Error(
                                  "Unexpected version number '".concat(
                                    n[0],
                                    "'",
                                  ),
                                );
                            var C = parseInt(m, 10);
                            if (isNaN(C))
                              throw new Error(
                                "Illegal subdomain index '".concat(n[1], "'"),
                              );
                            var b = parseInt(_, 10);
                            if (isNaN(b))
                              throw new Error(
                                "Illegal creation time '".concat(n[2], "'"),
                              );
                            if (h == null || h === "")
                              throw new Error("Empty cookie payload");
                            var v = h.replace(p, ".");
                            return new e({
                              creationTime: b,
                              payload: v,
                              subdomainIndex: C,
                              appendix: y,
                            });
                          } catch (e) {
                            return (t(e, f, g), null);
                          }
                        },
                      },
                    ],
                  );
                })();
              o.exports = h;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelPIISchema", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              o.exports = {
                default: {
                  type: "string",
                  typeParams: { lowercase: !0, strip: "whitespace_only" },
                },
                ph: { type: "phone_number" },
                em: { type: "email" },
                fn: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "whitespace_and_punctuation",
                  },
                },
                ln: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "whitespace_and_punctuation",
                  },
                },
                zp: { type: "postal_code" },
                ct: {
                  type: "string",
                  typeParams: {
                    lowercase: !0,
                    strip: "all_non_latin_alpha_numeric",
                    test: "^[a-z]+",
                  },
                },
                st: { type: "normalize_state" },
                country: { type: "normalize_country" },
                db: { type: "dob" },
                dob: { type: "date" },
                doby: { type: "string", typeParams: { test: "^[0-9]{4,4}$" } },
                ge: {
                  type: "enum",
                  typeParams: { lowercase: !0, options: ["f", "m"] },
                },
                dobm: {
                  type: "string",
                  typeParams: {
                    test: "^(0?[1-9]|1[012])$|^jan|^feb|^mar|^apr|^may|^jun|^jul|^aug|^sep|^oct|^nov|^dec",
                  },
                },
                dobd: {
                  type: "string",
                  typeParams: { test: "^(([0]?[1-9])|([1-2][0-9])|(3[01]))$" },
                },
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelQueueState", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                r = e.logWarning,
                i = a.getFbeventsModules("PixelQueue"),
                l = a.getFbeventsModules("SignalsEventPayload"),
                s = a.getFbeventsModules("signalsFBEventsSendGET"),
                u = a.getFbeventsModules("signalsFBEventsSendFetch"),
                c = 0xb3734563ab77,
                d = String(c),
                m = null,
                p = null,
                _ = null;
              function f(e) {
                m == null && (m = new i(e));
              }
              function g(e) {
                if (e == null) return null;
                if (Array.isArray(e)) return e;
                if (typeof e.length != "number") return null;
                var t = [];
                try {
                  for (var n = 0; n < e.length; n++) t.push(e[n]);
                } catch (e) {
                  return (r(e, "pixel", "qualityChecker"), null);
                }
                return t;
              }
              function h(e) {
                var t = U(e),
                  n;
                try {
                  for (t.s(); !(n = t.n()).done; ) {
                    var r = n.value;
                    y(r);
                  }
                } catch (e) {
                  t.e(e);
                } finally {
                  t.f();
                }
              }
              function y(e) {
                var t = g(e);
                if (t != null) {
                  if (m == null) {
                    try {
                      if (t.length > 1 && t[0] === "init") {
                        var n = t[1];
                        ((typeof n == "number" && n === c) ||
                          (typeof n == "string" && n === d)) &&
                          f("fbevents");
                      }
                    } catch (e) {
                      r(e, "pixel", "qualityChecker");
                    }
                    return;
                  }
                  try {
                    C(t);
                  } catch (e) {
                    r(e, "pixel", "qualityChecker");
                  }
                }
              }
              function C(e) {
                if (m != null) {
                  var t = m;
                  if (e[0] === "track" && !(e.length < 3)) {
                    var n = e[1],
                      r = e[2],
                      o = e[3];
                    if (
                      typeof n == "string" &&
                      !(r == null || G(r) !== "object")
                    ) {
                      var a = { eventName: n, params: v({}, r), eventData: o };
                      t.enqueue(a);
                    }
                  }
                }
              }
              function b(e, t, n, r) {
                var o;
                if (e === d) {
                  ((p = t), (_ = n));
                  var a =
                    (o = r == null ? void 0 : r.enabled) !== null &&
                    o !== void 0
                      ? o
                      : !1;
                  S(a);
                }
              }
              function S(e) {
                if (m != null) {
                  var t = m;
                  try {
                    e
                      ? t.setHandler(L())
                      : (t.disableStorage(), t.setHandler(R()));
                  } catch (e) {
                    r(e, "pixel", "qualityChecker");
                  }
                }
              }
              function R() {
                return function (e) {
                  for (var t; (t = e.dequeueItem()); )
                    (function (t) {
                      e.markItemAsCompleted(t);
                    })(t);
                };
              }
              function L() {
                var e = n.href,
                  r = t.referrer;
                return function (t) {
                  for (var n; (n = t.dequeueItem()); )
                    (function (n) {
                      (E(t, n, e, r), k(t, n, e, r), I(t, n, e, r));
                    })(n);
                };
              }
              function E(e, t, n, r) {
                var o,
                  a = t.item,
                  i = a.eventName,
                  l = a.params,
                  s = a.eventData,
                  c = T(
                    i,
                    (o = s == null ? void 0 : s.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r,
                  );
                (c.append("qttag", "z0"),
                  u(c)
                    .then(function (n) {
                      e.markItemAsCompleted(t);
                    })
                    .catch(function (n) {
                      e.markItemAsFailed(t);
                    }));
              }
              function k(e, t, n, r) {
                var o,
                  a = t.item,
                  i = a.eventName,
                  l = a.eventData,
                  u = T(
                    i,
                    (o = l == null ? void 0 : l.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r,
                  );
                (u.append("qttag", "z1"), s(u));
              }
              function I(e, t, n, r) {
                var o,
                  a = t.item,
                  i = a.eventName,
                  l = a.eventData,
                  u = T(
                    i,
                    (o = l == null ? void 0 : l.eventID) !== null &&
                      o !== void 0
                      ? o
                      : "",
                    n,
                    r,
                  );
                (u.append("qttag", "z2"), s(u, { highFetchPriority: !0 }));
              }
              function T(e, t, n, r) {
                var o = new l();
                return (
                  o.append("id", d),
                  o.append("ev", e),
                  o.append("eid", t),
                  o.append("dl", n),
                  o.append("rl", r),
                  o.append("a", "fbq_js"),
                  o.append("ts", String(new Date().valueOf())),
                  o.append("v", p != null ? p : "0.0.404"),
                  _ != null && o.append("r", _),
                  o
                );
              }
              o.exports = {
                tryInitQueue: h,
                tryEnqueueCommand: y,
                trySetQueueHandler: b,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPixelTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.Typed,
                n = t.objectWithFields({
                  eventCount: t.number(),
                  id: t.fbid(),
                  userData: t.mapOf(t.string()),
                  userDataFormFields: t.mapOf(t.string()),
                });
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPlugin", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = N(function e(t) {
                ($(this, e),
                  S(this, "__fbEventsPlugin", 1),
                  (this.plugin = t),
                  (this.__fbEventsPlugin = 1));
              });
              o.exports = e;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPluginLoadedEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
              function t(e) {
                var t = e != null && typeof e == "string" ? e : null;
                return t != null ? [t] : null;
              }
              o.exports = new e(t);
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsPluginManager", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                t = a.getFbeventsModules("SignalsFBEventsEvents"),
                n = t.pluginLoaded,
                r = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logWarning,
                s = a.getFbeventsModules("SignalsFBEventsPlugin");
              function u(e) {
                return "fbevents.plugins.".concat(e);
              }
              function c(e, t) {
                if (e === "fbevents") return new s(function () {});
                if (t instanceof s) return t;
                if (t == null || G(t) !== "object")
                  return (
                    l(new Error("Invalid pluginAPI registered ".concat(e))),
                    new s(function () {})
                  );
                var n = t.__fbEventsPlugin,
                  r = t.plugin;
                return n !== 1 || typeof r != "function"
                  ? (l(new Error("Invalid plugin registered ".concat(e))),
                    new s(function () {}))
                  : new s(r);
              }
              var d = (function () {
                function t(e, n) {
                  ($(this, t),
                    S(this, "_loadedPlugins", {}),
                    (this._instance = e),
                    (this._lock = n));
                }
                return N(t, [
                  {
                    key: "registerPlugin",
                    value: function (r, o) {
                      Object.prototype.hasOwnProperty.call(
                        this._loadedPlugins,
                        r,
                      ) ||
                        ((this._loadedPlugins[r] = c(r, o)),
                        this._loadedPlugins[r].plugin(a, this._instance, e),
                        n.trigger(r),
                        this._lock.releasePlugin(r));
                    },
                  },
                  {
                    key: "loadPlugin",
                    value: function (t) {
                      if (/^[a-zA-Z]\w+$/.test(t) === !1)
                        throw new Error("Invalid plugin name: ".concat(t));
                      var e = u(t);
                      if (this._loadedPlugins[e]) return !0;
                      if (a.fbIsModuleLoaded(e))
                        return (
                          this.registerPlugin(e, a.getFbeventsModules(e)),
                          !0
                        );
                      var n = ""
                        .concat(r.CONFIG.CDN_BASE_URL, "signals/plugins/")
                        .concat(t, ".js?v=")
                        .concat(a.version);
                      return this._loadedPlugins[e]
                        ? !1
                        : (this._lock.lockPlugin(e), r.loadJSFile(n), !0);
                    },
                  },
                ]);
              })();
              o.exports = d;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsProcessCCRulesEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsParamList");
                function n(e, n) {
                  var r = e instanceof t ? e : null,
                    o = G(n) === "object" ? v({}, n) : null;
                  return r != null ? [r, o] : null;
                }
                var r = new e(n);
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProcessEmailAddress",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  t = e.looksLikeHashed,
                  n = a.getFbeventsModules("SignalsFBEventsLogging"),
                  r = n.logError,
                  i = a.getFbeventsModules("SignalsFBEventsUtils"),
                  l = i.each,
                  s = i.keys,
                  u = a.getFbeventsModules("SignalsFBEventsValidationUtils"),
                  c = u.trim,
                  d = a.getFbeventsModules("SignalsFBEventsQE"),
                  m = ["em", "email"];
                function p(e) {
                  try {
                    if (e == null || G(e) !== "object") return e;
                    l(s(e), function (n) {
                      var r = e[n];
                      if (
                        !t(r) &&
                        !(
                          (typeof m.includes == "function" && !m.includes(n)) ||
                          r == null ||
                          typeof r != "string"
                        )
                      ) {
                        var o = c(r);
                        o.length !== 0 &&
                          (o[o.length - 1] === "," &&
                            (o = o.slice(0, o.length - 1)),
                          (e[n] = o));
                      }
                    });
                  } catch (e) {
                    ((e.message = "[NormalizeEmailAddress]: " + e.message),
                      r(e));
                  }
                  return e;
                }
                o.exports = p;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProhibitedPixelConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    lockWebpage: n.allowNull(n.boolean()),
                    blockReason: n.allowNull(n.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProhibitedSourcesTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    prohibitedSources: t.arrayOf(
                      t.objectWithFields({ domain: t.allowNull(t.string()) }),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsProtectedDataModeConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    standardParams: t.mapOf(t.boolean()),
                    disableAM: t.allowNull(t.boolean()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsQE", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                t = a.getFbeventsModules("SignalsFBEventsExperimentsTypedef"),
                n = a.getFbeventsModules(
                  "SignalsFBEventsLegacyExperimentGroupsTypedef",
                ),
                r = a.getFbeventsModules("SignalsFBEventsTypeVersioning"),
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.coerce,
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.reduce,
                c = a.getFbeventsModules("SignalsFBEventsLogging"),
                d = c.logWarning,
                m = function () {
                  return Math.random();
                },
                p = "pixel",
                _ = "FBEventsQE";
              function f(e) {
                for (
                  var t = u(
                      e,
                      function (e, t, n) {
                        if (n === 0) return (e.push([0, t.allocation]), e);
                        var r = R(e[n - 1], 2),
                          o = r[0],
                          a = r[1];
                        return (e.push([a, a + t.allocation]), e);
                      },
                      [],
                    ),
                    n = m(),
                    r = 0;
                  r < e.length;
                  r++
                ) {
                  var o = e[r],
                    a = o.passRate,
                    i = o.code,
                    l = o.name,
                    s = R(t[r], 2),
                    c = s[0],
                    d = s[1];
                  if (n >= c && n < d) {
                    var p = m() < a;
                    return { code: i, isInExperimentGroup: p, name: l };
                  }
                }
                return null;
              }
              var g = (function () {
                function o() {
                  ($(this, o),
                    S(this, "_result", null),
                    S(this, "_hasRolled", !1),
                    S(this, "_isExposed", !1),
                    S(this, "CONTROL", "CONTROL"),
                    S(this, "TEST", "TEST"),
                    S(this, "UNASSIGNED", "UNASSIGNED"));
                }
                return N(o, [
                  {
                    key: "setExperiments",
                    value: function (o) {
                      var e = l(o, r.waterfall([n, t]));
                      e != null &&
                        ((this._experiments = e),
                        (this._hasRolled = !1),
                        (this._result = null),
                        (this._isExposed = !1));
                    },
                  },
                  {
                    key: "get",
                    value: function (t) {
                      if (!this._hasRolled) {
                        var e = this._experiments;
                        if (e == null) return null;
                        var n = f(e);
                        (n != null && (this._result = n),
                          (this._hasRolled = !0));
                      }
                      return t == null || t === ""
                        ? this._result
                        : this._result != null && this._result.name === t
                          ? this._result
                          : null;
                    },
                  },
                  {
                    key: "getCode",
                    value: function (t) {
                      try {
                        if (t != null && t.toString() === "3615875995349958")
                          return "m1";
                      } catch (t) {
                        var e = new Error("QE override failed");
                        d(e, p, _);
                      }
                      var n = this.get();
                      if (n == null) return "";
                      var r = 0;
                      return (
                        n.isInExperimentGroup && (r |= 1),
                        this._isExposed && (r |= 2),
                        n.code + r.toString()
                      );
                    },
                  },
                  {
                    key: "getAssignmentFor",
                    value: function (t) {
                      var e = this.get();
                      return e != null && e.name === t
                        ? ((this._isExposed = !0),
                          e.isInExperimentGroup ? this.TEST : this.CONTROL)
                        : this.UNASSIGNED;
                    },
                  },
                  {
                    key: "isInTest",
                    value: function (n) {
                      if (e.eval("release_" + n)) return !0;
                      var t = this.get();
                      return t != null && t.name === n
                        ? ((this._isExposed = !0), t.isInExperimentGroup)
                        : !1;
                    },
                  },
                  {
                    key: "clearExposure",
                    value: function () {
                      this._isExposed = !1;
                    },
                  },
                ]);
              })();
              o.exports = new g();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsQEV2", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                t = a.getFbeventsModules("SignalsFBEventsExperimentsV2Typedef"),
                n = a.getFbeventsModules("SignalsFBEventsTyped"),
                r = n.coerce,
                i = a.getFbeventsModules("SignalsFBEventsUtils"),
                l = i.reduce,
                s = function () {
                  return Math.random();
                },
                u = "pixel",
                c = "FBEventsQEV2",
                d = "meta_qe";
              function m(e) {
                for (var t = s(), n = 0, r = 0, o = 0; o < e.length; o++) {
                  var a = e[o],
                    i = a.passRate,
                    l = a.code,
                    u = a.name,
                    c = a.allocation;
                  if (((r = n + c), t >= n && t < r)) {
                    var d = s() < i;
                    return { isExposed: !1, isInTest: d, code: l, name: u };
                  }
                  n = r;
                }
                return null;
              }
              var p = (function () {
                function n() {
                  ($(this, n),
                    S(this, "_experiments", []),
                    S(
                      this,
                      "_pageLoadLevelEvaluationExperimentResults",
                      new Map(),
                    ),
                    S(
                      this,
                      "_eventLevelEvaluationExperimentResults",
                      new Map(),
                    ),
                    S(this, "_metaQEExposed", !1),
                    S(this, "PAGE_LOAD_LEVEL", "PAGE_LOAD_LEVEL"),
                    S(this, "EVENT_LEVEL", "EVENT_LEVEL"));
                }
                return N(n, [
                  {
                    key: "_getMetaQEConfig",
                    value: function (n) {
                      return e.get(n, "metaQE");
                    },
                  },
                  {
                    key: "isInMetaQETreatment",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      return e != null
                        ? ((this._metaQEExposed = !0), e.meta_qe.in_treatment)
                        : !1;
                    },
                  },
                  {
                    key: "isInMetaQEControl",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      return e != null
                        ? ((this._metaQEExposed = !0), e.meta_qe.in_control)
                        : !1;
                    },
                  },
                  {
                    key: "setExperiments",
                    value: function (n) {
                      var e = r(n, t);
                      e != null && (this._experiments = e);
                    },
                  },
                  {
                    key: "_reset",
                    value: function () {
                      (this._pageLoadLevelEvaluationExperimentResults.clear(),
                        this._eventLevelEvaluationExperimentResults.clear(),
                        (this._metaQEExposed = !1));
                    },
                  },
                  {
                    key: "clearExposure",
                    value: function (t) {
                      this._eventLevelEvaluationExperimentResults.has(t) &&
                        this._eventLevelEvaluationExperimentResults.delete(t);
                    },
                  },
                  {
                    key: "isInTest",
                    value: function (t, n) {
                      var e = this._getExperimentByName(t);
                      if (e == null) return !1;
                      var r = this._getExperimentResultForUniverse(
                        e.universe,
                        e.evaluationType,
                        n,
                      );
                      return r == null || r.name !== t
                        ? !1
                        : ((r.isExposed = !0), r.isInTest);
                    },
                  },
                  {
                    key: "isInTestPageLoadLevelExperiment",
                    value: function (t) {
                      var e = this._getExperimentByName(t);
                      if (e == null || e.evaluationType != this.PAGE_LOAD_LEVEL)
                        return !1;
                      var n = this._getPageLoadLevelExperimentResult(
                        e.universe,
                      );
                      return n == null || n.name !== t
                        ? !1
                        : ((n.isExposed = !0), n.isInTest);
                    },
                  },
                  {
                    key: "getExperimentResultParams",
                    value: function (t, n) {
                      for (
                        var e = [], r = 0;
                        r < this._experiments.length;
                        r++
                      ) {
                        var o = this._experiments[r],
                          a = this._getExperimentResultForUniverse(
                            o.universe,
                            o.evaluationType,
                            t,
                          );
                        if (a != null) {
                          var i = this._getParamByResult(a);
                          e.includes(i) || e.push(i);
                        }
                      }
                      var l = this.getMetaQEParam(n);
                      return (l != null && !e.includes(l) && e.push(l), e);
                    },
                  },
                  {
                    key: "getMetaQEParam",
                    value: function (t) {
                      var e = this._getMetaQEConfig(t);
                      if (
                        e == null ||
                        (!e.meta_qe.in_treatment && !e.meta_qe.in_control)
                      )
                        return null;
                      var n = this._getExperimentByName(d);
                      if (n == null) return null;
                      var r = 0;
                      return (
                        e.meta_qe.in_treatment && (r |= 1),
                        this._metaQEExposed && (r |= 2),
                        n.code + r.toString()
                      );
                    },
                  },
                  {
                    key: "_getParamByResult",
                    value: function (t) {
                      var e = 0;
                      return (
                        t.isInTest && (e |= 1),
                        t.isExposed && (e |= 2),
                        t.code + e.toString()
                      );
                    },
                  },
                  {
                    key: "_getExperimentResultForUniverse",
                    value: function (t, n, r) {
                      return n === this.PAGE_LOAD_LEVEL
                        ? this._getPageLoadLevelExperimentResult(t)
                        : this._getEventLevelExperimentResult(t, r);
                    },
                  },
                  {
                    key: "_getPageLoadLevelExperimentResult",
                    value: function (t) {
                      if (this._pageLoadLevelEvaluationExperimentResults.has(t))
                        return this._pageLoadLevelEvaluationExperimentResults.get(
                          t,
                        );
                      var e = this._getExperimentsByUniverse(t),
                        n = m(e);
                      return (
                        this._pageLoadLevelEvaluationExperimentResults.set(
                          t,
                          n,
                        ),
                        n
                      );
                    },
                  },
                  {
                    key: "_getEventLevelExperimentResult",
                    value: function (t, n) {
                      if (this._eventLevelEvaluationExperimentResults.has(n)) {
                        var e =
                          this._eventLevelEvaluationExperimentResults.get(n);
                        if (e && e.has(t)) return e.get(t);
                      }
                      var r = this._getExperimentsByUniverse(t),
                        o = m(r);
                      this._eventLevelEvaluationExperimentResults.has(n) ||
                        this._eventLevelEvaluationExperimentResults.set(
                          n,
                          new Map(),
                        );
                      var a =
                        this._eventLevelEvaluationExperimentResults.get(n);
                      return (a && a.set(t, o), o);
                    },
                  },
                  {
                    key: "_getExperimentByName",
                    value: function (t) {
                      for (var e = 0; e < this._experiments.length; e++) {
                        var n = this._experiments[e];
                        if (n.name === t) return n;
                      }
                      return null;
                    },
                  },
                  {
                    key: "_getExperimentsByUniverse",
                    value: function (t) {
                      for (
                        var e = [], n = 0;
                        n < this._experiments.length;
                        n++
                      ) {
                        var r = this._experiments[n];
                        r.universe === t && e.push(r);
                      }
                      return e;
                    },
                  },
                ]);
              })();
              o.exports = new p();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsQualityCheckerConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({ enabled: n.boolean() });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "signalsFBEventsResolveLegacyArguments",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e = "report";
                function t(e) {
                  var t = R(e, 1),
                    n = t[0];
                  return e.length === 1 && Array.isArray(n)
                    ? { args: n, isLegacySyntax: !0 }
                    : { args: e, isLegacySyntax: !1 };
                }
                function n(t) {
                  var n = R(t, 2),
                    r = n[0],
                    o = n[1];
                  if (typeof r == "string" && r.slice(0, e.length) === e) {
                    var a = r.slice(e.length);
                    return a === "CustomEvent"
                      ? (o != null &&
                          G(o) === "object" &&
                          typeof o.event == "string" &&
                          (a = o.event),
                        ["trackCustom", a].concat(t.slice(1)))
                      : ["track", a].concat(t.slice(1));
                  }
                  return t;
                }
                function r(e) {
                  var r = t(e),
                    o = r.args,
                    a = r.isLegacySyntax,
                    i = n(o);
                  return { args: i, isLegacySyntax: a };
                }
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsResolveLink", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsGetValidUrl"),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.each,
                i = n.keys;
              function l(n, r, o) {
                var a = e.top !== e;
                if (!a) {
                  var l;
                  return ((l = n == null ? void 0 : n.length) !== null &&
                  l !== void 0
                    ? l
                    : 0) > 0
                    ? n
                    : r;
                }
                if (!r || r.length === 0) return n;
                if (o != null) {
                  var s = t(r);
                  if (!s) return n;
                  var u = s.origin,
                    c = i(o).some(function (e) {
                      return e != null && u.includes(e);
                    });
                  if (c) return n;
                }
                return r;
              }
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsRestrictedDomainsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    restrictedDomains: t.allowNull(
                      t.arrayOf(t.allowNull(t.string())),
                    ),
                    blacklistedIframeReferrers: t.allowNull(
                      t.mapOf(t.boolean()),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("signalsFBEventsSendBeacon", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsQE"),
                n = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                r = a.getFbeventsModules("SignalsFBEventsLogging"),
                i = r.logWarning,
                l = a.getFbeventsModules("SignalsEventPayload");
              function s(t, r) {
                try {
                  if (!e.navigator || !e.navigator.sendBeacon) return !1;
                  var o = r || {},
                    a = o.url,
                    l = a === void 0 ? n.ENDPOINT : a;
                  return (
                    t.set("rqm", "SB"),
                    e.navigator.sendBeacon(l, t.toFormData())
                  );
                } catch (e) {
                  return (
                    e instanceof Error &&
                      i(new Error("[SendBeacon]:" + e.message)),
                    !1
                  );
                }
              }
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsSendCloudbridgeEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.Typed,
                  i = a.getFbeventsModules(
                    "SignalsFBEventsMessageParamsTypedef",
                  ),
                  l = new e(r.tuple([i]));
                o.exports = l;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("signalsFBEventsSendEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsEvents"),
                n = t.setEventId,
                r = a.getFbeventsModules("SignalsParamList"),
                i = a.getFbeventsModules("SignalsFBEventsProcessCCRulesEvent"),
                l = a.getFbeventsModules(
                  "SignalsFBEventsLateValidateCustomParametersEvent",
                ),
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.each,
                c = s.keys,
                d = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                m = a.getFbeventsModules("SignalsFBEventsSetFilteredEventName"),
                p = a.getFbeventsModules("SignalsFBEventsAsyncParamUtils"),
                _ = p.appendAsyncParamsAndSendEvent,
                f = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                g = a.getFbeventsModules("signalsFBEventsFillParamList"),
                h = e.top !== e;
              function y(e, t) {
                ((e.customData = v({}, e.customData)),
                  (e.timestamp = new Date().valueOf()));
                var o = null;
                if (
                  (e.customParams != null &&
                    (o = f.eval("multi_eid_fix")
                      ? e.customParams.getEventId()
                      : e.customParams.get("eid")),
                  o == null || o === "")
                ) {
                  e.customParams = e.customParams || new r();
                  var a = e.customParams;
                  e.id != null && n.trigger(String(e.id), a, e.eventName);
                }
                var s = i.trigger(g(e), e.customData);
                s != null &&
                  u(s, function (t) {
                    t != null &&
                      u(c(t), function (n) {
                        ((e.customParams = e.customParams || new r()),
                          e.customParams.append(n, t[n]));
                      });
                  });
                var d = l.trigger(
                  String(e.id),
                  e.customData || {},
                  e.eventName,
                );
                d &&
                  u(d, function (t) {
                    t &&
                      u(c(t), function (n) {
                        ((e.customParams = e.customParams || new r()),
                          e.customParams.append(n, t[n]));
                      });
                  });
                var p = m.trigger(g(e));
                (p != null &&
                  u(p, function (t) {
                    t != null &&
                      u(c(t), function (n) {
                        ((e.customParams = e.customParams || new r()),
                          e.customParams.append(n, t[n]));
                      });
                  }),
                  t.asyncParamPromisesAllSettled
                    ? _(t, e)
                    : t.eventQueue.push(e));
              }
              o.exports = { sendEvent: y };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSendEventEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                r = a.getFbeventsModules("SignalsFBEventsTyped"),
                i = r.Typed,
                l = r.coerce,
                s = i.objectWithFields({
                  customData: i.allowNull(i.object()),
                  customParams: function (n) {
                    return n instanceof t ? n : void 0;
                  },
                  eventName: i.string(),
                  id: i.string(),
                  piiTranslator: function (t) {
                    return typeof t == "function" ? t : void 0;
                  },
                  documentLink: i.allowNull(i.string()),
                  referrerLink: i.allowNull(i.string()),
                }),
                u = new e(i.tuple([s]));
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendEventImpl", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                r = a.getFbeventsModules("SignalsFBEventsSendCloudbridgeEvent"),
                i = a.getFbeventsModules(
                  "SignalsFBEventsFilterProtectedModeEvent",
                ),
                l = a.getFbeventsModules(
                  "SignalsFBEventsGetAutomaticParametersEvent",
                ),
                s = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = s.some,
                c = a.getFbeventsModules("signalsFBEventsFireEvent"),
                d = a.getFbeventsModules("SignalsFBEventsUtils"),
                m = d.each,
                p = d.keys,
                _ = a.getFbeventsModules("SignalsParamList"),
                f = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                g = a.getFbeventsModules("SignalsPixelCookieUtils"),
                h = g.writeNewCookie,
                y = g.CLICKTHROUGH_COOKIE_PARAM,
                C = g.NINETY_DAYS_IN_MS,
                b = "_fbleid",
                v = 10080 * 60 * 1e3,
                S = a.getFbeventsModules("generateEventId");
              function R(e, t) {
                if (
                  e.id != null &&
                  f("offsite_clo_beta_event_id_coverage", e.id) &&
                  e.eventName === "Lead" &&
                  e.customParams != null
                ) {
                  var n = e.customParams.get(y),
                    r =
                      e.customParams != null ? e.customParams.get("eid") : null;
                  if (n != null && n.trim() != "") {
                    var o =
                      r != null ? r : S((t && t.VERSION) || "undefined", "LCP");
                    (r == null &&
                      e.customParams != null &&
                      e.customParams.append("eid", o),
                      h(b, o, v));
                  }
                }
              }
              function L(e) {
                var t = l.trigger(String(e.id), e.eventName);
                t != null &&
                  m(t, function (t) {
                    t != null &&
                      m(p(t), function (n) {
                        ((e.customParams = e.customParams || new _()),
                          e.customParams.append(n, t[n]));
                      });
                  });
              }
              function E(e) {
                if (e.customParams != null) {
                  var r = e.documentLink;
                  r !== n.href && e.customParams.append("dlc", "1");
                  var o = e.referrerLink;
                  o !== t.referrer && e.customParams.append("rlc", "1");
                }
              }
              function k(t, n) {
                var o = e.trigger(t);
                if (
                  !u(o, function (e) {
                    return e;
                  })
                ) {
                  (R(t, n), L(t), i.trigger(t), E(t));
                  var a = r.trigger(t);
                  if (
                    !u(a, function (e) {
                      return e;
                    })
                  ) {
                    var l =
                      Object.prototype.hasOwnProperty.call(t, "customData") &&
                      typeof t.customData != "undefined" &&
                      t.customData !== null;
                    (l || (t.customData = {}), c(t));
                  }
                }
              }
              o.exports = k;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendFetch", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                n = a.getFbeventsModules("SignalsEventPayload"),
                r = a.getFbeventsModules("SignalsFBEventsLogging"),
                i = r.logError,
                l = 2048,
                s = 8e3;
              function u(t) {
                var n =
                  typeof e != "undefined" &&
                  typeof e.DOMException != "undefined";
                if (n && t instanceof e.DOMException) {
                  var r = t.name;
                  return r === "AbortError"
                    ? "abort"
                    : r === "SecurityError"
                      ? "security"
                      : "unknown";
                }
                if (t instanceof TypeError) return "network";
                if (t instanceof Error) {
                  var o = t.name;
                  if (o === "AbortError") return "abort";
                  if (o === "SecurityError") return "security";
                  if (o === "TypeError") return "network";
                }
                return "unknown";
              }
              function c() {
                return typeof e != "undefined" && "AbortController" in e
                  ? new e.AbortController()
                  : { signal: void 0, abort: function () {} };
              }
              function d(e, t) {
                return m.apply(this, arguments);
              }
              function m() {
                return (
                  (m = C(
                    g().m(function n(r, o) {
                      var a, i, d, m, p, _, f, h, y, C, b, S, R, L;
                      return g().w(
                        function (n) {
                          for (;;)
                            switch ((n.p = n.n)) {
                              case 0:
                                return (
                                  (a = o != null ? o : {}),
                                  (i = a.url),
                                  (d = i === void 0 ? t.ENDPOINT : i),
                                  r.set("rqm", "fetch"),
                                  (m = r.toQueryString()),
                                  (p = d + "?" + m),
                                  (_ = p.length > l),
                                  (f = c()),
                                  (h = setTimeout(function () {
                                    return f.abort();
                                  }, s)),
                                  (y = "no-cors"),
                                  (C = "include"),
                                  (b = v(
                                    {
                                      method: _ ? "POST" : "GET",
                                      mode: y,
                                      credentials: C,
                                      cache: "no-store",
                                      keepalive: !0,
                                      signal: f.signal,
                                      fetchPriority: "high",
                                    },
                                    _
                                      ? {
                                          headers: {
                                            "Content-Type":
                                              "application/x-www-form-urlencoded",
                                          },
                                          body: r.toQueryString(),
                                        }
                                      : {},
                                  )),
                                  (n.p = 1),
                                  (S = _ ? d : p),
                                  (n.n = 2),
                                  e.fetch(S, b)
                                );
                              case 2:
                                return n.a(2, { ok: !0, reason: "delivered" });
                              case 3:
                                return (
                                  (n.p = 3),
                                  (L = n.v),
                                  (R = u(L)),
                                  n.a(2, { ok: !1, reason: R, error: L })
                                );
                              case 4:
                                return ((n.p = 4), clearTimeout(h), n.f(4));
                              case 5:
                                return n.a(2);
                            }
                        },
                        n,
                        null,
                        [[1, 3, 4, 5]],
                      );
                    }),
                  )),
                  m.apply(this, arguments)
                );
              }
              o.exports = d;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendFormPOST", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsEventPayload"),
                r = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                i = a.getFbeventsModules("SignalsFBEventsUtils"),
                l = i.listenOnce,
                s = a.getFbeventsModules("SignalsFBEventsLogging"),
                u = s.logError,
                c = s.logWarning,
                d = a.getFbeventsModules("SignalsFBEventsGuardrail");
              function m(n, o) {
                try {
                  var a = "fb" + Math.random().toString().replace(".", ""),
                    i = t.createElement("form");
                  ((i.method = "post"),
                    (i.action = o != null ? o : r.ENDPOINT),
                    (i.target = a),
                    (i.acceptCharset = "utf-8"),
                    (i.style.display = "none"));
                  var s = !!(e.attachEvent && !e.addEventListener),
                    m = t.createElement("iframe");
                  (s && (m.name = a),
                    (m.src = "about:blank"),
                    (m.id = a),
                    (m.name = a),
                    i.appendChild(m));
                  var p = d.eval("fix_fbevent_uri_error");
                  return (
                    l(m, "load", function () {
                      (n.set("rqm", "formPOST"),
                        n.forEach(function (e, n) {
                          var r = t.createElement("input");
                          if (p)
                            try {
                              r.name = decodeURIComponent(e);
                            } catch (t) {
                              ((r.name = e), c(t, "pixel", "SendFormPOST"));
                            }
                          else r.name = decodeURIComponent(e);
                          ((r.value = n), i.appendChild(r));
                        }),
                        l(m, "load", function () {
                          i.parentNode && i.parentNode.removeChild(i);
                        }),
                        i.submit());
                    }),
                    t.body != null && t.body.appendChild(i),
                    !0
                  );
                } catch (e) {
                  return (
                    e instanceof Error && u(new Error("[POST]:" + e.message)),
                    !0
                  );
                }
              }
              o.exports = m;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("signalsFBEventsSendGET", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                t = a.getFbeventsModules(
                  "SignalsFBEventsShouldRestrictReferrerEvent",
                ),
                n = a.getFbeventsModules("SignalsFBEventsUtils"),
                r = n.some,
                i = a.getFbeventsModules("SignalsEventPayload"),
                l = 2048;
              function s(n, o) {
                try {
                  var a = o || {},
                    i = a.ignoreRequestLengthCheck,
                    s = i === void 0 ? !1 : i,
                    u = a.url,
                    c = u === void 0 ? e.ENDPOINT : u,
                    d = a.attributionReporting,
                    m = d === void 0 ? !1 : d,
                    p = a.highFetchPriority,
                    _ = p === void 0 ? !1 : p,
                    f = a.expv2;
                  (n.set("rqm", s ? "FGET" : "GET"),
                    f != null && f.length > 0 && n.setAsDict("expv2", f));
                  var g = n.toQueryString(),
                    h = c + "?" + g;
                  if (s || h.length < l) {
                    var y = new Image();
                    o != null &&
                      o.errorHandler != null &&
                      (y.onerror = o.errorHandler);
                    var C = t.trigger(n);
                    return (
                      r(C, function (e) {
                        return e;
                      }) && (y.referrerPolicy = "origin"),
                      m && y.setAttribute("attributionsrc", ""),
                      _ && (y.fetchPriority = "high"),
                      (y.src = h),
                      !0
                    );
                  }
                  return !1;
                } catch (e) {
                  return !1;
                }
              }
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetCCRules", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsUtils"),
                n = t.filter,
                r = t.map,
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.coerce,
                s = i.Typed,
                u = a.getFbeventsModules(
                  "signalsFBEventsCoerceParameterExtractors",
                ),
                c = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                d = s.arrayOf(
                  s.objectWithFields({ id: s.number(), rule: s.string() }),
                );
              function m() {
                for (
                  var e = arguments.length, t = new Array(e), n = 0;
                  n < e;
                  n++
                )
                  t[n] = arguments[n];
                var r = t[0];
                if (r == null || G(r) !== "object") return null;
                var o = r.pixelID,
                  a = r.rules,
                  i = c(o);
                if (i == null) return null;
                var s = l(a, d);
                return [{ rules: s, pixelID: i }];
              }
              var p = new e(m);
              o.exports = p;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetESTRules", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsUtils"),
                n = t.filter,
                r = t.map,
                i = a.getFbeventsModules("SignalsFBEventsTyped"),
                l = i.coerce,
                s = i.Typed,
                u = a.getFbeventsModules(
                  "signalsFBEventsCoerceParameterExtractors",
                ),
                c = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                d = s.arrayOf(
                  s.objectWithFields({
                    condition: s.objectOrString(),
                    derived_event_name: s.string(),
                    rule_status: s.allowNull(s.string()),
                    transformations: s.allowNull(s.array()),
                    rule_id: s.allowNull(s.string()),
                  }),
                );
              function m() {
                for (
                  var e = arguments.length, t = new Array(e), n = 0;
                  n < e;
                  n++
                )
                  t[n] = arguments[n];
                var r = t[0];
                if (r == null || G(r) !== "object") return null;
                var o = r.pixelID,
                  a = r.rules,
                  i = c(o);
                if (i == null) return null;
                var s = l(a, d);
                return [{ rules: s, pixelID: i }];
              }
              var p = new e(m);
              o.exports = p;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsSetEventIDEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsParamList"),
                n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                r = a.getFbeventsModules("SignalsFBEventsTyped"),
                i = r.coerce,
                l = a.getFbeventsModules("signalsFBEventsCoercePixelID");
              function s(e, n, r) {
                var o = l(e),
                  a = n instanceof t ? n : null,
                  s = i(r, String);
                return o != null && a != null && s != null ? [o, a, s] : null;
              }
              var u = new e(s);
              o.exports = u;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsSetFilteredEventName",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsParamList"),
                  n = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  r = a.getFbeventsModules("SignalsFBEventsTyped"),
                  i = r.Typed,
                  l = r.coerce;
                function s(e) {
                  var n = e instanceof t ? e : null;
                  return n != null ? [n] : null;
                }
                var u = new e(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsSetIWLExtractorsEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsUtils"),
                  n = t.filter,
                  r = t.map,
                  i = a.getFbeventsModules(
                    "signalsFBEventsCoerceParameterExtractors",
                  ),
                  l = a.getFbeventsModules("signalsFBEventsCoercePixelID");
                function s() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  var a = t[0];
                  if (a == null || G(a) !== "object") return null;
                  var s = a.pixelID,
                    u = a.extractors,
                    c = l(s),
                    d = Array.isArray(u) ? r(u, i) : null,
                    m = d != null ? n(d, Boolean) : null;
                  return m != null &&
                    d != null &&
                    m.length === d.length &&
                    c != null
                    ? [{ extractors: m, pixelID: c }]
                    : null;
                }
                var u = new e(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsShared", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              (function () {
                "use strict";
                var n = {
                    3: function (t, n, r) {
                      var e = r(2640);
                      t.exports = e;
                    },
                    182: function (t, n, r) {
                      var e = r(2073),
                        o = r(4003),
                        a = TypeError;
                      t.exports = function (t) {
                        if (e(t)) return t;
                        throw a(o(t) + " is not a function");
                      };
                    },
                    235: function (t, n, r) {
                      var e = r(9036),
                        o = r(6759),
                        a = r(7803),
                        i = r(8890),
                        l = e("".charAt),
                        s = e("".charCodeAt),
                        u = e("".slice),
                        c = function (t) {
                          return function (e, n) {
                            var r,
                              c,
                              d = a(i(e)),
                              m = o(n),
                              p = d.length;
                            return m < 0 || m >= p
                              ? t
                                ? ""
                                : void 0
                              : (r = s(d, m)) < 55296 ||
                                  r > 56319 ||
                                  m + 1 === p ||
                                  (c = s(d, m + 1)) < 56320 ||
                                  c > 57343
                                ? t
                                  ? l(d, m)
                                  : r
                                : t
                                  ? u(d, m, m + 2)
                                  : c - 56320 + ((r - 55296) << 10) + 65536;
                          };
                        };
                      t.exports = { codeAt: c(!1), charAt: c(!0) };
                    },
                    244: function (t, n, r) {
                      var e = r(9036),
                        o = e({}.toString),
                        a = e("".slice);
                      t.exports = function (e) {
                        return a(o(e), 8, -1);
                      };
                    },
                    266: function (t, n, r) {
                      var e = r(182),
                        o = r(5809),
                        a = r(6731),
                        i = r(954),
                        l = TypeError,
                        s = function (n) {
                          return function (t, r, s, u) {
                            e(r);
                            var c = o(t),
                              d = a(c),
                              m = i(c),
                              p = n ? m - 1 : 0,
                              _ = n ? -1 : 1;
                            if (s < 2)
                              for (;;) {
                                if (p in d) {
                                  ((u = d[p]), (p += _));
                                  break;
                                }
                                if (((p += _), n ? p < 0 : m <= p))
                                  throw l(
                                    "Reduce of empty array with no initial value",
                                  );
                              }
                            for (; n ? p >= 0 : m > p; p += _)
                              p in d && (u = r(u, d[p], p, c));
                            return u;
                          };
                        };
                      t.exports = { left: s(!1), right: s(!0) };
                    },
                    347: function (t) {
                      t.exports = [
                        "constructor",
                        "hasOwnProperty",
                        "isPrototypeOf",
                        "propertyIsEnumerable",
                        "toLocaleString",
                        "toString",
                        "valueOf",
                      ];
                    },
                    492: function (t, n, r) {
                      var e = r(8471);
                      t.exports = function (t, n, r, o) {
                        return (o && o.enumerable ? (t[n] = r) : e(t, n, r), t);
                      };
                    },
                    538: function (t, n, r) {
                      var e = r(7131);
                      t.exports = function (t, n) {
                        var r = [][t];
                        return (
                          !!r &&
                          e(function () {
                            r.call(
                              null,
                              n ||
                                function () {
                                  return 1;
                                },
                              1,
                            );
                          })
                        );
                      };
                    },
                    651: function (t, n, r) {
                      var e = r(3557),
                        o = r(7980),
                        a = e("keys");
                      t.exports = function (e) {
                        return a[e] || (a[e] = o(e));
                      };
                    },
                    789: function (t) {
                      t.exports = function (e, t) {
                        return { value: e, done: t };
                      };
                    },
                    802: function (t, n, r) {
                      r(1284);
                      var e = r(8843);
                      t.exports = e("Array", "filter");
                    },
                    892: function (t, n, r) {
                      var e = r(6215);
                      t.exports = e;
                    },
                    909: function (t, n, r) {
                      var e = r(5391),
                        o = Object.defineProperty;
                      t.exports = function (t, n) {
                        try {
                          o(e, t, { value: n, configurable: !0, writable: !0 });
                        } catch (r) {
                          e[t] = n;
                        }
                        return n;
                      };
                    },
                    954: function (t, n, r) {
                      var e = r(2954);
                      t.exports = function (t) {
                        return e(t.length);
                      };
                    },
                    1001: function (t, n, r) {
                      var e = r(892);
                      t.exports = e;
                    },
                    1004: function (t, n, r) {
                      var e = r(7235);
                      t.exports =
                        e &&
                        !(typeof Symbol != "function" || Symbol.sham) &&
                        G(
                          typeof Symbol == "function"
                            ? Symbol.iterator
                            : "@@iterator",
                        ) == "symbol";
                    },
                    1049: function (t) {
                      var e = Math.ceil,
                        n = Math.floor;
                      t.exports =
                        Math.trunc ||
                        function (t) {
                          var r = +t;
                          return (r > 0 ? n : e)(r);
                        };
                    },
                    1059: function (t, n, r) {
                      r(7765);
                      var e = r(8843);
                      t.exports = e("Array", "find");
                    },
                    1113: function (t) {
                      t.exports = {};
                    },
                    1225: function (t, n, r) {
                      var e = r(7131),
                        o = r(6615),
                        a = r(6312),
                        i = o("species");
                      t.exports = function (t) {
                        return (
                          a >= 51 ||
                          !e(function () {
                            var e = [];
                            return (
                              ((e.constructor = {})[i] = function () {
                                return { foo: 1 };
                              }),
                              e[t](Boolean).foo !== 1
                            );
                          })
                        );
                      };
                    },
                    1284: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).filter;
                      e(
                        {
                          target: "Array",
                          proto: !0,
                          forced: !r(1225)("filter"),
                        },
                        {
                          filter: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0,
                            );
                          },
                        },
                      );
                    },
                    1306: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).map;
                      e(
                        { target: "Array", proto: !0, forced: !r(1225)("map") },
                        {
                          map: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0,
                            );
                          },
                        },
                      );
                    },
                    1731: function (t, n, r) {
                      var e = r(7452);
                      t.exports = e;
                    },
                    1938: function (t, n, r) {
                      var e = r(5391),
                        o = r(1981),
                        a = r(9e3),
                        i = r(2073),
                        l = r(5687).f,
                        s = r(3488),
                        u = r(7675),
                        c = r(2116),
                        d = r(8471),
                        m = r(4373),
                        p = function (t) {
                          var e = function (r, a, i) {
                            if (this instanceof e) {
                              switch (arguments.length) {
                                case 0:
                                  return new t();
                                case 1:
                                  return new t(r);
                                case 2:
                                  return new t(r, a);
                              }
                              return new t(r, a, i);
                            }
                            return o(t, this, arguments);
                          };
                          return ((e.prototype = t.prototype), e);
                        };
                      t.exports = function (t, n) {
                        var r,
                          o,
                          _,
                          f,
                          g,
                          h,
                          y,
                          C,
                          b,
                          v = t.target,
                          S = t.global,
                          R = t.stat,
                          L = t.proto,
                          E = S ? e : R ? e[v] : (e[v] || {}).prototype,
                          k = S ? u : u[v] || d(u, v, {})[v],
                          I = k.prototype;
                        for (f in n)
                          ((o =
                            !(r = s(
                              S ? f : v + (R ? "." : "#") + f,
                              t.forced,
                            )) &&
                            E &&
                            m(E, f)),
                            (h = k[f]),
                            o &&
                              (y = t.dontCallGetSet
                                ? (b = l(E, f)) && b.value
                                : E[f]),
                            (g = o && y ? y : n[f]),
                            (o && G(h) == G(g)) ||
                              ((C =
                                t.bind && o
                                  ? c(g, e)
                                  : t.wrap && o
                                    ? p(g)
                                    : L && i(g)
                                      ? a(g)
                                      : g),
                              (t.sham || (g && g.sham) || (h && h.sham)) &&
                                d(C, "sham", !0),
                              d(k, f, C),
                              L &&
                                (m(u, (_ = v + "Prototype")) || d(u, _, {}),
                                d(u[_], f, g),
                                t.real && I && (r || !I[f]) && d(I, f, g))));
                      };
                    },
                    1972: function (t, n, r) {
                      var e = r(244);
                      t.exports =
                        Array.isArray ||
                        function (t) {
                          return e(t) === "Array";
                        };
                    },
                    1981: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype,
                        a = o.apply,
                        i = o.call;
                      t.exports =
                        ((typeof Reflect == "undefined"
                          ? "undefined"
                          : G(Reflect)) == "object" &&
                          Reflect.apply) ||
                        (e
                          ? i.bind(a)
                          : function () {
                              return i.apply(a, arguments);
                            });
                    },
                    2073: function (t, n, r) {
                      var e = r(7023),
                        o = e.all;
                      t.exports = e.IS_HTMLDDA
                        ? function (e) {
                            return typeof e == "function" || e === o;
                          }
                        : function (e) {
                            return typeof e == "function";
                          };
                    },
                    2116: function (t, n, r) {
                      var e = r(9e3),
                        o = r(182),
                        a = r(5164),
                        i = e(e.bind);
                      t.exports = function (e, t) {
                        return (
                          o(e),
                          t === void 0
                            ? e
                            : a
                              ? i(e, t)
                              : function () {
                                  return e.apply(t, arguments);
                                }
                        );
                      };
                    },
                    2217: function (t, n, r) {
                      var e = r(2116),
                        o = r(9036),
                        a = r(6731),
                        i = r(5809),
                        l = r(954),
                        s = r(6601),
                        u = o([].push),
                        c = function (n) {
                          var t = n === 1,
                            r = n === 2,
                            o = n === 3,
                            c = n === 4,
                            d = n === 6,
                            m = n === 7,
                            p = n === 5 || d;
                          return function (_, f, g, h) {
                            for (
                              var y,
                                C,
                                b = i(_),
                                v = a(b),
                                S = e(f, g),
                                R = l(v),
                                L = 0,
                                E = h || s,
                                k = t ? E(_, R) : r || m ? E(_, 0) : void 0;
                              R > L;
                              L++
                            )
                              if (
                                (p || L in v) &&
                                ((C = S((y = v[L]), L, b)), n)
                              )
                                if (t) k[L] = C;
                                else if (C)
                                  switch (n) {
                                    case 3:
                                      return !0;
                                    case 5:
                                      return y;
                                    case 6:
                                      return L;
                                    case 2:
                                      u(k, y);
                                  }
                                else
                                  switch (n) {
                                    case 4:
                                      return !1;
                                    case 7:
                                      u(k, y);
                                  }
                            return d ? -1 : o || c ? c : k;
                          };
                        };
                      t.exports = {
                        forEach: c(0),
                        map: c(1),
                        filter: c(2),
                        some: c(3),
                        every: c(4),
                        find: c(5),
                        findIndex: c(6),
                        filterReject: c(7),
                      };
                    },
                    2373: function (t, n, r) {
                      var e,
                        o,
                        a,
                        i = r(7131),
                        l = r(2073),
                        s = r(5774),
                        u = r(3628),
                        c = r(3439),
                        d = r(492),
                        m = r(6615),
                        p = r(3599),
                        _ = m("iterator"),
                        f = !1;
                      ([].keys &&
                        ("next" in (a = [].keys())
                          ? (o = c(c(a))) !== Object.prototype && (e = o)
                          : (f = !0)),
                        !s(e) ||
                        i(function () {
                          var t = {};
                          return e[_].call(t) !== t;
                        })
                          ? (e = {})
                          : p && (e = u(e)),
                        l(e[_]) ||
                          d(e, _, function () {
                            return this;
                          }),
                        (t.exports = {
                          IteratorPrototype: e,
                          BUGGY_SAFARI_ITERATORS: f,
                        }));
                    },
                    2506: function (t, n, r) {
                      var e = r(5560),
                        o = r(7131);
                      t.exports =
                        e &&
                        o(function () {
                          return (
                            Object.defineProperty(function () {}, "prototype", {
                              value: 42,
                              writable: !1,
                            }).prototype !== 42
                          );
                        });
                    },
                    2633: function (t, n, r) {
                      var e = r(5560),
                        o = r(7131),
                        a = r(6171);
                      t.exports =
                        !e &&
                        !o(function () {
                          return (
                            Object.defineProperty(a("div"), "a", {
                              get: function () {
                                return 7;
                              },
                            }).a !== 7
                          );
                        });
                    },
                    2640: function (t, n, r) {
                      var e = r(3109);
                      t.exports = e;
                    },
                    2780: function (t, n, r) {
                      var e,
                        o = r(1938),
                        a = r(9e3),
                        i = r(5687).f,
                        l = r(2954),
                        s = r(7803),
                        u = r(5923),
                        c = r(8890),
                        d = r(7288),
                        m = r(3599),
                        p = a("".startsWith),
                        _ = a("".slice),
                        f = Math.min,
                        g = d("startsWith");
                      o(
                        {
                          target: "String",
                          proto: !0,
                          forced:
                            !!(
                              m ||
                              g ||
                              ((e = i(String.prototype, "startsWith")),
                              !e || e.writable)
                            ) && !g,
                        },
                        {
                          startsWith: function (t) {
                            var e = s(c(this));
                            u(t);
                            var n = l(
                                f(
                                  arguments.length > 1 ? arguments[1] : void 0,
                                  e.length,
                                ),
                              ),
                              r = s(t);
                            return p ? p(e, r, n) : _(e, n, n + r.length) === r;
                          },
                        },
                      );
                    },
                    2843: function (t, n, r) {
                      var e = r(8347),
                        o = r(7959);
                      t.exports = function (t, n, r, a) {
                        try {
                          return a ? n(e(r)[0], r[1]) : n(r);
                        } catch (e) {
                          o(t, "throw", e);
                        }
                      };
                    },
                    2954: function (t, n, r) {
                      var e = r(6759),
                        o = Math.min;
                      t.exports = function (t) {
                        return t > 0 ? o(e(t), 9007199254740991) : 0;
                      };
                    },
                    3057: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype.call;
                      t.exports = e
                        ? o.bind(o)
                        : function () {
                            return o.apply(o, arguments);
                          };
                    },
                    3109: function (t, n, r) {
                      r(7019);
                      var e = r(8843);
                      t.exports = e("Array", "includes");
                    },
                    3381: function (t, n, r) {
                      var e = r(9036);
                      t.exports = e({}.isPrototypeOf);
                    },
                    3439: function (t, n, r) {
                      var e = r(4373),
                        o = r(2073),
                        a = r(5809),
                        i = r(651),
                        l = r(7007),
                        s = i("IE_PROTO"),
                        u = Object,
                        c = u.prototype;
                      t.exports = l
                        ? u.getPrototypeOf
                        : function (t) {
                            var n = a(t);
                            if (e(n, s)) return n[s];
                            var r = n.constructor;
                            return o(r) && n instanceof r
                              ? r.prototype
                              : n instanceof u
                                ? c
                                : null;
                          };
                    },
                    3488: function (t, n, r) {
                      var e = r(7131),
                        o = r(2073),
                        a = /#|\.prototype\./,
                        i = function (n, r) {
                          var t = s[l(n)];
                          return t === c || (t !== u && (o(r) ? e(r) : !!r));
                        },
                        l = (i.normalize = function (e) {
                          return String(e).replace(a, ".").toLowerCase();
                        }),
                        s = (i.data = {}),
                        u = (i.NATIVE = "N"),
                        c = (i.POLYFILL = "P");
                      t.exports = i;
                    },
                    3514: function (t, n, r) {
                      var e = r(182),
                        o = r(6153);
                      t.exports = function (t, n) {
                        var r = t[n];
                        return o(r) ? void 0 : e(r);
                      };
                    },
                    3550: function (t, n, r) {
                      var e = r(3);
                      t.exports = e;
                    },
                    3557: function (t, n, r) {
                      var e = r(3599),
                        o = r(4993);
                      (t.exports = function (e, t) {
                        return o[e] || (o[e] = t !== void 0 ? t : {});
                      })("versions", []).push({
                        version: "3.32.2",
                        mode: e ? "pure" : "global",
                        copyright:
                          "\xA9 2014-2023 Denis Pushkarev (zloirock.ru)",
                        license:
                          "https://github.com/zloirock/core-js/blob/v3.32.2/LICENSE",
                        source: "https://github.com/zloirock/core-js",
                      });
                    },
                    3599: function (t) {
                      t.exports = !0;
                    },
                    3628: function (n, r, o) {
                      var e,
                        a = o(8347),
                        i = o(9157),
                        l = o(347),
                        s = o(6145),
                        u = o(9417),
                        c = o(6171),
                        d = o(651),
                        m = "prototype",
                        p = "script",
                        _ = d("IE_PROTO"),
                        f = function () {},
                        g = function (t) {
                          return "<" + p + ">" + t + "</" + p + ">";
                        },
                        h = function (t) {
                          (t.write(g("")), t.close());
                          var e = t.parentWindow.Object;
                          return ((t = null), e);
                        },
                        y = function () {
                          try {
                            e = new ActiveXObject("htmlfile");
                          } catch (e) {}
                          var n, r, o;
                          y =
                            typeof t != "undefined"
                              ? t.domain && e
                                ? h(e)
                                : ((r = c("iframe")),
                                  (o = "java" + p + ":"),
                                  (r.style.display = "none"),
                                  u.appendChild(r),
                                  (r.src = String(o)),
                                  (n = r.contentWindow.document).open(),
                                  n.write(g("document.F=Object")),
                                  n.close(),
                                  n.F)
                              : h(e);
                          for (var a = l.length; a--; ) delete y[m][l[a]];
                          return y();
                        };
                      ((s[_] = !0),
                        (n.exports =
                          Object.create ||
                          function (e, t) {
                            var n;
                            return (
                              e !== null
                                ? ((f[m] = a(e)),
                                  (n = new f()),
                                  (f[m] = null),
                                  (n[_] = e))
                                : (n = y()),
                              t === void 0 ? n : i.f(n, t)
                            );
                          }));
                    },
                    3768: function (t) {
                      t.exports = function (e, t) {
                        return {
                          enumerable: !(1 & e),
                          configurable: !(2 & e),
                          writable: !(4 & e),
                          value: t,
                        };
                      };
                    },
                    3859: function (t, n, r) {
                      var e = r(802);
                      t.exports = e;
                    },
                    3969: function (t, n, r) {
                      var e = r(7827),
                        o = r(2073),
                        a = r(3381),
                        i = r(1004),
                        l = Object;
                      t.exports = i
                        ? function (e) {
                            return G(e) == "symbol";
                          }
                        : function (t) {
                            var n = e("Symbol");
                            return o(n) && a(n.prototype, l(t));
                          };
                    },
                    4003: function (t) {
                      var e = String;
                      t.exports = function (t) {
                        try {
                          return e(t);
                        } catch (e) {
                          return "Object";
                        }
                      };
                    },
                    4084: function (t) {
                      t.exports =
                        (typeof navigator != "undefined" &&
                          String(navigator.userAgent)) ||
                        "";
                    },
                    4090: function (t, n, r) {
                      r(8132);
                      var e = r(8843);
                      t.exports = e("Array", "reduce");
                    },
                    4373: function (t, n, r) {
                      var e = r(9036),
                        o = r(5809),
                        a = e({}.hasOwnProperty);
                      t.exports =
                        Object.hasOwn ||
                        function (e, t) {
                          return a(o(e), t);
                        };
                    },
                    4512: function (t, n, r) {
                      var e = r(9036),
                        o = r(4373),
                        a = r(9441),
                        i = r(4581).indexOf,
                        l = r(6145),
                        s = e([].push);
                      t.exports = function (e, t) {
                        var n,
                          r = a(e),
                          u = 0,
                          c = [];
                        for (n in r) !o(l, n) && o(r, n) && s(c, n);
                        for (; t.length > u; )
                          o(r, (n = t[u++])) && (~i(c, n) || s(c, n));
                        return c;
                      };
                    },
                    4581: function (t, n, r) {
                      var e = r(9441),
                        o = r(8630),
                        a = r(954),
                        i = function (n) {
                          return function (t, r, i) {
                            var l,
                              s = e(t),
                              u = a(s),
                              c = o(i, u);
                            if (n && r != r) {
                              for (; u > c; ) if ((l = s[c++]) != l) return !0;
                            } else
                              for (; u > c; c++)
                                if ((n || c in s) && s[c] === r)
                                  return n || c || 0;
                            return !n && -1;
                          };
                        };
                      t.exports = { includes: i(!0), indexOf: i(!1) };
                    },
                    4619: function (t, n, r) {
                      var e = r(7006),
                        o = r(8347),
                        a = r(8934);
                      t.exports =
                        Object.setPrototypeOf ||
                        ("__proto__" in {}
                          ? (function () {
                              var t,
                                n = !1,
                                r = {};
                              try {
                                ((t = e(Object.prototype, "__proto__", "set"))(
                                  r,
                                  [],
                                ),
                                  (n = r instanceof Array));
                              } catch (e) {}
                              return function (e, r) {
                                return (
                                  o(e),
                                  a(r),
                                  n ? t(e, r) : (e.__proto__ = r),
                                  e
                                );
                              };
                            })()
                          : void 0);
                    },
                    4734: function (t, n, r) {
                      var e = r(1059);
                      t.exports = e;
                    },
                    4817: function (t, n, r) {
                      var e = r(6002);
                      t.exports = e;
                    },
                    4909: function (t, n, r) {
                      var e = r(5423);
                      t.exports = function t(n, r) {
                        return (
                          !(!n || !r) &&
                          (n === r ||
                            (!e(n) &&
                              (e(r)
                                ? t(n, r.parentNode)
                                : "contains" in n
                                  ? n.contains(r)
                                  : !!n.compareDocumentPosition &&
                                    !!(16 & n.compareDocumentPosition(r)))))
                        );
                      };
                    },
                    4970: function (t, n, r) {
                      var e = r(5560),
                        o = r(4373),
                        a = Function.prototype,
                        i = e && Object.getOwnPropertyDescriptor,
                        l = o(a, "name"),
                        s = l && function () {}.name === "something",
                        u = l && (!e || (e && i(a, "name").configurable));
                      t.exports = { EXISTS: l, PROPER: s, CONFIGURABLE: u };
                    },
                    4993: function (t, n, r) {
                      var e = r(5391),
                        o = r(909),
                        a = "__core-js_shared__",
                        i = e[a] || o(a, {});
                      t.exports = i;
                    },
                    5023: function (t, n, r) {
                      var e = r(9830);
                      t.exports = e;
                    },
                    5045: function (t, n, r) {
                      var e = r(3057),
                        o = r(5774),
                        a = r(3969),
                        i = r(3514),
                        l = r(6034),
                        s = r(6615),
                        u = TypeError,
                        c = s("toPrimitive");
                      t.exports = function (t, n) {
                        if (!o(t) || a(t)) return t;
                        var r,
                          s = i(t, c);
                        if (s) {
                          if (
                            (n === void 0 && (n = "default"),
                            (r = e(s, t, n)),
                            !o(r) || a(r))
                          )
                            return r;
                          throw u("Can't convert object to primitive value");
                        }
                        return (n === void 0 && (n = "number"), l(t, n));
                      };
                    },
                    5051: function (t, n, r) {
                      var e = r(7104),
                        o = r(6381).f,
                        a = r(8471),
                        i = r(4373),
                        l = r(5759),
                        s = r(6615)("toStringTag");
                      t.exports = function (t, n, r, u) {
                        if (t) {
                          var c = r ? t : t.prototype;
                          (i(c, s) || o(c, s, { configurable: !0, value: n }),
                            u && !e && a(c, "toString", l));
                        }
                      };
                    },
                    5109: function (t, n, r) {
                      var e = r(7004);
                      t.exports = e;
                    },
                    5141: function (t, n, r) {
                      var e = r(5045),
                        o = r(3969);
                      t.exports = function (t) {
                        var n = e(t, "string");
                        return o(n) ? n : n + "";
                      };
                    },
                    5164: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        var e = function () {}.bind();
                        return (
                          typeof e != "function" ||
                          Object.prototype.hasOwnProperty.call(e, "prototype")
                        );
                      });
                    },
                    5391: function (n, r, o) {
                      var t = function (t) {
                        return t && t.Math === Math && t;
                      };
                      n.exports =
                        t(
                          (typeof globalThis == "undefined"
                            ? "undefined"
                            : G(globalThis)) == "object" && globalThis,
                        ) ||
                        t(G(e) == "object" && e) ||
                        t(
                          (typeof self == "undefined"
                            ? "undefined"
                            : G(self)) == "object" && self,
                        ) ||
                        t(G(o.g) == "object" && o.g) ||
                        (function () {
                          return this;
                        })() ||
                        this ||
                        Function("return this")();
                    },
                    5423: function (t, n, r) {
                      var e = r(5504);
                      t.exports = function (t) {
                        return e(t) && t.nodeType == 3;
                      };
                    },
                    5504: function (r) {
                      r.exports = function (n) {
                        var r = (n ? n.ownerDocument || n : t).defaultView || e;
                        return !(
                          !n ||
                          !(typeof r.Node == "function"
                            ? n instanceof r.Node
                            : G(n) == "object" &&
                              typeof n.nodeType == "number" &&
                              typeof n.nodeName == "string")
                        );
                      };
                    },
                    5556: function (t, n, r) {
                      var e = r(4512),
                        o = r(347);
                      t.exports =
                        Object.keys ||
                        function (t) {
                          return e(t, o);
                        };
                    },
                    5560: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        return (
                          Object.defineProperty({}, 1, {
                            get: function () {
                              return 7;
                            },
                          })[1] !== 7
                        );
                      });
                    },
                    5663: function (t, n, r) {
                      var e = r(7104),
                        o = r(2073),
                        a = r(244),
                        i = r(6615)("toStringTag"),
                        l = Object,
                        s =
                          a(
                            (function () {
                              return arguments;
                            })(),
                          ) === "Arguments";
                      t.exports = e
                        ? a
                        : function (e) {
                            var t, n, r;
                            return e === void 0
                              ? "Undefined"
                              : e === null
                                ? "Null"
                                : typeof (n = (function (e, t) {
                                      try {
                                        return e[t];
                                      } catch (e) {}
                                    })((t = l(e)), i)) == "string"
                                  ? n
                                  : s
                                    ? a(t)
                                    : (r = a(t)) === "Object" && o(t.callee)
                                      ? "Arguments"
                                      : r;
                          };
                    },
                    5669: function (t, n, r) {
                      var e = r(6615),
                        o = r(1113),
                        a = e("iterator"),
                        i = Array.prototype;
                      t.exports = function (e) {
                        return e !== void 0 && (o.Array === e || i[a] === e);
                      };
                    },
                    5687: function (t, n, r) {
                      var e = r(5560),
                        o = r(3057),
                        a = r(6337),
                        i = r(3768),
                        l = r(9441),
                        s = r(5141),
                        u = r(4373),
                        c = r(2633),
                        d = Object.getOwnPropertyDescriptor;
                      n.f = e
                        ? d
                        : function (e, t) {
                            if (((e = l(e)), (t = s(t)), c))
                              try {
                                return d(e, t);
                              } catch (e) {}
                            if (u(e, t)) return i(!o(a.f, e, t), e[t]);
                          };
                    },
                    5759: function (t, n, r) {
                      var e = r(7104),
                        o = r(5663);
                      t.exports = e
                        ? {}.toString
                        : function () {
                            return "[object " + o(this) + "]";
                          };
                    },
                    5774: function (t, n, r) {
                      var e = r(2073),
                        o = r(7023),
                        a = o.all;
                      t.exports = o.IS_HTMLDDA
                        ? function (t) {
                            return G(t) == "object"
                              ? t !== null
                              : e(t) || t === a;
                          }
                        : function (t) {
                            return G(t) == "object" ? t !== null : e(t);
                          };
                    },
                    5809: function (t, n, r) {
                      var e = r(8890),
                        o = Object;
                      t.exports = function (t) {
                        return o(e(t));
                      };
                    },
                    5837: function (t, n, r) {
                      var e = r(4734);
                      t.exports = e;
                    },
                    5856: function (t, n, r) {
                      var e = r(5774),
                        o = r(244),
                        a = r(6615)("match");
                      t.exports = function (t) {
                        var n;
                        return (
                          e(t) &&
                          ((n = t[a]) !== void 0 ? !!n : o(t) === "RegExp")
                        );
                      };
                    },
                    5923: function (t, n, r) {
                      var e = r(5856),
                        o = TypeError;
                      t.exports = function (t) {
                        if (e(t))
                          throw o(
                            "The method doesn't accept regular expressions",
                          );
                        return t;
                      };
                    },
                    6002: function (t, n, r) {
                      var e = r(1731);
                      t.exports = e;
                    },
                    6034: function (t, n, r) {
                      var e = r(3057),
                        o = r(2073),
                        a = r(5774),
                        i = TypeError;
                      t.exports = function (t, n) {
                        var r, l;
                        if (
                          (n === "string" &&
                            o((r = t.toString)) &&
                            !a((l = e(r, t)))) ||
                          (o((r = t.valueOf)) && !a((l = e(r, t)))) ||
                          (n !== "string" &&
                            o((r = t.toString)) &&
                            !a((l = e(r, t))))
                        )
                          return l;
                        throw i("Can't convert object to primitive value");
                      };
                    },
                    6065: function (t) {
                      t.exports = function () {};
                    },
                    6145: function (t) {
                      t.exports = {};
                    },
                    6153: function (t) {
                      t.exports = function (e) {
                        return e == null;
                      };
                    },
                    6171: function (t, n, r) {
                      var e = r(5391),
                        o = r(5774),
                        a = e.document,
                        i = o(a) && o(a.createElement);
                      t.exports = function (e) {
                        return i ? a.createElement(e) : {};
                      };
                    },
                    6188: function (t, n, r) {
                      var e = r(1938),
                        o = r(3057),
                        a = r(3599),
                        i = r(4970),
                        l = r(2073),
                        s = r(7102),
                        u = r(3439),
                        c = r(4619),
                        d = r(5051),
                        m = r(8471),
                        p = r(492),
                        _ = r(6615),
                        f = r(1113),
                        g = r(2373),
                        h = i.PROPER,
                        y = i.CONFIGURABLE,
                        C = g.IteratorPrototype,
                        b = g.BUGGY_SAFARI_ITERATORS,
                        v = _("iterator"),
                        S = "keys",
                        R = "values",
                        L = "entries",
                        E = function () {
                          return this;
                        };
                      t.exports = function (t, n, r, i, _, g, k) {
                        s(r, n, i);
                        var I,
                          T,
                          D,
                          x = function (t) {
                            if (t === _ && w) return w;
                            if (!b && t && t in N) return N[t];
                            switch (t) {
                              case S:
                              case R:
                              case L:
                                return function () {
                                  return new r(this, t);
                                };
                            }
                            return function () {
                              return new r(this);
                            };
                          },
                          $ = n + " Iterator",
                          P = !1,
                          N = t.prototype,
                          M = N[v] || N["@@iterator"] || (_ && N[_]),
                          w = (!b && M) || x(_),
                          A = (n === "Array" && N.entries) || M;
                        if (
                          (A &&
                            (I = u(A.call(new t()))) !== Object.prototype &&
                            I.next &&
                            (a ||
                              u(I) === C ||
                              (c ? c(I, C) : l(I[v]) || p(I, v, E)),
                            d(I, $, !0, !0),
                            a && (f[$] = E)),
                          h &&
                            _ === R &&
                            M &&
                            M.name !== R &&
                            (!a && y
                              ? m(N, "name", R)
                              : ((P = !0),
                                (w = function () {
                                  return o(M, this);
                                }))),
                          _)
                        )
                          if (
                            ((T = {
                              values: x(R),
                              keys: g ? w : x(S),
                              entries: x(L),
                            }),
                            k)
                          )
                            for (D in T) (b || P || !(D in N)) && p(N, D, T[D]);
                          else e({ target: n, proto: !0, forced: b || P }, T);
                        return (
                          (a && !k) || N[v] === w || p(N, v, w, { name: _ }),
                          (f[n] = w),
                          T
                        );
                      };
                    },
                    6206: function (t, n, r) {
                      var e = r(1938),
                        o = r(6864);
                      e(
                        {
                          target: "Array",
                          stat: !0,
                          forced: !r(8224)(function (e) {
                            Array.from(e);
                          }),
                        },
                        { from: o },
                      );
                    },
                    6215: function (t, n, r) {
                      var e = r(4090);
                      t.exports = e;
                    },
                    6312: function (t, n, r) {
                      var e,
                        o,
                        a = r(5391),
                        i = r(4084),
                        l = a.process,
                        s = a.Deno,
                        u = (l && l.versions) || (s && s.version),
                        c = u && u.v8;
                      (c &&
                        (o =
                          (e = c.split("."))[0] > 0 && e[0] < 4
                            ? 1
                            : +(e[0] + e[1])),
                        !o &&
                          i &&
                          (!(e = i.match(/Edge\/(\d+)/)) || e[1] >= 74) &&
                          (e = i.match(/Chrome\/(\d+)/)) &&
                          (o = +e[1]),
                        (t.exports = o));
                    },
                    6337: function (t, n) {
                      var e = {}.propertyIsEnumerable,
                        r = Object.getOwnPropertyDescriptor,
                        o = r && !e.call({ 1: 2 }, 1);
                      n.f = o
                        ? function (e) {
                            var t = r(this, e);
                            return !!t && t.enumerable;
                          }
                        : e;
                    },
                    6381: function (t, n, r) {
                      var e = r(5560),
                        o = r(2633),
                        a = r(2506),
                        i = r(8347),
                        l = r(5141),
                        s = TypeError,
                        u = Object.defineProperty,
                        c = Object.getOwnPropertyDescriptor,
                        d = "enumerable",
                        m = "configurable",
                        p = "writable";
                      n.f = e
                        ? a
                          ? function (e, t, n) {
                              if (
                                (i(e),
                                (t = l(t)),
                                i(n),
                                typeof e == "function" &&
                                  t === "prototype" &&
                                  "value" in n &&
                                  p in n &&
                                  !n[p])
                              ) {
                                var r = c(e, t);
                                r &&
                                  r[p] &&
                                  ((e[t] = n.value),
                                  (n = {
                                    configurable: m in n ? n[m] : r[m],
                                    enumerable: d in n ? n[d] : r[d],
                                    writable: !1,
                                  }));
                              }
                              return u(e, t, n);
                            }
                          : u
                        : function (e, t, n) {
                            if ((i(e), (t = l(t)), i(n), o))
                              try {
                                return u(e, t, n);
                              } catch (e) {}
                            if ("get" in n || "set" in n)
                              throw s("Accessors not supported");
                            return ("value" in n && (e[t] = n.value), e);
                          };
                    },
                    6399: function (t, n, r) {
                      var e = r(5663),
                        o = r(3514),
                        a = r(6153),
                        i = r(1113),
                        l = r(6615)("iterator");
                      t.exports = function (t) {
                        if (!a(t))
                          return o(t, l) || o(t, "@@iterator") || i[e(t)];
                      };
                    },
                    6408: function (t) {
                      t.exports = function (e) {
                        if (e != null) return e;
                        throw new Error("Got unexpected null or undefined");
                      };
                    },
                    6553: function (t, n, r) {
                      var e = r(9036),
                        o = r(7131),
                        a = r(2073),
                        i = r(5663),
                        l = r(7827),
                        s = r(6678),
                        u = function () {},
                        c = [],
                        d = l("Reflect", "construct"),
                        m = /^\s*(?:class|function)\b/,
                        p = e(m.exec),
                        _ = !m.exec(u),
                        f = function (t) {
                          if (!a(t)) return !1;
                          try {
                            return (d(u, c, t), !0);
                          } catch (e) {
                            return !1;
                          }
                        },
                        g = function (t) {
                          if (!a(t)) return !1;
                          switch (i(t)) {
                            case "AsyncFunction":
                            case "GeneratorFunction":
                            case "AsyncGeneratorFunction":
                              return !1;
                          }
                          try {
                            return _ || !!p(m, s(t));
                          } catch (e) {
                            return !0;
                          }
                        };
                      ((g.sham = !0),
                        (t.exports =
                          !d ||
                          o(function () {
                            var e;
                            return (
                              f(f.call) ||
                              !f(Object) ||
                              !f(function () {
                                e = !0;
                              }) ||
                              e
                            );
                          })
                            ? g
                            : f));
                    },
                    6601: function (t, n, r) {
                      var e = r(9077);
                      t.exports = function (t, n) {
                        return new (e(t))(n === 0 ? 0 : n);
                      };
                    },
                    6615: function (t, n, r) {
                      var e = r(5391),
                        o = r(3557),
                        a = r(4373),
                        i = r(7980),
                        l = r(7235),
                        s = r(1004),
                        u = e.Symbol,
                        c = o("wks"),
                        d = s ? u.for || u : (u && u.withoutSetter) || i;
                      t.exports = function (e) {
                        return (
                          a(c, e) ||
                            (c[e] = l && a(u, e) ? u[e] : d("Symbol." + e)),
                          c[e]
                        );
                      };
                    },
                    6678: function (t, n, r) {
                      var e = r(9036),
                        o = r(2073),
                        a = r(4993),
                        i = e(Function.toString);
                      (o(a.inspectSource) ||
                        (a.inspectSource = function (e) {
                          return i(e);
                        }),
                        (t.exports = a.inspectSource));
                    },
                    6731: function (t, n, r) {
                      var e = r(9036),
                        o = r(7131),
                        a = r(244),
                        i = Object,
                        l = e("".split);
                      t.exports = o(function () {
                        return !i("z").propertyIsEnumerable(0);
                      })
                        ? function (e) {
                            return a(e) === "String" ? l(e, "") : i(e);
                          }
                        : i;
                    },
                    6759: function (t, n, r) {
                      var e = r(1049);
                      t.exports = function (t) {
                        var n = +t;
                        return n != n || n === 0 ? 0 : e(n);
                      };
                    },
                    6864: function (t, n, r) {
                      var e = r(2116),
                        o = r(3057),
                        a = r(5809),
                        i = r(2843),
                        l = r(5669),
                        s = r(6553),
                        u = r(954),
                        c = r(8724),
                        d = r(7013),
                        m = r(6399),
                        p = Array;
                      t.exports = function (t) {
                        var n = a(t),
                          r = s(this),
                          _ = arguments.length,
                          f = _ > 1 ? arguments[1] : void 0,
                          g = f !== void 0;
                        g && (f = e(f, _ > 2 ? arguments[2] : void 0));
                        var h,
                          y,
                          C,
                          b,
                          v,
                          S,
                          R = m(n),
                          L = 0;
                        if (!R || (this === p && l(R)))
                          for (h = u(n), y = r ? new this(h) : p(h); h > L; L++)
                            ((S = g ? f(n[L], L) : n[L]), c(y, L, S));
                        else
                          for (
                            v = (b = d(n, R)).next, y = r ? new this() : [];
                            !(C = o(v, b)).done;
                            L++
                          )
                            ((S = g ? i(b, f, [C.value, L], !0) : C.value),
                              c(y, L, S));
                        return ((y.length = L), y);
                      };
                    },
                    7004: function (t, n, r) {
                      var e = r(3859);
                      t.exports = e;
                    },
                    7006: function (t, n, r) {
                      var e = r(9036),
                        o = r(182);
                      t.exports = function (t, n, r) {
                        try {
                          return e(o(Object.getOwnPropertyDescriptor(t, n)[r]));
                        } catch (e) {}
                      };
                    },
                    7007: function (t, n, r) {
                      var e = r(7131);
                      t.exports = !e(function () {
                        function e() {}
                        return (
                          (e.prototype.constructor = null),
                          Object.getPrototypeOf(new e()) !== e.prototype
                        );
                      });
                    },
                    7013: function (t, n, r) {
                      var e = r(3057),
                        o = r(182),
                        a = r(8347),
                        i = r(4003),
                        l = r(6399),
                        s = TypeError;
                      t.exports = function (t, n) {
                        var r = arguments.length < 2 ? l(t) : n;
                        if (o(r)) return a(e(r, t));
                        throw s(i(t) + " is not iterable");
                      };
                    },
                    7019: function (t, n, r) {
                      var e = r(1938),
                        o = r(4581).includes,
                        a = r(7131),
                        i = r(6065);
                      (e(
                        {
                          target: "Array",
                          proto: !0,
                          forced: a(function () {
                            return !Array(1).includes();
                          }),
                        },
                        {
                          includes: function (t) {
                            return o(
                              this,
                              t,
                              arguments.length > 1 ? arguments[1] : void 0,
                            );
                          },
                        },
                      ),
                        i("includes"));
                    },
                    7023: function (n) {
                      var e = G(t) == "object" && t.all,
                        r = e === void 0 && e !== void 0;
                      n.exports = { all: e, IS_HTMLDDA: r };
                    },
                    7078: function (t, n, r) {
                      var e = r(7481);
                      t.exports = e;
                    },
                    7102: function (t, n, r) {
                      var e = r(2373).IteratorPrototype,
                        o = r(3628),
                        a = r(3768),
                        i = r(5051),
                        l = r(1113),
                        s = function () {
                          return this;
                        };
                      t.exports = function (t, n, r, u) {
                        var c = n + " Iterator";
                        return (
                          (t.prototype = o(e, { next: a(+!u, r) })),
                          i(t, c, !1, !0),
                          (l[c] = s),
                          t
                        );
                      };
                    },
                    7104: function (t, n, r) {
                      var e = {};
                      ((e[r(6615)("toStringTag")] = "z"),
                        (t.exports = String(e) === "[object z]"));
                    },
                    7131: function (t) {
                      t.exports = function (e) {
                        try {
                          return !!e();
                        } catch (e) {
                          return !0;
                        }
                      };
                    },
                    7235: function (t, n, r) {
                      var e = r(6312),
                        o = r(7131),
                        a = r(5391).String;
                      t.exports =
                        !!Object.getOwnPropertySymbols &&
                        !o(function () {
                          var t = Symbol("symbol detection");
                          return (
                            !a(t) ||
                            !(Object(t) instanceof Symbol) ||
                            (!(typeof Symbol != "function" || Symbol.sham) &&
                              e &&
                              e < 41)
                          );
                        });
                    },
                    7244: function (t, n, r) {
                      var e = r(5391),
                        o = r(244);
                      t.exports = o(e.process) === "process";
                    },
                    7288: function (t, n, r) {
                      var e = r(6615)("match");
                      t.exports = function (t) {
                        var n = /./;
                        try {
                          "/./"[t](n);
                        } catch (r) {
                          try {
                            return ((n[e] = !1), "/./"[t](n));
                          } catch (e) {}
                        }
                        return !1;
                      };
                    },
                    7452: function (t, n, r) {
                      r(1306);
                      var e = r(8843);
                      t.exports = e("Array", "map");
                    },
                    7481: function (t, n, r) {
                      var e = r(7888);
                      t.exports = e;
                    },
                    7632: function (t, n, r) {
                      var e = r(235).charAt,
                        o = r(7803),
                        a = r(9257),
                        i = r(6188),
                        l = r(789),
                        s = "String Iterator",
                        u = a.set,
                        c = a.getterFor(s);
                      i(
                        String,
                        "String",
                        function (e) {
                          u(this, { type: s, string: o(e), index: 0 });
                        },
                        function () {
                          var t,
                            n = c(this),
                            r = n.string,
                            o = n.index;
                          return o >= r.length
                            ? l(void 0, !0)
                            : ((t = e(r, o)), (n.index += t.length), l(t, !1));
                        },
                      );
                    },
                    7675: function (t) {
                      t.exports = {};
                    },
                    7765: function (t, n, r) {
                      var e = r(1938),
                        o = r(2217).find,
                        a = r(6065),
                        i = "find",
                        l = !0;
                      (i in [] &&
                        Array(1)[i](function () {
                          l = !1;
                        }),
                        e(
                          { target: "Array", proto: !0, forced: l },
                          {
                            find: function (t) {
                              return o(
                                this,
                                t,
                                arguments.length > 1 ? arguments[1] : void 0,
                              );
                            },
                          },
                        ),
                        a(i));
                    },
                    7779: function (t) {
                      function e(t, n) {
                        for (var r = t.length, o = 0; r--; ) {
                          var a = t[o++];
                          Array.isArray(a) ? e(a, n) : n.push(a);
                        }
                      }
                      t.exports = function (t) {
                        var n = [];
                        return (e(t, n), n);
                      };
                    },
                    7803: function (t, n, r) {
                      var e = r(5663),
                        o = String;
                      t.exports = function (t) {
                        if (e(t) === "Symbol")
                          throw TypeError(
                            "Cannot convert a Symbol value to a string",
                          );
                        return o(t);
                      };
                    },
                    7827: function (t, n, r) {
                      var e = r(7675),
                        o = r(5391),
                        a = r(2073),
                        i = function (t) {
                          return a(t) ? t : void 0;
                        };
                      t.exports = function (t, n) {
                        return arguments.length < 2
                          ? i(e[t]) || i(o[t])
                          : (e[t] && e[t][n]) || (o[t] && o[t][n]);
                      };
                    },
                    7888: function (t, n, r) {
                      (r(7632), r(6206));
                      var e = r(7675);
                      t.exports = e.Array.from;
                    },
                    7959: function (t, n, r) {
                      var e = r(3057),
                        o = r(8347),
                        a = r(3514);
                      t.exports = function (t, n, r) {
                        var i, l;
                        o(t);
                        try {
                          if (!(i = a(t, "return"))) {
                            if (n === "throw") throw r;
                            return r;
                          }
                          i = e(i, t);
                        } catch (e) {
                          ((l = !0), (i = e));
                        }
                        if (n === "throw") throw r;
                        if (l) throw i;
                        return (o(i), r);
                      };
                    },
                    7980: function (t, n, r) {
                      var e = r(9036),
                        o = 0,
                        a = Math.random(),
                        i = e((1).toString);
                      t.exports = function (e) {
                        return (
                          "Symbol(" +
                          (e === void 0 ? "" : e) +
                          ")_" +
                          i(++o + a, 36)
                        );
                      };
                    },
                    7981: function (t, n, r) {
                      var e = r(9012);
                      t.exports = e;
                    },
                    8132: function (t, n, r) {
                      var e = r(1938),
                        o = r(266).left,
                        a = r(538),
                        i = r(6312);
                      e(
                        {
                          target: "Array",
                          proto: !0,
                          forced:
                            (!r(7244) && i > 79 && i < 83) || !a("reduce"),
                        },
                        {
                          reduce: function (t) {
                            var e = arguments.length;
                            return o(this, t, e, e > 1 ? arguments[1] : void 0);
                          },
                        },
                      );
                    },
                    8224: function (t, n, r) {
                      var e = r(6615)("iterator"),
                        o = !1;
                      try {
                        var a = 0,
                          i = {
                            next: function () {
                              return { done: !!a++ };
                            },
                            return: function () {
                              o = !0;
                            },
                          };
                        ((i[e] = function () {
                          return this;
                        }),
                          Array.from(i, function () {
                            throw 2;
                          }));
                      } catch (e) {}
                      t.exports = function (t, n) {
                        try {
                          if (!n && !o) return !1;
                        } catch (e) {
                          return !1;
                        }
                        var r = !1;
                        try {
                          var a = {};
                          ((a[e] = function () {
                            return {
                              next: function () {
                                return { done: (r = !0) };
                              },
                            };
                          }),
                            t(a));
                        } catch (e) {}
                        return r;
                      };
                    },
                    8327: function (t, n, r) {
                      var e = r(7078);
                      t.exports = e;
                    },
                    8347: function (t, n, r) {
                      var e = r(5774),
                        o = String,
                        a = TypeError;
                      t.exports = function (t) {
                        if (e(t)) return t;
                        throw a(o(t) + " is not an object");
                      };
                    },
                    8471: function (t, n, r) {
                      var e = r(5560),
                        o = r(6381),
                        a = r(3768);
                      t.exports = e
                        ? function (e, t, n) {
                            return o.f(e, t, a(1, n));
                          }
                        : function (e, t, n) {
                            return ((e[t] = n), e);
                          };
                    },
                    8630: function (t, n, r) {
                      var e = r(6759),
                        o = Math.max,
                        a = Math.min;
                      t.exports = function (t, n) {
                        var r = e(t);
                        return r < 0 ? o(r + n, 0) : a(r, n);
                      };
                    },
                    8698: function (t, n, r) {
                      var e = r(5391),
                        o = r(2073),
                        a = e.WeakMap;
                      t.exports = o(a) && /native code/.test(String(a));
                    },
                    8724: function (t, n, r) {
                      var e = r(5141),
                        o = r(6381),
                        a = r(3768);
                      t.exports = function (t, n, r) {
                        var i = e(n);
                        i in t ? o.f(t, i, a(0, r)) : (t[i] = r);
                      };
                    },
                    8760: function (t, n, r) {
                      var e = r(5837);
                      t.exports = e;
                    },
                    8843: function (t, n, r) {
                      var e = r(7827);
                      t.exports = e;
                    },
                    8890: function (t, n, r) {
                      var e = r(6153),
                        o = TypeError;
                      t.exports = function (t) {
                        if (e(t)) throw o("Can't call method on " + t);
                        return t;
                      };
                    },
                    8934: function (t, n, r) {
                      var e = r(2073),
                        o = String,
                        a = TypeError;
                      t.exports = function (t) {
                        if (G(t) == "object" || e(t)) return t;
                        throw a("Can't set " + o(t) + " as a prototype");
                      };
                    },
                    9e3: function (t, n, r) {
                      var e = r(244),
                        o = r(9036);
                      t.exports = function (t) {
                        if (e(t) === "Function") return o(t);
                      };
                    },
                    9012: function (t, n, r) {
                      r(2780);
                      var e = r(8843);
                      t.exports = e("String", "startsWith");
                    },
                    9036: function (t, n, r) {
                      var e = r(5164),
                        o = Function.prototype,
                        a = o.call,
                        i = e && o.bind.bind(a, a);
                      t.exports = e
                        ? i
                        : function (e) {
                            return function () {
                              return a.apply(e, arguments);
                            };
                          };
                    },
                    9077: function (t, n, r) {
                      var e = r(1972),
                        o = r(6553),
                        a = r(5774),
                        i = r(6615)("species"),
                        l = Array;
                      t.exports = function (t) {
                        var n;
                        return (
                          e(t) &&
                            ((n = t.constructor),
                            ((o(n) && (n === l || e(n.prototype))) ||
                              (a(n) && (n = n[i]) === null)) &&
                              (n = void 0)),
                          n === void 0 ? l : n
                        );
                      };
                    },
                    9157: function (t, n, r) {
                      var e = r(5560),
                        o = r(2506),
                        a = r(6381),
                        i = r(8347),
                        l = r(9441),
                        s = r(5556);
                      n.f =
                        e && !o
                          ? Object.defineProperties
                          : function (e, t) {
                              i(e);
                              for (
                                var n, r = l(t), o = s(t), u = o.length, c = 0;
                                u > c;
                              )
                                a.f(e, (n = o[c++]), r[n]);
                              return e;
                            };
                    },
                    9257: function (t, n, r) {
                      var e,
                        o,
                        a,
                        i = r(8698),
                        l = r(5391),
                        s = r(5774),
                        u = r(8471),
                        c = r(4373),
                        d = r(4993),
                        m = r(651),
                        p = r(6145),
                        _ = "Object already initialized",
                        f = l.TypeError,
                        g = l.WeakMap;
                      if (i || d.state) {
                        var h = d.state || (d.state = new g());
                        ((h.get = h.get),
                          (h.has = h.has),
                          (h.set = h.set),
                          (e = function (t, n) {
                            if (h.has(t)) throw f(_);
                            return ((n.facade = t), h.set(t, n), n);
                          }),
                          (o = function (t) {
                            return h.get(t) || {};
                          }),
                          (a = function (t) {
                            return h.has(t);
                          }));
                      } else {
                        var y = m("state");
                        ((p[y] = !0),
                          (e = function (t, n) {
                            if (c(t, y)) throw f(_);
                            return ((n.facade = t), u(t, y, n), n);
                          }),
                          (o = function (t) {
                            return c(t, y) ? t[y] : {};
                          }),
                          (a = function (t) {
                            return c(t, y);
                          }));
                      }
                      t.exports = {
                        set: e,
                        get: o,
                        has: a,
                        enforce: function (n) {
                          return a(n) ? o(n) : e(n, {});
                        },
                        getterFor: function (t) {
                          return function (e) {
                            var n;
                            if (!s(e) || (n = o(e)).type !== t)
                              throw f(
                                "Incompatible receiver, " + t + " required",
                              );
                            return n;
                          };
                        },
                      };
                    },
                    9417: function (t, n, r) {
                      var e = r(7827);
                      t.exports = e("document", "documentElement");
                    },
                    9441: function (t, n, r) {
                      var e = r(6731),
                        o = r(8890);
                      t.exports = function (t) {
                        return e(o(t));
                      };
                    },
                    9830: function (t, n, r) {
                      var e = r(7981);
                      t.exports = e;
                    },
                  },
                  r = {};
                function a(e) {
                  var t = r[e];
                  if (t !== void 0) return t.exports;
                  var o = (r[e] = { exports: {} });
                  return (n[e].call(o.exports, o, o.exports, a), o.exports);
                }
                ((a.n = function (e) {
                  var t =
                    e && e.__esModule
                      ? function () {
                          return e.default;
                        }
                      : function () {
                          return e;
                        };
                  return (a.d(t, { a: t }), t);
                }),
                  (a.d = function (e, t) {
                    for (var n in t)
                      a.o(t, n) &&
                        !a.o(e, n) &&
                        Object.defineProperty(e, n, {
                          enumerable: !0,
                          get: t[n],
                        });
                  }),
                  (a.g = (function () {
                    if (
                      (typeof globalThis == "undefined"
                        ? "undefined"
                        : G(globalThis)) == "object"
                    )
                      return globalThis;
                    try {
                      return this || new Function("return this")();
                    } catch (t) {
                      if (G(e) == "object") return e;
                    }
                  })()),
                  (a.o = function (e, t) {
                    return Object.prototype.hasOwnProperty.call(e, t);
                  }),
                  (a.r = function (e) {
                    (typeof Symbol != "undefined" &&
                      (typeof Symbol != "function" || Symbol.toStringTag) &&
                      Object.defineProperty(
                        e,
                        typeof Symbol == "function"
                          ? Symbol.toStringTag
                          : "@@toStringTag",
                        { value: "Module" },
                      ),
                      Object.defineProperty(e, "__esModule", { value: !0 }));
                  }));
                var i = {};
                (a.r(i),
                  a.d(i, {
                    MicrodataExtractionMethods: function () {
                      return Xo;
                    },
                    SignalsESTCustomData: function () {
                      return On;
                    },
                    SignalsESTRuleEngine: function () {
                      return bn;
                    },
                    getJsonLDForExtractors: function () {
                      return Me;
                    },
                    getParameterExtractorFromGraphPayload: function () {
                      return we;
                    },
                    inferredEventsSharedUtils: function () {
                      return Qo;
                    },
                    signalsConvertNodeToHTMLElement: function () {
                      return I;
                    },
                    signalsExtractButtonFeatures: function () {
                      return Bn;
                    },
                    signalsExtractForm: function () {
                      return Un;
                    },
                    signalsExtractPageFeatures: function () {
                      return Wn;
                    },
                    signalsGetButtonActionType: function () {
                      return Kn;
                    },
                    signalsGetButtonImageUrl: function () {
                      return Qe;
                    },
                    signalsGetTextFromElement: function () {
                      return u;
                    },
                    signalsGetTextOrValueFromElement: function () {
                      return Ue;
                    },
                    signalsGetTruncatedButtonText: function () {
                      return Vn;
                    },
                    signalsGetValueFromHTMLElement: function () {
                      return d;
                    },
                    signalsGetWrappingButton: function () {
                      return Xn;
                    },
                    signalsIsIWLElement: function () {
                      return Hn;
                    },
                    signalsIsSaneButton: function () {
                      return ot;
                    },
                    unicodeSafeTruncate: function () {
                      return Be;
                    },
                  }));
                var l = {};
                (a.r(l),
                  a.d(l, {
                    BUTTON_SELECTORS: function () {
                      return He;
                    },
                    BUTTON_SELECTOR_FORM_BLACKLIST: function () {
                      return ze;
                    },
                    BUTTON_SELECTOR_SEPARATOR: function () {
                      return Ve;
                    },
                    EXPLICIT_BUTTON_SELECTORS: function () {
                      return Ke;
                    },
                    EXTENDED_BUTTON_SELECTORS: function () {
                      return je;
                    },
                    LINK_TARGET_SELECTORS: function () {
                      return Ge;
                    },
                  }));
                var s = {};
                function u(e) {
                  if (e == null) return null;
                  if (e.innerText != null && e.innerText.length !== 0)
                    return e.innerText;
                  var t = e.text;
                  return t != null && typeof t == "string" && t.length !== 0
                    ? t
                    : e.textContent != null && e.textContent.length > 0
                      ? e.textContent
                      : null;
                }
                (a.r(s),
                  a.d(s, {
                    extractJsonLd: function () {
                      return Io;
                    },
                    extractMetaTagData: function () {
                      return Ho;
                    },
                    extractOpenGraph: function () {
                      return qo;
                    },
                    extractRDFa: function () {
                      return Ko;
                    },
                    extractSchemaOrg: function () {
                      return Ro;
                    },
                    jsonRepair: function () {
                      return jo;
                    },
                    mergeProductMetadata: function () {
                      return ho;
                    },
                    stripJsonComments: function () {
                      return zo;
                    },
                  }));
                var c = 500;
                function d(e) {
                  var t = e.tagName.toLowerCase(),
                    n = void 0;
                  switch (t) {
                    case "meta":
                      n = e.getAttribute("content");
                      break;
                    case "audio":
                    case "embed":
                    case "iframe":
                    case "img":
                    case "source":
                    case "track":
                    case "video":
                      n = e.getAttribute("src");
                      break;
                    case "a":
                    case "area":
                    case "link":
                      n = e.getAttribute("href");
                      break;
                    case "object":
                      n = e.getAttribute("data");
                      break;
                    case "data":
                    case "meter":
                      n = e.getAttribute("value");
                      break;
                    case "time":
                      n = e.getAttribute("datetime");
                      break;
                    default:
                      n = u(e) || "";
                  }
                  return (
                    t === "span" &&
                      (n == null || (typeof n == "string" && n === "")) &&
                      (n = e.getAttribute("content")),
                    typeof n == "string" ? n.substr(0, c) : ""
                  );
                }
                var m = [
                    "Order",
                    "AggregateOffer",
                    "CreativeWork",
                    "Event",
                    "MenuItem",
                    "Product",
                    "Service",
                    "Trip",
                    "ActionAccessSpecification",
                    "ConsumeAction",
                    "MediaSubscription",
                    "Organization",
                    "Person",
                  ],
                  p = a(4909),
                  _ = a.n(p),
                  f = a(6408),
                  g = a.n(f),
                  h = a(5109),
                  y = a.n(h),
                  C = a(8327),
                  b = a.n(C),
                  v = a(3550),
                  S = a.n(v),
                  R = a(4817),
                  L = a.n(R),
                  E = function (n) {
                    for (
                      var e = L()(m, function (e) {
                          return '[vocab$="'
                            .concat("http://schema.org/", '"][typeof$="')
                            .concat(e, '"]');
                        }).join(", "),
                        r = [],
                        o = b()(t.querySelectorAll(e)),
                        a = [];
                      o.length > 0;
                    ) {
                      var i = o.pop();
                      if (!S()(r, i)) {
                        var l = { "@context": "http://schema.org" };
                        a.push({ htmlElement: i, jsonLD: l });
                        for (
                          var s = [{ element: i, workingNode: l }];
                          s.length;
                        ) {
                          var u = s.pop(),
                            c = u.element,
                            p = u.workingNode,
                            f = g()(c.getAttribute("typeof"));
                          p["@type"] = f;
                          for (
                            var h = b()(
                              c.querySelectorAll("[property]"),
                            ).reverse();
                            h.length;
                          ) {
                            var C = h.pop();
                            if (!S()(r, C)) {
                              r.push(C);
                              var v = g()(C.getAttribute("property"));
                              if (C.hasAttribute("typeof")) {
                                var R = {};
                                ((p[v] = R),
                                  s.push({ element: c, workingNode: p }),
                                  s.push({ element: C, workingNode: R }));
                                break;
                              }
                              p[v] = d(C);
                            }
                          }
                        }
                      }
                    }
                    return y()(a, function (e) {
                      return _()(e.htmlElement, n);
                    });
                  };
                function k(e) {
                  return (
                    (k =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    k(e)
                  );
                }
                function I(e) {
                  return (
                    (typeof HTMLElement == "undefined"
                      ? "undefined"
                      : k(HTMLElement)) === "object"
                      ? e instanceof HTMLElement
                      : e != null &&
                        k(e) === "object" &&
                        e !== null &&
                        e.nodeType === 1 &&
                        typeof e.nodeName == "string"
                  )
                    ? e
                    : null;
                }
                var T = /^\s*:scope/gi,
                  D = function (t, n) {
                    if (n[n.length - 1] === ">") return [];
                    var e = n[0] === ">";
                    if ((D.CAN_USE_SCOPE || !n.match(T)) && !e)
                      return t.querySelectorAll(n);
                    var r = n;
                    e && (r = ":scope ".concat(n));
                    var o = !1;
                    t.id ||
                      ((t.id = "__fb_scoped_query_selector_" + Date.now()),
                      (o = !0));
                    var a = t.querySelectorAll(r.replace(T, "#" + t.id));
                    return (o && (t.id = ""), a);
                  };
                D.CAN_USE_SCOPE = !0;
                var x = t.createElement("div");
                try {
                  x.querySelectorAll(":scope *");
                } catch (e) {
                  D.CAN_USE_SCOPE = !1;
                }
                var $ = D,
                  P = a(7779),
                  N = a.n(P),
                  M = a(1001),
                  w = a.n(M),
                  A = a(5023),
                  F = a.n(A);
                function O(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return q(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    W(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function B(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          ((u = !0), (o = e));
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    W(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function W(e, t) {
                  if (e) {
                    if (typeof e == "string") return q(e, t);
                    var n = {}.toString.call(e).slice(8, -1);
                    return (
                      n === "Object" &&
                        e.constructor &&
                        (n = e.constructor.name),
                      n === "Map" || n === "Set"
                        ? Array.from(e)
                        : n === "Arguments" ||
                            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                          ? q(e, t)
                          : void 0
                    );
                  }
                }
                function q(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var U = "children(",
                  V = "closest(";
                function H(e, t) {
                  return z(
                    e,
                    y()(
                      L()(
                        t.split(/((?:closest|children)\([^)]+\))/),
                        function (e) {
                          return e.trim();
                        },
                      ),
                      Boolean,
                    ),
                  );
                }
                function z(e, t) {
                  var n = function (t, n) {
                      return n.substring(t.length, n.length - 1).trim();
                    },
                    r = L()(t, function (e) {
                      return F()(e, V)
                        ? { selector: n(V, e), type: "closest" }
                        : F()(e, U)
                          ? { selector: n(U, e), type: "children" }
                          : { selector: e, type: "standard" };
                    }),
                    o = w()(
                      r,
                      function (e, t) {
                        if (t.type !== "standard") return [].concat(O(e), [t]);
                        var n = e[e.length - 1];
                        return n && n.type === "standard"
                          ? ((n.selector += " " + t.selector), e)
                          : [].concat(O(e), [t]);
                      },
                      [],
                    );
                  return w()(
                    o,
                    function (e, t) {
                      return y()(
                        N()(
                          L()(e, function (e) {
                            return j(e, t);
                          }),
                        ),
                        Boolean,
                      );
                    },
                    [e],
                  );
                }
                var j = function (t, n) {
                  var e = n.selector;
                  switch (n.type) {
                    case "children":
                      if (t == null) return [];
                      var r = e.split(",");
                      if (r.length < 2)
                        throw new Error("Invalid selector format: ".concat(e));
                      var o = B(r, 2),
                        a = o[0],
                        i = o[1],
                        l = b()(
                          y()(b()(t.childNodes), function (e) {
                            return I(e) != null && e.matches(i);
                          }),
                        ),
                        s = parseInt(a, 0);
                      return s < 0 || s >= l.length ? [] : [l[s]];
                    case "closest":
                      return t.parentNode ? [t.parentNode.closest(e)] : [];
                    default:
                      return b()($(t, e));
                  }
                };
                if (
                  (Element.prototype.matches ||
                    (Element.prototype.matches =
                      Element.prototype.msMatchesSelector ||
                      Element.prototype.webkitMatchesSelector),
                  !Element.prototype.closest)
                ) {
                  var K = t.documentElement;
                  Element.prototype.closest = function (e) {
                    var t = this;
                    if (!K.contains(t)) return null;
                    do {
                      if (t.matches(e)) return t;
                      t = t.parentElement || t.parentNode;
                    } while (t !== null && t.nodeType === 1);
                    return null;
                  };
                }
                var Q = [
                  "og",
                  "product",
                  "music",
                  "video",
                  "article",
                  "book",
                  "profile",
                  "website",
                  "twitter",
                ];
                function X(e) {
                  return (
                    (X =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    X(e)
                  );
                }
                function Y(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    (t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r));
                  }
                  return n;
                }
                function J(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? Y(Object(n), !0).forEach(function (t) {
                          Z(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                        ? Object.defineProperties(
                            e,
                            Object.getOwnPropertyDescriptors(n),
                          )
                        : Y(Object(n)).forEach(function (t) {
                            Object.defineProperty(
                              e,
                              t,
                              Object.getOwnPropertyDescriptor(n, t),
                            );
                          });
                  }
                  return e;
                }
                function Z(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (X(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (X(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value.",
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return X(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var ee = function () {
                    var e = w()(
                      y()(
                        L()(
                          b()(t.querySelectorAll("meta[property]")),
                          function (e) {
                            var t = e.getAttribute("property"),
                              n = e.getAttribute("content");
                            return typeof t == "string" &&
                              t.indexOf(":") !== -1 &&
                              typeof n == "string" &&
                              S()(Q, t.split(":")[0])
                              ? { key: t, value: n.substr(0, c) }
                              : null;
                          },
                        ),
                        Boolean,
                      ),
                      function (e, t) {
                        return J(
                          J({}, e),
                          {},
                          Z({}, t.key, e[t.key] || t.value),
                        );
                      },
                      {},
                    );
                    return e["og:type"] !== "product.item"
                      ? null
                      : {
                          "@context": "http://schema.org",
                          "@type": "Product",
                          offers: {
                            price: e["product:price:amount"],
                            priceCurrency: e["product:price:currency"],
                          },
                          productID: e["product:retailer_item_id"],
                        };
                  },
                  te = a(8760),
                  ne = a.n(te);
                function re(e) {
                  return (
                    (re =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    re(e)
                  );
                }
                function oe(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    (t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r));
                  }
                  return n;
                }
                function ae(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? oe(Object(n), !0).forEach(function (t) {
                          ie(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                        ? Object.defineProperties(
                            e,
                            Object.getOwnPropertyDescriptors(n),
                          )
                        : oe(Object(n)).forEach(function (t) {
                            Object.defineProperty(
                              e,
                              t,
                              Object.getOwnPropertyDescriptor(n, t),
                            );
                          });
                  }
                  return e;
                }
                function ie(e, t, n) {
                  return (
                    (t = se(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                function le(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    ((r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, se(r.key), r));
                  }
                }
                function se(e) {
                  var t = (function (e, t) {
                    if (re(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (re(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value.",
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return re(t) == "symbol" ? t : t + "";
                }
                var ue = (function () {
                    return (
                      (e = function e(n) {
                        ((function (e, t) {
                          if (!(e instanceof t))
                            throw new TypeError(
                              "Cannot call a class as a function",
                            );
                        })(this, e),
                          (this._anchorElement = t.createElement("a")),
                          (this._anchorElement.href = n));
                      }),
                      (n = [
                        {
                          key: "hash",
                          get: function () {
                            return this._anchorElement.hash;
                          },
                        },
                        {
                          key: "host",
                          get: function () {
                            return this._anchorElement.host;
                          },
                        },
                        {
                          key: "hostname",
                          get: function () {
                            return this._anchorElement.hostname;
                          },
                        },
                        {
                          key: "pathname",
                          get: function () {
                            return this._anchorElement.pathname.replace(
                              /(^\/?)/,
                              "/",
                            );
                          },
                        },
                        {
                          key: "port",
                          get: function () {
                            return this._anchorElement.port;
                          },
                        },
                        {
                          key: "protocol",
                          get: function () {
                            return this._anchorElement.protocol;
                          },
                        },
                        {
                          key: "searchParams",
                          get: function () {
                            var e = this;
                            return {
                              get: function (n) {
                                if (e._parsedQuery != null)
                                  return e._parsedQuery[n] || null;
                                var t = e._anchorElement.search;
                                if (t === "" || t == null)
                                  return ((e._parsedQuery = {}), null);
                                var r = t[0] === "?" ? t.substring(1) : t;
                                return (
                                  (e._parsedQuery = w()(
                                    r.split("&"),
                                    function (e, t) {
                                      var n = t.split("=");
                                      return n == null || n.length !== 2
                                        ? e
                                        : ae(
                                            ae({}, e),
                                            {},
                                            ie(
                                              {},
                                              decodeURIComponent(n[0]),
                                              decodeURIComponent(n[1]),
                                            ),
                                          );
                                    },
                                    {},
                                  )),
                                  e._parsedQuery[n] || null
                                );
                              },
                            };
                          },
                        },
                        {
                          key: "toString",
                          value: function () {
                            return this._anchorElement.href;
                          },
                        },
                        {
                          key: "toJSON",
                          value: function () {
                            return this._anchorElement.href;
                          },
                        },
                      ]) && le(e.prototype, n),
                      r && le(e, r),
                      Object.defineProperty(e, "prototype", { writable: !1 }),
                      e
                    );
                    var e, n, r;
                  })(),
                  ce = "PATH",
                  de = "QUERY_STRING";
                function me(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return _e(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    pe(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function pe(e, t) {
                  if (e) {
                    if (typeof e == "string") return _e(e, t);
                    var n = {}.toString.call(e).slice(8, -1);
                    return (
                      n === "Object" &&
                        e.constructor &&
                        (n = e.constructor.name),
                      n === "Map" || n === "Set"
                        ? Array.from(e)
                        : n === "Arguments" ||
                            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                          ? _e(e, t)
                          : void 0
                    );
                  }
                }
                function _e(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function fe(e, t) {
                  var n = g()(I(e)).className,
                    r = g()(I(t)).className,
                    o = n.split(" "),
                    a = r.split(" ");
                  return o
                    .filter(function (e) {
                      return a.includes(e);
                    })
                    .toString();
                }
                var ge = 0,
                  he = 1,
                  ye = 2;
                function Ce(e, t) {
                  if (
                    (e && !t) ||
                    (!e && t) ||
                    e === void 0 ||
                    t === void 0 ||
                    e.nodeType !== t.nodeType ||
                    e.nodeName !== t.nodeName
                  )
                    return ge;
                  var n = I(e),
                    r = I(t);
                  if ((n && !r) || (!n && r)) return ge;
                  if (n && r) {
                    if (n.tagName !== r.tagName) return ge;
                    if (n.className === r.className) return he;
                  }
                  return ye;
                }
                function be(e, t, n, r) {
                  var o = Ce(e, r.node);
                  return o === ge
                    ? o
                    : n > 0 && t !== r.index
                      ? ge
                      : o === 1
                        ? he
                        : r.relativeClass.length === 0
                          ? ge
                          : (fe(e, r.node), r.relativeClass, he);
                }
                function ve(e, t, n, r) {
                  if (r === n.length - 1) {
                    if (!be(e, t, r, n[r])) return null;
                    var o = I(e);
                    if (o) return [o];
                  }
                  if (!e || !be(e, t, r, n[r])) return null;
                  for (var a = [], i = e.firstChild, l = 0; i; ) {
                    var s = ve(i, l, n, r + 1);
                    (s && a.push.apply(a, me(s)),
                      (i = i.nextSibling),
                      (l += 1));
                  }
                  return a;
                }
                function Se(e, t) {
                  var n,
                    r = [],
                    o = (function (e, t) {
                      var n =
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ]) ||
                        e["@@iterator"];
                      if (!n) {
                        if (
                          Array.isArray(e) ||
                          (n = pe(e)) ||
                          (t && e && typeof e.length == "number")
                        ) {
                          n && (e = n);
                          var r = 0,
                            o = function () {};
                          return {
                            s: o,
                            n: function () {
                              return r >= e.length
                                ? { done: !0 }
                                : { done: !1, value: e[r++] };
                            },
                            e: function (t) {
                              throw t;
                            },
                            f: o,
                          };
                        }
                        throw new TypeError(
                          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                        );
                      }
                      var a,
                        i = !0,
                        l = !1;
                      return {
                        s: function () {
                          n = n.call(e);
                        },
                        n: function () {
                          var e = n.next();
                          return ((i = e.done), e);
                        },
                        e: function (t) {
                          ((l = !0), (a = t));
                        },
                        f: function () {
                          try {
                            i || n.return == null || n.return();
                          } finally {
                            if (l) throw a;
                          }
                        },
                      };
                    })(e);
                  try {
                    for (o.s(); !(n = o.n()).done; ) {
                      var a = ve(n.value, 0, t, 0);
                      a && r.push.apply(r, me(a));
                    }
                  } catch (e) {
                    o.e(e);
                  } finally {
                    o.f();
                  }
                  return r;
                }
                function Re(e, t) {
                  var n = (function (e, t) {
                    for (
                      var n = function (t) {
                          var e = t.parentNode;
                          if (!e) return -1;
                          for (var n = e.firstChild, r = 0; n && n !== t; )
                            ((n = n.nextSibling), (r += 1));
                          return n === t ? r : -1;
                        },
                        r = e,
                        o = t,
                        a = [],
                        i = [];
                      !r.isSameNode(o);
                    ) {
                      var l = Ce(r, o);
                      if (l === ge) return null;
                      var s = "";
                      if (
                        (l === ye && (s = fe(r, o)).length === 0) ||
                        (a.push({ node: r, relativeClass: s, index: n(r) }),
                        i.push(o),
                        (r = r.parentNode),
                        (o = o.parentNode),
                        !r || !o)
                      )
                        return null;
                    }
                    return r && o && r.isSameNode(o) && a.length > 0
                      ? {
                          parentNode: r,
                          node1Tree: a.reverse(),
                          node2Tree: i.reverse(),
                        }
                      : null;
                  })(e, t);
                  if (!n) return null;
                  var r = (function (e, t, n) {
                    for (var r = [], o = e.firstChild; o; )
                      (o.isSameNode(t.node) ||
                        o.isSameNode(n) ||
                        !Ce(t.node, o) ||
                        r.push(o),
                        (o = o.nextSibling));
                    return r;
                  })(n.parentNode, n.node1Tree[0], n.node2Tree[0]);
                  return r && r.length !== 0 ? Se(r, n.node1Tree) : null;
                }
                function Le(e) {
                  return (
                    (Le =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    Le(e)
                  );
                }
                function Ee(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          ((u = !0), (o = e));
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return ke(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                  n,
                                )
                              ? ke(e, t)
                              : void 0
                        );
                      }
                    })(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function ke(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function Ie(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    (t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r));
                  }
                  return n;
                }
                function Te(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? Ie(Object(n), !0).forEach(function (t) {
                          De(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                        ? Object.defineProperties(
                            e,
                            Object.getOwnPropertyDescriptors(n),
                          )
                        : Ie(Object(n)).forEach(function (t) {
                            Object.defineProperty(
                              e,
                              t,
                              Object.getOwnPropertyDescriptor(n, t),
                            );
                          });
                  }
                  return e;
                }
                function De(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (Le(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (Le(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value.",
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return Le(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var xe = w()(
                    [
                      "CONSTANT_VALUE",
                      "CSS",
                      "URI",
                      "SCHEMA_DOT_ORG",
                      "JSON_LD",
                      "RDFA",
                      "OPEN_GRAPH",
                      "GTM",
                      "META_TAG",
                      "GLOBAL_VARIABLE",
                    ],
                    function (e, t, n) {
                      return Te(Te({}, e), {}, De({}, t, n));
                    },
                    {},
                  ),
                  $e = {
                    "@context": "http://schema.org",
                    "@type": "Product",
                    additionalType: void 0,
                    offers: { price: void 0, priceCurrency: void 0 },
                    productID: void 0,
                  },
                  Pe = function (t, n, r) {
                    if (r == null) return t;
                    var e = g()(t.offers);
                    return {
                      "@context": "http://schema.org",
                      "@type": "Product",
                      additionalType:
                        t.additionalType != null
                          ? t.additionalType
                          : n === "content_type"
                            ? r
                            : void 0,
                      offers: {
                        price:
                          e.price != null
                            ? e.price
                            : n === "value"
                              ? r
                              : void 0,
                        priceCurrency:
                          e.priceCurrency != null
                            ? e.priceCurrency
                            : n === "currency"
                              ? r
                              : void 0,
                      },
                      productID:
                        t.productID != null
                          ? t.productID
                          : n === "content_ids"
                            ? r
                            : void 0,
                    };
                  };
                function Ne(n, r) {
                  var o = r.sort(function (e, t) {
                    return xe[e.extractorType] > xe[t.extractorType] ? 1 : -1;
                  });
                  return y()(
                    N()(
                      L()(o, function (r) {
                        switch (r.extractorType) {
                          case "SCHEMA_DOT_ORG":
                            return L()(
                              (function (e) {
                                for (
                                  var n = "schema.org/",
                                    r = L()(m, function (e) {
                                      return '[itemtype$="'
                                        .concat(n)
                                        .concat(e, '"]');
                                    }).join(", "),
                                    o = [],
                                    a = b()(t.querySelectorAll(r)),
                                    i = [];
                                  a.length > 0;
                                ) {
                                  var l = a.pop();
                                  if (!S()(o, l)) {
                                    var s = { "@context": "http://schema.org" };
                                    i.push({ htmlElement: l, jsonLD: s });
                                    for (
                                      var u = [{ element: l, workingNode: s }];
                                      u.length;
                                    ) {
                                      var c = u.pop(),
                                        p = c.element,
                                        f = c.workingNode,
                                        h = g()(p.getAttribute("itemtype"));
                                      f["@type"] = h.substr(h.indexOf(n) + 11);
                                      for (
                                        var C = b()(
                                          p.querySelectorAll("[itemprop]"),
                                        ).reverse();
                                        C.length;
                                      ) {
                                        var v = C.pop();
                                        if (!S()(o, v)) {
                                          o.push(v);
                                          var R = g()(
                                            v.getAttribute("itemprop"),
                                          );
                                          if (v.hasAttribute("itemscope")) {
                                            var E = {};
                                            ((f[R] = E),
                                              u.push({
                                                element: p,
                                                workingNode: f,
                                              }),
                                              u.push({
                                                element: v,
                                                workingNode: E,
                                              }));
                                            break;
                                          }
                                          f[R] = d(v);
                                        }
                                      }
                                    }
                                  }
                                }
                                return y()(i, function (t) {
                                  return _()(t.htmlElement, e);
                                });
                              })(n),
                              function (e) {
                                return { extractorID: r.id, jsonLD: e.jsonLD };
                              },
                            );
                          case "RDFA":
                            return L()(E(n), function (e) {
                              return { extractorID: r.id, jsonLD: e.jsonLD };
                            });
                          case "OPEN_GRAPH":
                            return { extractorID: r.id, jsonLD: ee() };
                          case "CSS":
                            var o = L()(
                              r.extractorConfig.parameterSelectors,
                              function (e) {
                                var t;
                                return (t = H(n, e.selector)) === null ||
                                  t === void 0
                                  ? void 0
                                  : t[0];
                              },
                            );
                            if (o == null) return null;
                            if (o.length === 2) {
                              var a = o[0],
                                i = o[1];
                              if (a != null && i != null) {
                                var l = Re(a, i);
                                l && o.push.apply(o, l);
                              }
                            }
                            var s =
                                r.extractorConfig.parameterSelectors[0]
                                  .parameterType,
                              u = L()(o, function (e) {
                                var t =
                                  (e == null ? void 0 : e.innerText) ||
                                  (e == null ? void 0 : e.textContent);
                                return [s, t];
                              }),
                              c = L()(
                                y()(u, function (e) {
                                  return Ee(e, 1)[0] !== "totalPrice";
                                }),
                                function (e) {
                                  var t = Ee(e, 2),
                                    n = t[0],
                                    r = t[1];
                                  return Pe($e, n, r);
                                },
                              );
                            if (
                              r.eventType === "InitiateCheckout" ||
                              r.eventType === "Purchase"
                            ) {
                              var p = ne()(u, function (e) {
                                return Ee(e, 1)[0] === "totalPrice";
                              });
                              p &&
                                (c = [
                                  {
                                    "@context": "http://schema.org",
                                    "@type": "ItemList",
                                    itemListElement: L()(c, function (e, t) {
                                      return {
                                        "@type": "ListItem",
                                        item: e,
                                        position: t + 1,
                                      };
                                    }),
                                    totalPrice: p[1] != null ? p[1] : void 0,
                                  },
                                ]);
                            }
                            return L()(c, function (e) {
                              return { extractorID: r.id, jsonLD: e };
                            });
                          case "CONSTANT_VALUE":
                            var f = r.extractorConfig,
                              h = f.parameterType,
                              C = f.value;
                            return { extractorID: r.id, jsonLD: Pe($e, h, C) };
                          case "URI":
                            var v = r.extractorConfig.parameterType,
                              R = (function (e, t, n) {
                                var r = new ue(e);
                                switch (t) {
                                  case ce:
                                    var o = y()(
                                        L()(
                                          r.pathname.split("/"),
                                          function (e) {
                                            return e.trim();
                                          },
                                        ),
                                        Boolean,
                                      ),
                                      a = parseInt(n, 10);
                                    return a < o.length ? o[a] : null;
                                  case de:
                                    return r.searchParams.get(n);
                                }
                                return null;
                              })(
                                e.location.href,
                                r.extractorConfig.context,
                                r.extractorConfig.value,
                              );
                            return { extractorID: r.id, jsonLD: Pe($e, v, R) };
                          default:
                            throw new Error(
                              "Extractor ".concat(
                                r.extractorType,
                                " not mapped",
                              ),
                            );
                        }
                      }),
                    ),
                    function (e) {
                      var t = e.jsonLD;
                      return !!t;
                    },
                  );
                }
                Ne.EXTRACTOR_PRECEDENCE = xe;
                var Me = Ne;
                function we(e) {
                  var t;
                  switch (e.extractor_type) {
                    case "CSS":
                      var n;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var r = e.extractor_config;
                      if (r.parameter_type)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig:
                          ((t = r),
                          {
                            parameterSelectors: L()(
                              t.parameter_selectors,
                              function (e) {
                                return {
                                  parameterType: e.parameter_type,
                                  selector: e.selector,
                                };
                              },
                            ),
                          }),
                        extractorType: "CSS",
                        id: g()(e.id),
                        ruleId:
                          (n = e.event_rule) === null || n === void 0
                            ? void 0
                            : n.id,
                      };
                    case "CONSTANT_VALUE":
                      var o;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var a = e.extractor_config;
                      if (a.parameter_selectors)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig: Ae(a),
                        extractorType: "CONSTANT_VALUE",
                        id: g()(e.id),
                        ruleId:
                          (o = e.event_rule) === null || o === void 0
                            ? void 0
                            : o.id,
                      };
                    case "URI":
                      var i;
                      if (e.extractor_config == null)
                        throw new Error("extractor_config must be set");
                      var l = e.extractor_config;
                      if (l.parameter_selectors)
                        throw new Error("extractor_config must be set");
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorConfig: Fe(l),
                        extractorType: "URI",
                        id: g()(e.id),
                        ruleId:
                          (i = e.event_rule) === null || i === void 0
                            ? void 0
                            : i.id,
                      };
                    default:
                      var s;
                      return {
                        domainURI: new ue(e.domain_uri),
                        eventType: e.event_type,
                        extractorType: e.extractor_type,
                        id: g()(e.id),
                        ruleId:
                          (s = e.event_rule) === null || s === void 0
                            ? void 0
                            : s.id,
                      };
                  }
                }
                function Ae(e) {
                  return { parameterType: e.parameter_type, value: e.value };
                }
                function Fe(e) {
                  return {
                    context: e.context,
                    parameterType: e.parameter_type,
                    value: e.value,
                  };
                }
                Ne.EXTRACTOR_PRECEDENCE = xe;
                var Oe = function (t, n, r) {
                    return typeof t != "string"
                      ? ""
                      : t.length < r && n === 0
                        ? t
                        : []
                            .concat(b()(t))
                            .slice(n, n + r)
                            .join("");
                  },
                  Be = function (t, n) {
                    return Oe(t, 0, n);
                  },
                  We = 120,
                  qe = [
                    "button",
                    "submit",
                    "input",
                    "li",
                    "option",
                    "progress",
                    "param",
                  ];
                function Ue(e) {
                  var t = u(e);
                  if (t != null && t !== "") return Be(t, We);
                  var n = e.type,
                    r = e.value;
                  return n != null && S()(qe, n) && r != null && r !== ""
                    ? Be(r, We)
                    : Be("", We);
                }
                var Ve = ", ",
                  He = [
                    "input[type='button']",
                    "input[type='image']",
                    "input[type='submit']",
                    "button",
                    "[class*=btn]",
                    "[class*=Btn]",
                    "[class*=submit]",
                    "[class*=Submit]",
                    "[class*=button]",
                    "[class*=Button]",
                    "[role*=button]",
                    "[href^='tel:']",
                    "[href^='callto:']",
                    "[href^='mailto:']",
                    "[href^='sms:']",
                    "[href^='skype:']",
                    "[href^='whatsapp:']",
                    "[id*=btn]",
                    "[id*=Btn]",
                    "[id*=button]",
                    "[id*=Button]",
                    "a",
                  ].join(Ve),
                  Ge = ["[href^='http://']", "[href^='https://']"].join(Ve),
                  ze = [
                    "[href^='tel:']",
                    "[href^='callto:']",
                    "[href^='sms:']",
                    "[href^='skype:']",
                    "[href^='whatsapp:']",
                  ].join(Ve),
                  je = He,
                  Ke = [
                    "input[type='button']",
                    "input[type='submit']",
                    "button",
                    "a",
                  ].join(Ve);
                function Qe(t) {
                  var n = "";
                  if (t.tagName === "IMG") return t.getAttribute("src") || "";
                  if (e.getComputedStyle) {
                    var r = e
                      .getComputedStyle(t)
                      .getPropertyValue("background-image");
                    if (r != null && r !== "none" && r.length > 0) return r;
                  }
                  if (
                    t.tagName === "INPUT" &&
                    t.getAttribute("type") === "image"
                  ) {
                    var o = t.getAttribute("src");
                    if (o != null) return o;
                  }
                  var a = t.getElementsByTagName("img");
                  if (a.length !== 0) {
                    var i = a.item(0);
                    n = (i ? i.getAttribute("src") : null) || "";
                  }
                  return n;
                }
                var Xe = [
                    "sms:",
                    "mailto:",
                    "tel:",
                    "whatsapp:",
                    "https://wa.me/",
                    "skype:",
                    "callto:",
                  ],
                  Ye = /[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g,
                  Je = /((([a-z])(?=[A-Z]))|(([A-Z])(?=[A-Z][a-z])))/g,
                  Ze = /(^\S{1}(?!\S))|((\s)\S{1}(?!\S))/g,
                  et = /\s+/g;
                function tt(e) {
                  return (
                    !!(function (e) {
                      var t = Xe;
                      if (!e.hasAttribute("href")) return !1;
                      var n = e.getAttribute("href");
                      return (
                        n != null &&
                        !!ne()(t, function (e) {
                          return F()(n, e);
                        })
                      );
                    })(e) ||
                    !!Ue(e)
                      .replace(Ye, " ")
                      .replace(Je, function (e) {
                        return e + " ";
                      })
                      .replace(Ze, function (e) {
                        return Be(e, e.length - 1) + " ";
                      })
                      .replace(et, " ")
                      .trim()
                      .toLowerCase() ||
                    !!Qe(e)
                  );
                }
                var nt = 600,
                  rt = 10;
                function ot(e) {
                  if (e == null || e === t.body || !tt(e)) return !1;
                  var n =
                    (typeof e.getBoundingClientRect == "function" &&
                      e.getBoundingClientRect().height) ||
                    e.offsetHeight;
                  return !isNaN(n) && n < nt && n > rt;
                }
                function at(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    ((r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, it(r.key), r));
                  }
                }
                function it(e) {
                  var t = (function (e, t) {
                    if (lt(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (lt(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value.",
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return lt(t) == "symbol" ? t : t + "";
                }
                function lt(e) {
                  return (
                    (lt =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    lt(e)
                  );
                }
                var st = Object.prototype.toString,
                  ut = !("addEventListener" in t);
                function ct(e) {
                  return Array.isArray
                    ? Array.isArray(e)
                    : st.call(e) === "[object Array]";
                }
                function dt(e) {
                  return e != null && lt(e) === "object" && ct(e) === !1;
                }
                function mt(e) {
                  return (
                    dt(e) === !0 &&
                    Object.prototype.toString.call(e) === "[object Object]"
                  );
                }
                var pt =
                    Number.isInteger ||
                    function (e) {
                      return (
                        typeof e == "number" &&
                        isFinite(e) &&
                        Math.floor(e) === e
                      );
                    },
                  _t = Object.prototype.hasOwnProperty,
                  ft = !{ toString: null }.propertyIsEnumerable("toString"),
                  gt = [
                    "toString",
                    "toLocaleString",
                    "valueOf",
                    "hasOwnProperty",
                    "isPrototypeOf",
                    "propertyIsEnumerable",
                    "constructor",
                  ],
                  ht = gt.length;
                function yt(e) {
                  if (
                    lt(e) !== "object" &&
                    (typeof e != "function" || e === null)
                  )
                    throw new TypeError("Object.keys called on non-object");
                  var t = [];
                  for (var n in e) _t.call(e, n) && t.push(n);
                  if (ft)
                    for (var r = 0; r < ht; r++)
                      _t.call(e, gt[r]) && t.push(gt[r]);
                  return t;
                }
                function Ct(e, t) {
                  if (e == null)
                    throw new TypeError(" array is null or not defined");
                  var n = Object(e),
                    r = n.length >>> 0;
                  if (typeof t != "function")
                    throw new TypeError(t + " is not a function");
                  for (var o = new Array(r), a = 0; a < r; ) {
                    var i = void 0;
                    (a in n && ((i = t(n[a], a, n)), (o[a] = i)), a++);
                  }
                  return o;
                }
                function bt(e) {
                  if (typeof e != "function") throw new TypeError();
                  for (
                    var t = Object(this),
                      n = t.length >>> 0,
                      r = arguments.length >= 2 ? arguments[1] : void 0,
                      o = 0;
                    o < n;
                    o++
                  )
                    if (o in t && e.call(r, t[o], o, t)) return !0;
                  return !1;
                }
                function vt(e) {
                  if (this == null) throw new TypeError();
                  var t = Object(this),
                    n = t.length >>> 0;
                  if (typeof e != "function") throw new TypeError();
                  for (
                    var r = [],
                      o = arguments.length >= 2 ? arguments[1] : void 0,
                      a = 0;
                    a < n;
                    a++
                  )
                    if (a in t) {
                      var i = t[a];
                      e.call(o, i, a, t) && r.push(i);
                    }
                  return r;
                }
                function St(e, t) {
                  try {
                    return t(e);
                  } catch (e) {
                    if (e instanceof TypeError) {
                      if (Rt.test(e)) return null;
                      if (Lt.test(e)) return;
                    }
                    throw e;
                  }
                }
                var Rt = /^null | null$|^[^(]* null /i,
                  Lt = /^undefined | undefined$|^[^(]* undefined /i;
                St.default = St;
                var Et = {
                    FBSet: (function () {
                      return (
                        (e = function e(t) {
                          ((function (e, t) {
                            if (!(e instanceof t))
                              throw new TypeError(
                                "Cannot call a class as a function",
                              );
                          })(this, e),
                            (this.items = t || []));
                        }),
                        (t = [
                          {
                            key: "has",
                            value: function (t) {
                              return bt.call(this.items, function (e) {
                                return e === t;
                              });
                            },
                          },
                          {
                            key: "add",
                            value: function (t) {
                              this.items.push(t);
                            },
                          },
                        ]) && at(e.prototype, t),
                        n && at(e, n),
                        Object.defineProperty(e, "prototype", { writable: !1 }),
                        e
                      );
                      var e, t, n;
                    })(),
                    castTo: function (t) {
                      return t;
                    },
                    each: function (t, n) {
                      Ct.call(this, t, n);
                    },
                    filter: function (t, n) {
                      return vt.call(t, n);
                    },
                    idx: St,
                    isArray: ct,
                    isEmptyObject: function (t) {
                      return yt(t).length === 0;
                    },
                    isInstanceOf: function (t, n) {
                      return n != null && t instanceof n;
                    },
                    isInteger: pt,
                    isNumber: function (t) {
                      return (
                        typeof t == "number" ||
                        (typeof t == "string" && /^\d+$/.test(t))
                      );
                    },
                    isObject: dt,
                    isPlainObject: function (t) {
                      if (mt(t) === !1) return !1;
                      var e = t.constructor;
                      if (typeof e != "function") return !1;
                      var n = e.prototype;
                      return (
                        mt(n) !== !1 &&
                        Object.prototype.hasOwnProperty.call(
                          n,
                          "isPrototypeOf",
                        ) !== !1
                      );
                    },
                    isSafeInteger: function (t) {
                      return pt(t) && t >= 0 && t <= Number.MAX_SAFE_INTEGER;
                    },
                    keys: yt,
                    listenOnce: function (t, n, r) {
                      var e = ut ? "on" + n : n,
                        o = ut ? t.attachEvent : t.addEventListener,
                        a = ut ? t.detachEvent : t.removeEventListener,
                        i = function () {
                          (a && a.call(t, e, i, !1), r());
                        };
                      o && o.call(t, e, i, !1);
                    },
                    map: Ct,
                    reduce: function (t, n, r, o) {
                      if (t == null)
                        throw new TypeError(" array is null or not defined");
                      if (typeof n != "function")
                        throw new TypeError(n + " is not a function");
                      var e,
                        a = Object(t),
                        i = a.length >>> 0,
                        l = 0;
                      if (r != null || o === !0) e = r;
                      else {
                        for (; l < i && !(l in a); ) l++;
                        if (l >= i)
                          throw new TypeError(
                            "Reduce of empty array with no initial value",
                          );
                        e = a[l++];
                      }
                      for (; l < i; ) (l in a && (e = n(e, a[l], l, t)), l++);
                      return e;
                    },
                    some: function (t, n) {
                      return bt.call(t, n);
                    },
                    stringIncludes: function (t, n) {
                      return t != null && n != null && t.indexOf(n) >= 0;
                    },
                    stringStartsWith: function (t, n) {
                      return t != null && n != null && t.indexOf(n) === 0;
                    },
                  },
                  kt = Et;
                function It(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    (t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r));
                  }
                  return n;
                }
                function Tt(e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t] != null ? arguments[t] : {};
                    t % 2
                      ? It(Object(n), !0).forEach(function (t) {
                          Dt(e, t, n[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                        ? Object.defineProperties(
                            e,
                            Object.getOwnPropertyDescriptors(n),
                          )
                        : It(Object(n)).forEach(function (t) {
                            Object.defineProperty(
                              e,
                              t,
                              Object.getOwnPropertyDescriptor(n, t),
                            );
                          });
                  }
                  return e;
                }
                function Dt(e, t, n) {
                  return (
                    (t = Pt(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                function xt(e) {
                  return (
                    (xt =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    xt(e)
                  );
                }
                function $t(e, t) {
                  for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    ((r.enumerable = r.enumerable || !1),
                      (r.configurable = !0),
                      "value" in r && (r.writable = !0),
                      Object.defineProperty(e, Pt(r.key), r));
                  }
                }
                function Pt(e) {
                  var t = (function (e, t) {
                    if (xt(e) != "object" || !e) return e;
                    var n =
                      e[
                        typeof Symbol == "function"
                          ? Symbol.toPrimitive
                          : "@@toPrimitive"
                      ];
                    if (n !== void 0) {
                      var r = n.call(e, t || "default");
                      if (xt(r) != "object") return r;
                      throw new TypeError(
                        "@@toPrimitive must return a primitive value.",
                      );
                    }
                    return (t === "string" ? String : Number)(e);
                  })(e, "string");
                  return xt(t) == "symbol" ? t : t + "";
                }
                function Nt(e, t, n) {
                  return (
                    (t = Ft(t)),
                    (function (e, t) {
                      if (t && (xt(t) == "object" || typeof t == "function"))
                        return t;
                      if (t !== void 0)
                        throw new TypeError(
                          "Derived constructors may only return object or undefined",
                        );
                      return (function (e) {
                        if (e === void 0)
                          throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called",
                          );
                        return e;
                      })(e);
                    })(
                      e,
                      wt()
                        ? Reflect.construct(t, n || [], Ft(e).constructor)
                        : t.apply(e, n),
                    )
                  );
                }
                function Mt(e) {
                  var t = typeof Map == "function" ? new Map() : void 0;
                  return (
                    (Mt = function (n) {
                      if (
                        n === null ||
                        !(function (e) {
                          try {
                            return (
                              Function.toString
                                .call(e)
                                .indexOf("[native code]") !== -1
                            );
                          } catch (t) {
                            return typeof e == "function";
                          }
                        })(n)
                      )
                        return n;
                      if (typeof n != "function")
                        throw new TypeError(
                          "Super expression must either be null or a function",
                        );
                      if (t !== void 0) {
                        if (t.has(n)) return t.get(n);
                        t.set(n, e);
                      }
                      function e() {
                        return (function (e, t, n) {
                          if (wt())
                            return Reflect.construct.apply(null, arguments);
                          var r = [null];
                          r.push.apply(r, t);
                          var o = new (e.bind.apply(e, r))();
                          return (n && At(o, n.prototype), o);
                        })(n, arguments, Ft(this).constructor);
                      }
                      return (
                        (e.prototype = Object.create(n.prototype, {
                          constructor: {
                            value: e,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0,
                          },
                        })),
                        At(e, n)
                      );
                    }),
                    Mt(e)
                  );
                }
                function wt() {
                  try {
                    var e = !Boolean.prototype.valueOf.call(
                      Reflect.construct(Boolean, [], function () {}),
                    );
                  } catch (e) {}
                  return (wt = function () {
                    return !!e;
                  })();
                }
                function At(e, t) {
                  return (
                    (At = Object.setPrototypeOf
                      ? Object.setPrototypeOf.bind()
                      : function (e, t) {
                          return ((e.__proto__ = t), e);
                        }),
                    At(e, t)
                  );
                }
                function Ft(e) {
                  return (
                    (Ft = Object.setPrototypeOf
                      ? Object.getPrototypeOf.bind()
                      : function (e) {
                          return e.__proto__ || Object.getPrototypeOf(e);
                        }),
                    Ft(e)
                  );
                }
                var Ot = kt.isSafeInteger,
                  Bt = kt.reduce,
                  Wt = (function (e) {
                    function t() {
                      var e,
                        n =
                          arguments.length > 0 && arguments[0] !== void 0
                            ? arguments[0]
                            : "";
                      return (
                        (function (e, t) {
                          if (!(e instanceof t))
                            throw new TypeError(
                              "Cannot call a class as a function",
                            );
                        })(this, t),
                        ((e = Nt(this, t, [n])).name = "PixelCoercionError"),
                        e
                      );
                    }
                    return (
                      (function (e, t) {
                        if (typeof t != "function" && t !== null)
                          throw new TypeError(
                            "Super expression must either be null or a function",
                          );
                        ((e.prototype = Object.create(t && t.prototype, {
                          constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0,
                          },
                        })),
                          Object.defineProperty(e, "prototype", {
                            writable: !1,
                          }),
                          t && At(e, t));
                      })(t, e),
                      (n = t),
                      r && $t(n.prototype, r),
                      o && $t(n, o),
                      Object.defineProperty(n, "prototype", { writable: !1 }),
                      n
                    );
                    var n, r, o;
                  })(Mt(Error));
                function qt() {
                  return function (e) {
                    if (e == null || !Array.isArray(e)) throw new Wt();
                    return e;
                  };
                }
                function Ut(e, t) {
                  try {
                    return t(e);
                  } catch (e) {
                    if (e.name === "PixelCoercionError") return null;
                    throw e;
                  }
                }
                function Vt(e, t) {
                  return t(e);
                }
                function Ht(e) {
                  if (!e) throw new Wt();
                }
                function Gt(e) {
                  var t = e.def,
                    n = e.validators;
                  return function (e) {
                    var r = Vt(e, t);
                    return (
                      n.forEach(function (e) {
                        if (!e(r)) throw new Wt();
                      }),
                      r
                    );
                  };
                }
                var zt = /^[1-9][0-9]{0,25}$/,
                  jt = {
                    allowNull: function (t) {
                      return function (e) {
                        return e == null ? null : t(e);
                      };
                    },
                    array: qt,
                    arrayOf: function (t) {
                      return function (e) {
                        return Vt(e, jt.array()).map(t);
                      };
                    },
                    assert: Ht,
                    boolean: function () {
                      return function (e) {
                        if (typeof e != "boolean") throw new Wt();
                        return e;
                      };
                    },
                    enumeration: function (t) {
                      return function (e) {
                        if (((n = t), Object.values(n)).includes(e)) return e;
                        var n;
                        throw new Wt();
                      };
                    },
                    fbid: function () {
                      return Gt({
                        def: function (t) {
                          var e = Ut(t, jt.number());
                          return e != null
                            ? (jt.assert(Ot(e)), "".concat(e))
                            : Vt(t, jt.string());
                        },
                        validators: [
                          function (e) {
                            return zt.test(e);
                          },
                        ],
                      });
                    },
                    mapOf: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.object());
                        return Bt(
                          Object.keys(n),
                          function (e, r) {
                            return Tt(Tt({}, e), {}, Dt({}, r, t(n[r])));
                          },
                          {},
                        );
                      };
                    },
                    matches: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.string());
                        if (t.test(n)) return n;
                        throw new Wt();
                      };
                    },
                    number: function () {
                      return function (e) {
                        if (typeof e != "number") throw new Wt();
                        return e;
                      };
                    },
                    object: function () {
                      return function (e) {
                        if (xt(e) !== "object" || Array.isArray(e) || e == null)
                          throw new Wt();
                        return e;
                      };
                    },
                    objectOrString: function () {
                      return function (e) {
                        if (
                          (xt(e) !== "object" && typeof e != "string") ||
                          Array.isArray(e) ||
                          e == null
                        )
                          throw new Wt();
                        return e;
                      };
                    },
                    objectWithFields: function (t) {
                      return function (e) {
                        var n = Vt(e, jt.object());
                        return Bt(
                          Object.keys(t),
                          function (e, r) {
                            if (e == null) return null;
                            var o = (0, t[r])(n[r]);
                            return Tt(Tt({}, e), {}, Dt({}, r, o));
                          },
                          {},
                        );
                      };
                    },
                    string: function () {
                      return function (e) {
                        if (typeof e != "string") throw new Wt();
                        return e;
                      };
                    },
                    stringOrNumber: function () {
                      return function (e) {
                        if (typeof e != "string" && typeof e != "number")
                          throw new Wt();
                        return e;
                      };
                    },
                    tuple: function (t) {
                      return function (e) {
                        var n = Vt(e, qt());
                        return (
                          Ht(n.length === t.length),
                          n.map(function (e, n) {
                            return Vt(e, t[n]);
                          })
                        );
                      };
                    },
                    withValidation: Gt,
                    func: function () {
                      return function (e) {
                        if (typeof e != "function" || e == null) throw new Wt();
                        return e;
                      };
                    },
                  },
                  Kt = {
                    Typed: jt,
                    coerce: Ut,
                    enforce: Vt,
                    PixelCoercionError: Wt,
                  },
                  Qt = Kt.Typed,
                  Xt = Qt.objectWithFields({
                    type: Qt.withValidation({
                      def: Qt.number(),
                      validators: [
                        function (e) {
                          return e >= 1 && e <= 3;
                        },
                      ],
                    }),
                    conditions: Qt.arrayOf(
                      Qt.objectWithFields({
                        targetType: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 6;
                            },
                          ],
                        }),
                        extractor: Qt.allowNull(
                          Qt.withValidation({
                            def: Qt.number(),
                            validators: [
                              function (e) {
                                return e >= 1 && e <= 11;
                              },
                            ],
                          }),
                        ),
                        operator: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 4;
                            },
                          ],
                        }),
                        action: Qt.withValidation({
                          def: Qt.number(),
                          validators: [
                            function (e) {
                              return e >= 1 && e <= 4;
                            },
                          ],
                        }),
                        value: Qt.allowNull(Qt.string()),
                      }),
                    ),
                  }),
                  Yt = "*";
                function Jt(e) {
                  var t = [],
                    n = e;
                  do {
                    var r = n.indexOf(Yt);
                    r < 0
                      ? (t.push(n), (n = ""))
                      : r === 0
                        ? (t.push(Yt), (n = n.slice(1)))
                        : (t.push(n.slice(0, r)), (n = n.slice(r)));
                  } while (n.length > 0);
                  return t;
                }
                var Zt = function (t, n) {
                  for (var e = Jt(t), r = n, o = 0; o < e.length; o++) {
                    var a = e[o];
                    if (a !== Yt) {
                      if (r.indexOf(a) !== 0) return !1;
                      r = r.slice(a.length);
                    } else {
                      if (o === e.length - 1) return !0;
                      var i = e[o + 1];
                      if (i === Yt) continue;
                      var l = r.indexOf(i);
                      if (l < 0) return !1;
                      r = r.slice(l);
                    }
                  }
                  return r === "";
                };
                function en(e, t) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return e;
                    })(e) ||
                    (function (e, t) {
                      var n =
                        e == null
                          ? null
                          : (typeof Symbol != "undefined" &&
                              e[
                                typeof Symbol == "function"
                                  ? Symbol.iterator
                                  : "@@iterator"
                              ]) ||
                            e["@@iterator"];
                      if (n != null) {
                        var r,
                          o,
                          a,
                          i,
                          l = [],
                          s = !0,
                          u = !1;
                        try {
                          if (((a = (n = n.call(e)).next), t === 0)) {
                            if (Object(n) !== n) return;
                            s = !1;
                          } else
                            for (
                              ;
                              !(s = (r = a.call(n)).done) &&
                              (l.push(r.value), l.length !== t);
                              s = !0
                            );
                        } catch (e) {
                          ((u = !0), (o = e));
                        } finally {
                          try {
                            if (
                              !s &&
                              n.return != null &&
                              ((i = n.return()), Object(i) !== i)
                            )
                              return;
                          } finally {
                            if (u) throw o;
                          }
                        }
                        return l;
                      }
                    })(e, t) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return tn(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                  n,
                                )
                              ? tn(e, t)
                              : void 0
                        );
                      }
                    })(e, t) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function tn(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var nn = Kt.enforce,
                  rn = Zt,
                  on = Object.freeze({
                    CLICK: 1,
                    LOAD: 2,
                    BECOME_VISIBLE: 3,
                    TRACK: 4,
                  }),
                  an = Object.freeze({
                    BUTTON: 1,
                    PAGE: 2,
                    JS_VARIABLE: 3,
                    EVENT: 4,
                    ELEMENT: 6,
                  }),
                  ln = Object.freeze({
                    CONTAINS: 1,
                    EQUALS: 2,
                    DOMAIN_MATCHES: 3,
                    STRING_MATCHES: 4,
                  }),
                  sn = Object.freeze({
                    URL: 1,
                    TOKENIZED_TEXT_V1: 2,
                    TOKENIZED_TEXT_V2: 3,
                    TEXT: 4,
                    CLASS_NAME: 5,
                    ELEMENT_ID: 6,
                    EVENT_NAME: 7,
                    DESTINATION_URL: 8,
                    DOMAIN: 9,
                    PAGE_TITLE: 10,
                    IMAGE_URL: 11,
                  }),
                  un = Object.freeze({ ALL: 1, ANY: 2, NONE: 3 });
                function cn(e, t, n) {
                  if (t == null) return null;
                  switch (e) {
                    case an.PAGE:
                      return (function (e, t) {
                        switch (e) {
                          case sn.URL:
                            return t.resolvedLink;
                          case sn.DOMAIN:
                            return new URL(t.resolvedLink).hostname;
                          case sn.PAGE_TITLE:
                            if (t.pageFeatures != null)
                              return JSON.parse(
                                t.pageFeatures,
                              ).title.toLowerCase();
                            break;
                          default:
                            return null;
                        }
                      })(t, n);
                    case an.BUTTON:
                      return (function (e, t) {
                        var n;
                        t.buttonText != null &&
                          (n = t.buttonText.toLowerCase());
                        var r = {};
                        switch (
                          (t.buttonFeatures != null &&
                            (r = JSON.parse(t.buttonFeatures)),
                          e)
                        ) {
                          case sn.DESTINATION_URL:
                            return r.destination;
                          case sn.TEXT:
                            return n;
                          case sn.TOKENIZED_TEXT_V1:
                            return n == null ? null : pn(n);
                          case sn.TOKENIZED_TEXT_V2:
                            return n == null ? null : _n(n);
                          case sn.ELEMENT_ID:
                            return r.id;
                          case sn.CLASS_NAME:
                            return r.classList;
                          case sn.IMAGE_URL:
                            return r.imageUrl;
                          default:
                            return null;
                        }
                      })(t, n);
                    case an.EVENT:
                      return (function (e, t) {
                        return e === sn.EVENT_NAME ? t.event : null;
                      })(t, n);
                    default:
                      return null;
                  }
                }
                function dn(e) {
                  return e != null ? e.split("#")[0] : e;
                }
                function mn(e, t) {
                  var n = e.replace(
                      /[\-!$><-==&_\/\?\.,0-9:; \]\[%~\"\{\}\)\(\+\@\^\`]/g,
                      " ",
                    ),
                    r = n.replace(/([A-Z])/g, " $1").split(" ");
                  if (r == null || r.length === 0) return "";
                  n = en(r, 1)[0];
                  for (var o = 1; o < r.length; o++)
                    r[o - 1] != null &&
                    r[o] != null &&
                    r[o - 1].length === 1 &&
                    r[o].length === 1 &&
                    r[o - 1] === r[o - 1].toUpperCase() &&
                    r[o] === r[o].toUpperCase()
                      ? (n += r[o])
                      : (n += " " + r[o]);
                  var a = n.split(" ");
                  if (a == null || a.length === 0) return n;
                  n = "";
                  for (var i = t ? 1 : 2, l = 0; l < a.length; l++)
                    a[l] != null && a[l].length > i && (n += a[l] + " ");
                  return n.replace(/\s+/g, " ");
                }
                function pn(e) {
                  var t = mn(e, !0).toLowerCase().split(" ");
                  return t
                    .filter(function (e, n) {
                      return t.indexOf(e) === n;
                    })
                    .join(" ")
                    .trim();
                }
                function _n(e) {
                  return mn(e, !1).toLowerCase().trim();
                }
                function fn(e, t) {
                  if (t.startsWith("*.")) {
                    var n = t.slice(2).split(".").reverse(),
                      r = e.split(".").reverse();
                    if (n.length !== r.length) return !1;
                    for (var o = 0; o < n.length; o++)
                      if (n[o] !== r[o]) return !1;
                    return !0;
                  }
                  return e === t;
                }
                function gn(e) {
                  try {
                    var t = new URL(e),
                      n = t.searchParams;
                    return (
                      n.delete("utm_source"),
                      n.delete("utm_medium"),
                      n.delete("utm_campaign"),
                      n.delete("utm_content"),
                      n.delete("utm_term"),
                      n.delete("utm_id"),
                      n.delete("utm_name"),
                      n.delete("fbclid"),
                      n.delete("fb_action_ids"),
                      n.delete("fb_action_types"),
                      n.delete("fb_source"),
                      n.delete("fb_aggregation_id"),
                      n.sort(),
                      t.origin + t.pathname + "?" + n.toString()
                    );
                  } catch (t) {
                    return e;
                  }
                }
                function hn(e) {
                  try {
                    return unescape(encodeURIComponent(e));
                  } catch (t) {
                    return e;
                  }
                }
                function yn(e, t, n) {
                  var r =
                    arguments.length > 3 &&
                    arguments[3] !== void 0 &&
                    arguments[3];
                  switch (e) {
                    case ln.EQUALS:
                      return (function (e, t) {
                        var n =
                            arguments.length > 2 &&
                            arguments[2] !== void 0 &&
                            arguments[2],
                          r =
                            e === t ||
                            e.toLowerCase() === hn(t).toLowerCase() ||
                            pn(e) === t ||
                            dn(e) === dn(t);
                        if (!n || r) return r;
                        var o = t.toLowerCase(),
                          a = e.toLowerCase();
                        return (
                          (r =
                            (r = r || a === o) ||
                            hn(a).toLowerCase() === hn(o).toLowerCase()),
                          (r = (r = pn(a) === o) || dn(a) === dn(o)) ||
                            gn(a) === gn(o)
                        );
                      })(t, n, r);
                    case ln.CONTAINS:
                      return n != null && n.includes(t);
                    case ln.DOMAIN_MATCHES:
                      return fn(n, t);
                    case ln.STRING_MATCHES:
                      return n != null && rn(t, n);
                    default:
                      return !1;
                  }
                }
                function Cn(e, t) {
                  var n =
                    arguments.length > 2 &&
                    arguments[2] !== void 0 &&
                    arguments[2];
                  if (
                    !(function (e, t) {
                      switch (e) {
                        case on.LOAD:
                          return t.event === "PageView";
                        case on.CLICK:
                          return t.event === "SubscribedButtonClick";
                        case on.TRACK:
                          return !0;
                        case on.BECOME_VISIBLE:
                        default:
                          return !1;
                      }
                    })(e.action, t)
                  )
                    return !1;
                  var r = cn(e.targetType, e.extractor, t);
                  if (r == null) return !1;
                  var o = e.value;
                  return (
                    o != null &&
                    ((e.extractor !== sn.TOKENIZED_TEXT_V1 &&
                      e.extractor !== sn.TOKENIZED_TEXT_V2) ||
                      (o = o.toLowerCase()),
                    yn(e.operator, o, r, n))
                  );
                }
                var bn = {
                    isMatchESTRule: function (t, n) {
                      var e =
                          arguments.length > 2 &&
                          arguments[2] !== void 0 &&
                          arguments[2],
                        r = t;
                      typeof t == "string" && (r = JSON.parse(t));
                      for (
                        var o = nn(r, Xt), a = [], i = 0;
                        i < o.conditions.length;
                        i++
                      )
                        a.push(Cn(o.conditions[i], n, e));
                      switch (o.type) {
                        case un.ALL:
                          return !a.includes(!1);
                        case un.ANY:
                          return a.includes(!0);
                        case un.NONE:
                          return !a.includes(!0);
                      }
                      return !1;
                    },
                    getKeywordsStringFromTextV1: pn,
                    getKeywordsStringFromTextV2: _n,
                    domainMatches: fn,
                  },
                  vn = Kt.coerce,
                  Sn = Kt.Typed,
                  Rn = kt.each,
                  Ln = kt.filter,
                  En = kt.reduce,
                  kn = [
                    "product",
                    "product_group",
                    "vehicle",
                    "automotive_model",
                  ],
                  In = Sn.objectWithFields({
                    "@context": Sn.string(),
                    additionalType: Sn.allowNull(Sn.string()),
                    offers: Sn.allowNull(
                      Sn.objectWithFields({
                        priceCurrency: Sn.allowNull(Sn.string()),
                        price: Sn.allowNull(Sn.string()),
                      }),
                    ),
                    productID: Sn.allowNull(Sn.string()),
                    sku: Sn.allowNull(Sn.string()),
                    "@type": Sn.string(),
                  }),
                  Tn = Sn.objectWithFields({
                    "@context": Sn.string(),
                    "@type": Sn.string(),
                    item: In,
                  }),
                  Dn = Sn.objectWithFields({
                    "@context": Sn.string(),
                    "@type": Sn.string(),
                    itemListElement: Sn.array(),
                    totalPrice: Sn.allowNull(Sn.string()),
                  });
                function xn(e) {
                  var t = vn(e, In);
                  if (t == null) return null;
                  var n = typeof t.productID == "string" ? t.productID : null,
                    r = typeof t.sku == "string" ? t.sku : null,
                    o = t.offers,
                    a = null,
                    i = null;
                  o != null && ((a = Mn(o.price)), (i = o.priceCurrency));
                  var l =
                      typeof t.additionalType == "string" &&
                      kn.includes(t.additionalType)
                        ? t.additionalType
                        : null,
                    s = [n, r],
                    u = {};
                  return (
                    (s = Ln(s, function (e) {
                      return e != null;
                    })).length && (u.content_ids = s),
                    i != null && (u.currency = i),
                    a != null && (u.value = a),
                    l != null && (u.content_type = l),
                    [u]
                  );
                }
                function $n(e) {
                  var t = vn(e, Tn);
                  return t == null ? null : Nn([t.item]);
                }
                function Pn(e) {
                  var t = vn(e, Dn);
                  if (t == null) return null;
                  var n = typeof t.totalPrice == "string" ? t.totalPrice : null;
                  n = Mn(n);
                  var r = Nn(t.itemListElement),
                    o = null;
                  return (
                    r != null &&
                      r.length > 0 &&
                      (o = En(
                        r,
                        function (e, t) {
                          var n = t.value;
                          if (n == null) return e;
                          try {
                            var r = parseFloat(n);
                            return e == null ? r : e + r;
                          } catch (t) {
                            return e;
                          }
                        },
                        null,
                        !0,
                      )),
                    (r = [
                      { value: n },
                      { value: o != null ? o.toString() : null },
                    ].concat(r))
                  );
                }
                function Nn(e) {
                  var t = [];
                  return (
                    Rn(e, function (n) {
                      if (e != null) {
                        var r =
                          typeof n["@type"] == "string" ? n["@type"] : null;
                        if (r !== null) {
                          var o = null;
                          switch (r) {
                            case "Product":
                              o = xn(n);
                              break;
                            case "ItemList":
                              o = Pn(n);
                              break;
                            case "ListItem":
                              o = $n(n);
                          }
                          o != null && (t = t.concat(o));
                        }
                      }
                    }),
                    (t = Ln(t, function (e) {
                      return e != null;
                    })),
                    Rn(t, function (e) {
                      Rn(Object.keys(e), function (t) {
                        var n = e[t];
                        (Array.isArray(n) && n.length > 0) ||
                          (typeof n == "string" && n !== "") ||
                          delete e[t];
                      });
                    }),
                    (t = Ln(t, function (e) {
                      return Object.keys(e).length > 0;
                    }))
                  );
                }
                function Mn(e) {
                  if (e == null) return null;
                  var t = e.replace(/\\u[\dA-F]{4}/gi, function (e) {
                    var t = e.replace(/\\u/g, ""),
                      n = parseInt(t, 16);
                    return String.fromCharCode(n);
                  });
                  if (
                    ((t = (function (e) {
                      var t = e;
                      if (t.length >= 3) {
                        var n = t.substring(t.length - 3);
                        if (/((\.)(\d)(0)|(\,)(0)(0))/.test(n)) {
                          var r = n.charAt(0),
                            o = n.charAt(1),
                            a = n.charAt(2);
                          (o !== "0" && (r += o),
                            a !== "0" && (r += a),
                            r.length === 1 && (r = ""),
                            (t = t.substring(0, t.length - 3) + r));
                        }
                      }
                      return t;
                    })(
                      (t = (t = (t = t.replace(/[^\d,\.]/g, "")).replace(
                        /(\.){2,}/g,
                        "",
                      )).replace(/(\,){2,}/g, "")),
                    )),
                    !wn(t))
                  )
                    return null;
                  var n = (function (e) {
                    var t = e;
                    if (t == null) return null;
                    var n = (function (e) {
                        var t = e.replace(/\,/g, "");
                        return Fn((t = An(t)), !1);
                      })(t),
                      r = (function (e) {
                        var t = e.replace(/\./g, "");
                        return Fn((t = An((t = t.replace(/\,/g, ".")))), !0);
                      })(t);
                    if (n == null || r == null)
                      return n != null ? n : r != null ? r : null;
                    var o = r.length;
                    return (
                      o > 0 && r.charAt(o - 1) !== "0" && (o -= 1),
                      n.length >= o ? n : r
                    );
                  })(t);
                  return n == null ? null : wn((t = n)) ? t : null;
                }
                function wn(e) {
                  return /\d/.test(e);
                }
                function An(e) {
                  var t = e,
                    n = t.indexOf(".");
                  return n < 0
                    ? t
                    : (t =
                        t.substring(0, n + 1) +
                        t.substring(n + 1).replace(/\./g, ""));
                }
                function Fn(e, t) {
                  try {
                    var n = parseFloat(e);
                    if (typeof (o = n) != "number" || Number.isNaN(o))
                      return null;
                    var r = t ? 3 : 2;
                    return parseFloat(n.toFixed(r)).toString();
                  } catch (e) {
                    return null;
                  }
                  var o;
                }
                var On = {
                    genCustomData: Nn,
                    reduceCustomData: function (t) {
                      if (t.length === 0) return {};
                      var e = En(
                        t,
                        function (e, t) {
                          return (
                            Rn(Object.keys(t), function (n) {
                              var r = t[n],
                                o = e[n];
                              if (o == null) e[n] = r;
                              else if (Array.isArray(o)) {
                                var a = Array.isArray(r) ? r : [r];
                                e[n] = o.concat(a);
                              }
                            }),
                            e
                          );
                        },
                        {},
                      );
                      return (
                        Rn(Object.keys(e), function (t) {
                          (e[t], e[t] == null && delete e[t]);
                        }),
                        e
                      );
                    },
                    getProductData: xn,
                    getItemListData: Pn,
                    getListItemData: $n,
                    genNormalizePrice: Mn,
                  },
                  Bn = function (t, n) {
                    var e = t.id,
                      r = t.tagName,
                      o = u(t),
                      a = r.toLowerCase(),
                      i = t.className,
                      l = t.querySelectorAll(He).length,
                      s = null;
                    (t.tagName === "A" &&
                    t instanceof HTMLAnchorElement &&
                    t.href
                      ? (s = t.href)
                      : n != null &&
                        n instanceof HTMLFormElement &&
                        n.action &&
                        (s = n.action),
                      typeof s != "string" && (s = ""));
                    var c = {
                      classList: i,
                      destination: s,
                      id: e,
                      imageUrl: Qe(t),
                      innerText: o || "",
                      numChildButtons: l,
                      tag: a,
                      type: t.getAttribute("type"),
                    };
                    return (
                      (t instanceof HTMLInputElement ||
                        t instanceof HTMLSelectElement ||
                        t instanceof HTMLTextAreaElement ||
                        t instanceof HTMLButtonElement) &&
                        ((c.name = t.name), (c.value = t.value)),
                      t instanceof HTMLAnchorElement && (c.name = t.name),
                      c
                    );
                  },
                  Wn = function () {
                    var e = t.querySelector("title");
                    return { title: Be(e && e.text, 500) };
                  },
                  qn = function (t, n) {
                    var e = t,
                      r =
                        t.matches ||
                        e.matchesSelector ||
                        e.mozMatchesSelector ||
                        e.msMatchesSelector ||
                        e.oMatchesSelector ||
                        e.webkitMatchesSelector ||
                        null;
                    return r !== null && r.bind(t)(n);
                  },
                  Un = function (t) {
                    if (t instanceof HTMLInputElement) return t.form;
                    if (qn(t, ze)) return null;
                    for (var e = I(t); e.nodeName !== "FORM"; ) {
                      var n = I(e.parentElement);
                      if (n == null) return null;
                      e = n;
                    }
                    return e;
                  },
                  Vn = function (t) {
                    return Ue(t).substring(0, 200);
                  },
                  Hn = function (n) {
                    if (
                      e.FacebookIWL != null &&
                      e.FacebookIWL.getIWLRoot != null &&
                      typeof e.FacebookIWL.getIWLRoot == "function"
                    ) {
                      var t = e.FacebookIWL.getIWLRoot();
                      return t && t.contains(n);
                    }
                    return !1;
                  },
                  Gn = "Outbound",
                  zn = "Download",
                  jn = [
                    ".pdf",
                    ".docx",
                    ".doc",
                    ".txt",
                    ".jpg",
                    ".jpeg",
                    ".png",
                    ".gif",
                    ".mp3",
                    ".wav",
                    ".ogg",
                    ".zip",
                    ".rar",
                    ".7z",
                    ".exe",
                    ".msi",
                    ".xlsx",
                    ".xls",
                    ".pptx",
                    ".ppt",
                  ],
                  Kn = function (n) {
                    var t = [],
                      r = e.location.hostname,
                      o = n.getAttribute("href");
                    return (
                      o !== null &&
                        o !== "" &&
                        typeof o == "string" &&
                        (o.startsWith("http://") || o.startsWith("https://")) &&
                        (new URL(o).host !== r && t.push(Gn),
                        jn.some(function (e) {
                          return o.endsWith(e);
                        }) && t.push(zn)),
                      t
                    );
                  },
                  Qn = (0, kt.filter)(He.split(Ve), function (e) {
                    return e !== "a";
                  }).join(Ve),
                  Xn = function e(t, n, r) {
                    if (t == null || !ot(t)) return null;
                    if (qn(t, n ? He : Qn)) return t;
                    if (r && qn(t, Ge)) {
                      var o = Kn(t);
                      if (o != null && o.length > 0) return t;
                    }
                    var a = I(t.parentNode);
                    return a != null ? e(a, n, r) : null;
                  },
                  Yn = 32,
                  Jn = 10,
                  Zn = 9,
                  er = 13,
                  tr = 160,
                  nr = 8192,
                  rr = 8202,
                  or = 8239,
                  ar = 8287,
                  ir = 12288;
                function lr(e) {
                  return /^[0-9A-Fa-f]$/.test(e);
                }
                function sr(e) {
                  return e >= "0" && e <= "9";
                }
                function ur(e) {
                  return ",:[]/{}()\n+".includes(e);
                }
                function cr(e) {
                  return (
                    (e >= "a" && e <= "z") ||
                    (e >= "A" && e <= "Z") ||
                    e === "_" ||
                    e === "$"
                  );
                }
                function dr(e) {
                  return (
                    (e >= "a" && e <= "z") ||
                    (e >= "A" && e <= "Z") ||
                    e === "_" ||
                    e === "$" ||
                    (e >= "0" && e <= "9")
                  );
                }
                var mr = /^(http|https|ftp|mailto|file|data|irc):\/\/$/,
                  pr = /^[A-Za-z0-9-._~:/?#@!$&\'()*+;=]$/;
                function _r(e) {
                  return ",[]/{}\n+".includes(e);
                }
                function fr(e) {
                  return br(e) || gr.test(e);
                }
                var gr = /^[[{\w-]$/;
                function hr(e, t) {
                  var n = e.charCodeAt(t);
                  return n === Yn || n === Jn || n === Zn || n === er;
                }
                function yr(e, t) {
                  var n = e.charCodeAt(t);
                  return n === Yn || n === Zn || n === er;
                }
                function Cr(e, t) {
                  var n = e.charCodeAt(t);
                  return (
                    n === tr ||
                    (n >= nr && n <= rr) ||
                    n === or ||
                    n === ar ||
                    n === ir
                  );
                }
                function br(e) {
                  return vr(e) || Rr(e);
                }
                function vr(e) {
                  return e === '"' || e === "\u201C" || e === "\u201D";
                }
                function Sr(e) {
                  return e === '"';
                }
                function Rr(e) {
                  return (
                    e === "'" ||
                    e === "\u2018" ||
                    e === "\u2019" ||
                    e === "`" ||
                    e === "\xB4"
                  );
                }
                function Lr(e) {
                  return e === "'";
                }
                function Er(e, t) {
                  var n =
                      arguments.length > 2 &&
                      arguments[2] !== void 0 &&
                      arguments[2],
                    r = e.lastIndexOf(t);
                  return r !== -1
                    ? e.substring(0, r) + (n ? "" : e.substring(r + 1))
                    : e;
                }
                function kr(e, t) {
                  var n = e.length;
                  if (!hr(e, n - 1)) return e + t;
                  for (; hr(e, n - 1); ) n--;
                  return e.substring(0, n) + t + e.substring(n);
                }
                function Ir(e, t, n) {
                  return e.substring(0, t) + e.substring(t + n);
                }
                function Tr(e, t) {
                  var n =
                    (typeof Symbol != "undefined" &&
                      e[
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator"
                      ]) ||
                    e["@@iterator"];
                  if (!n) {
                    if (
                      Array.isArray(e) ||
                      (n = (function (e, t) {
                        if (e) {
                          if (typeof e == "string") return Dr(e, t);
                          var n = {}.toString.call(e).slice(8, -1);
                          return (
                            n === "Object" &&
                              e.constructor &&
                              (n = e.constructor.name),
                            n === "Map" || n === "Set"
                              ? Array.from(e)
                              : n === "Arguments" ||
                                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                    n,
                                  )
                                ? Dr(e, t)
                                : void 0
                          );
                        }
                      })(e)) ||
                      (t && e && typeof e.length == "number")
                    ) {
                      n && (e = n);
                      var r = 0,
                        o = function () {};
                      return {
                        s: o,
                        n: function () {
                          return r >= e.length
                            ? { done: !0 }
                            : { done: !1, value: e[r++] };
                        },
                        e: function (t) {
                          throw t;
                        },
                        f: o,
                      };
                    }
                    throw new TypeError(
                      "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                    );
                  }
                  var a,
                    i = !0,
                    l = !1;
                  return {
                    s: function () {
                      n = n.call(e);
                    },
                    n: function () {
                      var e = n.next();
                      return ((i = e.done), e);
                    },
                    e: function (t) {
                      ((l = !0), (a = t));
                    },
                    f: function () {
                      try {
                        i || n.return == null || n.return();
                      } finally {
                        if (l) throw a;
                      }
                    },
                  };
                }
                function Dr(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                var xr = {
                    "\b": "\\b",
                    "\f": "\\f",
                    "\n": "\\n",
                    "\r": "\\r",
                    "	": "\\t",
                  },
                  $r = {
                    '"': '"',
                    "\\": "\\",
                    "/": "/",
                    b: "\b",
                    f: "\f",
                    n: "\n",
                    r: "\r",
                    t: "	",
                  };
                function Pr(e) {
                  var t = 0,
                    n = "";
                  (s(["```", "[```", "{```"]),
                    o() ||
                      (function () {
                        throw new Error(
                          "Unexpected end of json string at position ".concat(
                            e.length,
                          ),
                        );
                      })(),
                    s(["```", "```]", "```}"]));
                  var r = u(",");
                  for (
                    r && a(),
                      fr(e[t]) &&
                      (function (e) {
                        return /[,\n][ \t\r]*$/.test(e);
                      })(n)
                        ? (r || (n = kr(n, ",")),
                          (function () {
                            for (var e = !0, t = !0; t; )
                              (e ? (e = !1) : u(",") || (n = kr(n, ",")),
                                (t = o()));
                            (t || (n = Er(n, ",")),
                              (n = "[\n".concat(n, "\n]")));
                          })())
                        : r && (n = Er(n, ","));
                    e[t] === "}" || e[t] === "]";
                  )
                    (t++, a());
                  if (t >= e.length) return n;
                  function o() {
                    a();
                    var r =
                      (function () {
                        if (e[t] !== "{") return !1;
                        ((n += "{"), t++, a(), c(",") && a());
                        for (var r = !0; t < e.length && e[t] !== "}"; ) {
                          if (
                            (r ? (r = !1) : (u(",") || (n = kr(n, ",")), a()),
                            m(),
                            !(p() || S(!0)))
                          ) {
                            e[t] === "}" ||
                            e[t] === "{" ||
                            e[t] === "]" ||
                            e[t] === "[" ||
                            e[t] === void 0
                              ? (n = Er(n, ","))
                              : k();
                            break;
                          }
                          a();
                          var i = u(":"),
                            l = t >= e.length;
                          (i || (fr(e[t]) || l ? (n = kr(n, ":")) : I()),
                            o() || (i || l ? (n += "null") : I()));
                        }
                        return (
                          (function () {
                            e[t] === "}" ? ((n += "}"), t++) : (n = kr(n, "}"));
                          })(),
                          !0
                        );
                      })() ||
                      (function () {
                        if (e[t] === "[") {
                          ((n += "["), t++, a(), c(",") && a());
                          for (var r = !0; t < e.length && e[t] !== "]"; )
                            if (
                              (r ? (r = !1) : u(",") || (n = kr(n, ",")),
                              m(),
                              !o())
                            ) {
                              n = Er(n, ",");
                              break;
                            }
                          return (
                            e[t] === "]" ? ((n += "]"), t++) : (n = kr(n, "]")),
                            !0
                          );
                        }
                        return !1;
                      })() ||
                      p() ||
                      (function () {
                        var r = t;
                        if (e[t] === "-") {
                          if ((t++, L())) return (E(r), !0);
                          if (!sr(e[t])) return ((t = r), !1);
                        }
                        for (; sr(e[t]); ) t++;
                        if (e[t] === ".") {
                          if ((t++, L())) return (E(r), !0);
                          if (!sr(e[t])) return ((t = r), !1);
                          for (; sr(e[t]); ) t++;
                        }
                        if (e[t] === "e" || e[t] === "E") {
                          if ((t++, (e[t] !== "-" && e[t] !== "+") || t++, L()))
                            return (E(r), !0);
                          if (!sr(e[t])) return ((t = r), !1);
                          for (; sr(e[t]); ) t++;
                        }
                        if (!L()) return ((t = r), !1);
                        if (t > r) {
                          var o = e.slice(r, t),
                            a = /^0\d/.test(o);
                          return ((n += a ? '"'.concat(o, '"') : o), !0);
                        }
                        return !1;
                      })() ||
                      v("true", "true") ||
                      v("false", "false") ||
                      v("null", "null") ||
                      v("True", "true") ||
                      v("False", "false") ||
                      v("None", "null") ||
                      S(!1) ||
                      (function () {
                        if (e[t] === "/") {
                          var r = t;
                          for (
                            t++;
                            t < e.length && (e[t] !== "/" || e[t - 1] === "\\");
                          )
                            t++;
                          return (
                            t++,
                            (n += '"'.concat(e.substring(r, t), '"')),
                            !0
                          );
                        }
                      })();
                    return (a(), r);
                  }
                  function a() {
                    var e =
                        !(arguments.length > 0 && arguments[0] !== void 0) ||
                        arguments[0],
                      n = t,
                      r = i(e);
                    do (r = l()) && (r = i(e));
                    while (r);
                    return t > n;
                  }
                  function i(r) {
                    for (var o = r ? hr : yr, a = ""; ; )
                      if (o(e, t)) ((a += e[t]), t++);
                      else {
                        if (!Cr(e, t)) break;
                        ((a += " "), t++);
                      }
                    return a.length > 0 && ((n += a), !0);
                  }
                  function l() {
                    if (e[t] === "/" && e[t + 1] === "*") {
                      for (; t < e.length && !Nr(e, t); ) t++;
                      return ((t += 2), !0);
                    }
                    if (e[t] === "/" && e[t + 1] === "/") {
                      for (; t < e.length && e[t] !== "\n"; ) t++;
                      return !0;
                    }
                    return !1;
                  }
                  function s(n) {
                    if (
                      (function (n) {
                        var r,
                          o = Tr(n);
                        try {
                          for (o.s(); !(r = o.n()).done; ) {
                            var a = r.value,
                              i = t + a.length;
                            if (e.slice(t, i) === a) return ((t = i), !0);
                          }
                        } catch (e) {
                          o.e(e);
                        } finally {
                          o.f();
                        }
                        return !1;
                      })(n)
                    ) {
                      if (cr(e[t])) for (; t < e.length && dr(e[t]); ) t++;
                      return (a(), !0);
                    }
                    return !1;
                  }
                  function u(r) {
                    return e[t] === r && ((n += e[t]), t++, !0);
                  }
                  function c(n) {
                    return e[t] === n && (t++, !0);
                  }
                  function d() {
                    return c("\\");
                  }
                  function m() {
                    return (
                      a(),
                      e[t] === "." &&
                        e[t + 1] === "." &&
                        e[t + 2] === "." &&
                        ((t += 3), a(), c(","), !0)
                    );
                  }
                  function p() {
                    var r =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      o =
                        arguments.length > 1 && arguments[1] !== void 0
                          ? arguments[1]
                          : -1,
                      a = e[t] === "\\";
                    if ((a && (t++, (a = !0)), !br(e[t]))) return !1;
                    var i = Sr(e[t]) ? Sr : Lr(e[t]) ? Lr : Rr(e[t]) ? Rr : vr,
                      l = t,
                      s = n.length,
                      u = '"';
                    for (t++; ; ) {
                      var c = {
                          str: u,
                          stopAtDelimiter: r,
                          iBefore: l,
                          oBefore: s,
                          stopAtIndex: o,
                          isEndQuote: i,
                        },
                        m = _(c);
                      if (m !== null) return m;
                      var p = f(c);
                      if (p !== null) return p;
                      var b = g(c);
                      if (b !== null) {
                        if (b.shouldContinue) {
                          u = b.str;
                          continue;
                        }
                        return b.result;
                      }
                      var v = h(c);
                      if (v !== null) return v;
                      var S = y(u);
                      ((u = S !== null ? S : C(u)), a && d());
                    }
                  }
                  function _(r) {
                    if (t >= e.length) {
                      var o = r.str,
                        a = r.stopAtDelimiter,
                        i = r.iBefore,
                        l = r.oBefore,
                        s = R(t - 1);
                      if (!a && ur(e.charAt(s)))
                        return ((t = i), (n = n.substring(0, l)), p(!0));
                      var u = kr(o, '"');
                      return ((n += u), !0);
                    }
                    return null;
                  }
                  function f(e) {
                    if (t === e.stopAtIndex) {
                      var r = kr(e.str, '"');
                      return ((n += r), !0);
                    }
                    return null;
                  }
                  function g(r) {
                    if (r.isEndQuote(e[t])) {
                      var o = r.str,
                        i = r.stopAtDelimiter,
                        l = r.iBefore,
                        s = r.oBefore,
                        u = t,
                        c = o.length,
                        d = o + '"';
                      if (
                        (t++,
                        (n += d),
                        a(!1),
                        i || t >= e.length || ur(e[t]) || br(e[t]) || sr(e[t]))
                      )
                        return (b(), { result: !0, shouldContinue: !1 });
                      var m = R(u - 1),
                        _ = e.charAt(m);
                      return _ === ","
                        ? ((t = l),
                          (n = n.substring(0, s)),
                          { result: p(!1, m), shouldContinue: !1 })
                        : ur(_)
                          ? ((t = l),
                            (n = n.substring(0, s)),
                            { result: p(!0), shouldContinue: !1 })
                          : ((n = n.substring(0, s)),
                            (t = u + 1),
                            {
                              str: ""
                                .concat(d.substring(0, c), "\\")
                                .concat(d.substring(c)),
                              shouldContinue: !0,
                            });
                    }
                    return null;
                  }
                  function h(r) {
                    if (r.stopAtDelimiter && _r(e[t])) {
                      var o = r.iBefore,
                        a = r.str;
                      if (
                        e[t - 1] === ":" &&
                        mr.test(e.substring(o + 1, t + 2))
                      )
                        for (; t < e.length && pr.test(e[t]); )
                          ((a += e[t]), t++);
                      var i = kr(a, '"');
                      return ((n += i), b(), !0);
                    }
                    return null;
                  }
                  function y(n) {
                    if (e[t] === "\\") {
                      var r = e.charAt(t + 1);
                      if ($r[r] !== void 0)
                        ((n += e.slice(t, t + 2)), (t += 2));
                      else if (r === "u") {
                        for (var o = 2; o < 6 && lr(e[t + o]); ) o++;
                        o === 6
                          ? ((n += e.slice(t, t + 6)), (t += 6))
                          : t + o >= e.length
                            ? (t = e.length)
                            : (function () {
                                var n = e.slice(t, t + 6);
                                throw new Error(
                                  'Invalid unicode character "'
                                    .concat(n, '" at position ')
                                    .concat(t),
                                );
                              })();
                      } else ((n += r), (t += 2));
                      return n;
                    }
                    return null;
                  }
                  function C(n) {
                    var r,
                      o = e.charAt(t);
                    return (
                      o === '"' && e[t - 1] !== "\\"
                        ? ((n += "\\".concat(o)), t++)
                        : (r = o) === "\n" ||
                            r === "\r" ||
                            r === "	" ||
                            r === "\b" ||
                            r === "\f"
                          ? ((n += xr[o]), t++)
                          : (o >= " " ||
                              (function (e) {
                                throw new Error(
                                  "Invalid character "
                                    .concat(JSON.stringify(e), " at position ")
                                    .concat(t),
                                );
                              })(o),
                            (n += o),
                            t++),
                      n
                    );
                  }
                  function b() {
                    var r = !1;
                    for (a(); e[t] === "+"; ) {
                      ((r = !0), t++, a());
                      var o = (n = Er(n, '"', !0)).length,
                        i = p();
                      n = i ? Ir(n, o, 1) : kr(n, '"');
                    }
                    return r;
                  }
                  function v(r, o) {
                    return (
                      e.slice(t, t + r.length) === r &&
                      ((n += o), (t += r.length), !0)
                    );
                  }
                  function S(r) {
                    var a = t;
                    if (cr(e[t])) {
                      for (; t < e.length && dr(e[t]); ) t++;
                      for (var i = t; hr(e, i); ) i++;
                      if (e[i] === "(")
                        return (
                          (t = i + 1),
                          o(),
                          e[t] === ")" && (t++, e[t] === ";" && t++),
                          !0
                        );
                    }
                    if (
                      ((function (n, r) {
                        for (
                          ;
                          t < e.length &&
                          !_r(e[t]) &&
                          !br(e[t]) &&
                          (!r || e[t] !== ":");
                        )
                          t++;
                        if (e[t - 1] === ":" && mr.test(e.substring(n, t + 2)))
                          for (; t < e.length && pr.test(e[t]); ) t++;
                      })(a, r),
                      t > a)
                    ) {
                      for (; hr(e, t - 1) && t > 0; ) t--;
                      var l = e.slice(a, t);
                      return (
                        (n += l === "undefined" ? "null" : JSON.stringify(l)),
                        e[t] === '"' && t++,
                        !0
                      );
                    }
                  }
                  function R(t) {
                    for (var n = t; n > 0 && hr(e, n); ) n--;
                    return n;
                  }
                  function L() {
                    return t >= e.length || ur(e[t]) || hr(e, t);
                  }
                  function E(r) {
                    n += "".concat(e.slice(r, t), "0");
                  }
                  function k() {
                    throw new Error(
                      "Object key expected at position ".concat(t),
                    );
                  }
                  function I() {
                    throw new Error("Colon expected at position ".concat(t));
                  }
                  (function () {
                    throw new Error(
                      "Unexpected character "
                        .concat(JSON.stringify(e[t]), " at position ")
                        .concat(t),
                    );
                  })();
                }
                function Nr(e, t) {
                  return e[t] === "*" && e[t + 1] === "/";
                }
                function Mr(e) {
                  return (
                    (Mr =
                      typeof Symbol == "function" &&
                      G(
                        typeof Symbol == "function"
                          ? Symbol.iterator
                          : "@@iterator",
                      ) == "symbol"
                        ? function (e) {
                            return G(e);
                          }
                        : function (e) {
                            return e &&
                              typeof Symbol == "function" &&
                              e.constructor === Symbol &&
                              e !==
                                (typeof Symbol == "function"
                                  ? Symbol.prototype
                                  : "@@prototype")
                              ? "symbol"
                              : G(e);
                          }),
                    Mr(e)
                  );
                }
                function wr(e) {
                  return (
                    (function (e) {
                      if (Array.isArray(e)) return Ar(e);
                    })(e) ||
                    (function (e) {
                      if (
                        (typeof Symbol != "undefined" &&
                          e[
                            typeof Symbol == "function"
                              ? Symbol.iterator
                              : "@@iterator"
                          ] != null) ||
                        e["@@iterator"] != null
                      )
                        return Array.from(e);
                    })(e) ||
                    (function (e, t) {
                      if (e) {
                        if (typeof e == "string") return Ar(e, t);
                        var n = {}.toString.call(e).slice(8, -1);
                        return (
                          n === "Object" &&
                            e.constructor &&
                            (n = e.constructor.name),
                          n === "Map" || n === "Set"
                            ? Array.from(e)
                            : n === "Arguments" ||
                                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(
                                  n,
                                )
                              ? Ar(e, t)
                              : void 0
                        );
                      }
                    })(e) ||
                    (function () {
                      throw new TypeError(
                        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
                      );
                    })()
                  );
                }
                function Ar(e, t) {
                  (t == null || t > e.length) && (t = e.length);
                  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                  return r;
                }
                function Fr(e, t) {
                  var n = Object.keys(e);
                  if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    (t &&
                      (r = r.filter(function (t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                      })),
                      n.push.apply(n, r));
                  }
                  return n;
                }
                function Or(e, t, n) {
                  return (
                    (t = (function (e) {
                      var t = (function (e, t) {
                        if (Mr(e) != "object" || !e) return e;
                        var n =
                          e[
                            typeof Symbol == "function"
                              ? Symbol.toPrimitive
                              : "@@toPrimitive"
                          ];
                        if (n !== void 0) {
                          var r = n.call(e, t || "default");
                          if (Mr(r) != "object") return r;
                          throw new TypeError(
                            "@@toPrimitive must return a primitive value.",
                          );
                        }
                        return (t === "string" ? String : Number)(e);
                      })(e, "string");
                      return Mr(t) == "symbol" ? t : t + "";
                    })(t)) in e
                      ? Object.defineProperty(e, t, {
                          value: n,
                          enumerable: !0,
                          configurable: !0,
                          writable: !0,
                        })
                      : (e[t] = n),
                    e
                  );
                }
                var Br = kt.each,
                  Wr = kt.filter,
                  qr = kt.FBSet,
                  Ur = 500,
                  Vr = 12e4,
                  Hr = ["og:image"],
                  Gr = [{ property: "image", type: "Product" }],
                  zr = ["gtin", "gtin8", "gtin12", "gtin13", "gtin14", "isbn"],
                  jr = [
                    "product",
                    "https://schema.org/product",
                    "http://schema.org/product",
                  ],
                  Kr = [
                    "offer",
                    "https://schema.org/offer",
                    "http://schema.org/offer",
                  ],
                  Qr = [
                    "aggregateoffer",
                    "https://schema.org/aggregateoffer",
                    "http://schema.org/aggregateoffer",
                  ],
                  Xr = [
                    "aggregaterating",
                    "https://schema.org/aggregaterating",
                    "http://schema.org/aggregaterating",
                  ],
                  Yr = [
                    "brand",
                    "https://schema.org/brand",
                    "http://schema.org/brand",
                  ],
                  Jr = ["mpn"],
                  Zr = ["name"],
                  eo = ["description"],
                  to = ["aggregaterating"],
                  no = ["availability"],
                  ro = ["price", "lowprice"],
                  oo = ["pricecurrency"],
                  ao = ["sku", "productid", "@id"],
                  io = ["offers", "offer"],
                  lo = ["pricespecification"],
                  so = ["url"],
                  uo = ["itemcondition"],
                  co = ["keywords"],
                  mo = ["category"],
                  po = ["brand"],
                  _o = [
                    "name",
                    "description",
                    "ids",
                    "aggregate_rating",
                    "item_condition",
                    "keywords",
                    "category",
                    "brand",
                  ];
                function fo(e, t) {
                  return Gr.some(function (n) {
                    return (
                      (e === "https://schema.org/".concat(n.type) ||
                        e === "http://schema.org/".concat(n.type)) &&
                      n.property === t
                    );
                  });
                }
                function go(e) {
                  return Object.keys(e).length === 0;
                }
                function ho(e) {
                  for (
                    var t = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                        productUrls: [],
                      },
                      n = 0;
                    n < e.length;
                    n++
                  ) {
                    var r = e[n];
                    ((t.automaticParameters = yo(
                      t.automaticParameters,
                      r.automaticParameters,
                    )),
                      (t.productContents = Co(
                        t.productContents,
                        r.productContents,
                      )),
                      r.productUrls != null &&
                        (t.productUrls = t.productUrls.concat(r.productUrls)),
                      r.productID != null &&
                        t.productID == null &&
                        (t.productID = r.productID),
                      r.productUrl != null &&
                        t.productUrl == null &&
                        (t.productUrl = r.productUrl));
                  }
                  return t;
                }
                function yo(e, t) {
                  return (
                    t.currency != null && (e.currency = t.currency),
                    t.contents != null &&
                      Array.isArray(t.contents) &&
                      (e.contents == null
                        ? (e.contents = t.contents)
                        : (e.contents = e.contents.concat(t.contents))),
                    e
                  );
                }
                function Co(e, t) {
                  return e == null
                    ? t || []
                    : t == null
                      ? e || []
                      : e.concat(t);
                }
                function bo(e, t) {
                  var n = e.getAttribute(t);
                  return n == null || typeof n != "string" ? "" : n;
                }
                function vo(e, t) {
                  var n = [];
                  return (
                    t.forEach(function (t) {
                      if (t != null) {
                        var r = (function (e) {
                          for (var t = 1; t < arguments.length; t++) {
                            var n = arguments[t] != null ? arguments[t] : {};
                            t % 2
                              ? Fr(Object(n), !0).forEach(function (t) {
                                  Or(e, t, n[t]);
                                })
                              : Object.getOwnPropertyDescriptors
                                ? Object.defineProperties(
                                    e,
                                    Object.getOwnPropertyDescriptors(n),
                                  )
                                : Fr(Object(n)).forEach(function (t) {
                                    Object.defineProperty(
                                      e,
                                      t,
                                      Object.getOwnPropertyDescriptor(n, t),
                                    );
                                  });
                          }
                          return e;
                        })({}, e);
                        ((r.id = t), n.push(r));
                      }
                    }),
                    n.length !== 0 || go(e) || n.push(e),
                    n
                  );
                }
                function So() {
                  var e = t.querySelectorAll("[itemscope]");
                  if (e.length === 0) return {};
                  var n = Wr(e, function (e) {
                    return jr.includes(bo(e, "itemtype").toLowerCase());
                  });
                  if (n.length === 0) return {};
                  var r = {};
                  return (
                    n.forEach(function (e) {
                      r = yo(
                        r,
                        (function (e) {
                          var t = null,
                            n = null,
                            r = null,
                            o = null,
                            a = [
                              {
                                itempropsLowerCase: ["price"],
                                property: "item_price",
                                apply: function (t) {
                                  return Fo(t);
                                },
                                getDefault: function () {
                                  return null;
                                },
                                setDefault: function (t) {},
                              },
                              {
                                itempropsLowerCase: ["availability"],
                                property: "availability",
                                apply: function (t) {
                                  return Uo(t);
                                },
                                getDefault: function () {
                                  return null;
                                },
                                setDefault: function (t) {},
                              },
                              {
                                itempropsLowerCase: ["mpn"],
                                property: "mpn",
                                apply: function (t) {
                                  return t;
                                },
                                getDefault: function () {
                                  return n;
                                },
                                setDefault: function (t) {
                                  n = t;
                                },
                              },
                              {
                                itempropsLowerCase: zr,
                                property: "gtin",
                                apply: function (t) {
                                  return t;
                                },
                                getDefault: function () {
                                  return r;
                                },
                                setDefault: function (t) {
                                  r = t;
                                },
                              },
                              {
                                itempropsLowerCase: [
                                  "productid",
                                  "sku",
                                  "product_id",
                                ],
                                property: "id",
                                apply: function (t) {
                                  return t;
                                },
                                getDefault: function () {
                                  return t;
                                },
                                setDefault: function (n) {
                                  t = n;
                                },
                              },
                              {
                                itempropsLowerCase: ["pricecurrency"],
                                property: "currency",
                                apply: function (t) {
                                  return null;
                                },
                                getDefault: function () {
                                  return o;
                                },
                                setDefault: function (t) {
                                  o = t;
                                },
                              },
                            ];
                          e.querySelectorAll("[itemprop]").forEach(
                            function (e) {
                              var t = e.getAttribute("itemprop");
                              if (typeof t == "string" && t !== "") {
                                var n = d(e);
                                n != null &&
                                  n !== "" &&
                                  a.forEach(function (e) {
                                    var r = e.setDefault,
                                      o = e.itempropsLowerCase;
                                    (0, e.getDefault)() == null &&
                                      o.includes(t.toLowerCase()) &&
                                      r(n);
                                  });
                              }
                            },
                          );
                          var i = Wr(
                              e.querySelectorAll("[itemscope]"),
                              function (e) {
                                return Kr.includes(
                                  bo(e, "itemtype").toLowerCase(),
                                );
                              },
                            ),
                            l = [];
                          (i.forEach(function (e) {
                            var t = {};
                            (e
                              .querySelectorAll("[itemprop]")
                              .forEach(function (e) {
                                var n = e.getAttribute("itemprop");
                                if (typeof n == "string" && n !== "") {
                                  var r = d(e);
                                  r != null &&
                                    r !== "" &&
                                    a.forEach(function (e) {
                                      var o = e.apply,
                                        a = e.property;
                                      if (
                                        e.itempropsLowerCase.includes(
                                          n.toLowerCase(),
                                        )
                                      ) {
                                        var i = o(r);
                                        Oo(t, a, i);
                                      }
                                    });
                                }
                              }),
                              l.push(t));
                          }),
                            l.forEach(function (e) {
                              (Oo(e, "mpn", e.mpn ? e.mpn : n),
                                Oo(e, "gtin", e.gtin ? e.gtin : r),
                                Oo(e, "id", e.id ? e.id : t));
                            }));
                          var s = { currency: o };
                          return (wo(s, !0, l), s);
                        })(e),
                      );
                    }),
                    r
                  );
                }
                function Ro() {
                  var e =
                      arguments.length > 0 &&
                      arguments[0] !== void 0 &&
                      arguments[0],
                    n =
                      arguments.length > 2 &&
                      arguments[2] !== void 0 &&
                      arguments[2],
                    r = t.querySelectorAll("[itemscope]"),
                    o = [],
                    a = (function (e) {
                      for (var t = new qr(), n = 0; n < e.length; n++)
                        t.add(e[n]);
                      return t;
                    })(r),
                    i = {},
                    l = {},
                    s = {
                      automaticParameters: {},
                      productID: null,
                      productUrl: null,
                      productContents: [],
                    },
                    u = e ? So() : {},
                    c = (function (e) {
                      for (
                        var t = e.scopes,
                          n = e.seenProperties,
                          r = e.scopeSchemas,
                          o = e.productMetadata,
                          a = e.contentData,
                          i = e.includeAutomaticParameters,
                          l = e.productContentData,
                          s = e.includeProductContent,
                          u = null,
                          c = null,
                          m = t.length - 1;
                        m >= 0;
                        m--
                      ) {
                        var p = t[m],
                          _ = p.getAttribute("itemtype");
                        if (typeof _ == "string" && _ !== "") {
                          for (
                            var f = {},
                              g = p.querySelectorAll("[itemprop]"),
                              h = 0;
                            h < g.length;
                            h++
                          ) {
                            var y = g[h];
                            if (!n.has(y)) {
                              n.add(y);
                              var C = y.getAttribute("itemprop");
                              if (typeof C == "string" && C !== "") {
                                var b = d(y);
                                if (b != null && b !== "") {
                                  var v = f[C];
                                  v != null && fo(_, C)
                                    ? Array.isArray(v)
                                      ? f[C].push(b)
                                      : (f[C] = [v, b])
                                    : (o.productID == null &&
                                        (C === "productID"
                                          ? (u = b)
                                          : C === "sku" && (c = b)),
                                      o.productUrl == null &&
                                        C === "url" &&
                                        (o.productUrl = b),
                                      s && Lo(l, _, C, b),
                                      i && Eo(a, o, C, b),
                                      (f[C] = b));
                                }
                              }
                            }
                          }
                          r.unshift({
                            schema: {
                              dimensions: {
                                h: p.clientHeight,
                                w: p.clientWidth,
                              },
                              properties: f,
                              subscopes: [],
                              type: _,
                            },
                            scope: p,
                          });
                        }
                      }
                      return { localProductID: u, SKU: c };
                    })({
                      scopes: r,
                      seenProperties: a,
                      scopeSchemas: o,
                      productMetadata: s,
                      contentData: i,
                      includeAutomaticParameters: e,
                      productContentData: l,
                      includeProductContent: n,
                    });
                  ((function (e, t, n) {
                    t != null
                      ? (e.productID = t)
                      : n != null && (e.productID = n);
                  })(s, c.localProductID, c.SKU),
                    u.contents == null && (u.contents = []),
                    u.contents.push(i),
                    wo(s.automaticParameters, e, u.contents),
                    Ao(s.productContents, n, [l]));
                  var m = (function (e) {
                    for (var t = [], n = [], r = 0; r < e.length; r++) {
                      for (
                        var o = e[r],
                          a = o.scope,
                          i = o.schema,
                          l = n.length - 1;
                        l >= 0;
                        l--
                      ) {
                        if (n[l].scope.contains(a)) {
                          n[l].schema.subscopes.push(i);
                          break;
                        }
                        n.pop();
                      }
                      (n.length === 0 && t.push(i),
                        n.push({ schema: i, scope: a }));
                    }
                    return t;
                  })(o);
                  return { extractedProperties: m, productMetadata: s };
                }
                function Lo(e, t, n, r) {
                  ((n !== "productID" && n !== "sku") ||
                    (e.ids == null
                      ? (e.ids = [r])
                      : e.ids.includes(r) || e.ids.push(r)),
                    jr.includes(t.toLowerCase()) &&
                      n === "name" &&
                      (e.name = r),
                    jr.includes(t.toLowerCase()) &&
                      n === "description" &&
                      (e.description = r),
                    Xr.includes(t.toLowerCase()) &&
                      (e.aggregate_rating == null && (e.aggregate_rating = {}),
                      n === "ratingValue"
                        ? (e.aggregate_rating.ratingValue = r)
                        : n === "ratingCount"
                          ? (e.aggregate_rating.ratingCount = r)
                          : n === "reviewCount"
                            ? (e.aggregate_rating.reviewCount = r)
                            : n === "bestRating"
                              ? (e.aggregate_rating.bestRating = r)
                              : n === "worstRating" &&
                                (e.aggregate_rating.worstRating = r)),
                    Kr.includes(t.toLowerCase()) &&
                      e.item_condition == null &&
                      n === "itemCondition" &&
                      Oo(e, "item_condition", Uo(r)),
                    jr.includes(t.toLowerCase()) &&
                      e.keywords == null &&
                      n === "keywords" &&
                      (e.keywords = r),
                    Yr.includes(t.toLowerCase()) &&
                      e.brand == null &&
                      n === "name" &&
                      (e.brand = r),
                    jr.includes(t.toLowerCase()) &&
                      (e.category == null &&
                        n === "category" &&
                        (e.category = r),
                      e.brand == null && n === "brand" && (e.brand = r)));
                }
                function Eo(e, t, n, r) {
                  (t.automaticParameters.currency == null &&
                    n === "priceCurrency" &&
                    (t.automaticParameters.currency = r),
                    e.id != null ||
                      (n !== "productID" && n !== "sku") ||
                      (e.id = r),
                    e.mpn == null && n === "mpn" && (e.mpn = r),
                    e.gtin == null && zr.includes(n) && (e.gtin = r),
                    e.item_price == null &&
                      n === "price" &&
                      Oo(e, "item_price", Fo(r)),
                    e.availability == null &&
                      n === "availability" &&
                      Oo(e, "availability", Uo(r)));
                }
                function ko(e, t) {
                  if (e == null) return { content: [], currency: null };
                  var n = {},
                    r = (function (e) {
                      var t = { price: null, currency: null };
                      if (e == null) return t;
                      ((t.price = Fo(Bo(e, ro))), (t.currency = Bo(e, oo)));
                      var n = (function (e) {
                        var t = { price: null, currency: null };
                        return e == null
                          ? t
                          : Array.isArray(e)
                            ? (e.length === 0 ||
                                Br(e, function (e) {
                                  (e.priceCurrency != null &&
                                    (t.currency = Bo(e, oo)),
                                    (t.price = (function (e, t) {
                                      return e == null
                                        ? t
                                        : t == null
                                          ? e
                                          : e > t
                                            ? t
                                            : e;
                                    })(Fo(Bo(e, ro)), t.price)));
                                }),
                              t)
                            : ((t.price = Fo(Bo(e, ro))),
                              (t.currency = Bo(e, oo)),
                              t);
                      })(Bo(e, lo));
                      return (
                        t.price == null && (t.price = n.price),
                        t.currency == null && (t.currency = n.currency),
                        t
                      );
                    })(e),
                    o = Bo(e, Jr, t.mpn),
                    a = Bo(e, zr, t.gtin);
                  (Oo(n, "mpn", o),
                    Oo(n, "gtin", a),
                    Oo(n, "item_price", r.price),
                    Oo(n, "availability", Uo(Bo(e, no))));
                  var i = (function (e, t) {
                    var n =
                        arguments.length > 2 && arguments[2] !== void 0
                          ? arguments[2]
                          : null,
                      r = [];
                    if ((n && r.push(n), Mr(e) !== "object")) return r;
                    var o = [];
                    return (
                      Br(Object.keys(e), function (n) {
                        t.includes(n.toLowerCase()) && e[n] && o.push(e[n]);
                      }),
                      o.length > 0 ? o : r
                    );
                  })(e, ao, t.id);
                  return { content: vo(n, i), currency: r.currency };
                }
                function Io() {
                  for (
                    var e =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      n =
                        arguments.length > 1 &&
                        arguments[1] !== void 0 &&
                        arguments[1],
                      r = arguments.length > 2 ? arguments[2] : void 0,
                      o =
                        arguments.length > 3 &&
                        arguments[3] !== void 0 &&
                        arguments[3],
                      a = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                      },
                      i = [],
                      l = [],
                      s = t.querySelectorAll(
                        'script[type="application/ld+json"]',
                      ),
                      u = 0,
                      c = [],
                      d = {},
                      m = 0;
                    m < s.length;
                    m++
                  ) {
                    var p = s[m].textContent || s[m].innerText;
                    if (p != null && p !== "")
                      try {
                        if ((u += p.length) > Vr)
                          return (
                            wo(a.automaticParameters, e, c),
                            Ao(a.productContents, o, [d]),
                            {
                              extractedProperties: i,
                              invalidInnerTexts: l,
                              productMetadata: a,
                            }
                          );
                        for (var _ = To(p, n), f = 0; f < _.length; f++) {
                          var g = _[f];
                          (No(_, Bo(g, ["mainentity"])),
                            No(_, Bo(g, ["@graph"])),
                            No(_, Bo(g, ["hasvariant"])));
                          var h = {},
                            y = Do({
                              json: g,
                              productMetadata: a,
                              contentData: h,
                              includeAutomaticParameters: e,
                              productContentData: d,
                              includeProductContent: o,
                              logInfo: r,
                            }),
                            C = y.isTypeProduct,
                            b = y.offers;
                          if ((a.productUrl == null || C) && b != null) {
                            var v = $o({
                              offers: b,
                              productMetadata: a,
                              contentData: h,
                              includeAutomaticParameters: e,
                              productContentData: d,
                              includeProductContent: o,
                              logInfo: r,
                            });
                            c = c.concat(v);
                          }
                          i.push(g);
                        }
                      } catch (e) {
                        l.push(p);
                      }
                  }
                  return (
                    wo(a.automaticParameters, e, c),
                    Ao(a.productContents, o, [d]),
                    {
                      extractedProperties: i,
                      invalidInnerTexts: l,
                      productMetadata: a,
                    }
                  );
                }
                function To(e, t) {
                  var n = null;
                  n = zo(e);
                  try {
                    n = JSON.parse(n.replace(/[\n\r\t]+/g, " "));
                  } catch (e) {
                    if (!t) throw e;
                    try {
                      ((n = jo(n)),
                        (n = JSON.parse(n.replace(/[\n\r\t]+/g, " "))));
                    } catch (t) {
                      throw new Error(
                        "Failed to parse JSON even after repair attempt. Original error: ".concat(
                          e.message,
                        ),
                      );
                    }
                  }
                  return (Array.isArray(n) || (n = [n]), n);
                }
                function Do(e) {
                  var t = e.json,
                    n = e.productMetadata,
                    r = e.contentData,
                    o = e.includeAutomaticParameters,
                    a = e.productContentData,
                    i = e.includeProductContent,
                    l = Mo(t),
                    s = jr.includes(l),
                    u = Bo(t, io);
                  if (!s) return { isTypeProduct: s, offers: u };
                  var c = Bo(t, ao);
                  if (
                    ((n.productID != null && n.productID !== "") ||
                      (n.productID = c),
                    o &&
                      (Oo(r, "id", c),
                      Oo(r, "mpn", Bo(t, Jr)),
                      Oo(r, "gtin", Bo(t, zr))),
                    i)
                  ) {
                    (c &&
                      (a.ids == null
                        ? (a.ids = [c])
                        : a.ids.includes(c) || a.ids.push(c)),
                      Oo(a, "name", Bo(t, Zr)),
                      Oo(a, "description", Bo(t, eo)),
                      Oo(a, "aggregate_rating", Bo(t, to)),
                      Oo(a, "keywords", Bo(t, co)),
                      Oo(a, "category", Bo(t, mo)));
                    var d = Bo(t, po);
                    typeof d == "string"
                      ? (a.brand = d)
                      : Oo(a, "brand", Bo(d, Zr));
                  }
                  return (Po(t, n), xo(t, n), { isTypeProduct: s, offers: u });
                }
                function xo(e, t) {
                  var n = Bo(e, so);
                  n != null &&
                    n !== "" &&
                    (t.productUrls == null && (t.productUrls = []),
                    t.productUrls.push(n));
                }
                function $o(e) {
                  var t = e.offers,
                    n = e.productMetadata,
                    r = e.contentData,
                    o = e.includeAutomaticParameters,
                    a = e.productContentData,
                    i = e.includeProductContent,
                    l = [],
                    s = [];
                  if (Array.isArray(t)) s = t;
                  else {
                    var u = Mo(t),
                      c = Kr.includes(u),
                      d = Qr.includes(u);
                    (c || d) && (s = [t]);
                  }
                  return (
                    s.length === 0 ||
                      Br(s, function (e) {
                        if ((Po(e, n), xo(e, n), o)) {
                          var t = ko(e, r);
                          (n.automaticParameters.currency == null &&
                            (n.automaticParameters.currency = t.currency),
                            (l = l.concat(t.content)));
                        }
                        i &&
                          ((function (e, t) {
                            if (e != null) {
                              var n = Bo(e, ao);
                              n != null &&
                                (t.ids == null
                                  ? (t.ids = [n])
                                  : t.ids.includes(n) || t.ids.push(n));
                            }
                          })(e, a),
                          (function (e, t, n) {
                            e != null &&
                              Oo(
                                t,
                                "item_condition",
                                Uo(Bo(e, uo, n.item_condition)),
                              );
                          })(e, a, r));
                      }),
                    l
                  );
                }
                function Po(e, t) {
                  var n = Bo(e, so);
                  (t.productUrl != null && t.productUrl !== "") ||
                    (t.productUrl = n);
                }
                function No(e, t) {
                  if (t != null) {
                    var n = t;
                    (Array.isArray(t) || (n = [t]), e.push.apply(e, wr(n)));
                  }
                }
                function Mo(e) {
                  return e == null
                    ? ""
                    : typeof e["@type"] == "string" && e["@type"] != null
                      ? e["@type"].toLowerCase()
                      : "";
                }
                function wo(e, t, n) {
                  if (t) {
                    var r = n.filter(function (e) {
                      return !go(e);
                    });
                    r.length !== 0 && (e.contents = r);
                  }
                }
                function Ao(e, t, n) {
                  if (t) {
                    var r = n
                      .map(function (e) {
                        return (function (e) {
                          for (
                            var t = {}, n = 0, r = Object.keys(e);
                            n < r.length;
                            n++
                          ) {
                            var o = r[n];
                            _o.includes(o) && (t[o] = e[o]);
                          }
                          return t;
                        })(e);
                      })
                      .filter(function (e) {
                        return !go(e);
                      });
                    r.length !== 0 && e.push.apply(e, wr(r));
                  }
                }
                function Fo(e) {
                  if (typeof e == "string") {
                    var t = parseFloat(e.replace(/[^0-9.]/g, ""));
                    return isNaN(t) ? null : t;
                  }
                  return typeof e == "number" ? e : null;
                }
                function Oo(e, t, n) {
                  n != null && (e[t] = n);
                }
                function Bo(e, t) {
                  var n =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : null;
                  if (e == null || Mr(e) !== "object") return n;
                  var r = Object.keys(e),
                    o = {};
                  Br(r, function (n) {
                    t.includes(n.toLowerCase()) && (o[n.toLowerCase()] = e[n]);
                  });
                  var a = t.find(function (e) {
                    return o[e];
                  });
                  return a ? o[a] : n;
                }
                function Wo(e, t, n, r, o, a, i) {
                  var l,
                    s =
                      arguments.length > 7 &&
                      arguments[7] !== void 0 &&
                      arguments[7],
                    u = null,
                    c = null,
                    d = !1,
                    m = n[e];
                  return (
                    m != null && ((l = e), Hr.includes(l))
                      ? Array.isArray(m)
                        ? n[e].push(t)
                        : (n[e] = [m, t])
                      : (t &&
                          ((r.productID != null && r.productID !== "") ||
                            (e === "product:retailer_item_id" &&
                              ((u = t), (d = !0)),
                            e === "product:sku" && ((c = t), (d = !0))),
                          (r.productUrl != null && r.productUrl !== "") ||
                            e !== "og:url" ||
                            (r.productUrl = t),
                          e === "og:type" &&
                            t.toLowerCase().includes("product") &&
                            (d = !0),
                          s &&
                            (function (e, t, n) {
                              (n.name != null ||
                                (e !== "product:name" && e !== "og:title") ||
                                (n.name = t),
                                n.description != null ||
                                  (e !== "product:description" &&
                                    e !== "og:description") ||
                                  (n.description = t),
                                (e !== "product:retailer_item_id" &&
                                  e !== "product:sku") ||
                                  (n.ids == null
                                    ? (n.ids = [t])
                                    : n.ids.includes(t) || n.ids.push(t)),
                                (e !== "product:brand" && e !== "og:brand") ||
                                  (n.brand = t),
                                (e !== "product:category" &&
                                  e !== "og:category") ||
                                  (n.category = t),
                                n.item_condition != null ||
                                  (e !== "product:condition" &&
                                    e !== "og:condition") ||
                                  Oo(n, "item_condition", Uo(t)),
                                n.keywords != null ||
                                  (e !== "product:keywords" &&
                                    e !== "og:keywords") ||
                                  (n.keywords = t));
                            })(e, t, i),
                          a &&
                            (function (e, t, n, r) {
                              (n.automaticParameters.currency != null ||
                                (e !== "product:price:currency" &&
                                  e !== "og:price:currency") ||
                                (n.automaticParameters.currency = t),
                                r.id != null ||
                                  (e !== "product:retailer_item_id" &&
                                    e !== "product:sku") ||
                                  (r.id = t),
                                r.mpn == null &&
                                  e === "product:mfr_part_no" &&
                                  (r.mpn = t),
                                r.gtin == null &&
                                  zr
                                    .map(function (e) {
                                      return "product:".concat(e);
                                    })
                                    .includes(e) &&
                                  (r.gtin = t),
                                r.item_price != null ||
                                  (e !== "product:price:amount" &&
                                    e !== "og:price:amount") ||
                                  Oo(r, "item_price", Fo(t)),
                                r.availability != null ||
                                  (e !== "product:availability" &&
                                    e !== "og:availability") ||
                                  Oo(r, "availability", Uo(t)));
                            })(e, t, r, o)),
                        (n[e] = t)),
                    { productRetailerItemID: u, productSKU: c, isProduct: d }
                  );
                }
                function qo() {
                  for (
                    var e =
                        arguments.length > 0 &&
                        arguments[0] !== void 0 &&
                        arguments[0],
                      n =
                        arguments.length > 2 &&
                        arguments[2] !== void 0 &&
                        arguments[2],
                      r = {
                        automaticParameters: {},
                        productID: null,
                        productUrl: null,
                        productContents: [],
                      },
                      o = new qr([
                        "og",
                        "product",
                        "music",
                        "video",
                        "article",
                        "book",
                        "profile",
                        "website",
                        "twitter",
                      ]),
                      a = {},
                      i = null,
                      l = null,
                      s = !1,
                      u = {},
                      c = {},
                      d = t.querySelectorAll("meta[property]"),
                      m = 0;
                    m < d.length;
                    m++
                  ) {
                    var p = d[m],
                      _ = p.getAttribute("property"),
                      f = p.getAttribute("content");
                    if (
                      typeof _ == "string" &&
                      _.indexOf(":") !== -1 &&
                      typeof f == "string" &&
                      o.has(_.split(":")[0])
                    ) {
                      var g = Wo(_, Be(f, Ur), a, r, u, e, c, n);
                      (g.productRetailerItemID && (i = g.productRetailerItemID),
                        g.productSKU && (l = g.productSKU),
                        g.isProduct === !0 && (s = !0));
                    }
                  }
                  return (
                    i != null
                      ? (r.productID = i)
                      : l != null && (r.productID = l),
                    wo(r.automaticParameters, e, [u]),
                    s && Ao(r.productContents, n, [c]),
                    { extractedProperties: a, productMetadata: r }
                  );
                }
                function Uo(e) {
                  if (typeof e != "string" && !(e instanceof String))
                    return null;
                  var t = e.split("/");
                  return t.length > 0 ? t[t.length - 1] : "";
                }
                var Vo = { description: !0, keywords: !0 };
                function Ho() {
                  var e =
                      arguments.length > 0 &&
                      arguments[0] !== void 0 &&
                      arguments[0],
                    n = t.querySelector("title"),
                    r = n && (n.textContent || n.innerText);
                  if (e && (!r || r.trim() === "")) {
                    var o = t.querySelector('meta[property="og:title"]');
                    if (o) {
                      var a = o.getAttribute("content");
                      a && (r = a);
                    }
                  }
                  var i = { title: Be(r, Ur) },
                    l = (function () {
                      var e = t.querySelector('meta[property="og:locale"]');
                      if (e != null) {
                        var n = e.getAttribute("content");
                        if (n != null && n !== "") return n.substring(0, Go);
                      }
                      var r = t.documentElement;
                      if (r != null) {
                        var o = r.getAttribute("lang");
                        if (o != null && o !== "") return o.substring(0, Go);
                      }
                      var a = t.querySelector(
                        'meta[http-equiv="content-language"]',
                      );
                      if (a != null) {
                        var i = a.getAttribute("content");
                        if (i != null && i !== "") return i.substring(0, Go);
                      }
                      return null;
                    })();
                  l != null && (i.locale = l);
                  for (
                    var s = t.querySelectorAll("meta[name]"), u = 0;
                    u < s.length;
                    u++
                  ) {
                    var c = s[u],
                      d = c.getAttribute("name"),
                      m = c.getAttribute("content");
                    typeof d == "string" &&
                      typeof m == "string" &&
                      Vo[d] &&
                      (i[d] = Be(m, Ur));
                  }
                  return i;
                }
                var Go = 50;
                function zo(e) {
                  return e == null
                    ? null
                    : e.replace(
                        /\\"|\"(?:\\"|[^\"])*\"|(\/\/.*|\/\*[\s\S]*?\*\/)/g,
                        function (e, t) {
                          return t ? "" : e;
                        },
                      );
                }
                function jo(e) {
                  if (e == null) return null;
                  try {
                    return Pr(e);
                  } catch (t) {
                    return e;
                  }
                }
                function Ko() {
                  return {
                    extractedProperties: [],
                    productMetadata: {
                      automaticParameters: {},
                      productID: null,
                      productUrl: null,
                      productContents: [],
                      productUrls: [],
                    },
                  };
                }
                var Qo = l,
                  Xo = s;
                o.exports = i;
              })();
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsShouldRestrictReferrerEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsEventPayload"),
                  t = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  n = a.getFbeventsModules("SignalsFBEventsTyped"),
                  r = n.coerce,
                  i = n.Typed,
                  l = a.getFbeventsModules("SignalsFBEventsPixelTypedef");
                function s(t) {
                  var n = t instanceof e ? t : null;
                  return n != null ? [n] : null;
                }
                var u = new t(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsStandardParamChecksConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    standardParamChecks: t.allowNull(
                      t.mapOf(
                        t.allowNull(
                          t.arrayOf(
                            t.allowNull(
                              t.objectWithFields({
                                require_exact_match: t.boolean(),
                                potential_matches: t.allowNull(
                                  t.arrayOf(t.string()),
                                ),
                              }),
                            ),
                          ),
                        ),
                      ),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsTelemetry", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var t = a.getFbeventsModules("SignalsFBEventsLogging"),
                n = a.getFbeventsModules("SignalsEventPayload"),
                r = a.getFbeventsModules("SignalsFBEventsQE"),
                i = a.getFbeventsModules("signalsFBEventsSendGET"),
                l = 0.01,
                s = Math.random(),
                u =
                  e.fbq && e.fbq._releaseSegment
                    ? e.fbq._releaseSegment
                    : "unknown",
                c = s < l || u === "canary",
                d = "https://connect.facebook.net/log/fbevents_telemetry/";
              function m(r) {
                var o =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : 0,
                  a =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : !1;
                if (!(!a && !c))
                  try {
                    var l = new n();
                    (l.append(
                      "v",
                      e.fbq && e.fbq.version ? e.fbq.version : "unknown",
                    ),
                      l.append("rs", u),
                      l.append("e", r),
                      l.append("p", String(o)),
                      i(l, { ignoreRequestLengthCheck: !0, url: d }));
                  } catch (e) {
                    t.logError(e);
                  }
              }
              function p(e) {
                m("FBMQ_FORWARDED", e, !0);
              }
              o.exports = { logMobileNativeForwarding: p };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsTrackEventEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = t.coerce,
                i = n.objectWithFields({
                  pixelID: n.allowNull(n.string()),
                  eventName: n.string(),
                  customData: n.allowNull(n.object()),
                  eventData: n.allowNull(n.object()),
                  eventId: n.allowNull(n.string()),
                }),
                l = new e(n.tuple([i]));
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    sgwPixelId: n.allowNull(n.string()),
                    sgwHostUrl: n.allowNull(n.string()),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsTyped", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            l = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.filter,
                n = e.map,
                r = e.reduce,
                l = a.getFbeventsModules("SignalsFBEventsUtils"),
                s = l.isSafeInteger,
                d = (function (e) {
                  function t() {
                    var e,
                      n =
                        arguments.length > 0 && arguments[0] !== void 0
                          ? arguments[0]
                          : "",
                      r = arguments.length > 1 ? arguments[1] : void 0;
                    $(this, t);
                    var o = r != null ? "".concat(r, ": ").concat(n) : n;
                    return (
                      (e = i(this, t, [o])),
                      (e.name = "FBEventsCoercionError"),
                      e
                    );
                  }
                  return (u(t, e), N(t));
                })(c(Error));
              function m(e) {
                return Object.values(e);
              }
              function p() {
                return function (e) {
                  if (typeof e != "boolean")
                    throw new d(
                      "Expected boolean, got ".concat(G(e)),
                      "Typed.boolean",
                    );
                  return e;
                };
              }
              function _() {
                return function (e) {
                  if (typeof e != "number")
                    throw new d(
                      "Expected number, got ".concat(G(e)),
                      "Typed.number",
                    );
                  return e;
                };
              }
              function f() {
                return function (e) {
                  return e;
                };
              }
              function g() {
                return function (e) {
                  if (typeof e == "string") return e;
                  if (G(e) === "object" && e !== null)
                    try {
                      return JSON.stringify(e);
                    } catch (e) {
                      throw new d(
                        "Expected string, got object that cannot be stringified",
                        "Typed.string",
                      );
                    }
                  throw new d(
                    "Expected string, got ".concat(G(e)),
                    "Typed.string",
                  );
                };
              }
              function h() {
                return function (e) {
                  if (typeof e != "string" && typeof e != "number")
                    throw new d(
                      "Expected string or number, got ".concat(G(e)),
                      "Typed.stringOrNumber",
                    );
                  return e;
                };
              }
              function y() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new d(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.object",
                    );
                  return e;
                };
              }
              function C() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new d(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.mutableObject",
                    );
                  return v({}, e);
                };
              }
              function b() {
                return function (e) {
                  if (G(e) !== "object" || Array.isArray(e) || e == null)
                    throw new d(
                      "Expected object, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.stringRecord",
                    );
                  for (
                    var t = {}, n = 0, r = Object.keys(e);
                    n < r.length;
                    n++
                  ) {
                    var o = r[n],
                      a = e[o];
                    if (typeof a != "string")
                      throw new d(
                        'Expected all values to be strings, but key "'
                          .concat(o, '" has type ')
                          .concat(G(a)),
                        "Typed.stringRecord",
                      );
                    t[o] = a;
                  }
                  return t;
                };
              }
              function R() {
                return function (e) {
                  if (
                    (G(e) !== "object" && typeof e != "string") ||
                    Array.isArray(e) ||
                    e == null
                  )
                    throw new d(
                      "Expected object or string, got "
                        .concat(G(e))
                        .concat(Array.isArray(e) ? " (array)" : ""),
                      "Typed.objectOrString",
                    );
                  return e;
                };
              }
              function L() {
                return function (e) {
                  if (typeof e != "function" || e == null)
                    throw new d(
                      "Expected function, got ".concat(G(e)),
                      "Typed.func",
                    );
                  return e;
                };
              }
              function E() {
                return function (e) {
                  if (e == null || !Array.isArray(e))
                    throw new d(
                      "Expected array, got ".concat(G(e)),
                      "Typed.array",
                    );
                  return e;
                };
              }
              function k(e) {
                return function (t) {
                  if (m(e).includes(t)) return t;
                  throw new d(
                    "Expected one of ["
                      .concat(m(e).join(", "), "], got ")
                      .concat(String(t)),
                    "Typed.enumeration",
                  );
                };
              }
              function I(e) {
                return function (t) {
                  return M(t, q.array()).map(e);
                };
              }
              function T(e) {
                return function (t) {
                  var n = M(t, q.object());
                  return r(
                    Object.keys(n),
                    function (t, r) {
                      return v(v({}, t), {}, S({}, r, e(n[r])));
                    },
                    {},
                  );
                };
              }
              function D(e) {
                return function (t) {
                  return t == null ? null : e(t);
                };
              }
              function x(e) {
                return function (t) {
                  var n = M(t, q.object()),
                    o = r(
                      Object.keys(e),
                      function (t, r) {
                        var o = e[r],
                          a = n[r],
                          i = o(a);
                        return v(v({}, t), {}, S({}, r, i));
                      },
                      {},
                    );
                  return o;
                };
              }
              function P(e, t) {
                try {
                  return t(e);
                } catch (e) {
                  if (e.name === "FBEventsCoercionError") return null;
                  throw e;
                }
              }
              function M(e, t) {
                return t(e);
              }
              function w(e) {
                return function (t) {
                  var n = M(t, q.string());
                  if (e.test(n)) return n;
                  throw new d(
                    'String "'
                      .concat(n, '" does not match pattern ')
                      .concat(e.toString()),
                    "Typed.matches",
                  );
                };
              }
              function A(e) {
                if (!e) throw new d("Assertion failed", "Typed.assert");
              }
              function F(e) {
                return function (t) {
                  var n = M(t, E());
                  return (
                    A(n.length === e.length),
                    n.map(function (t, n) {
                      return M(t, e[n]);
                    })
                  );
                };
              }
              function O(e) {
                var t = e.def,
                  n = e.validators;
                return function (e) {
                  var r = M(e, t);
                  return (
                    n.forEach(function (e) {
                      if (!e(r))
                        throw new d(
                          "Validation failed for value: ".concat(String(r)),
                          "Typed.withValidation",
                        );
                    }),
                    r
                  );
                };
              }
              var B = /^[1-9][0-9]{0,25}$/;
              function W() {
                return O({
                  def: function (t) {
                    var e = P(t, q.number());
                    return e != null
                      ? (q.assert(s(e)), "".concat(e))
                      : M(t, q.string());
                  },
                  validators: [
                    function (e) {
                      return B.test(e);
                    },
                  ],
                });
              }
              var q = {
                allowNull: D,
                array: E,
                arrayOf: I,
                assert: A,
                boolean: p,
                enumeration: k,
                fbid: W,
                identity: f,
                mapOf: T,
                matches: w,
                mutableObject: C,
                number: _,
                object: y,
                objectOrString: R,
                objectWithFields: x,
                string: g,
                stringOrNumber: h,
                stringRecord: b,
                tuple: F,
                withValidation: O,
                func: L,
              };
              o.exports = {
                Typed: q,
                coerce: P,
                enforce: M,
                FBEventsCoercionError: d,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEventsTypeVersioning", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.coerce,
                n = e.enforce,
                r = e.FBEventsCoercionError;
              function i(e) {
                return function (t) {
                  for (var o = 0; o < e.length; o++) {
                    var a = e[o];
                    try {
                      return n(t, a);
                    } catch (e) {
                      if (e.name === "FBEventsCoercionError") continue;
                      throw e;
                    }
                  }
                  throw new r();
                };
              }
              function l(e, t) {
                return function (r) {
                  return t(n(r, e));
                };
              }
              var s = { waterfall: i, upgrade: l };
              o.exports = s;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedDataTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = e.coerce,
                  r = t.objectWithFields({
                    blacklisted_keys: t.allowNull(
                      t.mapOf(t.mapOf(t.arrayOf(t.string()))),
                    ),
                    sensitive_keys: t.allowNull(
                      t.mapOf(t.mapOf(t.arrayOf(t.string()))),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedEventNamesConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    unwantedEventNames: t.allowNull(
                      t.mapOf(t.allowNull(t.number())),
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedEventsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    restrictedEventNames: t.allowNull(
                      t.mapOf(t.allowNull(t.number())),
                    ),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsUnwantedParamsConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    unwantedParams: t.allowNull(t.arrayOf(t.string())),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsURLMetadataConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.coerce,
                  n = e.Typed,
                  r = n.objectWithFields({
                    contentIDRegex: n.arrayOf(
                      n.objectWithFields({
                        regex: n.string(),
                        regex_type: n.enumeration({
                          reversedpathregex: "REVERSED_PATH_REGEX",
                          queryparamregex: "QUERY_PARAM_REGEX",
                          pathregex: "PATH_REGEX",
                        }),
                        domain: n.string(),
                      }),
                    ),
                  });
                o.exports = r;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var e = Object.prototype.toString,
                n = !("addEventListener" in t);
              function r(e, t) {
                return t != null && e instanceof t;
              }
              function a(t) {
                return Array.isArray
                  ? Array.isArray(t)
                  : e.call(t) === "[object Array]";
              }
              function i(e) {
                return (
                  typeof e == "number" ||
                  (typeof e == "string" && /^\d+$/.test(e))
                );
              }
              function l(e) {
                return e != null && G(e) === "object" && a(e) === !1;
              }
              function s(e) {
                return (
                  l(e) === !0 &&
                  Object.prototype.toString.call(e) === "[object Object]"
                );
              }
              function u(e) {
                if (s(e) === !1) return !1;
                var t = e.constructor;
                if (typeof t != "function") return !1;
                var n = t.prototype;
                return !(
                  s(n) === !1 ||
                  Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") ===
                    !1
                );
              }
              var c =
                Number.isInteger ||
                function (e) {
                  return (
                    typeof e == "number" && isFinite(e) && Math.floor(e) === e
                  );
                };
              function d(e) {
                return c(e) && e >= 0 && e <= Number.MAX_SAFE_INTEGER;
              }
              function m(e, t, r) {
                var o = n ? "on" + t : t,
                  a = n ? e.attachEvent : e.addEventListener,
                  i = n ? e.detachEvent : e.removeEventListener,
                  l = function () {
                    (i && i.call(e, o, l, !1), r());
                  };
                a && a.call(e, o, l, !1);
              }
              var p = Object.prototype.hasOwnProperty,
                _ = !{ toString: null }.propertyIsEnumerable("toString"),
                f = [
                  "toString",
                  "toLocaleString",
                  "valueOf",
                  "hasOwnProperty",
                  "isPrototypeOf",
                  "propertyIsEnumerable",
                  "constructor",
                ],
                g = f.length;
              function h(e) {
                if (G(e) !== "object" && (typeof e != "function" || e === null))
                  throw new TypeError("Object.keys called on non-object");
                var t = [];
                for (var n in e) p.call(e, n) && t.push(n);
                if (_)
                  for (var r = 0; r < g; r++) p.call(e, f[r]) && t.push(f[r]);
                return t;
              }
              function y(e, t) {
                if (e == null)
                  throw new TypeError(" array is null or not defined");
                var n = Object(e),
                  r = n.length >>> 0;
                if (typeof t != "function")
                  throw new TypeError(t + " is not a function");
                for (var o = new Array(r), a = 0; a < r; ) {
                  var i = void 0,
                    l = void 0;
                  (a in n && ((i = n[a]), (l = t(i, a, n)), (o[a] = l)), a++);
                }
                return o;
              }
              function C(e, t, n, r) {
                if (e == null)
                  throw new TypeError(" array is null or not defined");
                if (typeof t != "function")
                  throw new TypeError(t + " is not a function");
                var o = Object(e),
                  a = o.length >>> 0,
                  i = 0,
                  l;
                if (n != null || r === !0) l = n;
                else {
                  for (; i < a && !(i in o); ) i++;
                  if (i >= a)
                    throw new TypeError(
                      "Reduce of empty array with no initial value",
                    );
                  l = o[i++];
                }
                for (; i < a; ) (i in o && (l = t(l, o[i], i, e)), i++);
                return l;
              }
              function b(e) {
                if (typeof e != "function") throw new TypeError();
                for (
                  var t = Object(this),
                    n = t.length >>> 0,
                    r = arguments.length >= 2 ? arguments[1] : void 0,
                    o = 0;
                  o < n;
                  o++
                )
                  if (o in t && e.call(r, t[o], o, t)) return !0;
                return !1;
              }
              function v(e) {
                return h(e).length === 0;
              }
              function S(e) {
                if (this === void 0 || this === null) throw new TypeError();
                var t = Object(this),
                  n = t.length >>> 0;
                if (typeof e != "function") throw new TypeError();
                for (
                  var r = [],
                    o = arguments.length >= 2 ? arguments[1] : void 0,
                    a = 0;
                  a < n;
                  a++
                )
                  if (a in t) {
                    var i = t[a];
                    e.call(o, i, a, t) && r.push(i);
                  }
                return r;
              }
              function R(e, t) {
                try {
                  return t(e);
                } catch (e) {
                  if (e instanceof TypeError) {
                    if (L.test(e)) return null;
                    if (E.test(e)) return;
                  }
                  throw e;
                }
              }
              var L = /^null | null$|^[^(]* null /i,
                E = /^undefined | undefined$|^[^(]* undefined /i;
              R.default = R;
              var k = (function () {
                function e(t) {
                  ($(this, e), (this.items = t || []));
                }
                return N(e, [
                  {
                    key: "has",
                    value: function (t) {
                      return b.call(this.items, function (e) {
                        return e === t;
                      });
                    },
                  },
                  {
                    key: "add",
                    value: function (t) {
                      this.items.push(t);
                    },
                  },
                ]);
              })();
              function I(e) {
                return e;
              }
              function T(e, t) {
                return e == null || t == null ? !1 : e.indexOf(t) >= 0;
              }
              function D(e, t) {
                return e == null || t == null ? !1 : e.indexOf(t) === 0;
              }
              function x(e) {
                return e.filter(function (t, n) {
                  return e.indexOf(t) === n;
                });
              }
              function P() {
                var e = Date.now();
                return typeof e == "number" ? e : new Date().getTime();
              }
              var M = {
                FBSet: k,
                castTo: I,
                each: function (t, n) {
                  y.call(this, t, n);
                },
                filter: function (t, n) {
                  return S.call(t, n);
                },
                getCurrentTime: P,
                idx: R,
                isArray: a,
                isEmptyObject: v,
                isInstanceOf: r,
                isInteger: c,
                isNumber: i,
                isObject: l,
                isPlainObject: u,
                isSafeInteger: d,
                keys: h,
                listenOnce: m,
                map: y,
                reduce: C,
                some: function (t, n) {
                  return b.call(t, n);
                },
                stringIncludes: T,
                stringStartsWith: D,
                removeDuplicates: x,
              };
              o.exports = M;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateCustomParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("SignalsFBEventsPixelTypedef");
                function l() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(t, r.tuple([i, r.object(), r.string()]));
                }
                var s = new e(l);
                o.exports = s;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateGetClickIDFromBrowserProperties",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent");
                function t(e) {
                  return e != null && typeof e == "string" && e !== ""
                    ? e
                    : null;
                }
                var n = new e(t);
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEventsValidateUrlParametersEvent",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                  t = a.getFbeventsModules("SignalsFBEventsTyped"),
                  n = t.coerce,
                  r = t.Typed,
                  i = a.getFbeventsModules("SignalsFBEventsPixelTypedef"),
                  l = a.getFbeventsModules("SignalsParamList");
                function s() {
                  for (
                    var e = arguments.length, t = new Array(e), o = 0;
                    o < e;
                    o++
                  )
                    t[o] = arguments[o];
                  return n(
                    t,
                    r.tuple([i, r.mapOf(r.string()), r.string(), r.object()]),
                  );
                }
                var u = new e(s);
                o.exports = u;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsValidationUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.stringStartsWith,
                n = /^[a-f0-9]{64}$/i,
                r = /^\s+|\s+$/g,
                i = /\s+/g,
                l = /[!\"#\$%&\'\(\)\*\+,\-\.\/:;<=>\?@ \[\\\]\^_`\{\|\}~\s]+/g,
                s = /[^a-zA-Z0-9]+/g,
                u = /^1\(?\d{3}\)?\d{7}$/,
                c = /^47\d{8}$/,
                d = /^\d{1,4}\(?\d{2,3}\)?\d{4,}$/;
              function m(e) {
                return typeof e == "string" ? e.replace(r, "") : "";
              }
              function p(e) {
                var t =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : "whitespace_only",
                  n = "";
                if (typeof e == "string")
                  switch (t) {
                    case "whitespace_only":
                      n = e.replace(i, "");
                      break;
                    case "whitespace_and_punctuation":
                      n = e.replace(l, "");
                      break;
                    case "all_non_latin_alpha_numeric":
                      n = e.replace(s, "");
                      break;
                  }
                return n;
              }
              function _(e) {
                return typeof e == "string" && n.test(e);
              }
              function f(e) {
                var n = String(e)
                  .replace(/[\-\s]+/g, "")
                  .replace(/^\+?0{0,2}/, "");
                return t(n, "0")
                  ? !1
                  : t(n, "1")
                    ? u.test(n)
                    : t(n, "47")
                      ? c.test(n)
                      : d.test(n);
              }
              o.exports = {
                isInternationalPhoneNumber: f,
                looksLikeHashed: _,
                strip: p,
                trim: m,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsWebchatConfigTypedef",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                  t = e.Typed,
                  n = t.objectWithFields({
                    automaticEventNamesEnabled: t.arrayOf(t.string()),
                    automaticEventsEnabled: t.boolean(),
                    pixelDataToWebchatEnabled: t.boolean(),
                  });
                o.exports = n;
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered("SignalsFBEventsWebChatEvent", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsBaseEvent"),
                t = a.getFbeventsModules("SignalsFBEventsTyped"),
                n = t.Typed,
                r = t.coerce,
                i = n.objectWithFields({
                  pixelID: n.allowNull(n.string()),
                  eventName: n.string(),
                  customData: n.allowNull(n.mutableObject()),
                  eventData: n.allowNull(n.object()),
                  customParams: n.allowNull(n.stringRecord()),
                }),
                l = new e(n.tuple([i]));
              o.exports = l;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsParamList", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censoredIneligibleKeysWithUD,
                n = a.getFbeventsModules("SignalsEventPayload"),
                r = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                i = "deep",
                l = "shallow",
                s = ["eid"];
              function u(e) {
                return JSON == null || !JSON.stringify
                  ? Object.prototype.toString.call(e)
                  : JSON.stringify(e);
              }
              function c(e) {
                if (e == null) return !0;
                var t = G(e);
                return t === "number" || t === "boolean" || t === "string";
              }
              var d = (function () {
                function e(t) {
                  ($(this, e),
                    S(this, "_params", new Map()),
                    (this._piiTranslator = t));
                }
                return N(
                  e,
                  [
                    {
                      key: "containsKey",
                      value: function (t) {
                        return this._params.has(t);
                      },
                    },
                    {
                      key: "get",
                      value: function (t) {
                        var e = this._params.get(t);
                        return e == null || e.length === 0
                          ? null
                          : e[e.length - 1];
                      },
                    },
                    {
                      key: "getAll",
                      value: function (t) {
                        var e = this._params.get(t);
                        return e || null;
                      },
                    },
                    {
                      key: "getAllParams",
                      value: function () {
                        var e = [],
                          t = U(this._params.entries()),
                          n;
                        try {
                          for (t.s(); !(n = t.n()).done; ) {
                            var r = R(n.value, 2),
                              o = r[0],
                              a = r[1],
                              i = U(a),
                              l;
                            try {
                              for (i.s(); !(l = i.n()).done; ) {
                                var s = l.value;
                                e.push({ name: o, value: s });
                              }
                            } catch (e) {
                              i.e(e);
                            } finally {
                              i.f();
                            }
                          }
                        } catch (e) {
                          t.e(e);
                        } finally {
                          t.f();
                        }
                        return e;
                      },
                    },
                    {
                      key: "replaceEntry",
                      value: function (t, n) {
                        (this._removeKey(t), this.append(t, n));
                      },
                    },
                    {
                      key: "replaceObjectEntry",
                      value: function (t, n) {
                        (this._removeObjectKey(t, n), this.append(t, n));
                      },
                    },
                    {
                      key: "addRange",
                      value: function (t) {
                        this.addParams(t.getAllParams());
                      },
                    },
                    {
                      key: "addParams",
                      value: function (t) {
                        for (var e = 0; e < t.length; e++) {
                          var n = t[e];
                          this._append({ name: n.name, value: n.value }, l, !1);
                        }
                        return this;
                      },
                    },
                    {
                      key: "append",
                      value: function (t, n) {
                        var e =
                          arguments.length > 2 && arguments[2] !== void 0
                            ? arguments[2]
                            : !1;
                        return (
                          this._append(
                            { name: encodeURIComponent(t), value: n },
                            i,
                            e,
                          ),
                          this
                        );
                      },
                    },
                    {
                      key: "appendHash",
                      value: function (t) {
                        var e =
                          arguments.length > 1 && arguments[1] !== void 0
                            ? arguments[1]
                            : !1;
                        for (var n in t)
                          Object.prototype.hasOwnProperty.call(t, n) &&
                            this._append(
                              { name: encodeURIComponent(n), value: t[n] },
                              i,
                              e,
                            );
                        return this;
                      },
                    },
                    {
                      key: "_removeKey",
                      value: function (t) {
                        this._params.delete(t);
                      },
                    },
                    {
                      key: "_removeObjectKey",
                      value: function (t, n) {
                        for (var e in n)
                          if (Object.prototype.hasOwnProperty.call(n, e)) {
                            var r = ""
                              .concat(t, "[")
                              .concat(encodeURIComponent(e), "]");
                            this._removeKey(r);
                          }
                      },
                    },
                    {
                      key: "_append",
                      value: function (t, n, r) {
                        var e = t.name,
                          o = t.value;
                        if (o != null)
                          for (var a = 0; a < s.length; a++) {
                            var l = s[a];
                            l === e && this._removeKey(e);
                          }
                        c(o)
                          ? this._appendPrimitive(e, o, r)
                          : n === i
                            ? this._appendObject(e, o, r)
                            : this._appendPrimitive(e, u(o), r);
                      },
                    },
                    {
                      key: "_translateValue",
                      value: function (n, o, a) {
                        if (typeof o == "boolean") return o ? "true" : "false";
                        if (!a) return "".concat(o);
                        if (!this._piiTranslator)
                          throw new Error(
                            "Cannot translate value for key '".concat(
                              n,
                              "' - translator is not initialized",
                            ),
                          );
                        var e = this._piiTranslator(n, "".concat(o));
                        return e == null
                          ? null
                          : (t.includes(n) &&
                              r.eval("send_normalized_ud_format") &&
                              this._appendPrimitive(
                                "nc" + n,
                                e.censoredFormat,
                                !1,
                              ),
                            e.finalValue);
                      },
                    },
                    {
                      key: "_appendPrimitive",
                      value: function (t, n, r) {
                        if (n != null) {
                          var e = this._translateValue(t, n, r);
                          if (e != null) {
                            var o = this._params.get(t);
                            o != null
                              ? (o.push(e), this._params.set(t, o))
                              : this._params.set(t, [e]);
                          }
                        }
                      },
                    },
                    {
                      key: "_appendObject",
                      value: function (t, n, r) {
                        var e = null;
                        for (var o in n)
                          if (Object.prototype.hasOwnProperty.call(n, o)) {
                            var a = ""
                              .concat(t, "[")
                              .concat(encodeURIComponent(o), "]");
                            try {
                              this._append({ name: a, value: n[o] }, l, r);
                            } catch (t) {
                              e == null && (e = t);
                            }
                          }
                        if (e != null) throw e;
                      },
                    },
                    {
                      key: "each",
                      value: function (t) {
                        var e = U(this._params.entries()),
                          n;
                        try {
                          for (e.s(); !(n = e.n()).done; ) {
                            var r = R(n.value, 2),
                              o = r[0],
                              a = r[1],
                              i = U(a),
                              l;
                            try {
                              for (i.s(); !(l = i.n()).done; ) {
                                var s = l.value;
                                t(o, s);
                              }
                            } catch (e) {
                              i.e(e);
                            } finally {
                              i.f();
                            }
                          }
                        } catch (t) {
                          e.e(t);
                        } finally {
                          e.f();
                        }
                      },
                    },
                    {
                      key: "getEventId",
                      value: function () {
                        for (
                          var e = ["eid", "eid[]", encodeURIComponent("eid[]")],
                            t = 0,
                            n = e;
                          t < n.length;
                          t++
                        ) {
                          var r = n[t],
                            o = this.get(r);
                          if (o != null && o.length > 0) return o;
                        }
                        return null;
                      },
                    },
                    {
                      key: "toPayload",
                      value: function () {
                        var e = new n();
                        return (
                          this.each(function (t, n) {
                            e.append(t, n);
                          }),
                          e
                        );
                      },
                    },
                  ],
                  [
                    {
                      key: "fromHash",
                      value: function (n, r) {
                        return new e(r).appendHash(n);
                      },
                    },
                  ],
                );
              })();
              o.exports = d;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelCookieUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var n = a.getFbeventsModules("SignalsFBEventsPixelCookie"),
                r = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                i = a.getFbeventsModules("SignalsFBEventsLogging"),
                l = i.logWarning,
                s = a.getFbeventsModules("SignalsFBEventsQEV2"),
                u = a.getFbeventsModules("SignalsFBEventsExperimentNames"),
                c = u.COOKIE_TTL_FIX,
                d = a.getFbeventsModules("SignalsFBEventsUtils"),
                m = d.getCurrentTime,
                p = 2160 * 60 * 60 * 1e3,
                _ = 1e3,
                f = "_fbc",
                g = "fbc",
                h = "fbcs",
                y = "aems",
                C = "_fbp",
                b = "fbp",
                v = "fbclid",
                S = [{ prefix: "", query: "fbclid", ebp_path: "clickID" }],
                R = { params: S },
                L = !1;
              function E(e) {
                var t = s.isInTestPageLoadLevelExperiment(c);
                if (t) {
                  var n = m();
                  return new Date(n + Math.round(e)).toUTCString();
                }
                return new Date(Date.now() + Math.round(e)).toUTCString();
              }
              function k(e) {
                var n = [];
                try {
                  for (
                    var r = t.cookie.split(";"),
                      o = "^\\s*".concat(e, "=\\s*(.*?)\\s*$"),
                      a = new RegExp(o),
                      i = 0;
                    i < r.length;
                    i++
                  ) {
                    var s = r[i].match(a);
                    s && n.push(s[1]);
                  }
                  return n &&
                    Object.prototype.hasOwnProperty.call(n, 0) &&
                    typeof n[0] == "string"
                    ? n[0]
                    : "";
                } catch (e) {
                  return (l("Fail to read from cookie: " + e.message), "");
                }
              }
              function I(e) {
                var t = k(e);
                return typeof t != "string" || t === "" ? null : n.unpack(t);
              }
              function T(e, t) {
                return e.slice(e.length - 1 - t).join(".");
              }
              function D(e, n, o) {
                var a =
                    arguments.length > 3 && arguments[3] !== void 0
                      ? arguments[3]
                      : p,
                  i = encodeURIComponent(n);
                try {
                  t.cookie =
                    "".concat(e, "=").concat(i, ";") +
                    "expires=".concat(E(a), ";") +
                    "domain=.".concat(o, ";") +
                    "".concat(r() ? "SameSite=Lax;" : "") +
                    "path=/";
                } catch (e) {
                  l("Fail to write cookie: " + e.message);
                }
                var u = I(e);
                if (u == null) {
                  var d = s.isInTestPageLoadLevelExperiment(c);
                  if (d)
                    try {
                      t.cookie =
                        "".concat(e, "=").concat(i, ";") +
                        "max-age=".concat(Math.floor(a / _), ";") +
                        "domain=.".concat(o, ";") +
                        "".concat(r() ? "SameSite=Lax;" : "") +
                        "path=/";
                    } catch (e) {
                      l("Fail to write cookie with max-age: " + e.message);
                    }
                }
              }
              function x(t, n) {
                var r = e.location.hostname,
                  o = r.split(".");
                if (n.subdomainIndex == null)
                  throw new Error("Subdomain index not set on cookie.");
                var a = T(o, n.subdomainIndex);
                return (D(t, n.pack(), a, p), n);
              }
              function $(t, r) {
                for (
                  var o =
                      arguments.length > 2 && arguments[2] !== void 0
                        ? arguments[2]
                        : p,
                    a = e.location.hostname,
                    i = a.split("."),
                    l = new n(r),
                    s = 0;
                  s < i.length;
                  s++
                ) {
                  var u = T(i, s);
                  ((l.subdomainIndex = s), D(t, l.pack(), u, o));
                  var c = k(t);
                  if (c != null && c != "" && n.unpack(c) != null) return l;
                }
                return l;
              }
              o.exports = {
                readPackedCookie: I,
                writeNewCookie: $,
                writeExistingCookie: x,
                CLICK_ID_PARAMETER: v,
                CLICKTHROUGH_COOKIE_NAME: f,
                CLICKTHROUGH_COOKIE_PARAM: g,
                DOMAIN_SCOPED_BROWSER_ID_COOKIE_NAME: C,
                DOMAIN_SCOPED_BROWSER_ID_COOKIE_PARAM: b,
                DEFAULT_FBC_PARAMS: S,
                DEFAULT_FBC_PARAM_CONFIG: R,
                DEFAULT_ENABLE_FBC_PARAM_SPLIT: L,
                MULTI_CLICKTHROUGH_COOKIE_PARAM: h,
                NINETY_DAYS_IN_MS: p,
                AEM_SOURCE_PAYLOAD_KEY: y,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelPIIConstants", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsUtils"),
                t = e.keys,
                n = e.map,
                r = {
                  ct: "ct",
                  city: "ct",
                  dob: "db",
                  dobd: "dobd",
                  dobm: "dobm",
                  doby: "doby",
                  email: "em",
                  fn: "fn",
                  f_name: "fn",
                  gen: "ge",
                  ln: "ln",
                  l_name: "ln",
                  phone: "ph",
                  st: "st",
                  state: "st",
                  zip: "zp",
                  zip_code: "zp",
                  pn: "ph",
                  primaryPhone: "ph",
                  user_email: "em",
                  eMailAddress: "em",
                  email_sha256: "em",
                  email_paypal: "em",
                  consent_global_email_nl: "em",
                  consent_global_email_drip: "em",
                  consent_fide_email_nl: "em",
                  consent_fide_email_drip: "em",
                  bd: "db",
                  birthday: "db",
                  dOB: "db",
                  external_id: "external_id",
                },
                i = {
                  em: [
                    "email",
                    "email_address",
                    "emailaddress",
                    "user_email",
                    "consent_global_email_nl",
                    "consent_global_email_drip",
                    "consent_fide_email_nl",
                    "consent_fide_email_drip",
                    "email_sha256",
                    "email_paypal",
                  ],
                  ph: [
                    "primaryphone",
                    "primary_phone",
                    "pn",
                    "phone",
                    "phone_number",
                    "tel",
                    "mobile",
                  ],
                  ln: ["lastname", "last_name", "surname", "lastnameeng"],
                  fn: [
                    "f_name",
                    "firstname",
                    "first_name",
                    "firstnameeng",
                    "name",
                    "profile_name",
                    "account_name",
                    "fbq_custom_name",
                  ],
                  ge: ["gender", "gen", "$gender"],
                  db: ["dob", "bd", "birthday", "d0b"],
                  ct: ["city", "$city"],
                  st: ["state", "$state"],
                  zp: ["zipcode", "zip_code", "zip", "postcode", "post_code"],
                },
                l = {
                  CITY: ["city"],
                  DATE: ["date", "dt", "day", "dobd"],
                  DOB: ["birth", "bday", "bdate", "bmonth", "byear", "dob"],
                  FEMALE: ["female", "girl", "woman"],
                  FIRST_NAME: [
                    "firstname",
                    "fn",
                    "fname",
                    "givenname",
                    "forename",
                  ],
                  GENDER_FIELDS: ["gender", "gen", "sex"],
                  GENDER_VALUES: [
                    "male",
                    "boy",
                    "man",
                    "female",
                    "girl",
                    "woman",
                  ],
                  LAST_NAME: [
                    "lastname",
                    "ln",
                    "lname",
                    "surname",
                    "sname",
                    "familyname",
                  ],
                  MALE: ["male", "boy", "man"],
                  MONTH: ["month", "mo", "mnth", "dobm"],
                  NAME: ["name", "fullname"],
                  PHONE_NUMBER: ["phone", "mobile", "contact"],
                  RESTRICTED: [
                    "ssn",
                    "unique",
                    "cc",
                    "card",
                    "cvv",
                    "cvc",
                    "cvn",
                    "creditcard",
                    "billing",
                    "security",
                    "social",
                    "pass",
                  ],
                  STATE: ["state", "province"],
                  USERNAME: ["username"],
                  YEAR: ["year", "yr", "doby"],
                  ZIP_CODE: [
                    "zip",
                    "zcode",
                    "pincode",
                    "pcode",
                    "postalcode",
                    "postcode",
                  ],
                },
                s = {
                  alabama: "al",
                  alaska: "ak",
                  arizona: "az",
                  arkansas: "ar",
                  california: "ca",
                  colorado: "co",
                  connecticut: "ct",
                  delaware: "de",
                  florida: "fl",
                  georgia: "ga",
                  hawaii: "hi",
                  idaho: "id",
                  illinois: "il",
                  indiana: "in",
                  iowa: "ia",
                  kansas: "ks",
                  kentucky: "ky",
                  louisiana: "la",
                  maine: "me",
                  maryland: "md",
                  massachusetts: "ma",
                  michigan: "mi",
                  minnesota: "mn",
                  mississippi: "ms",
                  missouri: "mo",
                  montana: "mt",
                  nebraska: "ne",
                  nevada: "nv",
                  newhampshire: "nh",
                  newjersey: "nj",
                  newmexico: "nm",
                  newyork: "ny",
                  northcarolina: "nc",
                  northdakota: "nd",
                  ohio: "oh",
                  oklahoma: "ok",
                  oregon: "or",
                  pennsylvania: "pa",
                  rhodeisland: "ri",
                  southcarolina: "sc",
                  southdakota: "sd",
                  tennessee: "tn",
                  texas: "tx",
                  utah: "ut",
                  vermont: "vt",
                  virginia: "va",
                  washington: "wa",
                  westvirginia: "wv",
                  wisconsin: "wi",
                  wyoming: "wy",
                },
                u = {
                  ontario: "on",
                  quebec: "qc",
                  britishcolumbia: "bc",
                  alberta: "ab",
                  saskatchewan: "sk",
                  manitoba: "mb",
                  novascotia: "ns",
                  newbrunswick: "nb",
                  princeedwardisland: "pe",
                  newfoundlandandlabrador: "nl",
                  yukon: "yt",
                  northwestterritories: "nt",
                  nunavut: "nu",
                },
                c = v(v({}, u), s),
                d = {
                  unitedstates: "us",
                  usa: "us",
                  ind: "in",
                  afghanistan: "af",
                  alandislands: "ax",
                  albania: "al",
                  algeria: "dz",
                  americansamoa: "as",
                  andorra: "ad",
                  angola: "ao",
                  anguilla: "ai",
                  antarctica: "aq",
                  antiguaandbarbuda: "ag",
                  argentina: "ar",
                  armenia: "am",
                  aruba: "aw",
                  australia: "au",
                  austria: "at",
                  azerbaijan: "az",
                  bahamas: "bs",
                  bahrain: "bh",
                  bangladesh: "bd",
                  barbados: "bb",
                  belarus: "by",
                  belgium: "be",
                  belize: "bz",
                  benin: "bj",
                  bermuda: "bm",
                  bhutan: "bt",
                  boliviaplurinationalstateof: "bo",
                  bolivia: "bo",
                  bonairesinteustatinsandsaba: "bq",
                  bosniaandherzegovina: "ba",
                  botswana: "bw",
                  bouvetisland: "bv",
                  brazil: "br",
                  britishindianoceanterritory: "io",
                  bruneidarussalam: "bn",
                  brunei: "bn",
                  bulgaria: "bg",
                  burkinafaso: "bf",
                  burundi: "bi",
                  cambodia: "kh",
                  cameroon: "cm",
                  canada: "ca",
                  capeverde: "cv",
                  caymanislands: "ky",
                  centralafricanrepublic: "cf",
                  chad: "td",
                  chile: "cl",
                  china: "cn",
                  christmasisland: "cx",
                  cocoskeelingislands: "cc",
                  colombia: "co",
                  comoros: "km",
                  congo: "cg",
                  congothedemocraticrepublicofthe: "cd",
                  democraticrepublicofthecongo: "cd",
                  cookislands: "ck",
                  costarica: "cr",
                  cotedivoire: "ci",
                  ivorycoast: "ci",
                  croatia: "hr",
                  cuba: "cu",
                  curacao: "cw",
                  cyprus: "cy",
                  czechrepublic: "cz",
                  denmark: "dk",
                  djibouti: "dj",
                  dominica: "dm",
                  dominicanrepublic: "do",
                  ecuador: "ec",
                  egypt: "eg",
                  elsalvador: "sv",
                  equatorialguinea: "gq",
                  eritrea: "er",
                  estonia: "ee",
                  ethiopia: "et",
                  falklandislandsmalvinas: "fk",
                  faroeislands: "fo",
                  fiji: "fj",
                  finland: "fi",
                  france: "fr",
                  frenchguiana: "gf",
                  frenchpolynesia: "pf",
                  frenchsouthernterritories: "tf",
                  gabon: "ga",
                  gambia: "gm",
                  georgia: "ge",
                  germany: "de",
                  ghana: "gh",
                  gibraltar: "gi",
                  greece: "gr",
                  greenland: "gl",
                  grenada: "gd",
                  guadeloupe: "gp",
                  guam: "gu",
                  guatemala: "gt",
                  guernsey: "gg",
                  guinea: "gn",
                  guineabissau: "gw",
                  guyana: "gy",
                  haiti: "ht",
                  heardislandandmcdonaldislands: "hm",
                  holyseevaticancitystate: "va",
                  vatican: "va",
                  honduras: "hn",
                  hongkong: "hk",
                  hungary: "hu",
                  iceland: "is",
                  india: "in",
                  indonesia: "id",
                  iranislamicrepublicof: "ir",
                  iran: "ir",
                  iraq: "iq",
                  ireland: "ie",
                  isleofman: "im",
                  israel: "il",
                  italy: "it",
                  jamaica: "jm",
                  japan: "jp",
                  jersey: "je",
                  jordan: "jo",
                  kazakhstan: "kz",
                  kenya: "ke",
                  kiribati: "ki",
                  koreademocraticpeoplesrepublicof: "kp",
                  northkorea: "kp",
                  korearepublicof: "kr",
                  southkorea: "kr",
                  kuwait: "kw",
                  kyrgyzstan: "kg",
                  laopeoplesdemocraticrepublic: "la",
                  laos: "la",
                  latvia: "lv",
                  lebanon: "lb",
                  lesotho: "ls",
                  liberia: "lr",
                  libya: "ly",
                  liechtenstein: "li",
                  lithuania: "lt",
                  luxembourg: "lu",
                  macao: "mo",
                  macedoniatheformeryugoslavrepublicof: "mk",
                  macedonia: "mk",
                  madagascar: "mg",
                  malawi: "mw",
                  malaysia: "my",
                  maldives: "mv",
                  mali: "ml",
                  malta: "mt",
                  marshallislands: "mh",
                  martinique: "mq",
                  mauritania: "mr",
                  mauritius: "mu",
                  mayotte: "yt",
                  mexico: "mx",
                  micronesiafederatedstatesof: "fm",
                  micronesia: "fm",
                  moldovarepublicof: "md",
                  moldova: "md",
                  monaco: "mc",
                  mongolia: "mn",
                  montenegro: "me",
                  montserrat: "ms",
                  morocco: "ma",
                  mozambique: "mz",
                  myanmar: "mm",
                  namibia: "na",
                  nauru: "nr",
                  nepal: "np",
                  netherlands: "nl",
                  newcaledonia: "nc",
                  newzealand: "nz",
                  nicaragua: "ni",
                  niger: "ne",
                  nigeria: "ng",
                  niue: "nu",
                  norfolkisland: "nf",
                  northernmarianaislands: "mp",
                  norway: "no",
                  oman: "om",
                  pakistan: "pk",
                  palau: "pw",
                  palestinestateof: "ps",
                  palestine: "ps",
                  panama: "pa",
                  papuanewguinea: "pg",
                  paraguay: "py",
                  peru: "pe",
                  philippines: "ph",
                  pitcairn: "pn",
                  poland: "pl",
                  portugal: "pt",
                  puertorico: "pr",
                  qatar: "qa",
                  reunion: "re",
                  romania: "ro",
                  russianfederation: "ru",
                  russia: "ru",
                  rwanda: "rw",
                  saintbarthelemy: "bl",
                  sainthelenaascensionandtristandacunha: "sh",
                  saintkittsandnevis: "kn",
                  saintlucia: "lc",
                  saintmartinfrenchpart: "mf",
                  saintpierreandmiquelon: "pm",
                  saintvincentandthegrenadines: "vc",
                  samoa: "ws",
                  sanmarino: "sm",
                  saotomeandprincipe: "st",
                  saudiarabia: "sa",
                  senegal: "sn",
                  serbia: "rs",
                  seychelles: "sc",
                  sierraleone: "sl",
                  singapore: "sg",
                  sintmaartenductchpart: "sx",
                  slovakia: "sk",
                  slovenia: "si",
                  solomonislands: "sb",
                  somalia: "so",
                  southafrica: "za",
                  southgeorgiaandthesouthsandwichislands: "gs",
                  southsudan: "ss",
                  spain: "es",
                  srilanka: "lk",
                  sudan: "sd",
                  suriname: "sr",
                  svalbardandjanmayen: "sj",
                  eswatini: "sz",
                  swaziland: "sz",
                  sweden: "se",
                  switzerland: "ch",
                  syrianarabrepublic: "sy",
                  syria: "sy",
                  taiwanprovinceofchina: "tw",
                  taiwan: "tw",
                  tajikistan: "tj",
                  tanzaniaunitedrepublicof: "tz",
                  tanzania: "tz",
                  thailand: "th",
                  timorleste: "tl",
                  easttimor: "tl",
                  togo: "tg",
                  tokelau: "tk",
                  tonga: "to",
                  trinidadandtobago: "tt",
                  tunisia: "tn",
                  turkey: "tr",
                  turkmenistan: "tm",
                  turksandcaicosislands: "tc",
                  tuvalu: "tv",
                  uganda: "ug",
                  ukraine: "ua",
                  unitedarabemirates: "ae",
                  unitedkingdom: "gb",
                  unitedstatesofamerica: "us",
                  unitedstatesminoroutlyingislands: "um",
                  uruguay: "uy",
                  uzbekistan: "uz",
                  vanuatu: "vu",
                  venezuelabolivarianrepublicof: "ve",
                  venezuela: "ve",
                  vietnam: "vn",
                  virginislandsbritish: "vg",
                  virginislandsus: "vi",
                  wallisandfutuna: "wf",
                  westernsahara: "eh",
                  yemen: "ye",
                  zambia: "zm",
                  zimbabwe: "zw",
                },
                m =
                  /^\+?\d{1,4}[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/,
                p =
                  /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i,
                _ = /^\d{5}(?:[-\s]\d{4})?$/,
                f = Object.freeze({ US: "^\\d{5}$" }),
                g = n(t(f), function (e) {
                  return f[e];
                }),
                h = {};
              ((h["^\\d{1,2}/\\d{1,2}/\\d{4}$"] = ["DD/MM/YYYY", "MM/DD/YYYY"]),
                (h["^\\d{1,2}-\\d{1,2}-\\d{4}$"] = [
                  "DD-MM-YYYY",
                  "MM-DD-YYYY",
                ]),
                (h["^\\d{4}/\\d{1,2}/\\d{1,2}$"] = ["YYYY/MM/DD"]),
                (h["^\\d{4}-\\d{1,2}-\\d{1,2}$"] = ["YYYY-MM-DD"]),
                (h["^\\d{1,2}/\\d{1,2}/\\d{2}$"] = ["DD/MM/YY", "MM/DD/YY"]),
                (h["^\\d{1,2}-\\d{1,2}-\\d{2}$"] = ["DD-MM-YY", "MM-DD-YY"]),
                (h["^\\d{2}/\\d{1,2}/\\d{1,2}$"] = ["YY/MM/DD"]),
                (h["^\\d{2}-\\d{1,2}-\\d{1,2}$"] = ["YY-MM-DD"]));
              var y = [
                "MM-DD-YYYY",
                "MM/DD/YYYY",
                "DD-MM-YYYY",
                "DD/MM/YYYY",
                "YYYY-MM-DD",
                "YYYY/MM/DD",
                "MM-DD-YY",
                "MM/DD/YY",
                "DD-MM-YY",
                "DD/MM/YY",
                "YY-MM-DD",
                "YY/MM/DD",
              ];
              o.exports = {
                COUNTRY_MAPPINGS: d,
                EMAIL_REGEX: p,
                PHONE_NUMBER_REGEX: m,
                POSSIBLE_FEATURE_FIELDS: l,
                PII_KEY_ALIAS_TO_SHORT_CODE: r,
                SIGNALS_FBEVENTS_DATE_FORMATS: y,
                VALID_DATE_REGEX_FORMATS: h,
                ZIP_REGEX_VALUES: g,
                ZIP_CODE_REGEX: _,
                STATE_MAPPINGS: c,
                PII_KEYS_TO_ALIASES_EXPANDED: i,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsPixelPIIUtils", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censorPII,
                n = a.getFbeventsModules("SignalsFBEventsNormalizers"),
                r = a.getFbeventsModules("SignalsFBEventsPixelPIISchema"),
                i = a.getFbeventsModules("SignalsFBEventsUtils"),
                l = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                s = a.getFbeventsModules("normalizeSignalsFBEventsEmailType"),
                u = a.getFbeventsModules(
                  "normalizeSignalsFBEventsPostalCodeType",
                ),
                c = a.getFbeventsModules(
                  "normalizeSignalsFBEventsPhoneNumberType",
                ),
                d = a.getFbeventsModules("normalizeSignalsFBEventsStringType"),
                m = d.normalizeName,
                p = d.normalizeCity,
                _ = d.normalizeState,
                f = a.getFbeventsModules("SignalsPixelPIIConstants"),
                g = f.EMAIL_REGEX,
                h = f.POSSIBLE_FEATURE_FIELDS,
                y = f.PII_KEY_ALIAS_TO_SHORT_CODE,
                C = f.ZIP_REGEX_VALUES,
                b = f.ZIP_CODE_REGEX,
                S = f.PHONE_NUMBER_REGEX,
                R = i.some,
                L = i.stringIncludes;
              function E(e) {
                var t = e.id,
                  n = e.keyword,
                  r = e.name,
                  o = e.placeholder,
                  a = e.value;
                return n.length > 2
                  ? L(r, n) || L(t, n) || L(o, n) || L(a, n)
                  : r === n || t === n || o === n || a === n;
              }
              function k(e) {
                var t = e.id,
                  n = e.keywords,
                  r = e.name,
                  o = e.placeholder,
                  a = e.value;
                return R(n, function (e) {
                  return E({
                    id: t,
                    keyword: e,
                    name: r,
                    placeholder: o,
                    value: a,
                  });
                });
              }
              function I(e) {
                return e != null && typeof e == "string" && g.test(e);
              }
              function T(e) {
                var t = e;
                return (
                  typeof t == "number" &&
                    typeof t.toString == "function" &&
                    (t = t.toString()),
                  t != null && typeof t == "string" && t.length > 6 && S.test(t)
                );
              }
              function D(e) {
                var t = e;
                return (
                  typeof t == "number" &&
                    typeof t.toString == "function" &&
                    (t = t.toString()),
                  t != null && typeof t == "string" && b.test(t)
                );
              }
              function x(e) {
                var t = e.value,
                  n = e.parentElement,
                  r = e.previousElementSibling,
                  o = null;
                if (
                  ((r instanceof HTMLInputElement ||
                    r instanceof HTMLTextAreaElement) &&
                    (o = r.value),
                  o == null || typeof o != "string" || n == null)
                )
                  return null;
                var a = n.innerText != null ? n.innerText : n.textContent;
                if (a == null || a.indexOf("@") < 0) return null;
                var i = "".concat(o, "@").concat(t);
                return g.test(i) ? i : null;
              }
              function $(e, t) {
                var n = e.name,
                  r = e.id,
                  o = e.placeholder,
                  a = e.value;
                return (
                  (t === "tel" && !(a.length <= 6 && h.ZIP_CODE.includes(r))) ||
                  k({
                    id: r,
                    keywords: h.PHONE_NUMBER,
                    name: n,
                    placeholder: o,
                  })
                );
              }
              function P(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return k({
                  id: n,
                  keywords: h.FIRST_NAME,
                  name: t,
                  placeholder: r,
                });
              }
              function N(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return k({
                  id: n,
                  keywords: h.LAST_NAME,
                  name: t,
                  placeholder: r,
                });
              }
              function M(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return (
                  k({ id: n, keywords: h.NAME, name: t, placeholder: r }) &&
                  !k({ id: n, keywords: h.USERNAME, name: t, placeholder: r })
                );
              }
              function w(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return k({ id: n, keywords: h.CITY, name: t, placeholder: r });
              }
              function A(e) {
                var t = e.name,
                  n = e.id,
                  r = e.placeholder;
                return k({ id: n, keywords: h.STATE, name: t, placeholder: r });
              }
              function F(e, t, n) {
                var r = e.name,
                  o = e.id,
                  a = e.placeholder,
                  i = e.value;
                return (t === "checkbox" || t === "radio") && n === !0
                  ? k({
                      id: o,
                      keywords: h.GENDER_VALUES,
                      name: r,
                      placeholder: a,
                      value: i,
                    })
                  : t === "text"
                    ? k({
                        id: o,
                        keywords: h.GENDER_FIELDS,
                        name: r,
                        placeholder: a,
                      })
                    : !1;
              }
              function O(e, t) {
                var n = e.name,
                  r = e.id;
                return (
                  (t !== "" &&
                    R(C, function (e) {
                      var n = t.match(String(e));
                      return n != null && n[0] === t;
                    })) ||
                  k({ id: r, keywords: h.ZIP_CODE, name: n })
                );
              }
              function B(e) {
                var t = e.name,
                  n = e.id;
                return k({ id: n, keywords: h.RESTRICTED, name: t });
              }
              function W(e) {
                return e.trim().toLowerCase().replace(/[_-]/g, "");
              }
              function q(e) {
                return e.trim().toLowerCase();
              }
              function U(e) {
                return R(h.MALE, function (t) {
                  return t === e;
                })
                  ? "m"
                  : R(h.FEMALE, function (t) {
                        return t === e;
                      })
                    ? "f"
                    : "";
              }
              function V(e) {
                return y[e] !== void 0 ? y[e] : e;
              }
              function H(e, t) {
                var o =
                    arguments.length > 2 && arguments[2] !== void 0
                      ? arguments[2]
                      : !1,
                  a = V(e),
                  i = r[a];
                (i == null || i.length === 0) && (i = r.default);
                var l = n[i.type];
                if (l == null) return null;
                var s = l(t, i.typeParams, o);
                return s != null && s !== "" ? s : null;
              }
              function G(e, n) {
                var r = n.value,
                  o = n instanceof HTMLInputElement && n.checked === !0,
                  a = e.name,
                  i = e.id,
                  d = e.inputType,
                  f = e.placeholder,
                  g = {
                    id: W(a),
                    name: W(i),
                    placeholder: (f != null && W(f)) || "",
                    value: q(r),
                  };
                if (B(g) || d === "password" || r === "" || r == null)
                  return null;
                if (I(g.value))
                  return {
                    normalized: { em: s(g.value) },
                    alternateNormalized: { em: s(g.value) },
                    rawCensored: l.eval("send_censored_em") ? { em: t(r) } : {},
                  };
                if (x(n) != null)
                  return {
                    normalized: { em: s(x(n)) },
                    alternateNormalized: { em: s(x(n)) },
                    rawCensored: l.eval("send_censored_em") ? { em: t(r) } : {},
                  };
                if (P(g))
                  return {
                    normalized: { fn: m(g.value) },
                    alternateNormalized: { fn: m(g.value) },
                    rawCensored: l.eval("send_censored_ph") ? { fn: t(r) } : {},
                  };
                if (N(g))
                  return {
                    normalized: { ln: m(g.value) },
                    alternateNormalized: { ln: m(g.value) },
                    rawCensored: l.eval("send_censored_ph") ? { ln: t(r) } : {},
                  };
                if ($(g, d))
                  return {
                    normalized: { ph: c(g.value) },
                    alternateNormalized: { ph: c(g.value, null, !0) },
                    rawCensored: l.eval("send_censored_ph")
                      ? { ph: t(g.value) }
                      : {},
                  };
                if (M(g)) {
                  var h = r.split(" "),
                    y = h[0];
                  h.shift();
                  var C = h.join(" "),
                    b = g.value.split(" "),
                    S = { fn: m(b[0]) };
                  b.shift();
                  var R = { ln: m(b.join(" ")) };
                  return {
                    normalized: v(v({}, S), R),
                    alternateNormalized: v(v({}, S), R),
                    rawCensored: l.eval("send_censored_ph")
                      ? { fn: t(y), ln: t(C) }
                      : {},
                  };
                } else {
                  if (w(g))
                    return {
                      normalized: { ct: p(g.value) },
                      alternateNormalized: { ct: p(g.value) },
                      rawCensored: { ct: t(r) },
                    };
                  if (A(g))
                    return {
                      normalized: { st: _(g.value) },
                      alternateNormalized: { st: _(g.value, null, !0) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { st: t(r) }
                        : {},
                    };
                  if (d != null && F(g, d, o))
                    return {
                      normalized: { ge: U(g.value) },
                      alternateNormalized: { ge: U(g.value) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { ge: t(r) }
                        : {},
                    };
                  if (O(g, r))
                    return {
                      normalized: { zp: u(g.value) },
                      alternateNormalized: { zp: u(g.value) },
                      rawCensored: l.eval("send_censored_ph")
                        ? { zp: t(r) }
                        : {},
                    };
                }
                return null;
              }
              o.exports = {
                extractPIIFields: G,
                getNormalizedPIIKey: V,
                getNormalizedPIIValue: H,
                isEmail: I,
                getGenderCharacter: U,
                isPhoneNumber: T,
                isZipCode: D,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("WebStorage", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var t = typeof e != "undefined" ? e : self,
                n = {
                  getLocalStorage: function () {
                    var e = null;
                    try {
                      if (
                        ((e = t.localStorage),
                        e != null &&
                          typeof e.setItem == "function" &&
                          typeof e.removeItem == "function")
                      ) {
                        var n = "__test__" + Date.now();
                        return (e.setItem(n, ""), e.removeItem(n), e);
                      }
                    } catch (e) {
                      return null;
                    }
                    return null;
                  },
                };
              o.exports = n;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("WebStorageMutex", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              function e() {
                return Date.now();
              }
              function t() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                  /[xy]/g,
                  function (e) {
                    var t = (Math.random() * 16) | 0,
                      n = e === "x" ? t : (t & 3) | 8;
                    return n.toString(16);
                  },
                );
              }
              var n = "pixel_mutex:",
                r = 1e3,
                i = a.getFbeventsModules("WebStorage"),
                l = i.getLocalStorage,
                s = t(),
                u = null,
                c = !1;
              function d() {
                return (c || ((c = !0), (u = l())), u);
              }
              function m(e) {
                return n + e;
              }
              function p() {
                return ""
                  .concat(e(), "-")
                  .concat(Math.random().toString(16).slice(2), "-")
                  .concat(t());
              }
              function _(e) {
                var t = d();
                if (!t) return null;
                var n = t.getItem(m(e));
                if (n == null) return null;
                try {
                  var r = JSON.parse(n);
                  if (
                    r &&
                    typeof r.ownerId == "string" &&
                    typeof r.token == "string" &&
                    Number.isFinite(r.expiresAt)
                  )
                    return r;
                } catch (e) {}
                return null;
              }
              function f(e, t) {
                var n = d();
                if (!n) return !1;
                try {
                  var r = JSON.stringify(t);
                  return (n.setItem(m(e), r), n.getItem(m(e)) === r);
                } catch (e) {
                  return !1;
                }
              }
              function g(e) {
                var t = d();
                if (t)
                  try {
                    t.removeItem(m(e));
                  } catch (e) {}
              }
              var h = new WeakMap(),
                y = new WeakSet(),
                C = (function () {
                  function t(e) {
                    ($(this, t),
                      A(this, y),
                      F(this, h, void 0),
                      (this.name = e),
                      W(h, this, null));
                  }
                  return N(
                    t,
                    [
                      {
                        key: "lock",
                        value: function (n, r, o) {
                          var t = this;
                          B(h, this) &&
                            (clearTimeout(B(h, this)), W(h, this, null));
                          var a = _(this.name);
                          ((!a || a.ownerId === s || a.expiresAt < e()) &&
                            q(y, this, v).call(this, o),
                            W(
                              h,
                              this,
                              setTimeout(function () {
                                (W(h, t, null),
                                  q(y, t, b).call(t) ? n(t) : r && r(t));
                              }, 0),
                            ));
                        },
                      },
                      {
                        key: "unlock",
                        value: function () {
                          (B(h, this) &&
                            (clearTimeout(B(h, this)), W(h, this, null)),
                            q(y, this, b).call(this) && g(this.name));
                        },
                      },
                    ],
                    [
                      {
                        key: "__testSetPageId",
                        value: function (t) {
                          s = t;
                        },
                      },
                    ],
                  );
                })();
              function b() {
                var t = _(this.name);
                return !!(t && t.ownerId === s && t.expiresAt >= e());
              }
              function v(e) {
                var t = Math.max(1, e == null ? r : e),
                  n = _(this.name);
                if (n && n.expiresAt >= Date.now() && n.ownerId !== s)
                  return !1;
                var o = { ownerId: s, token: p(), expiresAt: Date.now() + t };
                return !!f(this.name, o);
              }
              o.exports = C;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEvents.plugins.commonincludes",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsPlugin");
                o.exports = new e(function (e, t) {});
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      (o.exports = a.getFbeventsModules(
        "SignalsFBEvents.plugins.commonincludes",
      )),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.commonincludes", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.commonincludes", function () {
        return o.exports;
      }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e) {
      "@babel/helpers - typeof";
      return (
        (i =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        i(e)
      );
    }
    function l(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        ((r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, u(r.key), r));
      }
    }
    function s(e, t, n) {
      return (
        t && l(e.prototype, t),
        n && l(e, n),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function u(e) {
      var t = c(e, "string");
      return i(t) == "symbol" ? t : t + "";
    }
    function c(e, t) {
      if (i(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (i(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function d(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function m(e, t, n) {
      return (
        (t = g(t)),
        p(
          e,
          f() ? Reflect.construct(t, n || [], g(e).constructor) : t.apply(e, n),
        )
      );
    }
    function p(e, t) {
      if (t && (i(t) == "object" || typeof t == "function")) return t;
      if (t !== void 0)
        throw new TypeError(
          "Derived constructors may only return object or undefined",
        );
      return _(e);
    }
    function _(e) {
      if (e === void 0)
        throw new ReferenceError(
          "this hasn't been initialised - super() hasn't been called",
        );
      return e;
    }
    function f() {
      try {
        var e = !Boolean.prototype.valueOf.call(
          Reflect.construct(Boolean, [], function () {}),
        );
      } catch (e) {}
      return (f = function () {
        return !!e;
      })();
    }
    function g(e) {
      return (
        (g = Object.setPrototypeOf
          ? Object.getPrototypeOf.bind()
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        g(e)
      );
    }
    function h(e, t) {
      if (typeof t != "function" && t !== null)
        throw new TypeError(
          "Super expression must either be null or a function",
        );
      ((e.prototype = Object.create(t && t.prototype, {
        constructor: { value: e, writable: !0, configurable: !0 },
      })),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        t && y(e, t));
    }
    function y(e, t) {
      return (
        (y = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (e, t) {
              return ((e.__proto__ = t), e);
            }),
        y(e, t)
      );
    }
    function C(e, t) {
      return L(e) || R(e, t) || v(e, t) || b();
    }
    function b() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function v(e, t) {
      if (e) {
        if (typeof e == "string") return S(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? S(e, t)
              : void 0
        );
      }
    }
    function S(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    function R(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          ((u = !0), (o = e));
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function L(e) {
      if (Array.isArray(e)) return e;
    }
    (a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("sha256_with_dependencies_new", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              function e(e) {
                for (var t = "", n, r, o = 0; o < e.length; o++)
                  ((n = e.charCodeAt(o)),
                    (r = o + 1 < e.length ? e.charCodeAt(o + 1) : 0),
                    n >= 55296 &&
                      n <= 56319 &&
                      r >= 56320 &&
                      r <= 57343 &&
                      ((n = 65536 + ((n & 1023) << 10) + (r & 1023)), o++),
                    n <= 127
                      ? (t += String.fromCharCode(n))
                      : n <= 2047
                        ? (t += String.fromCharCode(
                            192 | ((n >>> 6) & 31),
                            128 | (n & 63),
                          ))
                        : n <= 65535
                          ? (t += String.fromCharCode(
                              224 | ((n >>> 12) & 15),
                              128 | ((n >>> 6) & 63),
                              128 | (n & 63),
                            ))
                          : n <= 2097151 &&
                            (t += String.fromCharCode(
                              240 | ((n >>> 18) & 7),
                              128 | ((n >>> 12) & 63),
                              128 | ((n >>> 6) & 63),
                              128 | (n & 63),
                            )));
                return t;
              }
              function t(e, t) {
                return (t >>> e) | (t << (32 - e));
              }
              function n(e, t, n) {
                return (e & t) ^ (~e & n);
              }
              function r(e, t, n) {
                return (e & t) ^ (e & n) ^ (t & n);
              }
              function a(e) {
                return t(2, e) ^ t(13, e) ^ t(22, e);
              }
              function i(e) {
                return t(6, e) ^ t(11, e) ^ t(25, e);
              }
              function l(e) {
                return t(7, e) ^ t(18, e) ^ (e >>> 3);
              }
              function s(e) {
                return t(17, e) ^ t(19, e) ^ (e >>> 10);
              }
              function u(e, t) {
                return (e[t & 15] +=
                  s(e[(t + 14) & 15]) + e[(t + 9) & 15] + l(e[(t + 1) & 15]));
              }
              var c = [
                  1116352408, 1899447441, 3049323471, 3921009573, 961987163,
                  1508970993, 2453635748, 2870763221, 3624381080, 310598401,
                  607225278, 1426881987, 1925078388, 2162078206, 2614888103,
                  3248222580, 3835390401, 4022224774, 264347078, 604807628,
                  770255983, 1249150122, 1555081692, 1996064986, 2554220882,
                  2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
                  113926993, 338241895, 666307205, 773529912, 1294757372,
                  1396182291, 1695183700, 1986661051, 2177026350, 2456956037,
                  2730485921, 2820302411, 3259730800, 3345764771, 3516065817,
                  3600352804, 4094571909, 275423344, 430227734, 506948616,
                  659060556, 883997877, 958139571, 1322822218, 1537002063,
                  1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
                  2428436474, 2756734187, 3204031479, 3329325298,
                ],
                d = new Array(8),
                m = new Array(2),
                p = new Array(64),
                _ = new Array(16),
                f = "0123456789abcdef";
              function g(e, t) {
                var n = (e & 65535) + (t & 65535),
                  r = (e >> 16) + (t >> 16) + (n >> 16);
                return (r << 16) | (n & 65535);
              }
              function h() {
                ((m[0] = m[1] = 0),
                  (d[0] = 1779033703),
                  (d[1] = 3144134277),
                  (d[2] = 1013904242),
                  (d[3] = 2773480762),
                  (d[4] = 1359893119),
                  (d[5] = 2600822924),
                  (d[6] = 528734635),
                  (d[7] = 1541459225));
              }
              function y() {
                var e, t, o, l, s, m, f, h, y, C;
                ((o = d[0]),
                  (l = d[1]),
                  (s = d[2]),
                  (m = d[3]),
                  (f = d[4]),
                  (h = d[5]),
                  (y = d[6]),
                  (C = d[7]));
                for (var b = 0; b < 16; b++)
                  _[b] =
                    p[(b << 2) + 3] |
                    (p[(b << 2) + 2] << 8) |
                    (p[(b << 2) + 1] << 16) |
                    (p[b << 2] << 24);
                for (var v = 0; v < 64; v++)
                  ((e = C + i(f) + n(f, h, y) + c[v]),
                    v < 16 ? (e += _[v]) : (e += u(_, v)),
                    (t = a(o) + r(o, l, s)),
                    (C = y),
                    (y = h),
                    (h = f),
                    (f = g(m, e)),
                    (m = s),
                    (s = l),
                    (l = o),
                    (o = g(e, t)));
                ((d[0] += o),
                  (d[1] += l),
                  (d[2] += s),
                  (d[3] += m),
                  (d[4] += f),
                  (d[5] += h),
                  (d[6] += y),
                  (d[7] += C));
              }
              function C(e, t) {
                var n,
                  r,
                  o = 0;
                r = (m[0] >> 3) & 63;
                var a = t & 63;
                for (
                  (m[0] += t << 3) < t << 3 && m[1]++, m[1] += t >> 29, n = 0;
                  n + 63 < t;
                  n += 64
                ) {
                  for (var i = r; i < 64; i++) p[i] = e.charCodeAt(o++);
                  (y(), (r = 0));
                }
                for (var l = 0; l < a; l++) p[l] = e.charCodeAt(o++);
              }
              function b() {
                var e = (m[0] >> 3) & 63;
                if (((p[e++] = 128), e <= 56))
                  for (var t = e; t < 56; t++) p[t] = 0;
                else {
                  for (var n = e; n < 64; n++) p[n] = 0;
                  y();
                  for (var r = 0; r < 56; r++) p[r] = 0;
                }
                ((p[56] = (m[1] >>> 24) & 255),
                  (p[57] = (m[1] >>> 16) & 255),
                  (p[58] = (m[1] >>> 8) & 255),
                  (p[59] = m[1] & 255),
                  (p[60] = (m[0] >>> 24) & 255),
                  (p[61] = (m[0] >>> 16) & 255),
                  (p[62] = (m[0] >>> 8) & 255),
                  (p[63] = m[0] & 255),
                  y());
              }
              function v() {
                for (var e = "", t = 0; t < 8; t++)
                  for (var n = 28; n >= 0; n -= 4)
                    e += f.charAt((d[t] >>> n) & 15);
                return e;
              }
              function S(e) {
                for (var t = 0, n = 0; n < 8; n++)
                  for (var r = 28; r >= 0; r -= 4)
                    e[t++] = f.charCodeAt((d[n] >>> r) & 15);
              }
              function R(e, t) {
                if ((h(), C(e, e.length), b(), t)) S(t);
                else return v();
              }
              function L(t) {
                var n =
                    arguments.length > 1 && arguments[1] !== void 0
                      ? arguments[1]
                      : !0,
                  r = arguments.length > 2 ? arguments[2] : void 0;
                if (t == null) return null;
                var o = t;
                return (n && (o = e(t)), R(o, r));
              }
              o.exports = L;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered("SignalsFBEvents.plugins.identity", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsCensor"),
                t = e.censorPII,
                n = a.getFbeventsModules("SignalsFBEventsLogging"),
                r = n.logUserError,
                i = a.getFbeventsModules("SignalsFBEventsPlugin"),
                l = a.getFbeventsModules("SignalsFBEventsUtils"),
                u = l.FBSet,
                c = a.getFbeventsModules("SignalsPixelPIIUtils"),
                p = c.getNormalizedPIIKey,
                _ = c.getNormalizedPIIValue,
                f = a.getFbeventsModules("sha256_with_dependencies_new"),
                g = /^[A-Fa-f0-9]{64}$|^[A-Fa-f0-9]{32}$/,
                y =
                  /^[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+(:?\.[\w!#\$%&\'\*\+\/\=\?\^`\{\|\}~\-]+)*@(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?$/i,
                b = /^\s+|\s+$/g,
                v = Object.prototype.hasOwnProperty,
                S = new u(["uid"]);
              function R(e) {
                return e == null ? !1 : y.test(e);
              }
              function L(e) {
                return e.replace(b, "");
              }
              function E(e) {
                return e.toLowerCase();
              }
              function k(e, t, n) {
                var o = p(e);
                if (t == null || t === "") return null;
                var a = _(o, t, n);
                if (o === "em" && !R(a))
                  throw (
                    r({
                      key_type: "email address",
                      key_val: e,
                      type: "PII_INVALID_TYPE",
                    }),
                    new Error("Invalid email format for key '".concat(e, "'"))
                  );
                return a != null && a != "" ? a : t;
              }
              function I(e, n) {
                if (n == null) return null;
                var o = /\[(.*)\]/.exec(e);
                if (o == null)
                  throw new Error(
                    "Invalid key format, expected bracket notation like 'ud[em]' but got: ".concat(
                      e,
                    ),
                  );
                var a = !1;
                e.length > 0 && e[0] === "a" && (a = !0);
                var i = C(o, 2),
                  l = i[1];
                if (S.has(l)) {
                  if (R(n))
                    throw (
                      r({ key: e, type: "PII_UNHASHED_PII" }),
                      new Error(
                        "Email for key '".concat(e, "' needs to be hashed"),
                      )
                    );
                  return { finalValue: n };
                }
                if (g.test(n)) {
                  var s = n.toLowerCase();
                  return { finalValue: s, censoredFormat: t(s) };
                }
                var u = k(l, n, a);
                return u != null && u != ""
                  ? { finalValue: f(u), censoredFormat: t(u) }
                  : null;
              }
              var T = (function (e) {
                  function t(e) {
                    var n;
                    return (
                      d(this, t),
                      (n = m(this, t, [
                        function (t) {
                          t.piiTranslator = e;
                        },
                      ])),
                      (n.piiTranslator = e),
                      n
                    );
                  }
                  return (h(t, e), s(t));
                })(i),
                D = new T(I);
              o.exports = D;
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.identity")),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.identity", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.identity", function () {
        return o.exports;
      }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("signalsFBEventsGetIsAndroid", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var t = e.navigator,
                  n = t.userAgent,
                  r = n.indexOf("Android") >= 0;
                function a() {
                  return r;
                }
                o.exports = a;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered("signalsFBEventsGetIsAndroidIAW", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules("signalsFBEventsGetIsAndroid"),
                  n = e.navigator,
                  r = n.userAgent,
                  i = r.indexOf("FB_IAB") >= 0,
                  l = r.indexOf("Instagram") >= 0,
                  s = 0,
                  u = r.match(/(FBAV|Instagram)[/\s](\d+)/);
                if (u != null) {
                  var c = u[0].match(/(\d+)/);
                  c != null && (s = parseInt(c[0], 10));
                }
                function d(e, n) {
                  var r = t() && (i || l);
                  return r
                    ? i && e != null
                      ? e <= s
                      : l && n != null
                        ? n <= s
                        : r
                    : !1;
                }
                o.exports = d;
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.privacysandbox",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("signalsFBEventsGetIsChrome"),
                    n = a.getFbeventsModules("signalsFBEventsGetIsAndroidIAW"),
                    r = a.getFbeventsModules("SignalsEventPayload"),
                    i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                    l = i.GPS_ENDPOINT,
                    s = a.getFbeventsModules("signalsFBEventsSendGET"),
                    u = a.getFbeventsModules("SignalsFBEventsFiredEvent"),
                    c = a.getFbeventsModules("SignalsFBEventsPlugin");
                  o.exports = new c(function (r, o) {
                    (!e() && !n()) ||
                      t.featurePolicy == null ||
                      !t.featurePolicy.allowsFeature("attribution-reporting") ||
                      u.listen(function (e, t) {
                        var n = t.get("id");
                        n != null &&
                          s(t, {
                            ignoreRequestLengthCheck: !0,
                            attributionReporting: !0,
                            url: l,
                          });
                      });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.privacysandbox",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.privacysandbox", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.privacysandbox",
          function () {
            return o.exports;
          },
        )));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("signalsFBEventsGetIwlUrl", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules("signalsFBEventsGetTier"),
                  n = r();
                function r() {
                  try {
                    if (e.trustedTypes && e.trustedTypes.createPolicy) {
                      var t = e.trustedTypes;
                      return t.createPolicy("facebook.com/signals/iwl", {
                        createScriptURL: function (n) {
                          var t =
                              typeof e.URL == "function" ? e.URL : e.webkitURL,
                            r = new t(n),
                            o =
                              r.hostname.endsWith(".facebook.com") &&
                              r.pathname == "/signals/iwl.js";
                          if (!o) throw new Error("Disallowed script URL");
                          return n;
                        },
                      });
                    }
                  } catch (e) {}
                  return null;
                }
                o.exports = function (r, o, a, i) {
                  var e = t(o),
                    l =
                      e == null
                        ? "www.facebook.com"
                        : "www.".concat(e, ".facebook.com"),
                    s = "https://"
                      .concat(l, "/signals/iwl.js?pixel_id=")
                      .concat(r, "&access_token=")
                      .concat(a);
                  return (
                    i === !0 && (s += "&from_extension=true"),
                    n != null ? n.createScriptURL(s) : s
                  );
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered("signalsFBEventsGetTier", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e =
                    /^https:\/\/www\.([A-Za-z0-9\.]+)\.facebook\.com\/tr\/?$/,
                  t = [
                    "https://www.facebook.com/tr",
                    "https://www.facebook.com/tr/",
                  ];
                o.exports = function (r) {
                  if (t.indexOf(r) !== -1) return null;
                  var n = e.exec(r);
                  if (n == null) throw new Error("Malformed tier: ".concat(r));
                  return n[1];
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.iwlbootstrapper",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var n = a.getFbeventsModules(
                      "SignalsFBEventsIWLBootStrapEvent",
                    ),
                    r = a.getFbeventsModules("SignalsFBEventsLogging"),
                    i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("signalsFBEventsGetIwlUrl"),
                    u = a.getFbeventsModules("signalsFBEventsGetTier"),
                    c = r.logUserError,
                    d = /^https:\/\/.*\.facebook\.com$/i,
                    m = "FACEBOOK_IWL_CONFIG_STORAGE_KEY",
                    p = "signals-browser-extension",
                    _ = null;
                  o.exports = new l(function (r, o) {
                    try {
                      _ = e.sessionStorage
                        ? e.sessionStorage
                        : {
                            getItem: function (t) {
                              return null;
                            },
                            removeItem: function (t) {},
                            setItem: function (t, n) {},
                          };
                    } catch (e) {
                      return;
                    }
                    var a = !1;
                    function l(n, r, o, l, c) {
                      var d = t.createElement("script");
                      ((d.async = !0),
                        (d.onload = function () {
                          if (!(!e.FacebookIWL || !e.FacebookIWL.init)) {
                            var t = u(i.ENDPOINT);
                            (t != null &&
                              e.FacebookIWL.set &&
                              e.FacebookIWL.set("tier", t),
                              o());
                          }
                        }),
                        (e.FacebookIWLSessionEnd = function () {
                          (_.removeItem(m), l ? ((a = !1), l()) : e.close());
                        }),
                        (d.src = s(n, i.ENDPOINT, r, c)),
                        t.body && t.body.appendChild(d));
                    }
                    var f = function (t) {
                      return !!(
                        o &&
                        o.pixelsByID &&
                        Object.prototype.hasOwnProperty.call(o.pixelsByID, t)
                      );
                    };
                    function g(t, n) {
                      if (!a) {
                        var r = _.getItem(m);
                        if (r) {
                          var o = JSON.parse(r),
                            i = o.pixelID,
                            s = o.graphToken,
                            u = o.sessionStartTime;
                          ((a = !0),
                            l(
                              i,
                              s,
                              function () {
                                var t = f(i) ? i.toString() : null;
                                e.FacebookIWL.init(t, s, u);
                              },
                              t,
                              n,
                            ));
                        }
                      }
                    }
                    function h(t, n, r) {
                      a ||
                        l(
                          t,
                          n,
                          function () {
                            return e.FacebookIWL.showConfirmModal(t);
                          },
                          void 0,
                          r,
                        );
                    }
                    function y(e, t, n, r, o) {
                      (_.setItem(
                        m,
                        JSON.stringify({
                          graphToken: e,
                          pixelID: t,
                          sessionStartTime: n,
                        }),
                      ),
                        g(r, o));
                    }
                    n.listen(function (t) {
                      var n = t.graphToken,
                        r = t.pixelID;
                      (y(n, r),
                        (e.FacebookIWLSessionEnd = function () {
                          return _.removeItem(m);
                        }));
                    });
                    function C(e) {
                      var t = e.data,
                        n = t.graphToken,
                        r = t.msg_type,
                        a = t.pixelID,
                        i = t.sessionStartTime,
                        l = t.source;
                      if (
                        o &&
                        o.pixelsByID &&
                        o.pixelsByID[a] &&
                        o.pixelsByID[a].codeless === "false"
                      ) {
                        c({ pixelID: a, type: "SITE_CODELESS_OPT_OUT" });
                        return;
                      }
                      var s = d.test(e.origin) || l === p;
                      if (
                        !(
                          _.getItem(m) ||
                          !s ||
                          !(
                            e.data &&
                            (r === "FACEBOOK_IWL_BOOTSTRAP" ||
                              r === "FACEBOOK_IWL_CONFIRM_DOMAIN")
                          )
                        )
                      ) {
                        if (
                          !Object.prototype.hasOwnProperty.call(o.pixelsByID, a)
                        ) {
                          e.source.postMessage(
                            "FACEBOOK_IWL_ERROR_PIXEL_DOES_NOT_MATCH",
                            e.origin,
                          );
                          return;
                        }
                        switch (r) {
                          case "FACEBOOK_IWL_BOOTSTRAP": {
                            e.source.postMessage(
                              "FACEBOOK_IWL_BOOTSTRAP_ACK",
                              e.origin,
                            );
                            var u = l === p,
                              f = u
                                ? function () {
                                    return e.source.postMessage(
                                      "FACEBOOK_IWL_SESSION_ENDED",
                                      e.origin,
                                    );
                                  }
                                : void 0;
                            y(n, a, i, f, u);
                            break;
                          }
                          case "FACEBOOK_IWL_CONFIRM_DOMAIN": {
                            (e.source.postMessage(
                              "FACEBOOK_IWL_CONFIRM_DOMAIN_ACK",
                              e.origin,
                            ),
                              h(a, n));
                            break;
                          }
                        }
                      }
                    }
                    if (_.getItem(m)) {
                      g();
                      return;
                    }
                    e.addEventListener("message", C);
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.iwlbootstrapper",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.iwlbootstrapper", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.iwlbootstrapper",
          function () {
            return o.exports;
          },
        )));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEventsOptTrackingOptions",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                a = o.exports;
              return (
                (function () {
                  "use strict";
                  o.exports = {
                    AUTO_CONFIG_OPT_OUT: 1,
                    AUTO_CONFIG: 2,
                    CONFIG_LOADING: 4,
                    SUPPORTS_DEFINE_PROPERTY: 8,
                    SUPPORTS_SEND_BEACON: 16,
                    HAS_INVALIDATED_PII: 32,
                    SHOULD_PROXY: 64,
                    IS_HEADLESS: 128,
                    IS_SELENIUM: 256,
                    HAS_DETECTION_FAILED: 512,
                    HAS_CONFLICTING_PII: 1024,
                    HAS_AUTOMATCHED_PII: 2048,
                    FIRST_PARTY_COOKIES: 4096,
                    IS_SHADOW_TEST: 8192,
                  };
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        a.ensureModuleRegistered("SignalsFBEventsProxyState", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              a = o.exports;
            return (
              (function () {
                "use strict";
                var e = !1;
                o.exports = {
                  getShouldProxy: function () {
                    return e;
                  },
                  setShouldProxy: function (n) {
                    e = n;
                  },
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.opttracking",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var t = a.getFbeventsModules("SignalsFBEventsEvents"),
                    n = t.getCustomParameters,
                    r = t.piiAutomatched,
                    i = t.piiConflicting,
                    l = t.piiInvalidated,
                    s = a.getFbeventsModules(
                      "SignalsFBEventsOptTrackingOptions",
                    ),
                    u = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    c = a.getFbeventsModules("SignalsFBEventsProxyState"),
                    d = a.getFbeventsModules("SignalsFBEventsUtils"),
                    m = d.some,
                    p = !1;
                  function _() {
                    try {
                      Object.defineProperty({}, "test", {});
                    } catch (e) {
                      return !1;
                    }
                    return !0;
                  }
                  function f() {
                    return !!(e.navigator && e.navigator.sendBeacon);
                  }
                  function g(e, t) {
                    return e ? t : 0;
                  }
                  var h = [
                      "_selenium",
                      "callSelenium",
                      "_Selenium_IDE_Recorder",
                    ],
                    y = [
                      "__webdriver_evaluate",
                      "__selenium_evaluate",
                      "__webdriver_script_function",
                      "__webdriver_script_func",
                      "__webdriver_script_fn",
                      "__fxdriver_evaluate",
                      "__driver_unwrapped",
                      "__webdriver_unwrapped",
                      "__driver_evaluate",
                      "__selenium_unwrapped",
                      "__fxdriver_unwrapped",
                    ];
                  function C() {
                    if (v(h)) return !0;
                    var t = m(y, function (t) {
                      return !!e.document[t];
                    });
                    if (t) return !0;
                    var n = e.document;
                    for (var r in n)
                      if (r.match(/\$[a-z]dc_/) && n[r].cache_) return !0;
                    if (
                      e.external &&
                      e.external.toString &&
                      e.external.toString().indexOf("Sequentum") >= 0
                    )
                      return !0;
                    if (n.documentElement && n.documentElement.getAttribute) {
                      var o = m(
                        ["selenium", "webdriver", "driver"],
                        function (t) {
                          return !!e.document.documentElement.getAttribute(t);
                        },
                      );
                      if (o) return !0;
                    }
                    return !1;
                  }
                  function b() {
                    return !!(
                      v(["_phantom", "__nightmare", "callPhantom"]) ||
                      /HeadlessChrome/.test(e.navigator.userAgent)
                    );
                  }
                  function v(t) {
                    var n = m(t, function (t) {
                      return !!e[t];
                    });
                    return n;
                  }
                  function S() {
                    var e = 0,
                      t = 0,
                      n = 0;
                    try {
                      ((e = g(C(), s.IS_SELENIUM)),
                        (t = g(b(), s.IS_HEADLESS)));
                    } catch (e) {
                      n = s.HAS_DETECTION_FAILED;
                    }
                    return {
                      hasDetectionFailed: n,
                      isHeadless: t,
                      isSelenium: e,
                    };
                  }
                  var R = new u(function (e, t) {
                    if (!p) {
                      var o = {};
                      l.listen(function (e) {
                        e != null && (o[typeof e == "string" ? e : e.id] = !0);
                      });
                      var a = {};
                      i.listen(function (e) {
                        e != null && (a[typeof e == "string" ? e : e.id] = !0);
                      });
                      var u = {};
                      (r.listen(function (e) {
                        e != null && (u[typeof e == "string" ? e : e.id] = !0);
                      }),
                        n.listen(function (n) {
                          var r = t.optIns,
                            i = g(
                              n != null &&
                                r.isOptedOut(n.id, "AutomaticSetup") &&
                                r.isOptedOut(n.id, "InferredEvents") &&
                                r.isOptedOut(n.id, "Microdata"),
                              s.AUTO_CONFIG_OPT_OUT,
                            ),
                            l = g(
                              n != null &&
                                (r.isOptedIn(n.id, "AutomaticSetup") ||
                                  r.isOptedIn(n.id, "InferredEvents") ||
                                  r.isOptedIn(n.id, "Microdata")),
                              s.AUTO_CONFIG,
                            ),
                            d = g(
                              e.disableConfigLoading !== !0,
                              s.CONFIG_LOADING,
                            ),
                            m = g(_(), s.SUPPORTS_DEFINE_PROPERTY),
                            p = g(f(), s.SUPPORTS_SEND_BEACON),
                            h = g(n != null && a[n.id], s.HAS_CONFLICTING_PII),
                            y = g(n != null && o[n.id], s.HAS_INVALIDATED_PII),
                            C = g(n != null && u[n.id], s.HAS_AUTOMATCHED_PII),
                            b = g(c.getShouldProxy(), s.SHOULD_PROXY),
                            v = g(
                              n != null &&
                                r.isOptedIn(n.id, "FirstPartyCookies"),
                              s.FIRST_PARTY_COOKIES,
                            ),
                            R = g(
                              n != null && r.isOptedIn(n.id, "ShadowTest"),
                              s.IS_SHADOW_TEST,
                            ),
                            L = S(),
                            E =
                              i |
                              l |
                              d |
                              m |
                              p |
                              y |
                              b |
                              L.isHeadless |
                              L.isSelenium |
                              L.hasDetectionFailed |
                              h |
                              C |
                              v |
                              R;
                          return { o: E };
                        }),
                        (p = !0));
                    }
                  });
                  ((R.OPTIONS = s), (o.exports = R));
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.opttracking",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.opttracking", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.opttracking", function () {
          return o.exports;
        })));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.unwanteddata",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                    t = e.configLoaded,
                    n = e.validateCustomParameters,
                    r = e.validateUrlParameters,
                    i = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    l = a.getFbeventsModules("SignalsFBEventsLogging"),
                    s = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    u = a.getFbeventsModules("SignalsFBEventsUtils"),
                    c = a.getFbeventsModules("sha256_with_dependencies_new"),
                    d = u.each,
                    m = u.map,
                    p = !1,
                    _ = a.getFbeventsModules("SignalsParamList");
                  o.exports = new s(function (e, t) {
                    n.listen(function (n, r, o) {
                      if (n == null) return {};
                      e.performanceMark(
                        "fbevents:start:unwantedDataProcessing",
                        n.id,
                      );
                      var a = t.optIns.isOptedIn(n.id, "UnwantedData");
                      if (!a) return {};
                      var s = t.optIns.isOptedIn(n.id, "ProtectedDataMode"),
                        u = i.get(n.id, "unwantedData");
                      if (u == null) return {};
                      var d = !1,
                        p = [],
                        _ = [],
                        f = {};
                      if (u.blacklisted_keys != null) {
                        var g = u.blacklisted_keys[o];
                        if (g != null) {
                          var h = g.cd;
                          m(h, function (e) {
                            Object.prototype.hasOwnProperty.call(r, e) &&
                              ((d = !0), p.push(e), delete r[e]);
                          });
                        }
                      }
                      if (u.sensitive_keys != null) {
                        var y = u.sensitive_keys[o];
                        if (y != null) {
                          var C = y.cd;
                          Object.keys(r).forEach(function (e) {
                            m(C, function (t) {
                              c(e) === t && ((d = !0), _.push(t), delete r[e]);
                            });
                          });
                        }
                      }
                      if (
                        ((f.unwantedParams = p),
                        (f.restrictedParams = _),
                        d && !s)
                      ) {
                        var b = p.length > 0,
                          v = _.length > 0;
                        if (b || v) {
                          (e.performanceMark(
                            "fbevents:end:unwantedDataProcessing",
                            n.id,
                          ),
                            l.logUserError({ type: "UNWANTED_CUSTOM_DATA" }));
                          var S = {};
                          return (
                            b && (S.up = p.join(",")),
                            v && (S.rp = _.join(",")),
                            S
                          );
                        }
                      }
                      return (
                        e.performanceMark(
                          "fbevents:end:unwantedDataProcessing",
                          n.id,
                        ),
                        {}
                      );
                    });
                    function o(e, t, n, r, o) {
                      var a = new URLSearchParams(t.search),
                        i = [],
                        l = [],
                        s = {};
                      if (n.blacklisted_keys != null) {
                        var u = n.blacklisted_keys[r];
                        if (u != null) {
                          var d = u.url;
                          m(d, function (e) {
                            a.has(e) &&
                              ((p = !0), i.push(e), a.set(e, "_removed_"));
                          });
                        }
                      }
                      if (n.sensitive_keys != null) {
                        var _ = n.sensitive_keys[r];
                        if (_ != null) {
                          var f = _.url;
                          a.forEach(function (e, t) {
                            m(f, function (e) {
                              c(t) === e &&
                                ((p = !0), l.push(e), a.set(t, "_removed_"));
                            });
                          });
                        }
                      }
                      return (
                        (s.unwantedParams = i),
                        (s.restrictedParams = l),
                        p
                          ? (o ||
                              (i.length > 0 && e.append("up_url", i.join(",")),
                              l.length > 0 && e.append("rp_url", l.join(","))),
                            a.toString())
                          : ""
                      );
                    }
                    r.listen(function (n, r, a, s) {
                      if (n != null) {
                        e.performanceMark(
                          "fbevents:start:validateUrlProcessing",
                          n.id,
                        );
                        var u = t.optIns.isOptedIn(n.id, "UnwantedData");
                        if (u) {
                          var c = t.optIns.isOptedIn(n.id, "ProtectedDataMode"),
                            d = i.get(n.id, "unwantedData");
                          if (d != null) {
                            if (
                              ((p = !1),
                              Object.prototype.hasOwnProperty.call(r, "dl") &&
                                r.dl.length > 0)
                            ) {
                              var m = new URL(r.dl),
                                _ = o(s, m, d, a, c);
                              p &&
                                _.length > 0 &&
                                ((m.search = _), (r.dl = m.toString()));
                            }
                            if (
                              Object.prototype.hasOwnProperty.call(r, "rl") &&
                              r.rl.length > 0
                            ) {
                              var f = new URL(r.rl),
                                g = o(s, f, d, a, c);
                              p &&
                                g.length > 0 &&
                                ((f.search = g), (r.rl = f.toString()));
                            }
                            (p && l.logUserError({ type: "UNWANTED_URL_DATA" }),
                              e.performanceMark(
                                "fbevents:end:validateUrlProcessing",
                                n.id,
                              ));
                          }
                        }
                      }
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.unwanteddata",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.unwanteddata", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.unwanteddata", function () {
          return o.exports;
        })));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.eventvalidation",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    t = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                    n = a.getFbeventsModules("SignalsFBEventsTyped"),
                    r = n.coerce,
                    i = n.Typed,
                    l = a.getFbeventsModules("SignalsFBEventsLogging"),
                    s = l.logUserError,
                    u = a.getFbeventsModules("sha256_with_dependencies_new");
                  o.exports = new e(function (e, n) {
                    t.listen(function (e) {
                      var t = e.id,
                        o = e.eventName,
                        a = r(t, i.fbid());
                      if (a == null) return !1;
                      var l = n.optIns.isOptedIn(a, "EventValidation");
                      if (!l) return !1;
                      var c = n.pluginConfig.get(a, "eventValidation");
                      if (c == null) return !1;
                      var d = c.unverifiedEventNames,
                        m = c.restrictedEventNames,
                        p = !1,
                        _ = !1,
                        f = u(o);
                      return (
                        d &&
                          ((p = d.includes(o) || (f != null && d.includes(f))),
                          p && s({ type: "UNVERIFIED_EVENT" })),
                        m &&
                          ((_ = m.includes(o) || (f != null && m.includes(f))),
                          _ && s({ type: "RESTRICTED_EVENT" })),
                        p || _
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.eventvalidation",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.eventvalidation", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.eventvalidation",
          function () {
            return o.exports;
          },
        )));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e, t) {
      var n =
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"]) ||
        e["@@iterator"];
      if (!n) {
        if (
          Array.isArray(e) ||
          (n = l(e)) ||
          (t && e && typeof e.length == "number")
        ) {
          n && (e = n);
          var r = 0,
            o = function () {};
          return {
            s: o,
            n: function () {
              return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
            },
            e: function (t) {
              throw t;
            },
            f: o,
          };
        }
        throw new TypeError(
          "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
        );
      }
      var a,
        i = !0,
        s = !1;
      return {
        s: function () {
          n = n.call(e);
        },
        n: function () {
          var e = n.next();
          return ((i = e.done), e);
        },
        e: function (t) {
          ((s = !0), (a = t));
        },
        f: function () {
          try {
            i || n.return == null || n.return();
          } finally {
            if (s) throw a;
          }
        },
      };
    }
    function l(e, t) {
      if (e) {
        if (typeof e == "string") return s(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? s(e, t)
              : void 0
        );
      }
    }
    function s(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    (a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("SignalsFBEventsClientHintTypedef", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            i = o.exports;
          return (
            (function () {
              "use strict";
              var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                t = e.coerce,
                n = e.Typed,
                r = n.objectWithFields({
                  brands: n.array(),
                  platform: n.allowNull(n.string()),
                  getHighEntropyValues: n.func(),
                }),
                i = n.objectWithFields({
                  model: n.allowNull(n.string()),
                  platformVersion: n.allowNull(n.string()),
                  fullVersionList: n.array(),
                });
              o.exports = {
                userAgentDataTypedef: r,
                highEntropyResultTypedef: i,
              };
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      a.ensureModuleRegistered(
        "SignalsFBEventsGetIsAndroidChrome",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("signalsFBEventsGetIsChrome");
                function t(e) {
                  return e === void 0
                    ? !1
                    : e.platform === "Android" &&
                        e.brands
                          .map(function (e) {
                            return e.brand;
                          })
                          .join(", ")
                          .includes("Chrome");
                }
                function n(e) {
                  return e.includes("Chrome") && e.includes("Android");
                }
                function r(t) {
                  var n = t.indexOf("Android") >= 0,
                    r = e();
                  return n && r;
                }
                o.exports = {
                  checkIsAndroidChromeWithClientHint: t,
                  checkIsAndroidChromeWithUAString: n,
                  checkIsAndroidChrome: r,
                };
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      a.ensureModuleRegistered(
        "SignalsFBEvents.plugins.clienthint",
        function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              l = o.exports;
            return (
              (function () {
                "use strict";
                var t = a.getFbeventsModules("SignalsFBEventsPlugin"),
                  n = a.getFbeventsModules("SignalsParamList"),
                  r = a.getFbeventsModules("SignalsFBEventsEvents"),
                  l = r.configLoaded,
                  s = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                  u = a.getFbeventsModules("SignalsFBEventsLogging"),
                  c = u.logError,
                  d = u.logWarning,
                  m = u.logInfo,
                  p = a.getFbeventsModules("SignalsFBEventsTyped"),
                  _ = p.coerce,
                  f = p.Typed,
                  g = a.getFbeventsModules("SignalsFBEventsClientHintTypedef"),
                  h = g.userAgentDataTypedef,
                  y = g.highEntropyResultTypedef,
                  C = a.getFbeventsModules("SignalsFBEventsGetIsAndroidChrome"),
                  b = C.checkIsAndroidChrome,
                  v = "chmd",
                  S = "chpv",
                  R = "chfv",
                  L = [v, S, R],
                  E = 200,
                  k = "clientHint",
                  I = "pixel",
                  T = "clienthint";
                function D(e) {
                  var t = _(e, y);
                  if (t == null)
                    return (
                      m(
                        new Error(
                          "[ClientHint Error] getHighEntropyValues returned null from Android Chrome source",
                        ),
                        I,
                        T,
                      ),
                      new Map()
                    );
                  var n = new Map();
                  (n.set(v, String(t.model)),
                    n.set(S, String(t.platformVersion)));
                  var r,
                    o,
                    a = i(t.fullVersionList),
                    l;
                  try {
                    for (a.s(); !(l = a.n()).done; )
                      ((o = l.value),
                        o.brand.includes("Chrome") && (r = o.version));
                  } catch (e) {
                    a.e(e);
                  } finally {
                    a.f();
                  }
                  return (n.set(R, String(r)), n);
                }
                function x(e, t) {
                  var n = i(L),
                    r;
                  try {
                    for (n.s(); !(r = n.n()).done; ) {
                      var o = r.value;
                      e.get(o) == null && e.append(o, t.get(o));
                    }
                  } catch (e) {
                    n.e(e);
                  } finally {
                    n.f();
                  }
                }
                function $(e, t, r) {
                  var o = D(e),
                    a = t.customParams || new n();
                  (x(a, o), (t.customParams = a));
                }
                o.exports = new t(function (t, n) {
                  var r = _(e.navigator.userAgentData, h);
                  if (r == null) {
                    e.navigator.userAgentData != null &&
                      d(
                        new Error(
                          "[ClientHint Error] UserAgentData coerce error",
                        ),
                      );
                    return;
                  } else if (!b(e.navigator.userAgent)) return;
                  var o = e.navigator.userAgentData
                    .getHighEntropyValues([
                      "model",
                      "platformVersion",
                      "fullVersionList",
                    ])
                    .then(function (e) {
                      var t = n.asyncParamFetchers.get(k);
                      return (
                        t != null &&
                          t.result == null &&
                          ((t.result = e), n.asyncParamFetchers.set(k, t)),
                        e
                      );
                    })
                    .catch(function (e) {
                      ((e.message =
                        "[ClientHint Error] Fetch error" + e.message),
                        d(e));
                    });
                  (n.asyncParamFetchers.set(k, { request: o, callback: $ }),
                    (n.asyncParamPromisesAllSettled = !1));
                });
              })(),
              o.exports
            );
          })(e, t, n, r);
        },
      ),
      (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.clienthint")),
      a.registerPlugin &&
        a.registerPlugin("fbevents.plugins.clienthint", o.exports),
      a.ensureModuleRegistered("fbevents.plugins.clienthint", function () {
        return o.exports;
      }));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.unwantedparams",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                    t = e.validateCustomParameters,
                    n = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    r = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    i = a.getFbeventsModules("SignalsParamList"),
                    l = a.getFbeventsModules("SignalsFBEventsUtils"),
                    s = l.each;
                  o.exports = new r(function (e, r) {
                    t.listen(function (t, o, a) {
                      if (t == null) return {};
                      e.performanceMark(
                        "fbevents:start:unwantedParamsProcessing",
                        t.id,
                      );
                      var i = r.optIns.isOptedIn(t.id, "UnwantedParams");
                      if (!i) return {};
                      var l = n.get(t.id, "unwantedParams");
                      if (l == null || l.unwantedParams == null) return {};
                      var u = [];
                      return (
                        s(l.unwantedParams, function (e) {
                          Object.prototype.hasOwnProperty.call(o, e) &&
                            (u.push(e), delete o[e]);
                        }),
                        e.performanceMark(
                          "fbevents:end:unwantedParamsProcessing",
                          t.id,
                        ),
                        u.length > 0 ? { spb: u.join(",") } : {}
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.unwantedparams",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.unwantedparams", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.unwantedparams",
          function () {
            return o.exports;
          },
        )));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered(
          "SignalsFBEvents.plugins.standardparamchecks",
          function () {
            return (function (e, t, n, r) {
              var o = { exports: {} },
                i = o.exports;
              return (
                (function () {
                  "use strict";
                  var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                    t = e.logUserError,
                    n = a.getFbeventsModules("SignalsFBEventsEvents"),
                    r = n.lateValidateCustomParameters,
                    i = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                    l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                    s = a.getFbeventsModules("SignalsParamList"),
                    u = a.getFbeventsModules("SignalsFBEventsUtils"),
                    c = u.each,
                    d = u.some,
                    m = u.keys,
                    p = u.isNumber;
                  function _(e, t) {
                    return t
                      ? t.require_exact_match
                        ? d(t.potential_matches, function (t) {
                            return t.toLowerCase() === e.toLowerCase();
                          })
                        : d(t.potential_matches, function (t) {
                            return new RegExp(t).test(e);
                          })
                      : !1;
                  }
                  o.exports = new l(function (e, n) {
                    r.listen(function (e, r, o) {
                      var a = n.optIns.isOptedIn(e, "StandardParamChecks");
                      if (!a) return {};
                      var l = i.get(e, "standardParamChecks");
                      if (l == null || l.standardParamChecks == null) return {};
                      var s = [];
                      return (
                        c(m(r), function (n) {
                          var o = l.standardParamChecks[n] || [];
                          if (!o || o.length == 0) return {};
                          var a = d(o, function (e) {
                            return _(String(r[n]), e);
                          });
                          a ||
                            (s.push(n),
                            t({
                              invalidParamName: n,
                              pixelID: e,
                              type: "INVALID_PARAM_FORMAT",
                            }));
                        }),
                        c(s, function (e) {
                          delete r[e];
                        }),
                        s.length > 0 ? { rks: s.join(",") } : {}
                      );
                    });
                  });
                })(),
                o.exports
              );
            })(e, t, n, r);
          },
        ),
        (o.exports = a.getFbeventsModules(
          "SignalsFBEvents.plugins.standardparamchecks",
        )),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.standardparamchecks", o.exports),
        a.ensureModuleRegistered(
          "fbevents.plugins.standardparamchecks",
          function () {
            return o.exports;
          },
        )));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    ((a.execStart = e.performance && e.performance.now && e.performance.now()),
      (function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })() &&
        (a.__fbeventsModules ||
          ((a.__fbeventsModules = {}),
          (a.__fbeventsResolvedModules = {}),
          (a.getFbeventsModules = function (e) {
            return (
              a.__fbeventsResolvedModules[e] ||
                (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
              a.__fbeventsResolvedModules[e]
            );
          }),
          (a.fbIsModuleLoaded = function (e) {
            return !!a.__fbeventsModules[e];
          }),
          (a.ensureModuleRegistered = function (e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
          })),
        a.ensureModuleRegistered("SignalsFBEvents.plugins.gating", function () {
          return (function (e, t, n, r) {
            var o = { exports: {} },
              i = o.exports;
            return (
              (function () {
                "use strict";
                var e = a.getFbeventsModules("SignalsFBEventsPlugin");
                o.exports = new e(function (e, t) {});
              })(),
              o.exports
            );
          })(e, t, n, r);
        }),
        (o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.gating")),
        a.registerPlugin &&
          a.registerPlugin("fbevents.plugins.gating", o.exports),
        a.ensureModuleRegistered("fbevents.plugins.gating", function () {
          return o.exports;
        })));
  })();
})(window, document, location, history);
(function (e, t, n, r) {
  var o = { exports: {} },
    a = o.exports;
  (function () {
    var a = e.fbq;
    if (
      ((a.execStart =
        e.performance && e.performance.now && e.performance.now()),
      !(function () {
        var t = e.postMessage || function () {};
        return a
          ? !0
          : (t(
              {
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage:
                  "Pixel code is not installed correctly on this page",
              },
              "*",
            ),
            "error" in console,
            !1);
      })())
    )
      return;
    function i(e) {
      "@babel/helpers - typeof";
      return (
        (i =
          typeof Symbol == "function" &&
          typeof (typeof Symbol == "function"
            ? Symbol.iterator
            : "@@iterator") == "symbol"
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  typeof Symbol == "function" &&
                  e.constructor === Symbol &&
                  e !==
                    (typeof Symbol == "function"
                      ? Symbol.prototype
                      : "@@prototype")
                  ? "symbol"
                  : typeof e;
              }),
        i(e)
      );
    }
    function l(e, t) {
      var n = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        (t &&
          (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })),
          n.push.apply(n, r));
      }
      return n;
    }
    function s(e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2
          ? l(Object(n), !0).forEach(function (t) {
              u(e, t, n[t]);
            })
          : Object.getOwnPropertyDescriptors
            ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
            : l(Object(n)).forEach(function (t) {
                Object.defineProperty(
                  e,
                  t,
                  Object.getOwnPropertyDescriptor(n, t),
                );
              });
      }
      return e;
    }
    function u(e, t, n) {
      return (
        (t = c(t)) in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function c(e) {
      var t = d(e, "string");
      return i(t) == "symbol" ? t : t + "";
    }
    function d(e, t) {
      if (i(e) != "object" || !e) return e;
      var n =
        e[typeof Symbol == "function" ? Symbol.toPrimitive : "@@toPrimitive"];
      if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (i(r) != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return (t === "string" ? String : Number)(e);
    }
    function m(e, t) {
      return g(e) || p(e, t) || C(e, t) || f();
    }
    function p(e, t) {
      var n =
        e == null
          ? null
          : (typeof Symbol != "undefined" &&
              e[
                typeof Symbol == "function" ? Symbol.iterator : "@@iterator"
              ]) ||
            e["@@iterator"];
      if (n != null) {
        var r,
          o,
          a,
          i,
          l = [],
          s = !0,
          u = !1;
        try {
          if (((a = (n = n.call(e)).next), t === 0)) {
            if (Object(n) !== n) return;
            s = !1;
          } else
            for (
              ;
              !(s = (r = a.call(n)).done) && (l.push(r.value), l.length !== t);
              s = !0
            );
        } catch (e) {
          ((u = !0), (o = e));
        } finally {
          try {
            if (!s && n.return != null && ((i = n.return()), Object(i) !== i))
              return;
          } finally {
            if (u) throw o;
          }
        }
        return l;
      }
    }
    function _(e) {
      return g(e) || b(e) || C(e) || f();
    }
    function f() {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function g(e) {
      if (Array.isArray(e)) return e;
    }
    function h(e) {
      return v(e) || b(e) || C(e) || y();
    }
    function y() {
      throw new TypeError(
        "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.",
      );
    }
    function C(e, t) {
      if (e) {
        if (typeof e == "string") return S(e, t);
        var n = {}.toString.call(e).slice(8, -1);
        return (
          n === "Object" && e.constructor && (n = e.constructor.name),
          n === "Map" || n === "Set"
            ? Array.from(e)
            : n === "Arguments" ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? S(e, t)
              : void 0
        );
      }
    }
    function b(e) {
      if (
        (typeof Symbol != "undefined" &&
          e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] !=
            null) ||
        e["@@iterator"] != null
      )
        return Array.from(e);
    }
    function v(e) {
      if (Array.isArray(e)) return S(e);
    }
    function S(e, t) {
      (t == null || t > e.length) && (t = e.length);
      for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    (a.__fbeventsModules ||
      ((a.__fbeventsModules = {}),
      (a.__fbeventsResolvedModules = {}),
      (a.getFbeventsModules = function (e) {
        return (
          a.__fbeventsResolvedModules[e] ||
            (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()),
          a.__fbeventsResolvedModules[e]
        );
      }),
      (a.fbIsModuleLoaded = function (e) {
        return !!a.__fbeventsModules[e];
      }),
      (a.ensureModuleRegistered = function (e, t) {
        a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t);
      })),
      a.ensureModuleRegistered("SignalsFBEvents", function () {
        return (function (e, t, n, r) {
          var o = { exports: {} },
            a = o.exports;
          return (
            (function () {
              "use strict";
              var a = e.fbq;
              ((a.execStart =
                e.performance && typeof e.performance.now == "function"
                  ? e.performance.now()
                  : null),
                (a.performanceMark = function (t, n) {
                  var r =
                    e.fbq && e.fbq._releaseSegment
                      ? e.fbq._releaseSegment
                      : "unknown";
                  r === "canary" &&
                    e.performance != null &&
                    typeof e.performance.mark == "function" &&
                    (n != null
                      ? e.performance.mark("".concat(t, "_").concat(n))
                      : e.performance.mark(t));
                }));
              var i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                l = a.getFbeventsModules("SignalsFBEventsQE"),
                u = a.getFbeventsModules("SignalsParamList"),
                c = a.getFbeventsModules("signalsFBEventsSendEvent"),
                d = c.sendEvent,
                p = a.getFbeventsModules("SignalsFBEventsUtils"),
                f = a.getFbeventsModules("SignalsFBEventsLogging"),
                g = a.getFbeventsModules("SignalsEventValidation"),
                y = a.getFbeventsModules("handleEventIdOverride"),
                C = a.getFbeventsModules("SignalsFBEventsFBQ"),
                b = a.getFbeventsModules("SignalsFBEventsJSLoader"),
                v = a.getFbeventsModules("SignalsFBEventsFireLock"),
                S = a.getFbeventsModules("SignalsFBEventsMobileAppBridge"),
                R = a.getFbeventsModules("signalsFBEventsInjectMethod"),
                L = a.getFbeventsModules("signalsFBEventsMakeSafe"),
                E = a.getFbeventsModules(
                  "signalsFBEventsResolveLegacyArguments",
                ),
                k = a.getFbeventsModules("SignalsFBEventsPluginManager"),
                I = a.getFbeventsModules("signalsFBEventsCoercePixelID"),
                T = a.getFbeventsModules("SignalsFBEventsEvents"),
                D = a.getFbeventsModules("SignalsFBEventsTyped"),
                x = D.coerce,
                $ = D.Typed,
                P = a.getFbeventsModules("SignalsFBEventsGuardrail"),
                N = a.getFbeventsModules("SignalsFBEventsModuleEncodings"),
                M = a.getFbeventsModules("signalsFBEventsDoAutomaticMatching"),
                w = a.getFbeventsModules("SignalsFBEventsTrackEventEvent"),
                A = a.getFbeventsModules("SignalsFBEventsCensor"),
                F = A.getCensoredPayload,
                O = a.getFbeventsModules("SignalsFBEventsLogging"),
                B = O.logInfo,
                W = p.each,
                q = p.FBSet,
                U = p.isEmptyObject,
                V = p.isPlainObject,
                H = p.isNumber,
                G = p.keys,
                z = p.stringStartsWith,
                j = T.execEnd,
                K = T.fired,
                Q = T.getCustomParameters,
                X = T.iwlBootstrap,
                Y = T.piiInvalidated,
                J = T.setIWLExtractors,
                Z = T.validateCustomParameters,
                ee = T.validateUrlParameters,
                te = T.setESTRules,
                ne = T.setCCRules,
                re = T.automaticPageView,
                oe = T.webchatEvent,
                ae = a.getFbeventsModules("SignalsFBEventsCorrectPIIPlacement"),
                ie = a.getFbeventsModules("SignalsFBEventsProcessEmailAddress"),
                le = a.getFbeventsModules(
                  "SignalsFBEventsAddGmailSuffixToEmail",
                ),
                se = a.getFbeventsModules("SignalsFBEventsQE"),
                ue = a.getFbeventsModules("SignalsFBEventsQEV2"),
                ce = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                de = a.getFbeventsModules("SignalsFBEventsPixelQueueState"),
                me = de.tryInitQueue,
                pe = de.tryEnqueueCommand,
                _e = f.logError,
                fe = f.logUserError,
                ge = v.global,
                he = -1,
                ye =
                  "b68919aff001d8366249403a2544fba2d833084f1ad22839b6310aadacb6a138",
                Ce = Array.prototype.slice,
                be = Object.prototype.hasOwnProperty,
                ve = n.href,
                Se = !1,
                Re = !1,
                Le = [],
                Ee = {},
                ke = t.referrer,
                Ie = { PageView: new q(), PixelInitialized: new q() },
                Te = new C(a, Ee),
                De = new k(Te, ge),
                xe = new q(["eid"]),
                $e = "pixel",
                Pe = "SignalsFBEvents";
              function Ne(e, t, n, r) {
                fe({
                  invalidParamName: e,
                  invalidParamValue: t,
                  method: n,
                  params: r,
                  type: "INVALID_FBQ_METHOD_PARAMETER",
                });
              }
              function Me(e) {
                for (var t in e) be.call(e, t) && (this[t] = e[t]);
                return this;
              }
              function we() {
                try {
                  return (pe(arguments), Ae.apply(this, arguments));
                } catch (e) {
                  _e(e);
                }
              }
              function Ae() {
                try {
                  var e = Ce.call(arguments);
                  if (ge.isLocked() && e[0] !== "consent") {
                    a.queue.push(arguments);
                    return;
                  }
                  var t = E(e),
                    n = h(t.args),
                    r = t.isLegacySyntax,
                    o = n.shift();
                  switch (o) {
                    case "addPixelId":
                      ((Se = !0), Oe.apply(this, n));
                      break;
                    case "init":
                      ((Re = !0), Oe.apply(this, n));
                      break;
                    case "set":
                      Fe.apply(this, n);
                      break;
                    case "track":
                      if (H(n[0])) {
                        je.apply(this, n);
                        break;
                      }
                      if (r === !0) {
                        Ue.apply(this, n);
                        break;
                      }
                      qe.apply(this, n);
                      break;
                    case "trackCustom":
                      Ue.apply(this, n);
                      break;
                    case "trackShopify":
                      He.apply(this, n);
                      break;
                    case "trackWebchat":
                      Ve.apply(this, n);
                      break;
                    case "send":
                      Ke.apply(this, n);
                      break;
                    case "on":
                      {
                        var i = _(n),
                          l = i[0],
                          s = i.slice(1),
                          u = T[l];
                        u && u.triggerWeakly(s);
                      }
                      break;
                    case "loadPlugin":
                      De.loadPlugin(n[0]);
                      break;
                    case "disabledExtensions":
                      var c = m(n, 1),
                        d = c[0];
                      Te.pluginConfig.set(null, "disabledExtensions", {
                        disabledExtensions: d,
                      });
                      break;
                    case "dataProcessingOptions":
                      switch (n.length) {
                        case 1: {
                          var p = m(n, 1),
                            f = p[0];
                          Te.pluginConfig.set(null, "dataProcessingOptions", {
                            dataProcessingOptions: f,
                            dataProcessingCountry: null,
                            dataProcessingState: null,
                          });
                          break;
                        }
                        case 3: {
                          var g = m(n, 3),
                            y = g[0],
                            C = g[1],
                            b = g[2];
                          Te.pluginConfig.set(null, "dataProcessingOptions", {
                            dataProcessingOptions: y,
                            dataProcessingCountry: C,
                            dataProcessingState: b,
                          });
                          break;
                        }
                        case 4: {
                          var v = m(n, 3),
                            S = v[0],
                            R = v[1],
                            L = v[2];
                          Te.pluginConfig.set(null, "dataProcessingOptions", {
                            dataProcessingOptions: S,
                            dataProcessingCountry: R,
                            dataProcessingState: L,
                          });
                          break;
                        }
                      }
                      break;
                    default:
                      Te.callMethod(arguments);
                      break;
                  }
                } catch (e) {
                  _e(e);
                }
              }
              function Fe(e) {
                for (
                  var t = arguments.length,
                    n = new Array(t > 1 ? t - 1 : 0),
                    r = 1;
                  r < t;
                  r++
                )
                  n[r - 1] = arguments[r];
                var o = [e].concat(n);
                switch (e) {
                  case "endpoint":
                    var u = n[0];
                    if (typeof u != "string")
                      throw new Error("endpoint value must be a string");
                    i.ENDPOINT = u;
                    break;
                  case "cdn":
                    var c = n[0];
                    if (typeof c != "string")
                      throw new Error("cdn value must be a string");
                    b.CONFIG.CDN_BASE_URL = c;
                    break;
                  case "releaseSegment":
                    var d = n[0];
                    if (typeof d != "string") {
                      Ne("new_release_segment", d, "set", o);
                      break;
                    }
                    a._releaseSegment = d;
                    break;
                  case "autoConfig": {
                    var m = n[0],
                      p = n[1],
                      _ = m === !0 || m === "true" ? "optIn" : "optOut";
                    typeof p == "string"
                      ? Te.callMethod([_, p, "AutomaticSetup"])
                      : p === void 0
                        ? (Te.disableAutoConfig = _ === "optOut")
                        : Ne("pixel_id", p, "set", o);
                    break;
                  }
                  case "firstPartyCookies": {
                    var f = n[0],
                      h = n[1],
                      y = f === !0 || f === "true" ? "optIn" : "optOut";
                    typeof h == "string"
                      ? Te.callMethod([y, h, "FirstPartyCookies"])
                      : h === void 0
                        ? (Te.disableFirstPartyCookies = y === "optOut")
                        : Ne("pixel_id", h, "set", o);
                    break;
                  }
                  case "experiments": {
                    l.setExperiments.apply(l, n);
                    break;
                  }
                  case "experimentsV2": {
                    ue.setExperiments.apply(ue, n);
                    break;
                  }
                  case "guardrails": {
                    P.setGuardrails.apply(P, n);
                    break;
                  }
                  case "moduleEncodings": {
                    N.setModuleEncodings.apply(N, n);
                    break;
                  }
                  case "mobileBridge": {
                    var C = n[0],
                      v = n[1];
                    if (typeof C != "string") {
                      Ne("pixel_id", C, "set", o);
                      break;
                    }
                    if (typeof v != "string") {
                      Ne("app_id", v, "set", o);
                      break;
                    }
                    S.registerBridge([C, v]);
                    break;
                  }
                  case "iwlExtractors": {
                    var R = n[0],
                      L = n[1];
                    J.triggerWeakly({ extractors: L, pixelID: R });
                    break;
                  }
                  case "estRules": {
                    var E = n[0],
                      k = n[1];
                    te.triggerWeakly({ rules: k, pixelID: E });
                    break;
                  }
                  case "ccRules": {
                    var I = n[0],
                      T = n[1];
                    ne.triggerWeakly({ rules: T, pixelID: I });
                    break;
                  }
                  case "startIWLBootstrap": {
                    var D = n[0],
                      w = n[1];
                    X.triggerWeakly({ graphToken: D, pixelID: w });
                    break;
                  }
                  case "parallelfire": {
                    var A = n[0],
                      F = n[1];
                    Te.pluginConfig.set(A, "parallelfire", { target: F });
                    break;
                  }
                  case "openbridge": {
                    var O = n[0],
                      B = n[1];
                    O !== null &&
                      B !== null &&
                      typeof O == "string" &&
                      typeof B == "string" &&
                      (Te.callMethod(["optIn", O, "OpenBridge"]),
                      Te.pluginConfig.set(O, "openbridge", {
                        endpoints: [{ endpoint: B }],
                      }));
                    break;
                  }
                  case "trackSingleOnly": {
                    var W = n[0],
                      q = n[1],
                      U = x(W, $.boolean()),
                      H = x(q, $.fbid());
                    if (H == null) {
                      Ne("pixel_id", q, "set", o);
                      break;
                    }
                    if (U == null) {
                      Ne("on_or_off", W, "set", o);
                      break;
                    }
                    var G = g.validateMetadata(e);
                    (G.error && fe(G.error),
                      G.warnings &&
                        G.warnings.forEach(function (e) {
                          fe(e);
                        }),
                      be.call(Ee, H)
                        ? (Ee[H].trackSingleOnly = U)
                        : fe({
                            metadataValue: e,
                            pixelID: H,
                            type: "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID",
                          }));
                    break;
                  }
                  case "userData": {
                    var z = n[0],
                      j = z == null || V(z);
                    if (!j) {
                      Ne("user_data", z, "set", o);
                      return;
                    }
                    for (var K = s({}, z), Q = 0; Q < Le.length; Q++) {
                      var Y = Le[Q],
                        Z = Te.optIns.isOptedIn(Y.id, "AutomaticMatching"),
                        ee = Te.optIns.isOptedIn(
                          Y.id,
                          "ShopifyAppIntegratedPixel",
                        );
                      (!ce("enable_shopify_additional_events", Y.id) &&
                        ee &&
                        z &&
                        be.call(z, "external_id") &&
                        delete z.external_id,
                        Z && ee
                          ? M(Te, Y, z, K)
                          : Ne("pixel_id", Y.id, "set", o));
                    }
                    break;
                  }
                  default: {
                    var re = Te.pluginConfig.getWithGlobalFallback(
                        null,
                        "dataProcessingOptions",
                      ),
                      oe =
                        re != null && re.dataProcessingOptions.includes("LDU"),
                      ae = n[0],
                      ie = n[1];
                    if (typeof e != "string") {
                      if (oe) break;
                      Ne("setting", e, "set", o);
                      break;
                    }
                    if (typeof ae != "string") {
                      if (oe) break;
                      Ne("value", ae, "set", o);
                      break;
                    }
                    if (typeof ie != "string") {
                      if (oe) break;
                      Ne("pixel_id", ie, "set", o);
                      break;
                    }
                    We(e, ae, ie);
                    break;
                  }
                }
              }
              ((a._initHandlers = []), (a._initsDone = {}));
              function Oe(e, t, n) {
                try {
                  he = he === -1 ? Date.now() : he;
                  var r = I(e);
                  if (r == null) return;
                  var o = t == null || V(t);
                  o || Ne("user_data", t, "init", [e, t]);
                  var a =
                      P.eval("send_censored_ph", r) ||
                      P.eval("send_censored_em", r),
                    i = {};
                  o && a && (i = F(t || {}));
                  var l = null;
                  t != null &&
                    ((l = s({}, t)), (t = ie(t)), (t = ae(t)), (t = le(t)));
                  var u = Te.pluginConfig.get(r, "protectedDataMode"),
                    c = Te.optIns.isOptedIn(r, "ProtectedDataMode"),
                    d = !0;
                  if (
                    (c && u != null && u.disableAM === !0 && (d = !1),
                    be.call(Ee, r))
                  ) {
                    t != null && U(Ee[r].userData)
                      ? ((Ee[r].userData = d && o ? t || {} : {}),
                        (Ee[r].alternateUserData = d && o ? l || {} : {}),
                        (Ee[r].censoredUserDataFormat = d ? i : {}),
                        De.loadPlugin("identity"))
                      : fe({ pixelID: r, type: "DUPLICATE_PIXEL_ID" });
                    return;
                  }
                  var m = {
                    agent: n ? n.agent : null,
                    eventCount: 0,
                    id: r,
                    userData: d && o ? t || {} : {},
                    alternateUserData: d && o ? l || {} : {},
                    userDataFormFields: {},
                    alternateUserDataFormFields: {},
                    censoredUserDataFormat: d ? i : {},
                    censoredUserDataFormatFormFields: {},
                  };
                  (Le.push(m),
                    (Ee[r] = m),
                    t != null && De.loadPlugin("identity"),
                    Te.optIns.isOptedIn(r, "OpenBridge") &&
                      De.loadPlugin("openbridge3"),
                    Be(),
                    Te.loadConfig(r));
                } catch (e) {
                  _e(e, "pixel", "Init");
                }
              }
              function Be() {
                for (var e = 0; e < a._initHandlers.length; e++) {
                  var t = a._initHandlers[e];
                  a._initsDone[e] || (a._initsDone[e] = {});
                  for (var n = 0; n < Le.length; n++) {
                    var r = Le[n];
                    a._initsDone[e][r.id] ||
                      ((a._initsDone[e][r.id] = !0), t(r));
                  }
                }
              }
              function We(e, t, n) {
                var r = g.validateMetadata(e);
                if (
                  (r.error && fe(r.error),
                  r.warnings &&
                    r.warnings.forEach(function (e) {
                      fe(e);
                    }),
                  be.call(Ee, n))
                ) {
                  for (var o = 0, a = Le.length; o < a; o++)
                    if (Le[o].id === n) {
                      Le[o][e] = t;
                      break;
                    }
                } else
                  fe({
                    metadataValue: t,
                    pixelID: n,
                    type: "SET_METADATA_ON_UNINITIALIZED_PIXEL_ID",
                  });
              }
              function qe(e, t, n) {
                ((t = t || {}),
                  g.validateEventAndLog(e, t),
                  e === "CustomEvent" &&
                    typeof t.event == "string" &&
                    (e = t.event),
                  Ue.call(this, e, t, n));
              }
              function Ue(t, n, r, o) {
                var i = this,
                  l = !1,
                  c = null;
                (this == null &&
                  ((i = new Me({
                    allowDuplicatePageViews: !0,
                    isAutomaticPageView: !0,
                  })),
                  (c = new u(a.piiTranslator)),
                  c.append("ie[a]", "1")),
                  o != null &&
                    G(o).length > 0 &&
                    (c == null && (c = new u(a.piiTranslator)),
                    Object.keys(o).forEach(function (e) {
                      c.append(e, o[e]);
                    })));
                try {
                  P.eval("reset_init_time_on_spa_page_change") &&
                    i.isAutomaticPageView &&
                    (he = he !== -1 ? Date.now() : he);
                  for (var d = 0, m = Le.length; d < m; d++) {
                    var p = Le[d],
                      _ = Date.now().toString(),
                      f = e.fbq.instance.pluginConfig.get(p.id, "buffer"),
                      g = !1;
                    (f != null &&
                      (g =
                        f.onlyBufferPageView === !0 &&
                        se.isInTest("spa_pageview_fix")),
                      (g = i.allowDuplicatePageViews || g),
                      i.isAutomaticPageView &&
                        (r = s(s({}, r), {}, { isAutomaticPageView: !0 })),
                      !(
                        !(t === "PageView" && g) &&
                        Object.prototype.hasOwnProperty.call(Ie, t) &&
                        Ie[t].has(p.id)
                      ) &&
                        p.trackSingleOnly !== !0 &&
                        (Ze({
                          customData: n,
                          eventData: r,
                          eventName: t,
                          pixel: p,
                          additionalCustomParams: c,
                          experimentId: _,
                        }),
                        Object.prototype.hasOwnProperty.call(Ie, t) &&
                          Ie[t].add(p.id)));
                  }
                } catch (e) {
                  throw e;
                } finally {
                }
              }
              function Ve(e, t, n, r) {
                try {
                  for (var o = 0, a = Le.length; o < a; o++) {
                    var i = Le[o];
                    i == null ||
                      i.id == null ||
                      oe.triggerWeakly([
                        {
                          pixelID: i.id,
                          eventName: e,
                          customData: t != null ? t : {},
                          eventData: n,
                          customParams: r,
                        },
                      ]);
                  }
                } catch (e) {
                  _e(e, "pixel", "webchat");
                }
              }
              function He(e, t, n, r, o) {
                var a = Ge(e, t, o),
                  i = ce("enable_shopify_additional_events", e);
                if (!(a && !i)) {
                  var l = {};
                  (a && (l = s(s({}, l), {}, { "ie[f]": "1" })),
                    (n = ze(e, t, n, o)),
                    g.validateEventAndLog(t, n),
                    t === "CustomEvent" &&
                      typeof n.event == "string" &&
                      (t = n.event),
                    Ue.call(this, t, n, r, l));
                }
              }
              function Ge(e, t, n) {
                if (t !== "ViewContent") return !1;
                var r = x(
                    n,
                    $.objectWithFields({
                      shopify_event_name: $.allowNull($.string()),
                    }),
                  ),
                  o = ["collection_viewed", "cart_viewed"];
                return (
                  (r == null ? void 0 : r.shopify_event_name) != null &&
                  o.includes(r.shopify_event_name)
                );
              }
              function ze(t, n, r, o) {
                r = r || {};
                try {
                  if (o == null || Object.keys(o).length === 0) return r;
                  var a = Te.optIns.isOptedIn(t, "ShopifyAppIntegratedPixel");
                  if (!a) return r;
                  var i = e.fbq.instance.pluginConfig.get(t, "gating"),
                    l = ce("content_type_opt", t),
                    s = ce("enable_product_variant_id", t),
                    u = ce("enable_shopify_payment_fields", t),
                    c = ce("enable_shopify_search_contents", t),
                    d = x(
                      o,
                      $.objectWithFields({
                        product_variant_ids: $.allowNull(
                          $.arrayOf($.stringOrNumber()),
                        ),
                        content_type_favor_variant: $.allowNull($.string()),
                        contents: $.allowNull(
                          $.arrayOf($.allowNull($.object())),
                        ),
                        order_id: $.allowNull($.stringOrNumber()),
                        payment_method: $.allowNull(
                          $.objectWithFields({
                            gateway: $.allowNull($.string()),
                            name: $.allowNull($.string()),
                            type: $.allowNull($.string()),
                          }),
                        ),
                      }),
                    );
                  return d == null
                    ? r
                    : (d.order_id != null && (r.order_id = d.order_id),
                      u &&
                        d.payment_method != null &&
                        (r.payment_method = d.payment_method),
                      n === "Search"
                        ? (c &&
                            d.contents != null &&
                            d.contents.length > 0 &&
                            (r.contents = d.contents),
                          r)
                        : (s
                            ? d.contents != null &&
                              d.contents.length > 0 &&
                              (r.contents = d.contents)
                            : l &&
                              ((r.content_ids = d.product_variant_ids),
                              (r.content_type = d.content_type_favor_variant)),
                          r));
                } catch (e) {
                  return (
                    (e.message = "[Shopify]: ".concat(e.message)),
                    _e(e),
                    r
                  );
                }
              }
              function je(e, t) {
                var n = Date.now().toString();
                Ze({ customData: t, eventName: e, experimentId: n });
              }
              function Ke(e, t, n) {
                Le.forEach(function (n) {
                  var r = Date.now().toString();
                  Ze({
                    customData: t,
                    eventName: e,
                    pixel: n,
                    experimentId: r,
                  });
                });
              }
              function Qe(e) {
                var t = e.toLowerCase().trim(),
                  n = t.endsWith("@icloud.com"),
                  r = t.endsWith("@privaterelay.appleid.com");
                if (n) return 2;
                if (r) return 1;
              }
              function Xe(e, t, n, r, o, i) {
                var l = new u(a.piiTranslator);
                i != null && (l = i);
                try {
                  var c = (e && e.userData) || {},
                    d = (e && e.censoredUserDataFormat) || {},
                    m = (e && e.censoredUserDataFormatFormFields) || {},
                    p = (e && e.userDataFormFields) || {},
                    _ = (e && e.alternateUserDataFormFields) || {},
                    f = (e && e.alternateUserData) || {},
                    g,
                    h = {},
                    y = {},
                    C = c.em;
                  C != null && Qe(C) && ((g = Qe(C)), g === 1 && (h.em = ye));
                  var b = p.em;
                  b != null && Qe(b) && ((g = Qe(b)), g === 1 && (y.em = ye));
                  var v = {},
                    S = f.em;
                  S != null && Qe(S) && ((g = Qe(S)), g === 1 && (v.em = ye));
                  var R = {},
                    L = _.em;
                  (L != null && Qe(L) && ((g = Qe(L)), g === 1 && (R.em = ye)),
                    g != null && l.append("ped", g),
                    d != {} && l.append("cud", d),
                    m != {} && l.append("cudff", m),
                    l.append("ud", s(s({}, c), h), !0),
                    l.append("aud", s(s({}, f), v), !0),
                    l.append("udff", s(s({}, p), y), !0),
                    l.append("audff", s(s({}, _), R), !0));
                } catch (t) {
                  Y.trigger(e);
                }
                (l.append("v", a.version),
                  a._releaseSegment && l.append("r", a._releaseSegment),
                  l.append("a", e && e.agent ? e.agent : a.agent),
                  e && (l.append("ec", e.eventCount), e.eventCount++));
                var E = Q.trigger(e, t, n, r, o);
                (W(E, function (t) {
                  return W(G(t), function (n) {
                    if (l.containsKey(n)) {
                      if (!xe.has(n))
                        if (n === "bfs" && V(t[n]) && V(l.get(n))) {
                          var r = l.get(n),
                            o = s(s({}, r), t[n]);
                          l.replaceEntry(n, o);
                        } else {
                          var a = ue.isInMetaQEControl(
                            e == null ? void 0 : e.id,
                          );
                          if (a)
                            throw new Error(
                              "Custom parameter ".concat(
                                n,
                                " has already been specified.",
                              ),
                            );
                          var i = l.get(n),
                            u = t != null ? t[n] : null;
                          (B(
                            i === u
                              ? new Error(
                                  "[SignalsFBEvents] ".concat(
                                    n,
                                    " param is the same as the existing value.",
                                  ),
                                )
                              : new Error(
                                  "[SignalsFBEvents] ".concat(
                                    n,
                                    " param is different from the existing value.",
                                  ),
                                ),
                            $e,
                            Pe,
                          ),
                            l.replaceEntry(n, u != null ? u : i),
                            !l.containsKey("ie[c]") &&
                              !l.containsKey("ie%5Bc%5D") &&
                              l.append("ie[c]", 1));
                        }
                      t &&
                        (Ye(n, t[n]) || Je(n, t[n])) &&
                        l.replaceEntry(n, t[n]);
                    } else l.append(n, t[n]);
                  });
                }),
                  l.append("it", he));
                var k = e && e.codeless === "false";
                l.append("coo", k);
                var I = Te.pluginConfig.getWithGlobalFallback(
                  e ? e.id : null,
                  "dataProcessingOptions",
                );
                if (I != null) {
                  var T = I.dataProcessingCountry,
                    D = I.dataProcessingOptions,
                    x = I.dataProcessingState;
                  (l.append("dpo", D.join(",")),
                    l.append("dpoco", T),
                    l.append("dpost", x));
                }
                var $ = Te.pluginConfig.getWithGlobalFallback(
                  e ? e.id : null,
                  "disabledExtensions",
                );
                if ($ != null) {
                  var P = $.disabledExtensions;
                  l.append("de", P.join(","));
                }
                return l;
              }
              function Ye(e, t) {
                return (
                  (e === "eid" || e === "eid%5B%5D") &&
                  t &&
                  typeof t == "string" &&
                  z(t, "ob3_plugin-set")
                );
              }
              function Je(e, t) {
                return (
                  (e === "eid" || e === "eid%5B%5D") &&
                  t &&
                  typeof t == "string" &&
                  z(t, "sgwpixel_plugin-set")
                );
              }
              function Ze(e) {
                var r = e.customData,
                  o = e.eventData,
                  a = e.eventName,
                  i = e.pixel,
                  l = e.additionalCustomParams,
                  s = e.experimentId;
                if (((r = r || {}), i != null && S.pixelHasActiveBridge(i))) {
                  S.sendEvent(i, a, r);
                  return;
                }
                var u = Xe(i, a, r, void 0, o, l);
                (y(o, r, u, i == null ? void 0 : i.id),
                  w.trigger({
                    pixelID: i ? i.id : null,
                    eventName: a,
                    customData: r,
                    eventData: o,
                    eventId: u.getEventId(),
                  }));
                var c = Z.trigger(i, r, a);
                W(c, function (e) {
                  e != null &&
                    W(G(e), function (t) {
                      t != null && u.append(t, e[t]);
                    });
                });
                var m = n.href,
                  p = t.referrer,
                  _ = {};
                (m != null && (_.dl = m),
                  p != null && (_.rl = p),
                  U(_) || ee.trigger(i, _, a, u),
                  d(
                    {
                      customData: r,
                      customParams: u,
                      eventName: a,
                      id: i ? i.id : null,
                      piiTranslator: null,
                      documentLink: _.dl ? _.dl : "",
                      referrerLink: _.rl ? _.rl : "",
                      eventData: o,
                      experimentId: s,
                    },
                    Te,
                  ));
              }
              function et() {
                for (; e.fbq.queue && e.fbq.queue.length && !ge.isLocked(); ) {
                  var t = e.fbq.queue.shift();
                  Ae.apply(e.fbq, t);
                }
              }
              (ge.onUnlocked(function () {
                et();
              }),
                a.pixelId && ((Se = !0), Oe(a.pixelId)),
                ((Se && Re) || e.fbq !== e._fbq) &&
                  fe({ type: "CONFLICTING_VERSIONS" }),
                Le.length > 1 && fe({ type: "MULTIPLE_PIXELS" }));
              function tt() {
                if (
                  a.disablePushState !== !0 &&
                  !(!r.pushState || !r.replaceState)
                ) {
                  var t = L(function () {
                    if ((re.trigger(), (ke = ve), (ve = n.href), ve !== ke)) {
                      var e = new Me({
                        allowDuplicatePageViews: !0,
                        isAutomaticPageView: !0,
                      });
                      we.call(e, "trackCustom", "PageView");
                    }
                  });
                  (R(r, "pushState", t),
                    R(r, "replaceState", t),
                    e.addEventListener("popstate", t, !1));
                }
              }
              function nt() {
                "onpageshow" in e &&
                  e.addEventListener("pageshow", function (e) {
                    if (e.persisted) {
                      re.trigger();
                      var t = new Me({
                        allowDuplicatePageViews: !0,
                        isAutomaticPageView: !0,
                      });
                      we.call(t, "trackCustom", "PageView");
                    }
                  });
              }
              K.listenOnce(function () {
                (tt(), nt());
              });
              function rt(e) {
                (a._initHandlers.push(e), Be());
              }
              function ot() {
                return { pixelInitializationTime: he, pixels: Le };
              }
              function at(e) {
                ((e.instance = Te),
                  (e.callMethod = we),
                  (e._initHandlers = []),
                  (e._initsDone = {}),
                  (e.send = Ke),
                  (e.getEventCustomParameters = Xe),
                  (e.addInitHandler = rt),
                  (e.getState = ot),
                  (e.init = Oe),
                  (e.set = Fe),
                  (e.loadPlugin = function (e) {
                    return De.loadPlugin(e);
                  }),
                  (e.registerPlugin = function (e, t) {
                    De.registerPlugin(e, t);
                  }));
              }
              (at(e.fbq),
                me(e.fbq.queue),
                et(),
                (o.exports = { doExport: at }),
                j.trigger());
            })(),
            o.exports
          );
        })(e, t, n, r);
      }),
      (o.exports = a.getFbeventsModules("SignalsFBEvents")),
      a.registerPlugin && a.registerPlugin("fbevents", o.exports),
      a.ensureModuleRegistered("fbevents", function () {
        return o.exports;
      }));
  })();
})(window, document, location, history);
fbq.registerPlugin("global_config", {
  __fbEventsPlugin: 1,
  plugin: function (fbq, instance, config) {
    fbq.loadPlugin("commonincludes");
    fbq.loadPlugin("identity");
    fbq.loadPlugin("privacysandbox");
    fbq.loadPlugin("opttracking");
    fbq.set("experiments", [
      { allocation: 0.01, code: "c", name: "no_op_exp", passRate: 0.5 },
      { allocation: 0, code: "d", name: "config_dedupe", passRate: 1 },
      {
        allocation: 0,
        code: "e",
        name: "send_fbc_when_no_cookie",
        passRate: 1,
      },
      { allocation: 0, code: "f", name: "send_events_in_batch", passRate: 0 },
      {
        allocation: 0,
        code: "h",
        name: "set_fbc_cookie_after_config_load",
        passRate: 0,
      },
      {
        allocation: 0,
        code: "i",
        name: "prioritize_send_beacon_in_url",
        passRate: 0.5,
      },
      { allocation: 0, code: "j", name: "fix_fbc_fbp_update", passRate: 0 },
      { allocation: 0, code: "l", name: "async_param_refactor", passRate: 0.5 },
      {
        allocation: 0.01,
        code: "m",
        name: "sync_process_event",
        passRate: 0.5,
      },
      {
        allocation: 0.04,
        code: "s",
        name: "fix_null_context_passed",
        passRate: 0.5,
      },
    ]);
    fbq.set("guardrails", [
      {
        name: "no_op",
        code: "a",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "extract_extra_microdata",
        code: "b",
        passRate: 0,
        enableForPixels: [],
      },
      {
        name: "sgw_auto_extract",
        code: "c",
        passRate: 1,
        enableForPixels: ["1296510287734738", "337570375319394"],
      },
      {
        name: "multi_eid_fix",
        code: "d",
        passRate: 0,
        enableForPixels: ["909978539160024"],
      },
      {
        name: "use_async_param_refactor",
        code: "f",
        passRate: 1,
        enableForPixels: ["3421688111417438"],
      },
      {
        name: "process_pii_from_shopify",
        code: "h",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "send_censored_ph",
        code: "f",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "send_censored_em",
        code: "g",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "fix_fbevent_uri_error",
        code: "j",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "send_normalized_ud_format",
        code: "e",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "enable_automatic_parameter_logging",
        code: "i",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "release_spa_pageview_fix",
        code: "l",
        passRate: 1,
        enableForPixels: ["569835061642423"],
      },
      {
        name: "fix_duplicate_opt_tracking_param",
        code: "m",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "release_fix_null_context_passed",
        code: "n",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "reset_init_time_on_spa_page_change",
        code: "o",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "fix_missing_event_name_error",
        code: "p",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "use_string_prefix_match_from_util",
        code: "q",
        passRate: 1,
        enableForPixels: [],
      },
      {
        name: "get_keywords_from_local_storage",
        code: "r",
        passRate: 0,
        enableForPixels: [
          "569835061642423",
          "1728810767262484",
          "197307666770807",
          "568414510204424",
        ],
      },
      {
        name: "bot_blocking_client_side_block_enabled",
        code: "s",
        passRate: 1,
        enableForPixels: ["1306783967701444"],
      },
      {
        name: "page_locale_metadata_enabled",
        code: "t",
        passRate: 0,
        enableForPixels: ["1728810767262484"],
      },
    ]);
    fbq.set("moduleEncodings", {
      map: {
        generateEventId: 0,
        handleEventIdOverride: 1,
        normalizeSignalsFBEventsDOBType: 2,
        normalizeSignalsFBEventsEmailType: 3,
        normalizeSignalsFBEventsEnumType: 4,
        normalizeSignalsFBEventsPhoneNumberType: 5,
        normalizeSignalsFBEventsPostalCodeType: 6,
        normalizeSignalsFBEventsStringType: 7,
        PixelQueue: 8,
        SignalsConvertNodeToHTMLElement: 9,
        SignalsEventPayload: 10,
        SignalsEventValidation: 11,
        SignalsFBEventsAddGmailSuffixToEmail: 12,
        SignalsFBEventsAsyncParamUtils: 13,
        SignalsFBEventsAutomaticPageViewEvent: 14,
        SignalsFBEventsBaseEvent: 15,
        SignalsFBEventsBotBlockingConfigTypedef: 16,
        SignalsFBEventsBrowserPropertiesConfigTypedef: 17,
        SignalsFBEventsBufferConfigTypedef: 18,
        SignalsFBEventsCCRuleEvaluatorConfigTypedef: 19,
        SignalsFBEventsCensor: 20,
        SignalsFBEventsClientHintConfigTypedef: 21,
        SignalsFBEventsClientSidePixelForkingConfigTypedef: 22,
        signalsFBEventsCoerceAutomaticMatchingConfig: 23,
        signalsFBEventsCoerceBatchingConfig: 24,
        signalsFBEventsCoerceInferedEventsConfig: 25,
        signalsFBEventsCoerceParameterExtractors: 26,
        signalsFBEventsCoercePixelID: 27,
        signalsFBEventsCoerceStandardParameter: 28,
        SignalsFBEventsConfigLoadedEvent: 29,
        SignalsFBEventsConfigStore: 30,
        SignalsFBEventsCookieConfigTypedef: 31,
        SignalsFBEventsCookieDeprecationLabelConfigTypedef: 32,
        SignalsFBEventsCorrectPIIPlacement: 33,
        SignalsFBEventsDataProcessingOptionsConfigTypedef: 34,
        SignalsFBEventsDefaultCustomDataConfigTypedef: 35,
        SignalsFBEventsDisabledExtensionsConfigTypedef: 36,
        signalsFBEventsDoAutomaticMatching: 37,
        SignalsFBEventsESTRuleEngineConfigTypedef: 38,
        SignalsFBEventsEvents: 39,
        SignalsFBEventsEventValidationConfigTypedef: 40,
        SignalsFBEventsExperimentNames: 41,
        SignalsFBEventsExperimentsTypedef: 42,
        SignalsFBEventsExperimentsV2Typedef: 43,
        SignalsFBEventsExtractPII: 44,
        SignalsFBEventsFBQ: 45,
        signalsFBEventsFeatureGate: 46,
        signalsFBEventsFillParamList: 47,
        SignalsFBEventsFilterProtectedModeEvent: 48,
        SignalsFBEventsFiredEvent: 49,
        signalsFBEventsFireEvent: 50,
        SignalsFBEventsFireLock: 51,
        SignalsFBEventsForkEvent: 52,
        SignalsFBEventsGatingConfigTypedef: 53,
        SignalsFBEventsGetAutomaticParametersEvent: 54,
        SignalsFBEventsGetCustomParametersEvent: 55,
        signalsFBEventsGetIsChrome: 56,
        signalsFBEventsGetIsIosInAppBrowser: 57,
        SignalsFBEventsGetIWLParametersEvent: 58,
        SignalsFBEventsGetTimingsEvent: 59,
        SignalsFBEventsGetValidUrl: 60,
        SignalsFBEventsGoogleAnalyticsBridgeConfigTypedef: 61,
        SignalsFBEventsGuardrail: 62,
        SignalsFBEventsGuardrailTypedef: 63,
        SignalsFBEventsIABPCMAEBridgeConfigTypedef: 64,
        SignalsFBEventsImagePixelOpenBridgeConfigTypedef: 65,
        signalsFBEventsInjectMethod: 66,
        signalsFBEventsIsHostMeta: 67,
        signalsFBEventsIsURLFromMeta: 68,
        SignalsFBEventsIWLBootStrapEvent: 69,
        SignalsFBEventsJSLoader: 70,
        SignalsFBEventsLateValidateCustomParametersEvent: 71,
        SignalsFBEventsLegacyExperimentGroupsTypedef: 72,
        SignalsFBEventsLogging: 73,
        signalsFBEventsMakeSafe: 74,
        SignalsFBEventsMessageParamsTypedef: 75,
        SignalsFBEventsMetaQEConfigTypedef: 76,
        SignalsFBEventsMicrodataConfigTypedef: 77,
        SignalsFBEventsMobileAppBridge: 78,
        SignalsFBEventsModuleEncodings: 79,
        SignalsFBEventsModuleEncodingsTypedef: 80,
        SignalsFBEventsNetworkConfig: 81,
        SignalsFBEventsNormalizers: 82,
        SignalsFBEventsOpenBridgeConfigTypedef: 83,
        SignalsFBEventsOptIn: 84,
        SignalsFBEventsPageStatusEvent: 85,
        SignalsFBEventsPageStatusMonitor: 86,
        SignalsFBEventsParallelFireConfigTypedef: 87,
        SignalsFBEventsPIIAutomatchedEvent: 88,
        SignalsFBEventsPIIConflictingEvent: 89,
        SignalsFBEventsPIIInvalidatedEvent: 90,
        SignalsFBEventsPixelCookie: 91,
        SignalsFBEventsPixelPIISchema: 92,
        SignalsFBEventsPixelQueueState: 93,
        SignalsFBEventsPixelTypedef: 94,
        SignalsFBEventsPlugin: 95,
        SignalsFBEventsPluginLoadedEvent: 96,
        SignalsFBEventsPluginManager: 97,
        SignalsFBEventsProcessCCRulesEvent: 98,
        SignalsFBEventsProcessEmailAddress: 99,
        SignalsFBEventsProhibitedPixelConfigTypedef: 100,
        SignalsFBEventsProhibitedSourcesTypedef: 101,
        SignalsFBEventsProtectedDataModeConfigTypedef: 102,
        SignalsFBEventsQE: 103,
        SignalsFBEventsQEV2: 104,
        SignalsFBEventsQualityCheckerConfigTypedef: 105,
        signalsFBEventsResolveLegacyArguments: 106,
        SignalsFBEventsResolveLink: 107,
        SignalsFBEventsRestrictedDomainsConfigTypedef: 108,
        signalsFBEventsSendBeacon: 109,
        SignalsFBEventsSendCloudbridgeEvent: 110,
        signalsFBEventsSendEvent: 111,
        SignalsFBEventsSendEventEvent: 112,
        signalsFBEventsSendEventImpl: 113,
        signalsFBEventsSendFetch: 114,
        signalsFBEventsSendFormPOST: 115,
        signalsFBEventsSendGET: 116,
        SignalsFBEventsSetCCRules: 117,
        SignalsFBEventsSetESTRules: 118,
        SignalsFBEventsSetEventIDEvent: 119,
        SignalsFBEventsSetFilteredEventName: 120,
        SignalsFBEventsSetIWLExtractorsEvent: 121,
        SignalsFBEventsShared: 122,
        SignalsFBEventsShouldRestrictReferrerEvent: 123,
        SignalsFBEventsStandardParamChecksConfigTypedef: 124,
        SignalsFBEventsTelemetry: 125,
        SignalsFBEventsTrackEventEvent: 126,
        SignalsFBEventsTriggerSgwPixelTrackCommandConfigTypedef: 127,
        SignalsFBEventsTyped: 128,
        SignalsFBEventsTypeVersioning: 129,
        SignalsFBEventsUnwantedDataTypedef: 130,
        SignalsFBEventsUnwantedEventNamesConfigTypedef: 131,
        SignalsFBEventsUnwantedEventsConfigTypedef: 132,
        SignalsFBEventsUnwantedParamsConfigTypedef: 133,
        SignalsFBEventsURLMetadataConfigTypedef: 134,
        SignalsFBEventsUtils: 135,
        SignalsFBEventsValidateCustomParametersEvent: 136,
        SignalsFBEventsValidateGetClickIDFromBrowserProperties: 137,
        SignalsFBEventsValidateUrlParametersEvent: 138,
        SignalsFBEventsValidationUtils: 139,
        SignalsFBEventsWebchatConfigTypedef: 140,
        SignalsFBEventsWebChatEvent: 141,
        SignalsParamList: 142,
        SignalsPixelCookieUtils: 143,
        SignalsPixelPIIConstants: 144,
        SignalsPixelPIIUtils: 145,
        WebStorage: 146,
        WebStorageMutex: 147,
        SignalsFBEvents: 148,
        "SignalsFBEvents.plugins.automaticparameters": 149,
        "[object Object]": 150,
        "SignalsFBEvents.plugins.botblocking": 151,
        "SignalsFBEvents.plugins.browserproperties": 152,
        "SignalsFBEvents.plugins.browserpropertiesplatform": 153,
        "SignalsFBEvents.plugins.buffer": 154,
        "SignalsFBEvents.plugins.ccruleevaluator": 155,
        "SignalsFBEvents.plugins.clienthint": 156,
        "SignalsFBEvents.plugins.clientsidepixelforking": 157,
        "SignalsFBEvents.plugins.commonincludes": 158,
        "SignalsFBEvents.plugins.cookie": 159,
        "SignalsFBEvents.plugins.cookiedeprecationlabel": 160,
        "SignalsFBEvents.plugins.debug": 161,
        "SignalsFBEvents.plugins.defaultcustomdata": 162,
        "SignalsFBEvents.plugins.engagementdata": 163,
        "SignalsFBEvents.plugins.estruleengine": 164,
        "SignalsFBEvents.plugins.eventvalidation": 165,
        "SignalsFBEvents.plugins.gating": 166,
        "SignalsFBEvents.plugins.googleanalyticsbridge": 167,
        "SignalsFBEvents.plugins.iabpcmaebridge": 168,
        "SignalsFBEvents.plugins.identifyintegration": 169,
        "SignalsFBEvents.plugins.identity": 170,
        "SignalsFBEvents.plugins.imagepixelopenbridge": 171,
        "SignalsFBEvents.plugins.inferredevents": 172,
        "SignalsFBEvents.plugins.iwlbootstrapper": 173,
        "SignalsFBEvents.plugins.iwlparameters": 174,
        "SignalsFBEvents.plugins.jsonld_microdata": 175,
        "SignalsFBEvents.plugins.lastexternalreferrer": 176,
        "SignalsFBEvents.plugins.microdata": 177,
        "SignalsFBEvents.plugins.openbridge3": 178,
        "SignalsFBEvents.plugins.openbridgerollout": 179,
        "SignalsFBEvents.plugins.opttracking": 180,
        "SignalsFBEvents.plugins.pagemetadata": 181,
        "SignalsFBEvents.plugins.parallelfire": 182,
        "SignalsFBEvents.plugins.performance": 183,
        "SignalsFBEvents.plugins.privacypreservingdatalookup": 184,
        "SignalsFBEvents.plugins.privacysandbox": 185,
        "SignalsFBEvents.plugins.prohibitedpixels": 186,
        "SignalsFBEvents.plugins.prohibitedsources": 187,
        "SignalsFBEvents.plugins.protecteddatamode": 188,
        "SignalsFBEvents.plugins.scrolldepth": 189,
        "SignalsFBEvents.plugins.shopifyappintegratedpixel": 190,
        "SignalsFBEvents.plugins.standardparamchecks": 191,
        "SignalsFBEvents.plugins.timespent": 192,
        "SignalsFBEvents.plugins.topicsapi": 193,
        "SignalsFBEvents.plugins.triggersgwpixeltrackcommand": 194,
        "SignalsFBEvents.plugins.unwanteddata": 195,
        "SignalsFBEvents.plugins.unwantedeventnames": 196,
        "SignalsFBEvents.plugins.unwantedevents": 197,
        "SignalsFBEvents.plugins.unwantedparams": 198,
        "SignalsFBEvents.plugins.urlmetadata": 199,
        "SignalsFBEvents.plugins.urlparamschematization": 200,
        "SignalsFBEvents.plugins.webchat": 201,
        "SignalsFBEvents.plugins.webpagecontentextractor": 202,
        "SignalsFBEvents.plugins.websiteperformance": 203,
        SignalsFBEventsTimespentTracking: 204,
        "SignalsFBevents.plugins.automaticmatchingforpartnerintegrations": 205,
        cbsdk_fbevents_embed: 206,
        SignalsFBEventsBlockFlags: 207,
        SignalsFBEventsCCRuleEngine: 208,
        SignalsFBEventsESTCustomData: 209,
        SignalsFBEventsEnums: 210,
        SignalsFBEventsFbcCombiner: 211,
        SignalsFBEventsFormFieldFeaturesType: 212,
        SignalsFBEventsGetIsAndroidChrome: 213,
        SignalsFBEventsLocalStorageUtils: 214,
        SignalsFBEventsOptTrackingOptions: 215,
        SignalsFBEventsPerformanceTiming: 216,
        SignalsFBEventsProxyState: 217,
        SignalsFBEventsTransformToCCInput: 218,
        SignalsFBEventsTypes: 219,
        SignalsFBEventsURLMetadataUtils: 220,
        SignalsFBEventsURLUtil: 221,
        SignalsFBEventsWildcardMatches: 222,
        SignalsInteractionUtil: 223,
        SignalsPageVisibilityUtil: 224,
        SignalsPixelClientSideForkingUtils: 225,
        sha256_with_dependencies_new: 226,
        signalsFBEventsExtractMicrodataSchemas: 227,
        signalsFBEventsGetIsAndroid: 228,
        signalsFBEventsGetIsAndroidIAW: 229,
        signalsFBEventsGetIsChromeInclIOS: 230,
        signalsFBEventsGetIsSafariOrMobileSafari: 231,
        signalsFBEventsGetIsWebview: 232,
        signalsFBEventsGetIwlUrl: 233,
        signalsFBEventsGetTier: 234,
        signalsFBEventsIsHostFacebook: 235,
        signalsFBEventsMakeSafeString: 236,
        signalsFBEventsShouldNotDropCookie: 237,
        loadBaseCode: 238,
        SignalsFBEventsAutomaticEventsTypes: 239,
        SignalsFBEventsFeatureCounter: 240,
        SignalsFBEventsThrottler: 241,
        signalsFBEventsCollapseUserData: 242,
        signalsFBEventsElementDoesMatch: 243,
        signalsFBEventsExtractButtonFeatures: 244,
        signalsFBEventsExtractEventPayload: 245,
        signalsFBEventsExtractForm: 246,
        signalsFBEventsExtractFormFieldFeatures: 247,
        signalsFBEventsExtractFromInputs: 248,
        signalsFBEventsExtractPageFeatures: 249,
        signalsFBEventsGetTruncatedButtonText: 250,
        signalsFBEventsGetWrappingButton: 251,
        signalsFBEventsIsIWLElement: 252,
        signalsFBEventsIsSaneAndNotDisabledButton: 253,
        SignalsFBEventsBotDetectionEngine: 254,
        "babel.config": 255,
        SignalsFBEventsConfigTypes: 256,
        SignalsFBEventsForkCbsdkEvent: 257,
        getDeepStackTrace: 258,
        getIntegrationCandidates: 259,
        SignalsFBEventsBuildMicrodata: 260,
        SignalsFBEventsExtractMicrodataFromJsonLdV2: 261,
        SignalsFBEventsExtractMicrodataFromOpenGraphV2: 262,
        SignalsFBEventsExtractMicrodataFromSchemaOrgV2: 263,
        SignalsFBEventsExtractMicrodataUtils: 264,
        SignalsFBEventsMicrodata: 265,
        SignalsFBEventsProcessMicrodata: 266,
        signalsFBEventsSendXHR: 267,
        ExperimentUtil: 268,
        OpenBridgeConnection: 269,
        OpenBridgeFBLogin: 270,
        ResolveLinks: 271,
        openBridgeDomainFilter: 272,
        openBridgeUserDataUtils: 273,
        PdlWasm: 274,
        PdlWasmTypes: 275,
        WebPDL: 276,
        WebPDLUtility: 277,
        pdl: 278,
        topics_api_utility_lib: 279,
        analytics_debug: 280,
        analytics_ecommerce: 281,
        analytics_enhanced_ecommerce: 282,
        analytics_enhanced_link_attribution: 283,
        analytics_release: 284,
        proxy_polyfill: 285,
        SignalsFBEventsBrowserPropertiesTypedef: 286,
        SignalsFBEventsClientHintTypedef: 287,
        SignalsFBEventsESTRuleConditionTypedef: 288,
        SignalsFBEventsLocalStorageTypedef: 289,
        URLSchematization: 290,
        fbevents_embed: 291,
        AllowableQueryBucketizedValues: 292,
        AllowableQueryKeys: 293,
        AllowableQueryValues: 294,
        EnumExtractor: 295,
        FBIDsExtractor: 296,
        AllowedRegexParameterValue: 297,
        AllowedURLParameterValue: 298,
        BucketedURLParameterValue: 299,
        IURLParameterValue: 300,
        UtmIdFetcher: 301,
        FBIDValidator: 302,
        URLParameterConfig: 303,
        URLSchematizer: 304,
      },
      hash: "20296eac3bb30511174edf43e83f1c9e303df926d3c833283a366d6f5480f82a",
    });
    config.set(null, "batching", { batchWaitTimeMs: 10, maxBatchSize: 10 });
    config.set(null, "microdata", { waitTimeMs: 500 });
    fbq.set("experimentsV2", [
      {
        allocation: 1,
        code: "pl",
        name: "page_load_level_no_op_experiment",
        passRate: 0.5,
        universe: "page_load_level_no_op_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "el",
        name: "event_level_no_op_experiment",
        passRate: 0.5,
        universe: "event_level_no_op_universe",
        evaluationType: "EVENT_LEVEL",
      },
      {
        allocation: 1,
        code: "bc",
        name: "button_click_optimize_experiment_v2",
        passRate: 1,
        universe: "button_click_experiment_universe",
        evaluationType: "EVENT_LEVEL",
      },
      {
        allocation: 0,
        code: "se",
        name: "process_additional_shopify_events",
        passRate: 0,
        universe: "shopify_events_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "ra",
        name: "microdata_refactor_migration_automatic_parameters",
        passRate: 0,
        universe: "microdata_refactor_migration_automatic_parameters",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "rp",
        name: "microdata_refactor_migration_page_meta_data",
        passRate: 0,
        universe: "microdata_refactor_migration_page_meta_data",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.5,
        code: "ct",
        name: "cookie_ttl_fix",
        passRate: 0.5,
        universe: "cookie_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.5,
        code: "im",
        name: "in_memory_cookie_jar",
        passRate: 0.5,
        universe: "cookie_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 1,
        code: "hf",
        name: "high_fetch_priority_image",
        passRate: 0.5,
        universe: "high_fetch_priority_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0,
        code: "zz",
        name: "meta_qe",
        passRate: 0,
        universe: "qe_universe",
        evaluationType: "PAGE_LOAD_LEVEL",
      },
      {
        allocation: 0.05,
        code: "pt",
        name: "page_title_og_fallback",
        passRate: 0.5,
        universe: "page_title_og_fallback_universe",
        evaluationType: "EVENT_LEVEL",
      },
    ]);
    instance.configLoaded("global_config");
  },
});
