﻿var siteURL = SiteUrl();

$(document).ready(function (e) {
  $.ajaxSetup({ cache: false });
  $("#ccn1").focus();
  $("#btnCheckBalance").click(function (e) {
    var no1 = $("#ccn1").val();
    var no2 = $("#ccn2").val();
    var no3 = $("#ccn3").val();
    var no4 = $("#ccn4").val();

    var mobileno1 = $("#MobileNo1").val();
    var mobileno = $("#MobileNo").val();

    if (no1 == "" || no2 == "" || no3 == "" || no4 == "") {
      $("#spnShowCardNoMessage").html("Please Enter Card Number.");
      return false;
    } else {
      if (
        no1.length < 4 ||
        no2.length < 4 ||
        no3.length < 4 ||
        no4.length < 4
      ) {
        $("#spnShowCardNoMessage").html("Please Enter Proper Card Number.");
        return false;
      } else {
        $("#spnShowCardNoMessage").html("");
      }
    }

    $("#transtable1").html("");
    $("#transtable2").html("");

    $("#dvWrapper").show();
    $("#dvTable").show();
    // return false;
    $.ajax({
      cache: false,
      url: siteURL + "/Login/GetUserGiftCardBalance",
      type: "post",
      dataType: "json",
      data: {
        cardNumber: no1 + no2 + no3 + no4,
        //ROneCardNo1: no1,
        //ROneCardNo2: no2,
        //ROneCardNo3: no3,
        //ROneCardNo4: no4,
        //MobileNo: mobileno,
        //MobileNo1: mobileno1
      },
      error: function () {
        window.location.href = siteURL + "/User/Logout";
      },
      success: function (data) {
        $("#dvWrapper").hide();
        $("#dvTable").hide();
        //alert(data);
        //alert(data.Errormsg);
        //console.log(data);
        // console.log(data.ErrorMessage.indexOf("Success"))
        if (data != "" && data.Errormsg != "") {
          if (data.Errormsg != "null" || data.Errormsg != "undefined") {
            // if (data.ErrorMessage != '') {

            if (data.Errormsg.indexOf("SUCCESS") > -1) {
              //$("#ccn1").attr("readonly", "readonly");
              //$("#ccn2").attr("readonly", "readonly");
              //$("#ccn3").attr("readonly", "readonly");
              //$("#ccn4").attr("readonly", "readonly");

              //$("#ccn1").attr('disabled', 'disabled');
              //$("#ccn2").attr('disabled', 'disabled');
              //$("#ccn3").attr('disabled', 'disabled');
              //$("#ccn4").attr('disabled', 'disabled');

              if (data.CardStatus == "INACTIVE") {
                $("#spnValidateMessage").html(
                  "The Validity period for your gift card has elapsed. The gift card will no longer be in use.",
                );
                return false;
              }

              $("#spnValidateMessage").html("");
              var currentBalanceAsOn = data.CurrentBalanceAsOn;
              if (
                currentBalanceAsOn == null ||
                currentBalanceAsOn == "null" ||
                currentBalanceAsOn == ""
              ) {
                currentBalanceAsOn = "-";
              }

              var divTransactionData = document.getElementById("transtable1");
              var transTable = "<table><thead>";
              transTable += "<tr>";
              transTable += "<th width='20%'>Card Number</th>";
              transTable += "<th width='15%'>Total Amount</th>";
              transTable += "<th width='15%'>Current Balance</th>";
              transTable += "<th width='15%'>Amount Used</th>";
              //transTable += "<th width='20%'>Current Balance as On</th>"; // As discussed with Sunil, hide it.
              transTable += "<th width='15%'>Card Status</th>";
              transTable += "</tr>";
              transTable += "</thead>";
              transTable += "<tbody>";
              transTable += "<tr>";
              transTable += "<td>" + data.CardNumber + "</td>";
              transTable += "<td>" + data.TotalAmountLoaded + "</td>";
              transTable += "<td>" + data.TotalAmountRemaining + "</td>";
              transTable += "<td>" + data.TotalAmountSpent + "</td>";
              //transTable += "<td>" + currentBalanceAsOn + "</td>";
              transTable += "<td>" + data.CardStatus + "</td>";
              transTable += "</tr>";
              transTable += "</tbody>";
              transTable += "</table>";

              //if (data.BalanceTransactionList == null || data.BalanceTransactionList == "") {
              //    transTable += "<tr><td colspan='5'>Sorry, no data found!</td></tr>";
              //}

              $("#transtable1").html(transTable);

              /***Table 2**/

              var divTransactionData1 = document.getElementById("transtable2");
              var transTable1 = "<table><thead>";
              transTable1 += "<tr>";
              transTable1 += "<th width='25%'>Transaction Type</th>";
              //transTable += "<th width='15%'>Invoice Number</th>";
              transTable1 += "<th width='15%'>Store Code/Name</th>";
              transTable1 += "<th width='15%'>Amount Spent</th>";
              transTable1 += "<th width='20%'>Transaction Date & Time</th>";
              transTable1 += "</tr>";
              transTable1 += "</thead>";
              transTable1 += "<tbody>";

              if (data.BalanceTransactionList != null) {
                for (i = 0; i < data.BalanceTransactionList.length; i++) {
                  transTable1 += "<tr>";
                  transTable1 +=
                    "<td>" + data.BalanceTransactionList[i].TransType + "</td>";
                  transTable1 +=
                    "<td>" + data.BalanceTransactionList[i].Store + "</td>";
                  transTable1 +=
                    "<td>" + data.BalanceTransactionList[i].Amount + "</td>";
                  transTable1 +=
                    "<td>" +
                    data.BalanceTransactionList[i].TxnDaTeTime +
                    "</td>";
                  transTable1 += "</tr>";
                }
              }

              if (
                data.BalanceTransactionList == null ||
                data.BalanceTransactionList == ""
              ) {
                transTable +=
                  "<tr><td colspan='5'>Sorry, no data found!</td></tr>";
              }

              transTable1 += "</tbody></table>";
              $("#transtable2").html(transTable1);

              $("#transtable1").show("slow");
              $("#transtable2").show("slow");
            } else {
              $("#spnValidateMessage").html("No Data found.");
            }
          } else {
            $("#spnValidateMessage").html("No Data found.");
          }
        } else {
          $("#spnValidateMessage").html("No Data found.");
        }

        $("html, body").animate(
          {
            scrollTop: $("#headingGiftCardBalanceCheck").offset().top,
          },
          2000,
        );
      },
    });
  });
});
